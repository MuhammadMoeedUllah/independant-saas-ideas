# SaaS Replacement Opportunities: start here

Research completed Sep 25 2026. The folder holds **106 app ideas**, including a books, readers & parent-child education domain (section 6), (`ideas/`), **51 state market files** covering all 50 states plus DC (`states/`), and a sortable master ranking (`SaaS_Opportunities_Master.xlsx`).

Every idea file has the same layout:
- the incumbents' current prices and dated price hikes
- 6–12 real complaints, each paraphrased with a link
- a numbered feature list split into MVP and V2
- a price that undercuts the incumbent
- a go-to-market plan for the first 100 customers
- risks, and a 25-point score

Each state file lists:
- the laws and deadlines that force a software purchase
- the top 7 ideas to launch there
- state-only ideas
- where to sell: associations, events and online groups
- which city to launch in first

**Scores (each 1–5, total out of 25):** Pain, Price gap, Build ease, Sales speed, Market size. **Priority** adds 0.1 point for each state that ranks the idea in its top 3. You can change that weight in the spreadsheet.

---

## 1. The top 15 (by Priority)

| # | ID | Product | Replaces | Score | States top-3 | Why now |
|---|---|---|---|---|---|---|
| 1 | [B04](ideas/B04-owned-lead-capture-home-services-angi-thumbtack-lsa.md) | **FirstCall**: owned lead capture + AI text-back for home-service pros | Angi/HomeAdvisor, Thumbtack, Google LSA | 23 | **40** | Google ended manual LSA disputes (Jul 2024) and dropped the $2k Guarantee (Nov 2025). Angi auto-renews with a 35% exit fee. |
| 2 | [A03](ideas/A03-reviews-texting-podium-birdeye-alternative.md) | **LocalLoop**: reviews + business texting | Podium, Birdeye | 22 | 24 | 12-month auto-renew contracts with 90-day notice. Heavy BBB billing complaints. |
| 3 | [F01](ideas/F01-salon-barber-booking-vagaro-fresha-alternative.md) | **Chairly**: salon/barber/suite booking | Vagaro, Fresha, Mindbody/Booker, GlossGenius | 22 | 8 | Fresha went paid in Mar 2025 and takes 20% new-client commissions. Vagaro froze payouts (Sep 2026). |
| 4 | [C05](ideas/C05-construction-pm-remodelers-coconstruct-exodus.md) | **FlatBuild**: remodeler/small-GC project management | Buildertrend, CoConstruct | 20 | 2 | **CoConstruct stops new projects Mar 31 2027.** Every user has to move. |
| 5 | [J06](ideas/J06-professional-license-ce-tracking-entity-compliance-cebroker-legalzoom-alternative.md) | **LicenseLedger**: license/CE + entity compliance | CE Broker, Harbor Compliance, LegalZoom | 20 | 2 | CE Broker is rated 1.5/5. FinCEN's BOI change (Aug 2026) means registered agents need new products. |
| 6 | [A06](ideas/A06-courses-community-kajabi-teachable-alternative.md) | **Coursehouse**: courses + community | Kajabi, Teachable, Circle | 20 | 1 | Kajabi raised prices 20–25% from Jan 13 2026, with no grandfathering. |
| 7 | [F02](ideas/F02-gym-studio-mindbody-glofox-alternative.md) | **OpenStudio**: gym/studio management | Mindbody, ABC Glofox, Zen Planner | 20 | 1 | Mindbody discovery fees and hidden pricing. Renewal-date targeting. |
| 8 | [B01](ideas/B01-email-sms-mailchimp-klaviyo-alternative.md) | **ListFair**: email + SMS marketing | Mailchimp, Klaviyo | 20 | 0 | Mailchimp cut its free plan (Feb 17 2026). Klaviyo bills every profile. |
| 9 | [I01](ideas/I01-nonprofit-donor-crm-blackbaud-bloomerang-givebutter-alternative.md) | **GiftLedger**: small-nonprofit donor CRM | Raiser's Edge NXT, Bloomerang, Givebutter | 20 | 0 | Blackbaud renewal escalators. Givebutter tip class action (Apr 2026). Year-end giving season. |
| 10 | [I04](ideas/I04-event-ticketing-small-organizers-eventbrite-alternative.md) | **DoorList**: small-organizer ticketing | Eventbrite | 20 | 0 | Bending Spoons closed its Eventbrite takeover Mar 10 2026 (layoffs followed). FTC all-in pricing rule. |
| 11 | [L03](ideas/L03-shopify-app-bundle-reviews-upsell-popup-loyalty-alternative.md) | **StackSaver**: one Shopify app replacing 5–10 | Yotpo, Smile.io, Loox, Judge.me, pop-ups | 20 | 0 | Merchants audit app bills before Black Friday/Cyber Monday. Order-volume tiers. |
| 12 | [D07](ideas/D07-tours-activities-fareharbor-peek-alternative.md) | **BookTrail**: tours & activities booking | FareHarbor, Peek, Xola | 19 | 7 | 6% fee added to guests' bills. **Oct–Mar off-season is when operators switch.** |
| 13 | [C01](ideas/C01-field-service-hvac-plumbing-electrical.md) | **FlatRate**: field service software for HVAC/plumbing/electrical | ServiceTitan, Housecall Pro, Jobber | 19 | 5 | ServiceTitan exit fees of $22k–37k. One Housecall Pro bill went from $351 to $681. |
| 14 | [K03](ideas/K03-small-fleet-back-office-eld-tms-ifta-samsara-motive-dat.md) | **HaulDesk**: small-fleet back office + IFTA | Samsara/Motive, DAT, dispatch software | 19 | 4 | **IFTA due Oct 31.** DAT renewals up 25–45%. |
| 15 | [A01](ideas/A01-forms-typeform-jotform-alternative.md) | **FormFlare**: your forms idea | Typeform, Jotform, SurveyMonkey | 19 | 2 | Response caps. Jotform renewals reportedly tripled. HIPAA costs $99+/mo. |

The full ranked list of all 106 ideas is in the spreadsheet (**Ideas** tab) and in section 7 below.

---

## 2. Recommended first bets

**Bet 1: the "home-services front office" (B04 + A03, with C01 later).**
- FirstCall is the #1 idea in the whole study. It ranks in the top 3 for 40 of 51 states, because home-service contractors are everywhere and all of them overpay for leads.
- Sell FirstCall first: flat monthly price, instant AI text-back, true cost per booked job for each lead source.
- Add LocalLoop (reviews + texting) as the upsell that replaces Podium/Birdeye.
- Both are CRUD, telephony and notifications, so they fit a 2–4 week AI-assisted MVP.
- **Launch in:** Dallas–Fort Worth, Tampa Bay, Phoenix, then Atlanta.
- **Offer Spanish from day one** in TX, FL, AZ and CA.

**Bet 2: a deadline-driven migration play (C05, plus S8-01 in California).**
- CoConstruct's Mar 31 2027 cutoff forces every remaining user to choose a new tool within six months.
- Build a one-click CoConstruct importer and a flat price. Target the LA fire-rebuild contractors (S8-01), who face California's home-improvement payment rules.

**Bet 3: an owner-operator booking app with fast card sales (F01, then F02).**
- Salon/barber owners and suite renters decide alone and pay by card.
- Fresha's commissions and Vagaro's frozen payouts are live anger right now.

**Quick-cash compliance add-ons, sold on a date:**
- J01 NexusBook: TaxJar reprices Oct 1 2026, and several states dropped the 200-transaction test.
- J06 LicenseLedger, plus S2-01 ParCheck: Delaware franchise tax is due Mar 1.
- J03 PostedUp: labor-law poster and pay-transparency changes.
- Each has a hard deadline, which shortens the sale.

**About your forms idea (A01):** it holds up at 19/25, but the free and cheap tier is crowded. Tally is free and unlimited, with custom domains at $24/mo. Win on what Tally lacks:
- form-by-text and kiosk/offline capture
- per-vendor subdomains with a parent roll-up
- a cheap HIPAA tier

Sell it to agencies, clinics and event organizers, or bundle it into FirstCall and the vertical apps as their intake layer rather than launching it alone.

---

## 3. Switching-window calendar (next 6 months)

| Date | Trigger | Ideas to push |
|---|---|---|
| **Oct 1 2026** | TaxJar month-to-month customers move to new pricing | J01 |
| Oct 1 2026 | California CARS Act (SB 766) takes effect for used-car dealers | K02 |
| Oct 1 2026 | Xero price change (per G02 research) | G02 |
| Oct 1 2026 | Texas TEFA first school payments (Odyssey) | F06, F07 |
| Oct 15 2026 | Tennessee scholarship payout | F06 |
| **Oct 31 2026** | IFTA Q3 fuel-tax return | K03 |
| Oct 31 2026 | Illinois Remote Retailer Tax Amnesty ends. Minnesota Paid Leave premiums due. | J01, G04 |
| Oct–Dec 2026 | Off-season switching for tours, campgrounds, golf and camps | D06, D07, D08, I06 |
| Oct–Dec 2026 | Pre-tax-season buying by CPAs; year-end giving for nonprofits and churches | G03, I01, I02 |
| Nov 2 2026 | Fannie/Freddie UAD 3.6 appraisal format becomes mandatory | H05 |
| ~Nov 2026 | Federal hemp THC cap (H.R. 5371). Check the exact date. | J04 |
| **Jan 1 2027** | Payroll switch date. Maryland FAMLI contributions start. Michigan $15 minimum wage. Massachusetts PFML employer share changes. Connecticut sick leave reaches 1+ employee (verify). Indiana med-spa registration due. | G04, J03, D04, E04 |
| Feb 1 2027 | Second TEFA payment. New York pesticide annual report (verify). | F06, C03 |
| **Mar 1 2027** | Delaware franchise tax and annual report | S2-01, J06 |
| **Mar 31 2027** | CoConstruct stops new projects | C05, S8-01 |
| Apr 15 2027 | NY DFS Part 500 cybersecurity certification | S1-01 |

---

## 4. Where to launch first (state tiers)

- **Fast (launch here first):** TX, FL, CA, AZ, CO, UT, GA, TN, NY, NJ, PA, IL, MI, MA, MD, MN, MO, WA.
- **Medium–Fast / Medium:** NC, OH, NV, VA, SC, OK, LA, AR, KY, IA, KS, NE, IN, WI, OR, HI, ID, NM, NH, RI, CT, ME, DC, DE.
- **Slow (niche-only):**
  - MS: home-care visit-verification (EVV) mandate
  - WV: ESA niche
  - AK: tours
  - SD: Black Hills tourism
  - ND: oil-patch fleets
  - MT and WY: outfitters and registered agents
  - VT: a good PR test bed

See `_states_summary.csv` or the **States** tab for each state's first city, top 3 ideas and best local hook.

**State hooks worth building on:**
- **Wisconsin §134.49:** a business auto-renewal is unenforceable without a signed disclosure and a notice sent before the cancellation deadline. That gives Wisconsin customers a free legal way out of Podium, Birdeye and RingCentral contracts.
- **Utah (Lehi):** Podium's home turf, with the densest pool of unhappy customers and ex-reps to hire.
- **Texas TEFA:** $1B, 100k+ students, in year 1 of 2026–27. There is new ESA money in AZ (106k students), IA, AR, SC, WV, FL and more.
- **Florida:**
  - FTSA texting-consent law: $500 per text.
  - Condo and HOA website rules.
  - Sunbiz dissolves entities that miss their annual report.
- **New York:** the most federal ADA website lawsuits (1,021 in 2025). An auto-renewal law amendment took effect in Nov 2025.
- **California:**
  - LA fire rebuilds.
  - Automatic-renewal law changes (verify).
  - Home-improvement deposit cap: $1,000 or 10%.

---

## 5. Patterns across the research

1. **The same three complaints show up in almost every category:**
   - auto-renewing annual contracts with 60–90-day notice windows and exit fees
   - bills that grow per seat, per contact, per location or per transaction
   - AI sold as a paid add-on

   So the standard offer should be a flat price, month-to-month, free migration and AI included. Lead with "we'll help you leave your contract" (see the auto-renewal laws in WI, NY and CA).
2. **Acquisitions, private-equity roll-ups and take-privates come before price hikes:**
   - Storable
   - Covetrus
   - Patterson (Eaglesoft)
   - Personify (WildApricot)
   - Eventbrite (Bending Spoons)
   - PowerSchool (Bain)
   - Squarespace/Acuity
   - ServiceTitan's FieldRoutes

   Watch for new deals and target their customers right after.
3. **New laws create buyers on a fixed date:**
   - junk-fee and all-in pricing rules (CA, MN, VA, MA, CO, and the FTC)
   - paid leave (MN, DE, ME, MD, VA)
   - pay transparency
   - privacy (20 states)
   - med-spa rules (TX, IN, CA, NJ)
   - EVV mandates
   - ESA programs

   Compliance features let you charge more and shorten the sale.
4. **The best buyers own the business and pay by card:** contractors, salon owners, studio owners, tour operators and small nonprofits. Avoid segments that buy through RFPs, like local government (J07), until you have revenue.
5. **Ideas to put off (14/25 or below):**
   - K04 towing
   - L05 Jira Data Center
   - G05 insurance agencies
   - G06 RIAs
   - H06 self-storage
   - J04 cannabis
   - J05 alcohol shipping
   - J07 local government
   - I06 camps
   - D05 hotels
   - K05 movers
   - K06 car wash
   - L06 password manager

---

## 6. New domain: books, readers & parent-child education

This domain adds 17 ideas (R01–R08 books & readers, P01–P07 parent-child education, S9-02 and S9-04 state-specific). Each of the 51 state files now also has a **"Books, reading & family education"** section covering:
- library-materials or freedom-to-read laws
- science-of-reading and third-grade reading laws
- homeschool rules
- ESA or scholarship money that can buy books, curriculum and classes
- where to sell

The ranking below adds 0.1 point for each state that ranks the idea in its education top 3.

| # | ID | Product | Replaces | Score | States (edu top 3) | Why now |
|---|---|---|---|---|---|---|
| 1 | [P03](ideas/P03-homeschool-state-compliance-records-esa-529-homeschool-planet-alternative.md) | **HomeRoll**: homeschool records + state compliance + ESA receipts | Homeschool Planet ($84.95/yr), Homeschool Manager, Homeschool-life | 18 | **35** | ESA money now reaches homeschoolers: TX TEFA $2k, FL PEP ~$8k, UT $4k–6k, AL $2k. NY and PA require state-specific paperwork. |
| 2 | [P04](ideas/P04-independent-kids-class-teachers-outschool-varsity-wyzant-preply-alternative.md) | **ClassHouse**: storefront for independent kids-class teachers | Outschool (30% fee), Wyzant, Preply, Varsity Tutors | 19 | 12 | Outschool switched to pay-per-class (May 25 2026). Varsity Tutors for Schools wound down (Jul 31 2026). |
| 3 | [R02](ideas/R02-reading-challenges-readathon-beanstack-readathon-alternative.md) | **ReadRally**: reading challenges, logs & read-a-thons | Beanstack ($1,430/yr), READsquared ($595), Read-A-Thon | 19 | 9 | Federal LSTA library funding is at $0 for FY27. Spring read-a-thon and summer-reading planning. |
| 4 | [R08](ideas/R08-ai-decodable-reading-epic-abcmouse-raz-kids-alternative.md) | **Readlings**: AI decodable stories for each child's phonics level | Epic ($84.99/yr), ABCmouse, Reading Eggs, Raz-Kids ($115→$132) | 18 | 13 | Federal reading bill H.R. 7890 passed the House Sep 16 2026. ABCmouse billing complaints. |
| 5 | [R06](ideas/R06-indie-author-hq-bookfunnel-netgalley-booksprout-alternative.md) | **LaunchShelf**: indie-author HQ (ARCs, reader list, direct store) | BookFunnel, NetGalley, Booksprout, StoryOrigin, Payhip | 19 | 0 | BookFunnel's Mid-List plan doubled to $200/yr (Feb 2026). KDP cut paperback royalties (Jun 2025). |
| 6 | [P01](ideas/P01-science-of-reading-decodables-og-tutor-toolkit-project-read-litlab-alternative.md) | **PhonicsPrep**: decodables & lesson kits for reading tutors and OG specialists | Project Read, LitLab, TPT decodables, Barton | 17 | 17 | 40+ states have science-of-reading laws and 14+ ban three-cueing. California adopts new materials Jan 2027. |
| 7 | [P07](ideas/P07-family-screen-time-bark-qustodio-assessment-pivot-learning-spend-wallet.md) | **LearnLedger**: family learning-spend wallet (ESA/529/tax-credit receipts) | receipt spreadsheets (a Bark/Qustodio clone was rejected at 13/25) | 17 | 17 | 2027 tax season. 13 states don't follow federal K–12 529 rules. New state tax credits (MN, ID, OH, MT). |
| 8 | [R01](ideas/R01-school-library-compliance-catalog-follett-destiny-alternative.md) | **ClearShelf**: neutral school-library catalog + compliance log | Follett Destiny, Alexandria, Bookmarked | 16 | 20 | TX SB 13 year two; NC H 805 classroom catalogs; Iowa SF 496 enforceable again (Apr 2026). The product is neutral: it serves both kinds of state law. |
| 9 | [P02](ideas/P02-third-grade-reading-plan-parent-portal-mclass-iready-companion.md) | **ReadingPlan Home**: parent–teacher reading-plan portal | mCLASS Home Connect, Word templates | 16 | 19 | IN retained ~3,040 third graders in 2025. New retention laws: WV 2026–27, OK and MD 2027–28, WI 2027. |
| 10 | [P05](ideas/P05-pto-pta-hub-diy-fun-run-read-a-thon-givebacks-memberhub-boosterthon-alternative.md) | **PTOHub**: PTA hub + DIY fun-run/read-a-thon | Givebacks/MemberHub, MoneyMinder, Boosterthon, Apex | 17 | 3 | Board handoff May–Aug; fall fun runs. |

Lower priority in this domain:
- S9-04 CoverDesk (SC homeschool associations): 17
- P06 StoryNest (preschool family reading): 15
- R04 OpenBookFair: 15. Literati already offers a better book fair.
- R05 SpineDesk (indie bookstores): 15
- S9-02 ReadyTutor LA: 15
- R03 Branchline (public libraries): 13. Only 9.7% of libraries want to switch systems.
- R07 ReadClear (content descriptors): 13. Data rights are unclear and the topic is politically risky; use it as a data layer inside R01 instead.

**Recommended bet in this domain: a "family learning" suite built around HomeRoll (P03).**
- Families pay by card, and it's a top-3 education pick in 35 states.
- ESA and tax-credit money now reaches homeschoolers in TX, FL, AZ, UT, AL, NH, WY, AR, ID and MN.
- Add LearnLedger (P07) receipts as the upsell.
- Sell to homeschool associations and umbrella schools through CoverDesk (S9-04) to reach many families at once.
- **Launch in** Texas (500k–620k homeschoolers per THSC; $2k TEFA), then Florida and Arizona. In New York and Pennsylvania, sell the paperwork: IHIP quarterly reports, and PA portfolios with evaluator sign-off.

**Second bet: ClassHouse (P04) with PhonicsPrep (P01).** Independent teachers and reading tutors are small businesses that pay by card. Outschool's 30% fee and switch to pay-per-class give them a reason to leave now. ESA programs (AZ lists Outschool as a vendor) let them bill ESA accounts, and science-of-reading laws drive demand for tutors.

**Third bet: Readlings (R08).** AI makes personalized decodable stories cheap to produce. Sell to families first, then add a classroom tier. It also works as a feature of HomeRoll and ClassHouse.

**Dates to sell against:**

| Date | Trigger | Ideas |
|---|---|---|
| Oct–Dec 2026 | TEFA year-1 homeschool money flowing; NY IHIP quarterly reports; FL PEP funding cycles | P03, P07 |
| Jan 2027 | CA materials adoption (AB 1454); AL CHOOSE application window; MT federal tax-credit scholarship money starts | P01, R08, P03, P07 |
| Jan–Apr 2027 | Tax season: families claim learning receipts for tax credits (MN, ID, OH) and 529s | P07 |
| Jan–Mar 2027 | Libraries and schools plan summer reading and spring read-a-thons | R02, P05 |
| Spring 2027 | Third-grade reading tests (e.g., Indiana IREAD-3) lead to reading plans and retention notices | P02, P01 |
| May–Aug 2027 | PTA boards hand off; PA homeschool evaluator certifications (Jun 30) | P05, P03 |
| Jul–Sep 2027 | CT homeschool withdrawal rules (Jul 1); WI promotion gate (Sep 1); OK and MD retention laws take effect | P03, P02 |

All education-state facts are in `_states_edu_summary.csv` and each state file. The fact-check (Sep 25) led to these changes:
- **R06** dropped to 19: BookFunnel's rise is +33% like-for-like, and existing users keep their old prices.
- **P05** dropped to 17: MoneyMinder already bundles Cheddar Up, and only the Massachusetts PTA's Givebacks mandate is confirmed.
- **R01** dropped to 16: a paper catalog satisfies Nebraska's law.

---

## 7. Full catalog (all 106 ideas, sorted by score)

| ID | Product | Category | Replaces | Score | Urgency trigger |
|---|---|---|---|---|---|
| [B04](ideas/B04-owned-lead-capture-home-services-angi-thumbtack-lsa.md) | FirstCall | Marketing/CRM | Angi/HomeAdvisor, Thumbtack, Google LSA | 23 | Google ended LSA disputes & $2k guarantee Nov 2025; Angi 35% exit fee |
| [A03](ideas/A03-reviews-texting-podium-birdeye-alternative.md) | LocalLoop | Forms/comms | Podium, Birdeye | 22 | 12-mo auto-renew, 90-day notice, ~8% renewal uplift, heavy BBB billing complaints |
| [F01](ideas/F01-salon-barber-booking-vagaro-fresha-alternative.md) | Chairly | Beauty/fitness/kids/pets | Vagaro, Fresha, Mindbody/Booker, GlossGenius, Booksy | 22 | Fresha paid Mar 2025; 20% new-client commissions; Vagaro frozen payouts Sep 2026 |
| [A06](ideas/A06-courses-community-kajabi-teachable-alternative.md) | Coursehouse | Forms/comms | Kajabi, Teachable, Circle | 20 | Kajabi +20-25% from Jan 13 2026 not grandfathered; Teachable 7.5% fee |
| [B01](ideas/B01-email-sms-mailchimp-klaviyo-alternative.md) | ListFair | Marketing/CRM | Mailchimp, Klaviyo | 20 | Mailchimp free plan cut Feb 2026; legacy +11-13% Apr 2026; Klaviyo bills all profiles |
| [C05](ideas/C05-construction-pm-remodelers-coconstruct-exodus.md) | FlatBuild | Home services | Buildertrend, CoConstruct, Procore | 20 | CoConstruct stops new projects Mar 31 2027 - forced migration |
| [F02](ideas/F02-gym-studio-mindbody-glofox-alternative.md) | OpenStudio | Beauty/fitness/kids/pets | Mindbody, ABC Glofox, Zen Planner | 20 | Mindbody discovery fee; Glofox hikes 70-300% |
| [I01](ideas/I01-nonprofit-donor-crm-blackbaud-bloomerang-givebutter-alternative.md) | GiftLedger | Nonprofit/events | Raiser's Edge NXT, Bloomerang, Givebutter | 20 | Blackbaud renewal escalators, FTC order; Givebutter tip class action Apr 2026; year-end giving |
| [I04](ideas/I04-event-ticketing-small-organizers-eventbrite-alternative.md) | DoorList | Nonprofit/events | Eventbrite | 20 | Bending Spoons takeover + layoffs Mar 2026; FTC all-in ticket rule May 2025 |
| [J06](ideas/J06-professional-license-ce-tracking-entity-compliance-cebroker-legalzoom-alternative.md) | LicenseLedger | Compliance | CE Broker, Harbor Compliance, LegalZoom | 20 | CE Broker 1.5/5; FinCEN BOI domestic exemption final Aug 2026 |
| [L03](ideas/L03-shopify-app-bundle-reviews-upsell-popup-loyalty-alternative.md) | StackSaver | Horizontal | Yotpo, Smile.io, Loox, Judge.me, pop-up/upsell apps | 20 | Feature gating + order-volume bumps; pre-BFCM app-bill audits |
| [A01](ideas/A01-forms-typeform-jotform-alternative.md) | FormFlare | Forms/comms | Typeform, Jotform, SurveyMonkey | 19 | Response caps; Jotform renewals reportedly 3x; HIPAA forces $99+ tiers |
| [A04](ideas/A04-esign-docusign-pandadoc-alternative.md) | SignFlat | Forms/comms | DocuSign, PandaDoc, Dropbox Sign | 19 | Renewal refunds refused, envelope caps, new per-doc fees, Dropbox Sign breach |
| [B02](ideas/B02-smb-crm-hubspot-gohighlevel-alternative.md) | OwnerCRM | Marketing/CRM | HubSpot, GoHighLevel | 19 | HubSpot Starter->Pro $890/mo + $3k onboarding; GHL clients stranded when agency quits |
| [B07](ideas/B07-client-management-creatives-honeybook-dubsado-alternative.md) | StudioDesk | Marketing/CRM | HoneyBook, Dubsado | 19 | HoneyBook +51-89% Feb 2025; loyalty discount ended Feb 2026; held funds |
| [C01](ideas/C01-field-service-hvac-plumbing-electrical.md) | FlatRate | Home services | ServiceTitan, Housecall Pro, Jobber | 19 | ServiceTitan exit fees $22-37k; HCP bill $351->$681 |
| [D02](ideas/D02-direct-online-ordering-chownow-owner-alternative.md) | DirectPlate | Hospitality/retail | Owner.com, ChowNow, DoorDash | 19 | NYC fee cap ended Jun 2025; app fees up to ~43% |
| [D03](ideas/D03-reservations-waitlist-opentable-resy-alternative.md) | TableKeep | Hospitality/retail | OpenTable, Resy, Tock | 19 | OpenTable 2% deposit fee Jan 2026; Resy-Tock merger 2026 |
| [D07](ideas/D07-tours-activities-fareharbor-peek-alternative.md) | BookTrail | Hospitality/retail | FareHarbor, Peek, Xola | 19 | 6% guest fee; FareHarbor 2026 platform change |
| [G01](ideas/G01-small-law-practice-trust-clio-mycase-alternative.md) | LawLedger | Pro services | Clio, MyCase, Smokeball, PracticePanther | 19 | Clio 2026 AI repricing (~34% reported), forced AI, hidden tier prices |
| [I03](ideas/I03-membership-associations-chambers-wild-apricot-alternative.md) | DuesDesk | Nonprofit/events | WildApricot, MemberClicks, GrowthZone | 19 | Repeated WildApricot hikes, 20% outside-processor surcharge; Personify sold Jan 2026 |
| [K03](ideas/K03-small-fleet-back-office-eld-tms-ifta-samsara-motive-dat.md) | HaulDesk | Auto/transport | Samsara/Motive, DAT, dispatch TMS, IFTA services | 19 | IFTA due Oct 31; DAT renewals +25-45%; Samsara auto-renew complaints |
| [L02](ideas/L02-project-management-flat-price-monday-asana-clickup-alternative.md) | Studioboard | Horizontal | monday.com, Asana, ClickUp | 19 | Seat-block pricing; AI credits since May 2026 |
| [P04](ideas/P04-independent-kids-class-teachers-outschool-varsity-wyzant-preply-alternative.md) | ClassHouse | Parent-child education | Outschool, Wyzant, Preply, Varsity Tutors | 19 | Varsity Tutors for Schools wind-down Jul 31 2026; Outschool payment changes |
| [R02](ideas/R02-reading-challenges-readathon-beanstack-readathon-alternative.md) | ReadRally | Books & readers | Beanstack, READsquared, Read-A-Thon | 19 | Spring read-a-thon planning; IMLS/LSTA subsidies at risk |
| [R06](ideas/R06-indie-author-hq-bookfunnel-netgalley-booksprout-alternative.md) | LaunchShelf | Books & readers | BookFunnel, NetGalley, Booksprout/BookSirens, StoryOrigin, Payhip | 19 | BookFunnel Mid-List base $100->$200 (Feb 20 2026; +33% like-for-like, existing users grandfathered); KDP paperback royalty cut Jun 2025 |
| [S1-01](ideas/S1-01-ny-dfs-part-500-cyber-compliance-kit.md) | Part500 Kit | State-specific | NY DFS cybersecurity compliance for small insurance agencies/brokers/mortgage brokers | 19 | NY DFS Part 500 annual certification due Apr 15 |
| [S2-01](ideas/S2-01-delaware-franchise-tax-annual-report-autopilot.md) | ParCheck | State-specific | Delaware franchise tax & annual report services (registered agents, LegalZoom) | 19 | DE franchise tax Mar 1; LLC tax now $400 due Jun 1; scam mailers |
| [S8-01](ideas/S8-01-rebuildledger-ca-fire-rebuild-contract-draw-compliance.md) | RebuildLedger | State-specific | Buildertrend/CoConstruct for LA fire-rebuild contractors (draws, deposit caps, permits) | 19 | 16,264 structures lost in 2025 LA fires; CA home-improvement payment rules |
| [B06](ideas/B06-business-phone-call-tracking-ringcentral-callrail-alternative.md) | RingFlat | Marketing/CRM | RingCentral, CallRail, Quo | 18 | RingCentral 541 BBB complaints, many Jul-Aug 2026 |
| [C03](ideas/C03-pest-control-lawn-care-compliance.md) | SprayLog | Home services | PestPac, FieldRoutes, RealGreen | 18 | NY pesticide report due Feb 1; FieldRoutes 3-yr contracts |
| [C06](ideas/C06-lien-deadlines-notices-waivers.md) | LienClock | Home services | Levelset (Procore Pay) | 18 | TX lien-law changes; per-notice fees |
| [D04](ideas/D04-restaurant-scheduling-tips-7shifts-homebase-alternative.md) | ShiftTip | Hospitality/retail | 7shifts, Homebase | 18 | 7shifts plan changes Jul 2025; federal tip reporting |
| [E01](ideas/E01-therapy-ehr-simplepractice-therapynotes-alternative.md) | Hearth EHR | Health | SimplePractice, TherapyNotes | 18 | Aetna/Alma rate flattening 7/2026; SP AI add-ons, repeated hikes |
| [E02](ideas/E02-chiro-pt-ehr-chirotouch-webpt-alternative.md) | Alignly | Health | ChiroTouch, WebPT | 18 | ChiroTouch renewal $74->$198; WebPT annual hikes |
| [E08](ideas/E08-clinic-intake-scheduling-payments-tebra-intakeq-alternative.md) | Clipboardless | Health | Tebra, Phreesia, NexHealth, IntakeQ | 18 | Tebra 60-day non-renewal window, 4.9%/yr uplift |
| [G02](ideas/G02-smb-accounting-quickbooks-online-xero-alternative.md) | PlainLedger | Pro services | QuickBooks Online/Desktop, Xero | 18 | QBO Aug 1 2026 hike (Plus $140, Advanced $340); Xero hike Oct 1 |
| [G03](ideas/G03-cpa-tax-practice-portal-taxdome-karbon-alternative.md) | SeasonDesk | Pro services | TaxDome, Karbon, Canopy | 18 | TaxDome $600->$1,000/seat since 2023; Oct-Dec pre-season window |
| [H01](ideas/H01-small-landlord-pm-appfolio-buildium-alternative.md) | DoorLedger | Real estate | AppFolio, Buildium, Avail, TurboTenant | 18 | Buildium 6 increases in 2.5 yrs; CO HB25-1090 Jan 2026 |
| [H05](ideas/H05-home-inspection-report-software-spectora-alternative.md) | InspectKit | Real estate | Spectora, HomeGauge, ISN | 18 | Spectora ads in client portals Apr 2026, $4/inspection fee |
| [I05](ideas/I05-youth-sports-clubs-leagues-teamsnap-sportsengine-alternative.md) | ClubHouse | Nonprofit/events | TeamSnap ONE, SportsEngine, LeagueApps | 18 | Forced TeamSnap ONE migration removed admin features; 1.1 Trustpilot |
| [J01](ideas/J01-sales-tax-nexus-filing-avalara-taxjar-alternative.md) | NexusBook | Compliance | TaxJar, Avalara | 18 | TaxJar month-to-month moves to new pricing Oct 1 2026; mid tiers +110-128% |
| [J03](ideas/J03-smb-employment-law-posters-pay-transparency-poster-guard-mineral-alternative.md) | PostedUp | Compliance | Poster Guard, GovDocs, Mineral | 18 | 5 required poster changes in Sep 2026 alone; pay-transparency laws through 2027 |
| [K01](ideas/K01-auto-repair-shop-tekmetric-shopmonkey-alternative.md) | BayBook | Auto/transport | Tekmetric, Shopmonkey, AutoLeap, Shop-Ware | 18 | Tier-upgrade bill creep; Shopmonkey billing-after-cancel |
| [L01](ideas/L01-automation-flat-price-zapier-make-alternative.md) | FlatFlow | Horizontal | Zapier, Make | 18 | Task caps exhausted in days; overages; refused refunds |
| [L04](ideas/L04-async-video-sop-loom-alternative.md) | ClipSOP | Horizontal | Loom | 18 | Creator Lite free seats removed Feb 2026 |
| [P03](ideas/P03-homeschool-state-compliance-records-esa-529-homeschool-planet-alternative.md) | HomeRoll | Parent-child education | Homeschool Planet, Homeschool Manager, Homeschool-life | 18 | 529 homeschool expansion; TX TEFA $2k homeschool; NY/PA filings |
| [R08](ideas/R08-ai-decodable-reading-epic-abcmouse-raz-kids-alternative.md) | Readlings | Books & readers | Epic, ABCmouse, Reading Eggs, Raz-Kids | 18 | Federal science-of-reading bill passed House Sep 16 2026 (verify); ABCmouse billing complaints |
| [B03](ideas/B03-social-scheduling-hootsuite-sprout-alternative.md) | PostFlat | Marketing/CRM | Hootsuite, Sprout Social | 17 | Hootsuite $99/user/mo; renewal/refund complaints |
| [C02](ideas/C02-roofing-exteriors-crm-storm.md) | StormDesk | Home services | AccuLynx, JobNimbus, EagleView, Hover | 17 | Storm season per-user and add-on creep |
| [C07](ideas/C07-restoration-claims-documentation-supplements.md) | ClaimKit | Home services | CompanyCam, Encircle (+Xactimate) | 17 | CAT spikes; carriers reject O&P ~85% |
| [E04](ideas/E04-med-spa-compliance-ehr-zenoti-boulevard-alternative.md) | Glowchart | Health | Zenoti, Boulevard, PatientNow, Aesthetic Record | 17 | IN registration 1/1/2027; TX Jenifer's Law; CA SB 351 |
| [F03](ideas/F03-kids-activities-dance-gym-martial-arts-jackrabbit-alternative.md) | RecitalReady | Beauty/fitness/kids/pets | Jackrabbit, iClassPro, Spark | 17 | Per-student tier creep; Jun-Aug switch window |
| [F04](ideas/F04-pet-grooming-boarding-daycare-gingr-moego-alternative.md) | PackLeader | Beauty/fitness/kids/pets | Gingr, PetExec, MoeGo | 17 | Gingr $2k gateway fee; MoeGo SMS caps |
| [F05](ideas/F05-childcare-subsidy-attendance-brightwheel-procare-alternative.md) | RollCall | Beauty/fitness/kids/pets | Brightwheel, Procare | 17 | HHS proof-of-spend Jan 2026; attendance pay rule Jul 2026 |
| [F06](ideas/F06-microschool-private-school-esa-billing-facts-alternative.md) | ESA Desk | Beauty/fitness/kids/pets | FACTS, Blackbaud, GetESAPaid | 17 | TX TEFA year 1 (2026-27); AR/AZ ClassWallet reviews |
| [G04](ideas/G04-payroll-state-compliance-gusto-adp-alternative.md) | StatePay | Pro services | Gusto, ADP RUN, Paychex | 17 | Gusto +22% Mar 2026; new state paid-leave programs; Jan 1 switch |
| [G07](ideas/G07-staffing-ats-crm-bullhorn-alternative.md) | BenchBoard | Pro services | Bullhorn, JobDiva, Crelate | 17 | Bullhorn auto-renewals; Indeed bills started applications |
| [H02](ideas/H02-hoa-condo-florida-website-compliance-vantaca-townsq-alternative.md) | BoardBinder | Real estate | Vantaca, TownSq, CINC, AppFolio, Buildium | 17 | FL condo 25+ unit website deadline passed Jan 1 2026 |
| [I02](ideas/I02-church-giving-chms-pushpay-alternative.md) | TitheBox | Nonprofit/events | Pushpay / ChurchStaq | 17 | Pushpay 1-3 yr uncancellable contracts, PE owned; Q4 giving season |
| [J02](ideas/J02-smb-privacy-cookie-accessibility-compliance-termly-osano-alternative.md) | SiteShield | Compliance | Termly, iubenda, Osano, overlays | 17 | IN/KY/RI privacy laws Jan 2026; 3,117 federal ADA web suits 2025 |
| [K02](ideas/K02-independent-dealer-ca-cars-act-compliance-dealercenter-frazer.md) | DealJacket | Auto/transport | DealerCenter, Frazer (adjacent) | 17 | CA CARS Act (SB 766) effective Oct 1 2026 |
| [P01](ideas/P01-science-of-reading-decodables-og-tutor-toolkit-project-read-litlab-alternative.md) | PhonicsPrep | Parent-child education | Project Read, LitLab, TPT decodables, Barton | 17 | Federal reading bill passed House Sep 2026 (verify); CA materials adoption Jan 2027 |
| [P05](ideas/P05-pto-pta-hub-diy-fun-run-read-a-thon-givebacks-memberhub-boosterthon-alternative.md) | PTOHub | Parent-child education | Givebacks/MemberHub, MoneyMinder, Boosterthon, Apex | 17 | Board handoff May-Aug; fall fun runs; state PTAs mandate Givebacks |
| [P07](ideas/P07-family-screen-time-bark-qustodio-assessment-pivot-learning-spend-wallet.md) | LearnLedger | Parent-child education | Receipt spreadsheets for ESA/529 family learning spend (screen-time clone rejected, 13/25) | 17 | 2027 tax season; 13 states don't conform to federal K-12 529 rules |
| [S5-01](ideas/S5-01-illinois-bipa-safe-time-clock-leave-compliance.md) | ClockRight IL | State-specific | Biometric time clocks + IL/Chicago/Cook paid-leave & tip-credit tracking | 17 | IL BIPA exposure; Chicago tip-credit phase-out; PLAWA |
| [S9-04](ideas/S9-04-sc-option3-homeschool-association-umbrella-school-admin.md) | CoverDesk | State-specific | Homeschool-life / email + Google Forms for SC Option 3 associations & TN umbrella schools | 17 | 81 SC Option 3 associations; fastest homeschool growth (+21.5%) |
| [A02](ideas/A02-scheduling-acuity-calendly-alternative.md) | BookFlat | Forms/comms | Acuity, Calendly, Setmore | 16 | Acuity bugs post-Squarespace take-private; Calendly AI upsell tiers (Aug 2026) |
| [A05](ideas/A05-helpdesk-zendesk-intercom-alternative.md) | Quietdesk | Forms/comms | Intercom, Zendesk, Help Scout | 16 | $0.75-0.99 per AI resolution; Zendesk AI +$50/agent |
| [B05](ideas/B05-local-listings-reputation-yext-brightlocal-alternative.md) | ListingKeep | Marketing/CRM | Yext, BrightLocal | 16 | Yext listings revert after cancel; surprise $499-529 renewals |
| [C04](ideas/C04-pool-cleaning-route-businesses.md) | RouteBook | Home services | Skimmer, Pool Brain, ZenMaid | 16 | Per-pool/per-cleaner fee growth (weak) |
| [D06](ideas/D06-campground-rv-park-campspot-alternative.md) | SiteLoop | Hospitality/retail | Campspot, Newbook, Staylist | 16 | Camper booking fees vs all-in pricing laws |
| [D09](ideas/D09-independent-retail-pos-lightspeed-clover-alternative.md) | ShelfPOS | Hospitality/retail | Lightspeed Retail, Clover | 16 | Lightspeed $930 non-processing invoice; Clover contracts expiring |
| [E03](ideas/E03-dental-comms-membership-weave-alternative.md) | Bitewing | Health | Weave, Kleer, BoomCloud | 16 | Weave renewals +15-25%; Patterson taken private Apr 2025 |
| [E07](ideas/E07-home-care-agency-evv-wellsky-axiscare-alternative.md) | Shiftwell | Health | WellSky, AxisCare | 16 | Medicaid EVV mandate; possible 80/20 wage rule |
| [F07](ideas/F07-tutoring-music-lessons-esa-ready-mymusicstaff-teachworks-alternative.md) | LessonLedger | Beauty/fitness/kids/pets | My Music Staff, Teachworks, TutorBird | 16 | ESA money for tutors; incumbents cheap |
| [H03](ideas/H03-short-term-rental-pms-guesty-hostaway-alternative.md) | StayDesk | Real estate | Guesty, Hostaway, OwnerRez, Hospitable | 16 | Airbnb 15.5% host-only fee for PMS-connected hosts Oct 27 2025 |
| [H04](ideas/H04-agent-crm-buyer-agreement-follow-up-boss-boldtrail-alternative.md) | AgentPact | Real estate | Follow Up Boss, BoldTrail/kvCORE | 16 | Written buyer agreement before touring (NAR settlement) |
| [P02](ideas/P02-third-grade-reading-plan-parent-portal-mclass-iready-companion.md) | ReadingPlan Home | Parent-child education | mCLASS Home Connect, Word templates | 16 | IN retained ~3,040 3rd graders; WV retention starts 2026-27 |
| [R01](ideas/R01-school-library-compliance-catalog-follett-destiny-alternative.md) | ClearShelf | Books & readers | Follett Destiny, Alexandria, Bookmarked | 16 | NE LB 390 due 2026-27; TX SB 13 year two; NC classroom catalogs |
| [S4-01](ideas/S4-01-fortified-roof-grant-documentation.md) | FortiFile | State-specific | Paperwork for FORTIFIED roof grant jobs (OK, LA); on-ramp to C02 | 16 | Strengthen Oklahoma Homes / Louisiana Fortify Homes $10k grants |
| [S7-01](ideas/S7-01-outfitter-guide-booking-permit-reporting.md) | GuideLedger | State-specific | FareHarbor/Peek for hunting & fishing outfitters + permit use reports | 16 | State outfitter-board use reports & late penalties; EXPLORE Act |
| [D01](ideas/D01-restaurant-pos-toast-clover-alternative.md) | FlatTab POS | Hospitality/retail | Toast, Clover, Square | 15 | Toast +0.23% Sep 2024; forced Clover 36-mo contracts expire 2026-27 |
| [D08](ideas/D08-golf-tee-sheet-golfnow-barter-alternative.md) | TeeFree | Hospitality/retail | GolfNow, foreUP, Lightspeed Golf | 15 | Barter ~$94.5k/yr; winter switch window |
| [E05](ideas/E05-vet-pims-avimark-pulse-ezyvet-alternative.md) | Tailwag PIMS | Health | Covetrus AVImark/Pulse, ezyVet | 15 | AVImark wind-down signals; Pulse price locks broken |
| [E06](ideas/E06-aba-speech-ot-practice-centralreach-alternative.md) | SkillTrack | Health | CentralReach | 15 | Early auto-renewals, per-user creep, payer audits |
| [I07](ideas/I07-k12-parent-communication-private-charter-parentsquare-alternative.md) | SchoolPing | Nonprofit/events | ParentSquare, Remind, SchoolMessenger | 15 | PowerSchool breach + Bain buyout; Remind SMS cutoff |
| [P06](ideas/P06-preschool-family-reading-engagement-book-lending-readyrosie-footsteps2brilliance-alternative.md) | StoryNest | Parent-child education | ReadyRosie, Footsteps2Brilliance | 15 | Imagination Library cuts (WA, IN, MO); Head Start funding shocks |
| [R04](ideas/R04-school-book-fairs-indie-bookstores-scholastic-alternative.md) | OpenBookFair | Books & readers | Scholastic Book Fairs, Literati | 15 | Fair booking seasons; content disputes; rotating PTA chairs |
| [R05](ideas/R05-indie-bookstore-back-office-bookmanager-basil-square-isbn-alternative.md) | SpineDesk | Books & readers | Basil, BookManager, IndieCommerce, Square/Shopify ISBN workarounds | 15 | IndieCommerce fees rose Jan 2026; 600+ new stores in 2025 |
| [S9-02](ideas/S9-02-louisiana-reading-voucher-tutor-kit-steve-carter-gator.md) | ReadyTutor LA | State-specific | Wyzant/Varsity Tutors/Outschool for LA voucher-paid reading tutors | 15 | Steve Carter $1,500 tutoring vouchers; GATOR ESA on Odyssey |
| [D05](ideas/D05-independent-hotel-pms-cloudbeds-alternative.md) | InnDesk | Hospitality/retail | Cloudbeds, Little Hotelier | 14 | FTC all-in hotel pricing May 2025; channel sync failures |
| [G05](ideas/G05-insurance-agency-ams-applied-epic-ezlynx-alternative.md) | AgencyLite | Pro services | EZLynx, Applied Epic, AMS360, QQCatalyst | 14 | EZLynx +50% (2023, user-reported); contract lock-in |
| [G06](ideas/G06-ria-crm-compliance-reg-sp-redtail-smarsh-alternative.md) | AdvisorVault | Pro services | Redtail, Wealthbox, Smarsh | 14 | SEC Reg S-P small-firm deadline ~Jun 2026 (verify) |
| [H06](ideas/H06-self-storage-management-storable-sitelink-alternative.md) | UnitLedger | Real estate | SiteLink, storEDGE (Storable) | 14 | Storable increases every 1.5-2 yrs; state lien-law changes |
| [I06](ideas/I06-summer-camps-after-school-campminder-ultracamp-alternative.md) | CampFile | Nonprofit/events | CampMinder, UltraCamp, CampBrain | 14 | Sep-Dec only switch window before registration |
| [J04](ideas/J04-cannabis-hemp-compliance-metrc-reconciliation-dutchie-alternative.md) | TagTrue | Compliance | Dutchie, Flowhub, Treez (beside Metrc) | 14 | Federal hemp 0.4mg/container cap ~Nov 2026 (verify) |
| [J05](ideas/J05-winery-brewery-distillery-dtc-shipping-compliance-shipcompliant-alternative.md) | CellarPermit | Compliance | Sovos ShipCompliant | 14 | Recurring permit renewals only; no hard trigger |
| [J07](ideas/J07-small-government-volunteer-fire-neris-reporting-tyler-civicplus-eso-alternative.md) | StationLog | Compliance | ESO, ImageTrend, Tyler, CivicPlus | 14 | NFIRS retired Jan 31 2026; all depts on NERIS |
| [K05](ideas/K05-movers-junk-removal-smartmoving-supermove-alternative.md) | MoveBoard | Auto/transport | SmartMoving, Supermove, MoveitPro | 14 | Off-season switch window (weak) |
| [K06](ideas/K06-car-wash-membership-crm-rinsed-alternative-detailers.md) | WashClub | Auto/transport | Rinsed, Urable, DRB | 14 | Membership churn/declines; auto-renewal laws (weak) |
| [L06](ideas/L06-office-password-manager-lastpass-1password-alternative.md) | OfficeKeys | Horizontal | LastPass, 1Password | 14 | LastPass-linked crypto thefts; 1Password hike Mar 2026 |
| [K04](ideas/K04-towing-impound-compliance-towbook-alternative.md) | TowLedger | Auto/transport | Towbook, Omadi, Beacon | 13 | State/city non-consent tow caps (weak) |
| [L05](ideas/L05-self-hosted-wiki-tracker-jira-confluence-data-center-alternative.md) | Harbor | Horizontal | Jira/Confluence Data Center | 13 | No new DC licenses Mar 30 2026; read-only Mar 2029 |
| [R03](ideas/R03-small-public-library-events-rooms-ils-libcal-sirsidynix-alternative.md) | Branchline | Books & readers | LibCal, LibraryMarket, Communico, SirsiDynix | 13 | IMLS cuts; SirsiDynix bought by Constellation Dec 2024 |
| [R07](ideas/R07-neutral-book-content-descriptors-common-sense-media-alternative.md) | ReadClear | Books & readers | Common Sense Media, BookLooks (closed), Shelf Checkout | 13 | BookLooks closed Mar 2025; TX SB 13 30-day purchase listing |

---

## 8. How reliable this is

- The research ran Sep 24–25 2026. Prices change often, so check them before quoting them in sales material.
- Complaints are paraphrased with links. Some come from competitor blogs quoting G2/Capterra, and those are labeled in the files.
- The session's web-search quota (200 searches) ran out partway through wave 2. After that, facts came from direct page fetches, and anything that couldn't be confirmed on a page is marked **(verify)**.
- **Fact-check pass (Sep 24 2026):** the top 12 ideas and the TX, FL, CA, AZ, NY and CO state files were checked against their sources, along with C06, H02 and the S1/S2/S8 ideas. Each file ends with a **Verification** section.
- **Main corrections from that pass:**
  - HoneyBook's price gap is smaller than first thought; B07 dropped to 19.
  - Lien-notice rules in C06: New York has no preliminary notice; Colorado requires a 10-day notice of intent.
  - Florida's SIRS deadline was moved to Dec 31 2025.
  - Colorado's HB25-1090 does not cover ticket sellers.
  - The Delaware LLC tax is $400.
  - West Virginia's Hope Scholarship no longer runs on ClassWallet.
  - CMMC Phase II was suspended on Jul 13 2026, so there is no DC-area defense-contractor compliance idea for now.
- Market sizes are mostly labeled estimates.
- None of this is legal or financial advice. Check the laws with counsel before building compliance features.

## Folder map
- `INDEX.md`: this file.
- `SaaS_Opportunities_Master.xlsx`: sortable ranking with **Read me**, **Ideas** and **States** tabs (States includes each state's top education ideas).
- `ideas/`: 106 idea files.
  - A–L: 12 categories.
  - R and P: books & readers, and parent-child education.
  - S1–S9: state-specific ideas.
- `states/`: 51 state files, plus the template.
- `_scoreboard.csv`, `_states_summary.csv` and `_states_edu_summary.csv`: the raw tables.
- `_state_leads_from_category_research.md`: every state law or lead the research found.
- `_TEMPLATE_AND_RUBRIC.md` and `_AGENT_BRIEF.md`: the method, so you can add more ideas the same way.
