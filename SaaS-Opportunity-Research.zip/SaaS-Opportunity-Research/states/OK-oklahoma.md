# Oklahoma (OK): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:**
  - 395,520 small businesses, 99.4% of Oklahoma businesses.
  - 706,906 small-business employees, **50.8% of Oklahoma employees** ([SBA Advocacy 2025 Oklahoma profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Oklahoma_2025-State-Profile.pdf)).
  - **Veterans own 7.4% of businesses**, above Texas's 5.6%. Women own 44.7% and Hispanic owners 8.6% (same source).
- **New-business momentum:**
  - Mar 2023–Mar 2024: 13,472 establishments opened and 11,896 closed, a net gain of 1,576.
  - Small businesses added a net 16,295 jobs, 80.0% of all net new jobs.
  - Banks lent $1.1B to firms with revenue under $1M in 2023 (same SBA profile).
  - Census BFS state counts were not retrieved.
- **Buyer clusters:**
  - **Oklahoma City metro (incl. Moore, Norman, Edmond):** hail and tornado roofing and restoration, HVAC, the state agencies (CIB, OMMA, OID), churches, and oil and gas services.
  - **Tulsa:** energy services, aerospace MRO, trucking, churches and nonprofits.
  - **Lawton, Enid and the I-35/I-40 corridors:** trucking and ag services (inference).
  - **Tribal-nation economies** (Cherokee, Chickasaw, Choctaw) buy for hospitality and small enterprises (verify).
- **Industries overweight vs. US:** estimate, from SBA counts plus hail data.
  - **Construction** is the #1 small-business sector by count: 49,414 firms. It employs 65,233 people.
  - **Storm roofing:** Oklahoma was **#3 in the US for major hail events in 2025**, with 369 events ([III hail facts](https://www.iii.org/fact-statistic/facts-statistics-hail)). State Farm also named OK a top-5 hail-claims state.
  - **Health care** is the largest small-business employer, with 112,677 employees.
  - **Accommodation & food** employs 99,457 people.
  - **Medical-marijuana dispensaries** run on Metrc. Oklahoma's dispensary count is among the highest in the US (verify the count).
  - **Oil and gas field services** (verify).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Strengthen Oklahoma Homes (SOH).** Pays up to **$10,000 per home** for a FORTIFIED roof. Funds are **paid directly to the contractor after completion and submission of the FORTIFIED certification**. Homeowners choose from three qualified bidders. FORTIFIED-designated homes get discounts on the wind portion of their premiums ([OID OKReady](https://oid.ok.gov/okready/)). | Roofers (FORTIFIED-certified), evaluators | Periodic rounds; the program timeline runs Nov 2024–Jul 2026 and later | C02, **S4-01** |
| **CIB roofing contractor registration.** Requires $500,000 general liability for residential roofing. The commercial endorsement needs $1,000,000 and 4 hours of CE every 36 months. CIB is also rolling out 2026 building-code updates and **2027 proposed rule amendments** ([CIB roofing](https://oklahoma.gov/cib/your-industry/roofing.html), [CIB](https://oklahoma.gov/cib.html)). | Roofers, mechanical, electrical and plumbing trades | 2026–2027 | C02, C01, J06 |
| **SB 546 consumer data privacy.** Signed **Mar 20 2026**; the House passed it 84–4 and the Senate 38–7 ([LegiScan](https://legiscan.com/OK/bill/SB546/2026)). The effective date and applicability thresholds weren't shown (verify, likely 2027). | Larger online sellers and data-heavy SMBs | TBD (verify) | J02 |
| **Oklahoma Telephone Solicitation Act (HB 3168, 2022), a "mini-TCPA."** Background knowledge: requires prior express written consent for automated marketing calls and texts, limits calls to 8am–8pm and 3 per 24 hours, and gives consumers a private right of action (about $500 per violation) (verify). | Any SMB that texts Oklahoma consumers (home services, med spas, dealers) | In force since Nov 1 2022 (verify) | A03, B01, B04, B06 |
| **Parental Choice Tax Credit.** A refundable credit of **$5,000–$7,500** for private-school costs. Schools **register on OkTAP**, give each student an **Enrollment Verification Number**, and **checks are mailed to the school** ([Oklahoma Tax Commission](https://oklahoma.gov/tax/individuals/parental-choice-tax-credit.html)). | Private schools | Yearly | F06 |
| **OMMA seed-to-sale.** Tracking runs on Metrc, and embargoed product is blocked from sale automatically ([OMMA](https://oklahoma.gov/omma.html)). | Dispensaries, processors | In force | J04 |
| **IFTA Q3** | Carriers | Oct 31 2026 | K03 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | C02 (+ S4-01 module) | StormDesk + FortiFile | #3 hail state. SOH pays the **contractor** only once FORTIFIED documentation is certified, so photo and paperwork completeness is cash flow. Construction is the #1 small-business sector. |
| 2 | B04 | FirstCall | Highest national score (23). Construction-heavy buyers are paying Angi and Thumbtack. Lead flow is episodic after storms. |
| 3 | A03 | LocalLoop | Sells as the **mini-TCPA-safe** option: built-in consent capture, quiet hours and a 3-per-day cap. Podium and Birdeye don't market Oklahoma-specific guardrails (inference). |
| 4 | C01 | FlatRate | HVAC and plumbing in OKC and Tulsa. CIB-licensed trades. Oct–Feb off-season switch window. |
| 5 | I02 | TitheBox (vs Pushpay) | Dense Protestant congregation base (I02 names OK). The **Q4 giving season** is now. Pushpay's multi-year contracts are the pain point. |
| 6 | K03 | HaulDesk | I-35/I-40 freight corridors, energy hot-shot work and small fleets. IFTA is due Oct 31. |
| 7 | F06 | ESA Desk | Private schools must issue EVNs and reconcile tax-credit checks mailed to the school against tuition. The same product serves Texas TEFA across the Red River. |

## State-only opportunities
1. **FORTIFIED-grant roofer workflow** → full file at **ideas/S4-01-fortified-roof-grant-documentation.md**.
   - SOH ($10k per roof, paid to the contractor after certification) plus Louisiana's LFHP create a documentation-gated payment. General roofing CRMs don't center on it (inference).
2. **Mini-TCPA consent layer.** A cheap add-on to A03/B04/B06 that logs written consent, enforces 8am–8pm Oklahoma time and caps attempts at 3 per 24 hours (verify the statute details before shipping).
   - The same layer can be reused for Florida and Maryland (see state leads).
3. **Dispensary back office (J04 variant).** Oklahoma has one of the densest owner-operated dispensary markets on Metrc.
   - It is a weaker bet: national scoring was 14, and consolidation risk is high (verify current license counts and moratorium status).

## Where to sell
- **Associations & events** (background knowledge; verify names and vendor programs):
  - **Home services and construction:** Oklahoma Roofing Contractors Association, Oklahoma Home Builders Association, Oklahoma Association of REALTORS.
  - **Professional services:** Oklahoma Society of CPAs, Oklahoma Bar Association.
  - **Hospitality:** Oklahoma Restaurant Association, Oklahoma Hotel & Lodging Association.
  - **Energy, freight and cannabis:** Oklahoma Trucking Association, Oklahoma Independent Petroleum Association, Oklahoma cannabis trade associations.
  - **Churches and private schools:** Baptist General Convention of Oklahoma (churches), Oklahoma private and Christian school associations.
  - **Contractor lists:** FORTIFIED contractor and evaluator trainings run through IBHS and OID.
- **Online communities:** r/oklahoma, r/okc and r/tulsa; r/Roofing and r/HVAC during storm season; OKC and Tulsa small-business Facebook groups (verify names).
- **Partners:**
  - **Business support:** Oklahoma SBDC network (verify host), Greater OKC Chamber, Tulsa Regional Chamber, tribal small-business assistance centers (e.g. Cherokee Nation; verify).
  - **Supply houses:** roofing (ABC, SRS, QXO/Beacon) and HVAC.
  - **Insurance:** independent insurance agents, who explain FORTIFIED wind discounts to homeowners and can refer roofers.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | No statewide statute confirmed in this pass. State Board of Education rules on school library materials (2023–24) are to be verified. OK is on neither category-research list | Verify | R01, R07 |
| Science-of-reading law: **Strong Readers Act** (70 O.S. §1210.508A–E) as amended by **SB 1778** | SB 1778 was **signed Apr 21 2026**. Districts must employ reading specialists who complete a micro-credential "which will focus on the science of reading," with **$3,000 stipends**. It creates a **$43.75M Strong Readers Act Fund** (40% Tier 1, 30% Tier 2/3, 30% rewards), and literacy coaches grow from 5 to 20 ([Oklahoma Voice, Apr 21 2026](https://oklahomavoice.com/2026/04/21/oklahoma-governor-signs-landmark-childhood-reading-bill-into-law/)). The OSDE publishes a Strong Readers Family Guide and "Strategies and Activities for Reading at Home" ([OSDE](https://oklahoma.gov/education/services/literacy-policy-and-programs/strong-readers.html)). Three-cueing status to be verified | Signed Apr 21 2026 | P01, R08 |
| 3rd-grade reading plan / retention law | **From 2027–28**, third graders who score below basic and fail a second literacy assessment must repeat the grade, with limited exemptions. Schools must **notify parents within 30 days** of a reading deficiency and give **monthly progress updates** through improvement plans. Tier 2/3 help includes tutoring, summer programs and transitional classrooms ([Oklahoma Voice](https://oklahomavoice.com/2026/04/21/oklahoma-governor-signs-landmark-childhood-reading-bill-into-law/)) | 2027–28 | **P02**, R08, P04 |
| Homeschool rules (HSLDA tier: **none**) | No notice, assessment, teacher qualifications, mandated subjects or immunization rule. Compulsory ages 5–18 ([HSLDA OK](https://hslda.org/legal/oklahoma)) | In force | P03 (records only for the tax credit) |
| ESA / scholarship money that can buy books, curriculum, classes | **Parental Choice Tax Credit** (2023): refundable, **$5,000–$7,500** per private-school child (scaled to AGI) and **$1,000 per homeschooler**, with a separate **$5M annual homeschool cap**. **39,197 students** took part in 2025–26, and the program cap rises from $150M (TY2024) to **$250M (TY2026)**. Eligible uses include "tuition and fees, online education, tutoring, textbooks, curriculum and supplementary materials, and testing fees" but not therapies or transportation ([EdChoice](https://www.edchoice.org/school-choice/programs/oklahoma-parental-choice-tax-credit/)). OK also **opted in to the federal tax-credit scholarship** (IRS list, Jun 8 2026), which starts Jan 1 2027 ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | Yearly (tax-year cycle) | **P07**, P03, P04, R08 |
| Other | **Imagination Library statewide since 2020** (SB 1803), funded 50/50 public and private, with **$2.5M** in federal relief funds through FY2024 ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)). The post-relief state funding status needs verifying | 2020– | P06 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home:** SB 1778 requires a parent notice within 30 days and **monthly** progress updates, with retention starting 2027–28. That's a recurring parent-communication load no district template handles, so sell in 2026–27 before retention starts.
- **P07 LearnLedger:** homeschoolers claim a $1,000 refundable credit and private-school families $5k–$7.5k, and eligible spend (tutoring, curriculum, textbooks) needs receipts.
- **P03 HomeRoll:** there's no regulatory paperwork, but the tax credit and 2027 federal scholarships make a spend-and-records log useful.

**Where to sell:**
- **Libraries:** Oklahoma Library Association annual conference (spring, verify) and its school-librarian division (verify).
- **Families:** Oklahoma PTA; OSDE literacy office family-guide channels.
- **Homeschool groups:** Oklahoma Christian Home Educators' Consociation (OCHEC) (verify).
- **Reading groups:** IDA Oklahoma Branch (verify).
- **Booksellers:** Mountains & Plains Independent Booksellers Association (verify).

## Launch verdict
**Speed:** Medium.
- Faster in the Mar–Jun hail season and during SOH grant rounds.
- A small market overall, but storm spikes create urgency.

**First city:** Oklahoma City (Moore/Norman hail corridor).

**Lead offer:** C02 StormDesk with the FORTIFIED/SOH documentation module (S4-01). The pitch: "Get your SOH grant jobs certified and paid faster: unlimited canvassers, photo checklists matched to FORTIFIED steps, $199/mo flat."

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Oklahoma](https://advocacy.sba.gov/wp-content/uploads/2025/06/Oklahoma_2025-State-Profile.pdf)
- [Oklahoma Insurance Department: Strengthen Oklahoma Homes (OKReady)](https://oid.ok.gov/okready/)
- [Oklahoma Construction Industries Board: Roofing Contractor Registration](https://oklahoma.gov/cib/your-industry/roofing.html)
- [Oklahoma Construction Industries Board: home (2026 code updates, 2027 proposed rules)](https://oklahoma.gov/cib.html)
- [LegiScan: OK SB 546 (2026), data privacy, signed Mar 20 2026](https://legiscan.com/OK/bill/SB546/2026)
- [LegiScan: OK SB 546 (2025 session status)](https://legiscan.com/OK/bill/SB546/2025)
- [Oklahoma Tax Commission: Parental Choice Tax Credit](https://oklahoma.gov/tax/individuals/parental-choice-tax-credit.html)
- [Oklahoma Medical Marijuana Authority](https://oklahoma.gov/omma.html)
- [Insurance Information Institute: Facts + Statistics: Hail](https://www.iii.org/fact-statistic/facts-statistics-hail)
- Internal: ideas/A03, B04, C01, C02, I02, J02, J04, K03, F06; states/_state_leads (mini-TCPA lead)
- [Oklahoma Voice: governor signs SB 1778 reading bill (Apr 21 2026)](https://oklahomavoice.com/2026/04/21/oklahoma-governor-signs-landmark-childhood-reading-bill-into-law/)
- [OSDE: Strong Readers Act](https://oklahoma.gov/education/services/literacy-policy-and-programs/strong-readers.html)
- [EdChoice: Oklahoma Parental Choice Tax Credit](https://www.edchoice.org/school-choice/programs/oklahoma-parental-choice-tax-credit/)
- [HSLDA: Oklahoma homeschool law](https://hslda.org/legal/oklahoma)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
