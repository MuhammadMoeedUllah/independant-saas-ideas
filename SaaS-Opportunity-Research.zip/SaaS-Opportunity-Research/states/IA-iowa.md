# Iowa (IA): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 289,962 small businesses (99.3% of Iowa businesses) employing 637,557 people, or 46.0% of Iowa employees, above the national share. 61,829 small employer firms. Data year 2022. ([SBA Advocacy 2025 Iowa profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Iowa_2025-State-Profile.pdf))
- **New-business momentum:** Small businesses posted a net gain of 12,573 jobs from March 2023 to March 2024 ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Iowa_2025-State-Profile.pdf)). The largest small-business employers are health care and social assistance (108,949), accommodation and food services (84,051) and construction (60,604). Census BFS application trend was not fetched in this pass.
- **Buyer clusters:**
  - **Des Moines metro:** insurance and financial services, construction, restaurants, private schools.
  - **Cedar Rapids and Iowa City:** health care, trades, derecho/hail roofing.
  - **Quad Cities (Davenport):** trucking and logistics, manufacturing suppliers.
  - **Sioux City:** meatpacking suppliers, trucking.
  - **Waterloo/Cedar Falls and Ames:** university towns with restaurants and services.
  - **Rural Iowa:** co-ops, grain elevators, ag-equipment dealers, custom applicators, small-town restaurants and bars.
  - **I-80/I-35 corridor:** owner-operator trucking.
- **Industries overweight vs. US:** agriculture and ag retail/co-ops, accommodation and food services (#2 small-business employer), trucking, insurance, and nonpublic (mostly faith-based) schools, now funded by a universal ESA. Overweights are estimates from SBA ranks and cluster analysis.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Students First Education Savings Accounts:** universal from 2025-26 for all Iowa K-12 residents, **$8,148 per student for 2026-27**, administered by **Odyssey**. Funds go first to tuition and fees at accredited nonpublic schools; any remaining balance can be spent on eligible expenses in a marketplace. | Accredited nonpublic schools (tuition billing and reconciliation). Tutors and vendors only for leftover balances. | 2026-27 applications ran Apr 16–Jun 30 2026. Fall funds released Jul 15 2026. **Tuition/fee confirmation was due Sep 30 2026.** | F06 (F07 is secondary) |
| **Pesticide handler certification and Category 12 soil fumigation:** testing began Jul 15 2026. The COVID-era unproctored private applicator exam ended Dec 31 2025. | Ag retailers, custom applicators, handlers | Jul 15 2026 | C03 (regional ag edition) |
| **Iowa Consumer Data Protection Act** | Large controllers (high consumer thresholds, so most SMBs are exempt; verify) | Jan 1 2025 (per J02) | J02 (weak for SMBs) |
| **Sales tax:** remote-seller 200-transaction test dropped (per J01) | Iowa e-commerce and remote sellers | In force (date: verify) | J01 |
| **IFTA quarterly return** | Interstate carriers (a large Iowa base) | **Oct 31 2026**, then Jan 31 | K03 |
| **Medicaid EVV:** sources conflict (CareBridge MCO model vs Sandata closed model) | Home care agencies | In force | E07 (weak until confirmed) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall | Highest overall score (23). Construction is the #3 small-business employer. Rural and small-metro trades overpay Angi and LSA for scarce leads. |
| 2 | A03 | LocalLoop | Score 22. Iowa's big restaurant, clinic and auto base, plus small-town word-of-mouth economies, run on reviews and texting. |
| 3 | F06 | ESA Desk | Universal ESA through Odyssey, $8,148 per student, and money that must flow through nonpublic-school tuition first. Iowa private schools now need clean tuition, fee and ESA reconciliation. This is the state-only hook. |
| 4 | K03 | HaulDesk | Dense small-carrier and owner-operator base along I-80/I-35, plus ag hauling. IFTA is due Oct 31 2026 and DAT renewals are rising 25–45%. |
| 5 | C03 | SprayLog (ag + lawn edition) | Iowa has one of the largest commercial-applicator bases in the US (verify count). The new handler category makes certification and records tracking timely. |
| 6 | F01 | Chairly | Score 22. Salon and barber owners in every county seat. Fresha and Vagaro fee anger is national. |
| 7 | C02 | StormDesk | Derecho and hail exposure (Cedar Rapids 2020 derecho; verify). The Oct–Feb off-season is the roofing CRM re-evaluation window. |

Close alternates: D02 DirectPlate for small-town restaurants, I02 TitheBox for churches in Q4 giving season.

## State-only opportunities
1. **ESA tuition reconciliation for Iowa nonpublic schools (F06 Iowa edition).** Match each ESA student's Odyssey award to the tuition and fee invoice, handle the Sep 30 confirmation and the mid-year changes, and show families their leftover marketplace balance. Buyers are small parochial and Christian schools where the principal or business manager decides. It sells ahead of the 2027-28 application window, which opened Apr 16 in 2026.
2. **Ag custom-applicator records and billing (regional).** Co-op and independent custom applicators, and a fast-growing group of drone spray operators, need field-level application records, customer copies, per-acre invoicing and certification/handler tracking. FAA 14 CFR 137.71 also requires aerial operators to keep customer, date, material and quantity records for 12 months. Incumbent ag-retail ERPs are enterprise-priced (not verified). Candidate for a separate idea file after complaint research.

## Where to sell
- **Associations & events** (from knowledge, verify):
  - Iowa Restaurant Association
  - Home Builders Association of Iowa and Master Builders of Iowa
  - Iowa Association of REALTORS
  - Iowa Society of CPAs
  - Iowa State Bar Association
  - Iowa Dental Association
  - Iowa Motor Truck Association
  - Agribusiness Association of Iowa (winter convention/expo)
  - Iowa Catholic Conference and diocesan school offices, plus Iowa Christian school networks (ESA)
  - Farm Progress Show (in Boone in alternating years)
- **Online communities:** r/Iowa, r/desmoines, r/CedarRapids, r/iowacity, r/QuadCities. Iowa ESA parent Facebook groups (verify).
- **Partners:**
  - America's SBDC Iowa
  - ISU Extension (ag and small business)
  - Iowa Credit Union League member CUs
  - Farm Credit Services of America
  - Rural bankers
  - Trucking insurance agents and IFTA filing services

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials law: SF 496 (2023)** | Schools must keep library materials age-appropriate and remove books with depictions of sex acts, and librarians can be held liable for noncompliance. The law also limits K–6 instruction on gender identity and sexual orientation. More than 3,400 titles were removed at first. In early **Apr 2026** (Apr 6 or Apr 9, depending on source) an Eighth Circuit panel reversed the injunction, so the law can be enforced. The case returns to district court, and the plaintiffs are weighing next steps ([Publishing Perspectives, Apr 2026](https://publishingperspectives.com/2026/04/u-s-appeals-courts-deals-a-blow-to-the-freedom-to-read/); [PEN America, Dec 18 2025](https://pen.org/report/the-bills-igniting-book-bans/)) | Enforceable since Apr 2026 | R01, R07 |
| **Science of reading and three-cueing ban** | **HF 2545** requires "systematic and sequential" literacy instruction and bans the three-cueing system. Teacher-prep programs must align to the science of reading, and candidates must pass the Foundations of Reading test. Iowa Code 279.68 (as amended by HF 2618 and HF 784) requires universal screening and progress monitoring from an approved list for 2025–26 ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/iowa/)). Enactment years were not shown (verify; likely 2024) | In force | P01, R08 |
| **3rd-grade reading plan or retention law** | Conditional retention, per category research. The summer-reading and retention details under 279.68 were not on the fetched page (verify) | In force (verify) | P02 |
| **Homeschool: five options** | Options range from "no notice, low regulation" (independent private instruction) upward. Notice is required except for options 1–2, and assessment only for option 4 ([HSLDA Iowa](https://hslda.org/legal/iowa)) | In force | P03 |
| **ESA and scholarship money** | **Students First ESA:** universal, **$8,148 for 2026–27**, run through Odyssey. Funds pay nonpublic tuition first, then marketplace items (see table above). Homeschool use is unclear (verify). **HF 2078 (2026)**, a $4,000 refundable credit for families switching to private or home school, was not enacted ([FutureEd](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). Iowa opted in to the federal tax-credit scholarship on Jan 5 2026 ([Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)). The state Tuition and Textbook Credit amounts were not checked (verify) | 2026–27; federal credit 2027 | F06, P07, P04, R05 |
| **Other: library funding** | A small Iowa library district paid **$1,430/yr** for Beanstack using an Enrich Iowa state grant (R02 evidence) | 2025 | R02, R03 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf:** SF 496 book provisions have been enforceable again since Apr 2026, so school libraries need an auditable record of every review and removal decision (neutral compliance log).
- **R07 ReadClear:** neutral content descriptors help reviewers apply the "depictions of sex acts" test the same way every time.
- **R02 ReadRally:** small libraries paying $1,430/yr for Beanstack out of state grants are price-sensitive switchers.

**Where to sell:**
- **Libraries:** Iowa Library Association annual conference (October; verify) and the Iowa Association of School Librarians (IASL; verify).
- **Parents:** Iowa PTA.
- **Homeschool:** Network of Iowa Christian Home Educators (NICHE; verify).
- **Reading specialists:** IDA Iowa branch (verify).
- **Booksellers:** the Midwest Independent Booksellers Association (MIBA; verify its current name).

## Launch verdict
**Speed:** Medium. **First city:** Des Moines. **Lead offer:** F06 ESA Desk: "Odyssey ESA + tuition reconciliation for Iowa private schools." Schools just went through the Sep 30 2026 confirmation crunch; sell before spring disbursements and 2027-28 re-enrollment. Pair it with B04 FirstCall and K03 HaulDesk (IFTA Oct 31) for volume.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Iowa](https://advocacy.sba.gov/wp-content/uploads/2025/06/Iowa_2025-State-Profile.pdf)
- [Iowa Dept. of Education, Students First Education Savings Accounts](https://educate.iowa.gov/pk-12/educational-choice/education-savings-accounts)
- [Iowa Dept. of Agriculture & Land Stewardship, Applicator Licensing & Certification](https://iowaagriculture.gov/pesticide-bureau/applicator-licensing-certification)
- [Iowa Dept. of Agriculture & Land Stewardship, Pesticide Bureau](https://iowaagriculture.gov/pesticide-bureau)
- [14 CFR 137.71, agricultural aircraft operator records (eCFR)](https://www.ecfr.gov/current/title-14/chapter-I/subchapter-G/part-137/subpart-D/section-137.71)
- Internal: ../ideas/F06, F07, J01, J02, K03, C03, E07 idea files; ../_state_leads_from_category_research.md
- [Publishing Perspectives: US appeals court ruling on Iowa SF 496 (Apr 2026)](https://publishingperspectives.com/2026/04/u-s-appeals-courts-deals-a-blow-to-the-freedom-to-read/)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [The Reading League Compass: Iowa](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/iowa/)
- [HSLDA: Iowa homeschool law](https://hslda.org/legal/iowa)
- [FutureEd: 2026 private school choice bill tracker (Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
- [Ballotpedia: Federal K-12 tax credit scholarship participation](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- Internal: ../ideas/R01, R02, R07
