# Utah (UT): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** **371,569** small businesses, 99.4% of Utah firms. They employ **690,069** people, or **45.4%** of Utah employees. **294,809** have no employees ([SBA Advocacy 2026 Utah profile, Sep 2026](https://advocacy.sba.gov/wp-content/uploads/2026/09/Utah.pdf); [2025 profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Utah_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Small businesses opened **15,459** establishments and added **15,508 net jobs** (Mar 2024–Mar 2025). That is the strongest net small-business job gain of the eight states in this batch ([SBA 2026 profile](https://advocacy.sba.gov/wp-content/uploads/2026/09/Utah.pdf)).
  - Most common small-business types by count:
    - Professional, scientific and technical services: 62,543
    - Real estate and rental: 48,058
    - Construction: 35,362
- **Buyer clusters (estimate):**
  - **Utah County / "Silicon Slopes"** (Lehi, Provo, Orem, American Fork): home of **Podium** ([BBB lists Podium in Lehi](https://www.bbb.org/us/ut/lehi/profile/sales-lead-generation/podium-1166-90023083/complaints), via A03), plus Weave (dental comms), Canopy (tax-practice software), Entrata (multifamily PM), BambooHR (Lindon) and Filevine (Salt Lake City) (verify each). Also the direct-sales/MLM and course-creator economy (Nu Skin, Young Living, doTERRA; verify), and door-to-door pest control and solar sales companies (e.g., Aptive, Provo; verify).
  - **Salt Lake Valley:** trades, real estate, law and CPA firms, restaurants.
  - **Davis/Weber (Ogden) and St. George:** fast-growing suburbs with new-home construction, HVAC, and St. George snowbird/STR demand.
  - **Park City, Moab, Zion/Springdale:** tours, rafting and jeep outfitters, STRs, lodging.
- **Industries overweight vs. US (estimate):**
  - Professional and technical services (the #1 small-business category here)
  - Real estate and rentals
  - Construction
  - Kids' activities and youth sports: the youngest state with the largest households (verify)
  - Direct sales and online courses
  - Pest control (door-to-door sales model)

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Utah Fits All scholarship (ESA):** **up to $8,000/yr** per student. 2026–27 cycle: new-student applications Apr 1–May 1, private school selection by Jun 15, awards Jun 16, funds released **Jul 15** ([Utah Fits All](https://www.utaheducationfitsall.org/)). Odyssey is the platform (per F06). The program site links to a **pending lawsuit**, so there is legal uncertainty (verify status). | Private schools, microschools, tutors, therapists, music teachers who serve ESA families | 2026–27 funds flowing; next cycle opens Mar 1 2027 | **F06** ESA Desk, **F07** LessonLedger |
| **Utah Consumer Privacy Act** (in force Dec 31 2023; thresholds $25M revenue plus 100k consumers, so few SMBs) (verify) | Larger e-commerce/DTC | In force | **J02** (low for SMBs) |
| **Utah AI Policy Act** (SB 149, 2024; narrowed 2025). Disclosure of generative-AI interactions, stricter for regulated occupations (verify) | Clinics, law and CPA firms, contractors using AI chat or voice receptionists | In force (sunset/extension, verify) | Feature for **A03**, **B06**, **E08**: an "AI disclosure" toggle |
| **Remote-seller nexus.** Utah dropped the 200-transaction test (per the state-leads file) (verify) | E-commerce/DTC sellers (Utah has many) | In force | **J01** NexusBook, **L03** |
| **FinCEN BOI domestic exemption, final Aug 11 2026** ([FinCEN](https://www.fincen.gov/boi), via J06). Utah annual renewals still apply (verify). | All LLCs | Now | **J06** |
| **Tax pre-season**: CPA and EA firms pick practice tools Oct–Dec (per G03) | CPA, EA and bookkeeping firms | Oct–Dec 2026 | **G03** SeasonDesk |

Utah has comparatively **few** new SMB compliance mandates: minimum wage stays at the federal level and there is no state pay-transparency or paid-leave program (verify). The Utah pitch is **price, contracts and bad vendor behavior**, not a law deadline.

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **A03** | LocalLoop (vs Podium/Birdeye) | Podium's home turf. Utah businesses got the densest Podium sales coverage, so they carry the densest pool of 12-month auto-renew contracts. BBB shows 64 complaints in 3 years (per A03). Hire ex-Podium reps who know the objections. Scoreboard 22. |
| 2 | **B04** | FirstCall (owned leads) | Construction is the #3 small-business category here, with new-home growth in Utah County, Davis and St. George. Scoreboard 23. |
| 3 | **A06** | Coursehouse (vs Kajabi/Teachable) | A06 names UT and AZ as coaching and MLM-adjacent creator hubs. The Kajabi +20–25% hike (Jan 13 2026, not grandfathered) is a live grievance. |
| 4 | **F03** | RecitalReady (dance/gym/martial arts) | F03 names Utah as a family-heavy market. Large households mean high per-family enrollment, sibling discounts and multi-kid billing, which is where per-student tiers hurt. |
| 5 | **C03** | SprayLog (pest control vs PestPac/FieldRoutes) | Utah's door-to-door pest-control model produces many small spin-off companies, often founded by former reps, that buy FieldRoutes on 3-year contracts (verify cluster). Summer-sales companies re-tool in fall and winter. |
| 6 | **F06** | ESA Desk | Utah Fits All ($8k) on Odyssey. Utah runs on Odyssey, so the same invoice engine as TX TEFA. Growth is capped by the lawsuit risk (verify). |
| 7 | **G03** | SeasonDesk (vs TaxDome/Karbon/Canopy) | **Oct–Dec is the pre-season switch window now.** Canopy is based in Lehi (verify), and TaxDome went from $600 to $1,000 per seat. Utah has many small CPA/EA firms serving its large professional-services base. |

Runners-up: **E03** Bitewing (Weave is Lehi-based, verify; Weave renewals +15–25%), **I05** ClubHouse (youth sports), **F07** LessonLedger (ESA piano and tutoring).

## State-only opportunities
1. **"Silicon Slopes" talent and switcher arbitrage (GTM, not a product).** Utah is where Podium, Weave and Canopy (verify) trained thousands of SMB SaaS sellers and CSMs. Hire experienced ex-incumbent reps and CSMs on commission to run "exit-your-contract" campaigns across A03, E03 and G03. Their customer lists are not ours to use, but their know-how about renewal windows and objections is.
2. **Direct-sales/MLM distributor toolkit (A06 + B01 variant).** Thousands of independent distributors and coaches in Utah County need a cheap course/community space and compliant email/SMS. The MLM parent companies' own back offices don't cover the distributor's personal brand. This is a niche wedge for A06, not a separate file.
3. **Door-to-door pest spin-off starter pack (C03 variant).** Summer-sales pest companies launch new micro-brands every year. A "start your pest company" bundle of route plus pesticide-application records, contract e-sign and autopay, priced at $99/mo with no contract, beats 3-year FieldRoutes deals (verify local cluster size).

## Where to sell
- **Associations & events (verify names/dates):**
  - Silicon Slopes (Silicon Slopes Summit)
  - Utah Restaurant Association
  - Utah Hotel & Lodging Association
  - Utah Apartment Association
  - Utah Association of REALTORS
  - Utah Association of CPAs (UACPA)
  - Utah State Bar
  - Utah Dental Association
  - Utah Home Builders Association and the Salt Lake Home Builders Association Parade of Homes
  - Utah Pest Control Association
  - Utah Private School Association and Utah Fits All provider sessions
  - Western Hunting & Conservation Expo (Salt Lake City, Feb) for the outfitter wedge (see S7-01)
- **Online communities:**
  - Reddit: r/Utah, r/SaltLakeCity, r/Provo, r/utahcounty, r/StGeorge, r/sales (ex-Podium reps)
  - Facebook: Utah Fits All parent groups, Utah dance-studio owners, Utah County small-business groups
- **Partners:**
  - Utah SBDC (Salt Lake Community College) and the Salt Lake Chamber
  - Mountain America and America First credit unions, Zions Bank (verify)
  - Local fractional-CFO and bookkeeping firms
  - Web agencies that serve Utah home-services companies

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials law: HB 29 (2024)** | A statewide removal ("trigger") mechanism: once a set number of districts remove a title, it comes out statewide. PEN counted **19 titles** removed statewide as of Dec 2025 ([PEN America, Dec 2025](https://pen.org/report/the-bills-igniting-book-bans/)). The earlier "sensitive materials" law, HB 374 (2022), is from background knowledge (verify). | 2024 → list grows | R01, R07 |
| **Science-of-reading law: SB 241 (2026)** | **Curriculum:** schools must adopt science-of-reading curriculum and interventions. **Evaluations:** teachers' and principals' science-of-reading skill becomes part of their annual evaluations. **Testing:** Acadience benchmark testing expands to kindergarten ([Moab Times, Feb 18 2026](https://www.moabtimes.com/articles/heres-a-breakdown-of-utahs-sweeping-plan-to-hold-back-struggling-third-grade-readers/); [Kane County SD, Mar 10 2026](https://kanek12.org/2026/03/10/sb241s1-new-early-childhood-literacy/)). A three-cueing ban was not confirmed (verify). | 2026 → | P01, R08 |
| **3rd-grade reading plan / retention: SB 241 (2026)** | **Plans and notices:** individualized reading plans for students below benchmark, and written parent notice each time a K–3 student scores "below" or "well below" (Moab Times, which describes the Feb 2026 draft). **Retention:** 3rd graders who miss the end-of-year benchmark are held back starting **2029–30**. Parents can appeal to USBE, and English learners and students with disabilities have exemptions. **Goal and funding:** 80% of 3rd graders reading on grade level by Jul 1 2030, with **$16M** for K–3 coaches and paraprofessionals (Kane County SD). | Plans now; retention 2029–30 | P02 |
| Homeschool (HSLDA tier: low, verify) | A single one-time notice to the district. No testing, subjects, credentials or annual renewal ([Libertas, 2026](https://libertas.institute/utah-school-choice/)). | n/a | P03 |
| **ESA: Utah Fits All (UFA)** | **2026–27 awards:** **$8,000** for private school, **$4,000** for home-based students aged 5–11 and **$6,000** for ages 12–18. **Program manager:** Odyssey, since May 16 2025. **Appropriation:** **$120M**. **Covered:** "textbooks, curricula, or other instructional materials," tutoring, software, hardware once every 3 years, therapies, and transport up to $750 ([UFA FAQ](https://www.utaheducationfitsall.org/faqs/)). **Court status:** the Utah Supreme Court let the program keep running during the appeal (as of Jan 2026) ([Libertas](https://libertas.institute/utah-school-choice/)). | 2026–27 funds released Jul 15 | P03, P04, P07, R05, R08 |
| Other | Utah has an app-store age-verification law similar to Texas's (via P07). No state Imagination Library funding was found in this pass (verify). | n/a | P07 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll.** Home-based UFA money ($4k–$6k per child, on Odyssey) turns a low-regulation state into a receipt-and-records market.
- **P02 ReadingPlan Home.** SB 241's reading plans and "below benchmark" parent letters start now, well before retention bites in 2029–30.
- **R08 Readlings.** UFA explicitly pays for software and instructional materials, and SB 241 pushes districts toward science-of-reading practice at home.

**Where to sell** (names from background knowledge; verify months):
- Utah Library Association (spring conference) and Utah Educational Library Media Association (UELMA).
- Utah PTA.
- Utah Home Education Association and UFA parent Facebook groups.
- Decoding Dyslexia Utah, and IDA or Reading League chapters (verify).
- Mountains & Plains Independent Booksellers Association.

## Launch verdict
**Speed:** Fast. The buyer pool is mid-sized, but Utah is the densest source of unhappy Podium customers and experienced SMB-SaaS sellers. **First city:** Lehi/Provo (Utah County), then Salt Lake City.

**Lead offer:** **A03 LocalLoop**. The hook: "Podium's backyard deserves a flat $99: free contract-exit letter plus your reviews and texting moved in 10 minutes."

## Sources
- [SBA Office of Advocacy, 2026 Small Business Profile: Utah (Sep 2026)](https://advocacy.sba.gov/wp-content/uploads/2026/09/Utah.pdf)
- [SBA Office of Advocacy, 2025 Utah profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Utah_2025-State-Profile.pdf)
- [Utah Fits All scholarship: amounts, 2026–27 timeline, pending lawsuit link](https://www.utaheducationfitsall.org/)
- [BBB: Podium (Lehi, UT) complaints](https://www.bbb.org/us/ut/lehi/profile/sales-lead-generation/podium-1166-90023083/complaints) (via idea A03)
- [FinCEN BOI page](https://www.fincen.gov/boi) (via idea J06)
- Internal: ideas A03, A06, B04, C03, F03, F06, G03; `_state_leads_from_category_research.md`; `_scoreboard.csv`
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [Moab Times: Breakdown of Utah's plan to hold back struggling third-grade readers (Feb 18 2026)](https://www.moabtimes.com/articles/heres-a-breakdown-of-utahs-sweeping-plan-to-hold-back-struggling-third-grade-readers/)
- [Kane County School District: SB241S1 new early childhood literacy (Mar 10 2026)](https://kanek12.org/2026/03/10/sb241s1-new-early-childhood-literacy/)
- [Utah Fits All FAQs (Odyssey program manager, 2026–27 amounts, eligible expenses)](https://www.utaheducationfitsall.org/faqs/)
- [Libertas Institute: Utah school choice guide (2026)](https://libertas.institute/utah-school-choice/)
- Internal (education): ideas R01, R07, R08, P02, P03, P07
