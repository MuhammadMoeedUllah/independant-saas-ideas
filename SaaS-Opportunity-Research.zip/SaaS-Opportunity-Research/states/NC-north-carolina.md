# North Carolina (NC): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 1.1 million small businesses (99.6% of NC businesses) employ 1.8 million people, or 44.2% of NC employees. From Mar 2023 to Mar 2024, 38,748 establishments opened and 30,680 closed (net +8,068). Small firms produced a net 52,820 jobs, 89.9% of net job growth ([SBA Advocacy 2025 North Carolina profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/North_Carolina_2025-State-Profile.pdf)).
- **New-business momentum:**
  - **137,591 business applications in Jan–Aug 2026** (not seasonally adjusted), 3.2% of US applications, roughly in line with population share (verify) ([Census BFS monthly CSV](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)).
  - Small-business employment grew 19.1% from 1998 to 2022, above the US rate.
  - Most small-business employees: accommodation and food (276,148), health care (255,024) and retail (156,433) (SBA profile).
- **Buyer clusters:**
  - **Charlotte:** home services, banking and fintech, salon suites, logistics, churches.
  - **Raleigh-Durham (Triangle):** tech and life-science startups, remodelers, dental and medical practices, fast-growing suburbs (Cary, Apex, Wake Forest).
  - **Asheville/Western NC:** short-term rentals, tours, breweries, and the Hurricane Helene rebuild (Sep 2024; verify recovery status).
  - **Outer Banks and Wilmington:** vacation rentals, fishing charters, weddings.
  - **Pinehurst/Sandhills:** golf.
  - **Mountain resident camps.**
- **Industries overweight vs. US** (inference, verify):
  - Banking and fintech (Charlotte).
  - Life sciences and tech (Research Triangle).
  - Mountain and beach tourism.
  - Furniture and textile legacy manufacturing.
  - Golf.
  - Resident summer camps.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **G.S. 64-26, E-Verify** for employers with **25+ employees in NC** (G.S. 64-25 definition). Verification records must be kept while the person is employed plus one year ([64-26](https://www.ncleg.gov/EnactedLegislation/Statutes/HTML/BySection/Chapter_64/GS_64-26.html); [64-25](https://www.ncleg.gov/EnactedLegislation/Statutes/HTML/BySection/Chapter_64/GS_64-25.html)). | Employers with 25+ staff | In force | G04, J03, regional E-Verify kit |
| **Mechanics lien agent system (LiensNC, G.S. 44A Art. 2).** The system "allows (but does not require)" potential lien claimants to give notice they are working on a project ([LiensNC](https://www.liensnc.com/the-law.html)). From memory, verify: owners appoint a lien agent on qualifying projects of $40,000 or more, and a sub who skips the Notice to Lien Agent (within 15 days of first furnishing) can lose priority against later buyers and lenders. | Subcontractors, suppliers, remodelers | Ongoing | C06, C05 |
| **Sales-tax economic nexus:** the 200-transaction test was dropped, so the threshold is $100k in sales only (per J01 list; verify effective date, reportedly Jul 1 2024). | Remote sellers into NC | In force | J01 |
| **K-12 scholarships:** the Opportunity Scholarship (universal since 2024–25; verify) and **ESA+** for students with disabilities, with ESA+ paid through ClassWallet ([NCSEAA](https://k12.ncseaa.edu/); [GetESAPaid rail list](https://getesapaid.com/become-an-esa-vendor)). | Private schools, therapists and tutors (ESA+) | 2026–27 school year | F06, F07 |
| **Medicaid EVV:** Sandata is the state aggregator per E07. HHAeXchange runs separate NC info hubs for **Home Health, PHP and Tailored Plans** ([HHAeXchange hub](https://www.hhaexchange.com/info-hub)). | Home care, home health | Ongoing | E07 |
| **Minimum wage:** $7.25, no scheduled increase ([DOL](https://www.dol.gov/agencies/whd/minimum-wage/state)). | n/a | n/a | n/a |
| **No comprehensive privacy law** ([privacyterms.io](https://privacyterms.io/us-state-privacy-laws-2026)). | n/a | n/a | J02 weak |
| **Resident-camp licensing** (NC appears in the leads list; verify the statute and inspection cycle). | Summer camps | Sep–Dec is the only switch window before registration opens | I06 |
| **Hurricane season** (coast) and Helene-type inland flooding. | Roofers, restoration, remodelers | Jun 1–Nov 30 | C02, C07, C05 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture) | Charlotte and the Triangle are two of the fastest-growing Sun Belt metros, with many new-home suburbs and trades hungry for leads. Google LSA's Nov 2025 changes and Angi's exit fees are the hook. |
| 2 | A03 | LocalLoop (reviews and texting) | Home-service and dental density in Charlotte and Raleigh. Sell on price plus a no-auto-renew promise. |
| 3 | F01 | Chairly (salon/barber booking) | F01's research lists Charlotte among the leading salon-suite metros. The Fresha and Vagaro fee backlash is the switching window. |
| 4 | C05 | FlatBuild (remodeler PM) | Raleigh and Charlotte are named high-remodel metros in C05. CoConstruct stops new projects Mar 31 2027, forcing migrations, and Western NC rebuild work continues. |
| 5 | C06 | LienClock (lien deadlines) | NC's lien-agent notice is a state-specific step that subs skip. A lien-agent lookup plus notice tracker for NC, bundled with the deadline engine, is an easy local wedge. |
| 6 | H03 | StayDesk (STR PMS) | Asheville, Boone, the Outer Banks and Wilmington have many self-managing hosts and small managers. Airbnb's 15.5% host-only fee (Oct 27 2025) hits PMS-connected hosts. |
| 7 | I02 | TitheBox (church giving) | Dense Protestant congregations, and the Q4 giving season is the switch window now. |

Bench:
- **I06 CampFile:** mountain resident camps; the Sep–Dec window is open now.
- **D08 TeeFree:** Pinehurst and a high course count.
- **J01 NexusBook:** the dropped 200-transaction test.
- **D07 BookTrail:** Asheville and Outer Banks tours and charters.
- **G06 AdvisorVault:** Charlotte RIAs.

## State-only opportunities
1. **NC lien-agent notice module (C06 add-on).** Look up the project's lien agent, send and log the Notice to Lien Agent within the statutory window, then chain the standard NC notice and lien dates. Subs in the fast-growing Triangle and Charlotte building markets are the buyers. Verify the $40k threshold and 15-day rule before building.
2. **Western NC mountain STR plus tours bundle (H03 + D07).** Rebuild-era cabin rentals and outfitters around Asheville, Boone and the NC Smokies side (Bryson City, Cherokee area) share guests with TN's Smokies. One regional "Smokies" sales motion covers both states.
3. **Resident-camp registration and health-form suite (I06).** NC mountain camps must switch between Sep and Dec before registration opens. The only weak spot is the camp count, which is small.

## Where to sell
- **Associations & events** (verify names and dates):
  - **Hospitality:** NC Restaurant & Lodging Association.
  - **Building and real estate:** NC Home Builders Association, NC REALTORS.
  - **Professional:** NCACPA, NC Bar Association, NC Dental Society, NC Veterinary Medical Association.
  - **Health, trucking and camps:** Association for Home & Hospice Care of NC, NC Trucking Association, American Camp Association Southeastern.
  - **Local and general business:** Charlotte Regional Business Alliance, Greater Raleigh Chamber, NC Chamber.
- **Online communities:** r/Charlotte, r/raleigh, r/bullcity, r/asheville, r/northcarolina and r/OuterBanks; Triangle startup meetups (e.g., around American Underground, verify); Nextdoor; camp-director and STR-host Facebook groups (names not verified).
- **Partners:**
  - NC Small Business and Technology Development Center (SBTDC), the state's SBDC.
  - Community colleges' small-business centers (verify).
  - HVAC and plumbing supply houses.
  - Banks: Truist and First Citizens, both headquartered in NC.
  - Lien and construction attorneys.
  - Western NC recovery and tourism organizations.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law: **H 805, S.L. 2025-84** ("Prevent Sexual Exploitation/Women and Minors"), §3.3 | Local boards must adopt policies that (1) "Provide public access to the titles of library books available within each school" and (2) "Allow a parent of a student to identify library books that cannot be borrowed by the student." "Library books" cover print, electronic and non-print resources other than textbooks for independent use, and "can be held in a formal school library or in a classroom." The governor vetoed it Jul 3 2025, and the General Assembly overrode the veto on **Jul 29 2025**. It applies from **2025–26** ([NCGA session-law summary](https://dashboard.ncleg.gov/api/Services/BillSummary/2025/H805-SMRQ-85(sl)-v-3)). **Rollout:** New Hanover teachers enter classroom books into Destiny, spreadsheets or AI shelf-scanning apps and collect opt-outs on Google Forms. Some were told to close classroom libraries until cataloging was done ([WHQR, Aug 28 2025](https://www.whqr.org/local/2025-08-28/nhcs-teachers-scramble-to-comply-with-new-classroom-library-law)). One teacher scanned 800 of 1,300 books over "at least eight hours." In Catawba County, 2% of teachers didn't comply and their classroom libraries were closed ([Spectrum News, Nov 2025](https://spectrumlocalnews.com/nc/charlotte/news/2025/11/23/cataloging-classroom-libraries-)) | In force since 2025–26; new books and new teachers every year | **R01**, R07 |
| Science-of-reading / three-cueing law | Excellent Public Schools Act of 2021 (science of reading; LETRS training; verify the session-law number). Category research lists NC among the **three-cueing-ban** states. mCLASS (DIBELS 8) is the statewide K–5 assessment ([Amplify NC, via P02](https://amplify.com/northcarolina/)) | In force | P01, R08 |
| 3rd-grade reading plan / retention law: **Read to Achieve** (G.S. 115C-83.1 et seq.) | Third graders who aren't proficient are retained unless they earn a **good-cause exemption**: an alternative assessment (e.g., DIBELS 8), a reading portfolio, limited-English status, an IEP, or a prior retention. They are "invited to attend a district-sponsored reading camp prior to retention." Parents "will be notified in writing of student retention and why the student is not eligible for a good cause exemption" ([NC DPI RtA](https://www.dpi.nc.gov/districts-schools/accountability-and-testing/state-tests/grade-3-read-achieve-rta); [Nash County PS](https://www.ncpschools.net/departments/academic-services-accountability/read-to-achieve)). NC is on the category-research **mandatory retention** list | Every spring and summer (camp before retention) | **P02**, R08 |
| Homeschool rules (HSLDA tier: **low**, verify on the map) | A **notice of intent** to DNPE, "only required once, when you are establishing a new homeschool." The teacher needs "at least a high school diploma or its equivalent." Schools run on "a regular schedule for at least nine calendar months." A **nationally standardized test every year** covers "English grammar, reading, spelling, and mathematics," with results kept "one year after the testing." Families also keep attendance and immunization records ([HSLDA how-to-comply NC](https://hslda.org/post/how-to-comply-with-north-carolinas-homeschool-law)). Compulsory ages 7–16. HSLDA tracks SB 866 (verify content) ([HSLDA NC](https://hslda.org/legal/north-carolina)) | Annual test; records kept 1 year | **P03** |
| ESA / scholarship money that can buy books, curriculum, classes | **Opportunity Scholarships** (2013): universal eligibility but not universal funding, "about $3,500 to $7,700 based on family income." **103,400 students at 696 schools in 2025–26** ([EdChoice](https://www.edchoice.org/school-choice/programs/north-carolina-opportunity-scholarships/)). **ESA+:** a "$9,000 annual award," or **$17,000** for certain disabilities. Homeschoolers are **eligible**, funds go through **ClassWallet**, and it covers tutoring, speech therapy and ed-tech, plus **art and music tutoring from 2026–27**. The 2026–27 application window ran **Feb 2–Mar 2** ([NCSEAA ESA+](https://k12.ncseaa.edu/the-education-student-accounts)). **Federal tax-credit scholarship:** Ballotpedia lists NC as declined (Aug 6 2025 entry), and it's not on the IRS list of 27 states as of Jun 8 2026 (verify any legislative push) | ESA+ 2027–28 window ~Feb 2027 (verify) | P03, P07, P04, R08 |
| Other | **Imagination Library statewide since 2017** (SB 257 directed funds to DHHS) ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)). The current state share isn't confirmed (verify, given 2025–26 cuts elsewhere) | 2017– | P06 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf:** H 805 turned every classroom bookshelf into a public catalog with parent block lists. Teachers are scanning books by hand, and some classroom libraries closed. A phone shelf-scan tool that publishes a parent-searchable catalog and enforces opt-outs at checkout is the sharpest law-driven education buy we found in this batch.
- **P02 ReadingPlan Home:** Read to Achieve has mandatory retention, reading camps and written parent notices. Add a parent-facing plan and home practice layer that sits beside mCLASS Home Connect.
- **P03 HomeRoll:** NC homeschool families need an annual standardized test plus attendance and immunization records. ESA+ homeschoolers also need ClassWallet receipts (P07 module).

**Where to sell:**
- **School libraries:** NC School Library Media Association conference (fall, verify); NCSBA policy services.
- **Public libraries:** NC Library Association (biennial conference, verify year and month).
- **Families:** NC PTA.
- **Homeschool groups:** North Carolinians for Home Education (NCHE) annual conference (late spring, verify).
- **Reading groups:** The Reading League North Carolina; IDA branch covering NC (verify).
- **Booksellers:** Southern Independent Booksellers Alliance (verify).

## Launch verdict
**Speed:** Medium-Fast. **First city:** Charlotte, then Raleigh-Durham. **Lead offer:** FirstCall (B04) for trades in new-build suburbs. In the Triangle, add FlatBuild (C05) with a "CoConstruct refugee" free-migration offer ahead of the Mar 31 2027 cutoff.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: North Carolina](https://advocacy.sba.gov/wp-content/uploads/2025/06/North_Carolina_2025-State-Profile.pdf)
- [US Census Bureau, Business Formation Statistics monthly CSV (Jan–Aug 2026)](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)
- [N.C. Gen. Stat. 64-26, E-Verify](https://www.ncleg.gov/EnactedLegislation/Statutes/HTML/BySection/Chapter_64/GS_64-26.html)
- [N.C. Gen. Stat. 64-25, definitions](https://www.ncleg.gov/EnactedLegislation/Statutes/HTML/BySection/Chapter_64/GS_64-25.html)
- [LiensNC, the law](https://www.liensnc.com/the-law.html)
- [NCSEAA K-12 scholarships](https://k12.ncseaa.edu/)
- [GetESAPaid, ESA payment rails by state](https://getesapaid.com/become-an-esa-vendor)
- [HHAeXchange information hub (NC Home Health, PHP, Tailored Plans)](https://www.hhaexchange.com/info-hub)
- [US DOL, state minimum wage table](https://www.dol.gov/agencies/whd/minimum-wage/state)
- [privacyterms.io, US state privacy laws 2026](https://privacyterms.io/us-state-privacy-laws-2026)
- [NCGA: H 805 / S.L. 2025-84 session-law summary](https://dashboard.ncleg.gov/api/Services/BillSummary/2025/H805-SMRQ-85(sl)-v-3)
- [WHQR: NHCS teachers scramble to comply with classroom library law (Aug 28 2025)](https://www.whqr.org/local/2025-08-28/nhcs-teachers-scramble-to-comply-with-new-classroom-library-law)
- [Spectrum News: new law requires cataloging classroom libraries (Nov 2025)](https://spectrumlocalnews.com/nc/charlotte/news/2025/11/23/cataloging-classroom-libraries-)
- [NC DPI: Grade 3 Read to Achieve](https://www.dpi.nc.gov/districts-schools/accountability-and-testing/state-tests/grade-3-read-achieve-rta)
- [Nash County Public Schools: Read to Achieve](https://www.ncpschools.net/departments/academic-services-accountability/read-to-achieve)
- [HSLDA: How to comply with North Carolina's homeschool law](https://hslda.org/post/how-to-comply-with-north-carolinas-homeschool-law)
- [HSLDA: North Carolina homeschool law](https://hslda.org/legal/north-carolina)
- [EdChoice: North Carolina Opportunity Scholarships](https://www.edchoice.org/school-choice/programs/north-carolina-opportunity-scholarships/)
- [NCSEAA: Education Student Accounts (ESA+) 2026-27](https://k12.ncseaa.edu/the-education-student-accounts)
- [Ballotpedia: state participation in the federal K-12 tax credit scholarship program](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
