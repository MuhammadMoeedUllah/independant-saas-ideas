# Maryland (MD): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 696,710 small businesses (99.6% of MD businesses), employing 1.2 million people (47.9% of private employees). 586,327 are nonemployer firms ([SBA Advocacy 2025 MD profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Maryland_2025-State-Profile.pdf)).
- **New-business momentum:**
  - From Mar 2023 to Mar 2024, establishments had 17,678 openings and 15,270 closings.
  - Small businesses gained 172,789 jobs and lost 156,176, a net of +16,613 ([SBA Advocacy 2025](https://advocacy.sba.gov/wp-content/uploads/2025/06/Maryland_2025-State-Profile.pdf)).
  - Census BFS trend was not fetched in this pass.
- **Buyer clusters** (estimate, verify):
  - **Montgomery and Prince George's Counties** (DC suburbs): federal contractors, IT consultancies, clinics, associations, immigrant-owned restaurants and salons.
  - **Baltimore metro:** health care (Johns Hopkins ecosystem), trades, restaurants, nonprofits.
  - **Howard and Anne Arundel Counties** (Columbia, Fort Meade, Annapolis): cyber and defense subcontractors, marine trades.
  - **Ocean City and the Eastern Shore:** seasonal hospitality and short-term rentals.
  - **Frederick and Hagerstown:** logistics and trades.
- **Industries overweight vs. US** (estimate):
  - **Professional, scientific & technical services:** 106,969 small firms (the most of any sector) and 165,328 small-business employees. Driven by federal and IT contracting.
  - **Health care:** 178,430 small-business employees.
  - **Construction:** 134,309 small-business employees.
  - **Associations and nonprofits:** the DC-area association cluster.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **FAMLI (paid family and medical leave).** Contributions start Jan 1 2027 at 0.90% of wages, split 50/50. Employers with under 15 employees are exempt from the employer share but must still remit the employee share. Benefits start Jan 3 2028 ([OnPay, Jul 2026](https://onpay.com/insights/paid-family-leave-by-state/), via G04; verify on labor.maryland.gov, which returned 404 this pass). | Every MD employer | **Jan 1 2027**, about 14 weeks away | G04, J03 |
| **Stop the Spam Calls Act of 2023** (SB 90, Ch. 413). Restricts the methods, times and frequency of telephone solicitations, including automated texts. Violations count as unfair or deceptive trade practices ([MGA](https://mgaleg.maryland.gov/mgawebsite/Legislation/Details/sb0090?ys=2023RS)). Background, verify: calls allowed 8am–8pm only, max 3 per 24 hours, prior express written consent required for automated systems. | Any business that texts or calls MD consumers for marketing: home services, med spas, gyms, dealers | In force Jan 1 2024 | A03, B01, B06, B04 |
| **3% sales and use tax on data and IT services**, from the Budget Reconciliation and Financing Act of 2025 (HB 352, Ch. 604; approved May 20 2025) ([MGA bill](https://mgaleg.maryland.gov/mgawebsite/Legislation/Details/hb0352?ys=2025RS), [fiscal note](https://mgaleg.maryland.gov/2025RS/fnotes/bil_0002/hb0352.pdf)). Start date Jul 1 2025 (verify). | MD IT consultancies and SaaS or data vendors that must now collect and file; buyers that must self-assess use tax | In force (2025) | J01 |
| **Marketplaces collect county lodging taxes** ([Avalara MyLodgeTax, Nov 2025](https://www.avalara.com/mylodgetax/en/blog/2025/11/more-states-require-short-term-rental-marketplaces-like-airbnb-and-vrbo-to-collect-lodging-taxes.html)) | Short-term rental hosts and property managers (Ocean City, Deep Creek) | Jul 1 2027 | H03 |
| **Maryland Online Data Privacy Act (MODPA).** Unusually strict data-minimization rules ([J02](../ideas/J02-smb-privacy-cookie-accessibility-compliance-termly-osano-alternative.md); applicability thresholds: verify) | Businesses over the MD consumer thresholds | Oct 1 2025 | J02 |
| **Wage-range transparency in job postings** ([J03](../ideas/J03-smb-employment-law-posters-pay-transparency-poster-guard-mineral-alternative.md); verify) | All MD employers | In force since Oct 1 2024 | J03 |
| **Cannabis track-and-trace.** MD is a Metrc state ([Metrc](https://www.metrc.com/partners/)). | Licensed cannabis businesses | Ongoing | J04 |
| **CMMC.** Phase 1 self-assessments are live, but Phase II was suspended Jul 13 2026 ([DoD CIO](https://dodcio.defense.gov/CMMC/About/)). | Fort Meade and Aberdeen defense subcontractors | Paused; wait-and-see | (watch; L05 adjacent) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | G04 | StatePay (payroll state-compliance copilot) | FAMLI contributions start Jan 1 2027 for every MD employer, the biggest near-term deadline in the Mid-Atlantic. Q4 is also the natural payroll switch window. Webinar hook: "Maryland FAMLI employer checklist." |
| 2 | A03 | LocalLoop (reviews + texting) | MD's mini-TCPA makes "compliance-first texting" (consent log, quiet hours, frequency caps) a real differentiator over Podium/Birdeye. |
| 3 | B04 | FirstCall (owned lead capture) | Top score (23). Dense, high-income suburbs with 134k small-business construction employees. The owned-SMS follow-up must respect MD consent rules. |
| 4 | F01 | Chairly (salon/barber booking) | Dense immigrant-owned salons and barbershops in PG and Montgomery Counties. Commission and payout pain (F01). |
| 5 | J01 | NexusBook (sales-tax nexus and filing) | The 3% data/IT services tax turned thousands of MD IT and software firms, the state's largest small-business sector, into sales-tax filers. TaxJar's Oct 1 2026 repricing adds urgency. |
| 6 | I03 | DuesDesk (membership associations) | Associations cluster in the DC/MD/VA region (I03), and WildApricot keeps raising prices. |
| 7 | B01 | ListFair (email + SMS) | The Mailchimp free-plan cut (Feb 2026) plus MD text-consent rules. Built-in consent logging sells here. |

## State-only opportunities
1. **FAMLI readiness kit for sub-15-employee firms** (G04 lead magnet). It covers registration, employee-share withholding and notices before Jan 1 2027. Many micro-employers wrongly assume they are fully exempt. Sell via MACPA members and payroll bureaus. G04 covers the product, so there is no separate S2 file.
2. **MD 3% IT-services tax helper** (J01 "MD pack"). It tells a consultancy which service lines are taxable, handles registration and monthly/quarterly filing, and generates invoice language. Narrow but painful; confirm scope with the Comptroller before selling.
3. **Govcon small-subcontractor compliance** (CMMC Level 1 annual affirmation, SPRS score, SAM renewal). The need is regional, but the **Jul 13 2026 suspension of CMMC Phase II** stalls urgency. Revisit when the DoD reform task force reports.

## Where to sell
All association names below are from background knowledge (verify).
- **Associations & events:**
  - Maryland Chamber of Commerce; Restaurant Association of Maryland; Maryland Hotel & Lodging Association; Ocean City Hotel-Motel-Restaurant Association.
  - Maryland Association of CPAs (MACPA; the key FAMLI channel); Maryland State Bar Association.
  - Maryland Building Industry Association; Maryland Nonprofits; Maryland Tech Council.
- **Online communities:** r/maryland, r/baltimore, r/MontgomeryCountyMD, r/annapolis; county small-business Facebook groups; Montgomery County and Baltimore Nextdoor business pages.
- **Partners:** Maryland SBDC (University of Maryland network); Montgomery County and Prince George's County economic development corporations; payroll bureaus and CPAs (FAMLI); community banks; Maryland Tech Council for the IT-services tax angle.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **Freedom-to-read law: Freedom to Read Act (HB 785, 2024)** | Covers both school and public libraries ([Book Riot, Aug 2026](https://bookriot.com/massachusetts-passes-freedom-to-read-law/); [EdWeek, Jan 7 2026](https://www.edweek.org/policy-politics/states-are-banning-book-bans-will-it-work/2026/01)). Libraries need written collection-development and reconsideration policies, and staff are protected (verify details and effective date) | 2024 (verify) | R01, R03 |
| **Science of reading** | Maryland has layered screening and literacy rules ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/maryland/)):<br>• **Ready to Read Act (2019):** kindergarten screening 3 times a year, with supplemental instruction and family communication.<br>• **COMAR 13A.03.08:** extends screening to grades 1–3 and adds progress monitoring and reporting.<br>• **Blueprint:** local literacy plans and science-of-reading training for PreK–3 staff.<br>• **State Board PreK–3 policy:** bans guessing-based reading techniques ([Baltimore Banner, Aug 22 2024](https://www.thebanner.com/education/k-12-schools/maryland-literacy-policy-third-grade-3DYNYLJ3YJFW3HNHORGVCBWQEM/)).<br>An updated screener list was due fall 2025 | In force | P01, R08 |
| **3rd-grade retention (State Board literacy policy)** | Third graders who score **below 735 on MCAP** may be held back. Parents can instead choose promotion with supplemental support (summer school, before- or after-school tutoring). Schools must notify families **within 15 days** of a retention decision, and K–3 strugglers get intensive intervention until they read at grade level. Screening happens 3 times a year, and dyslexia screening yearly from kindergarten. The Banner (Aug 2024) says retention applies starting **2026–27**, while category research says 2027–28 (verify) | 2026–27 or 2027–28 (verify) | P02, P01 |
| **Homeschool** | Four options. Notice and state subjects are required, with no assessment ([HSLDA Maryland](https://hslda.org/legal/maryland)). HSLDA's scale was read as "low" but should be checked (verify). The portfolio-review and umbrella options are not detailed (verify) | In force | P03 |
| **ESA and scholarship money** | The BOOST voucher exists (funding level not checked; verify). **HB 1204 (2026)**, an income-based ESA, and **SB 329**, federal tax-credit participation, were not enacted ([FutureEd](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). Maryland is not on the IRS list (Jun 8 2026) | n/a | (P07 weak) |
| **Other: subscriptions** | Maryland's automatic-renewal law takes effect Jun 2026 (category research; verify). It affects family subscription products | Jun 2026 (verify) | R08, P07 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home:** retention decisions, 15-day notices and a parent choice between retention and supplemental support call for a clear family-facing plan and paper trail.
- **R01 ClearShelf:** the Freedom to Read Act requires written policies and a reconsideration process in school and public libraries.
- **P01 PhonicsPrep:** tutors deliver the before- and after-school and summer supplemental support that lets parents opt out of retention.

**Where to sell:**
- **Libraries:** Maryland Library Association (spring conference; verify) and the Maryland Association of School Librarians (MASL; verify).
- **Parents:** Maryland PTA.
- **Homeschool:** Maryland Association of Christian Home Educators (MACHE; verify).
- **Reading specialists:** IDA Maryland branch (verify).
- **Booksellers:** NAIBA (New Atlantic Independent Booksellers Association).

## Launch verdict
**Speed:** Fast, because FAMLI's Jan 1 2027 start forces action this quarter. **First city:** Baltimore, with a second push in Montgomery County (Rockville–Silver Spring–Bethesda). **Lead offer:** G04 StatePay's free "FAMLI-ready in 15 minutes" checker, upselling the flat-price compliance copilot. Cross-sell A03 LocalLoop as "Maryland-compliant texting."

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Maryland](https://advocacy.sba.gov/wp-content/uploads/2025/06/Maryland_2025-State-Profile.pdf)
- [MGA, SB 90 (2023), Stop the Spam Calls Act, Ch. 413](https://mgaleg.maryland.gov/mgawebsite/Legislation/Details/sb0090?ys=2023RS)
- [MGA, HB 352 (2025), Budget Reconciliation and Financing Act, Ch. 604](https://mgaleg.maryland.gov/mgawebsite/Legislation/Details/hb0352?ys=2025RS)
- [DLS fiscal and policy note, HB 352 (2025)](https://mgaleg.maryland.gov/2025RS/fnotes/bil_0002/hb0352.pdf)
- [OnPay, paid family leave by state (Jul 2026)](https://onpay.com/insights/paid-family-leave-by-state/)
- [Avalara MyLodgeTax, marketplaces collecting lodging taxes (Nov 2025)](https://www.avalara.com/mylodgetax/en/blog/2025/11/more-states-require-short-term-rental-marketplaces-like-airbnb-and-vrbo-to-collect-lodging-taxes.html)
- [DoD CIO, About CMMC (Phase II suspension Jul 13 2026)](https://dodcio.defense.gov/CMMC/About/)
- [Metrc partners/markets](https://www.metrc.com/partners/)
- [Baltimore Banner: Maryland literacy policy won't force retention (Aug 22 2024)](https://www.thebanner.com/education/k-12-schools/maryland-literacy-policy-third-grade-3DYNYLJ3YJFW3HNHORGVCBWQEM/)
- [The Reading League Compass: Maryland](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/maryland/)
- [Book Riot: Massachusetts passes freedom-to-read law, with list of states (Aug 2026)](https://bookriot.com/massachusetts-passes-freedom-to-read-law/)
- [EdWeek: States are banning book bans (Jan 7 2026)](https://www.edweek.org/policy-politics/states-are-banning-book-bans-will-it-work/2026/01)
- [HSLDA: Maryland homeschool law](https://hslda.org/legal/maryland)
- [FutureEd: 2026 private school choice bill tracker (Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
