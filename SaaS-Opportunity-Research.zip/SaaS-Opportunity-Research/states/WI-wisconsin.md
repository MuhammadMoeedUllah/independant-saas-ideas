# Wisconsin (WI): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 497,370 small businesses (99.4% of Wisconsin businesses). They employ 1.2 million people, or **48.0% of Wisconsin employees**, the highest small-business share of the five Great Lakes states in this pass ([SBA Advocacy 2025 Wisconsin profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Wisconsin_2025-State-Profile.pdf); counts use 2022 data).
- **New-business momentum:** Healthiest in the region relative to size.
  - From March 2023 to March 2024, 18,895 establishments opened and 16,828 closed, a net gain of 2,067. Small businesses accounted for 17,959 openings and 15,963 closings.
  - Small businesses added a net 15,910 jobs.
  - All figures are from the same SBA profile.
- **Buyer clusters** (metro detail is an estimate):
  - **Milwaukee:** manufacturing, breweries, restaurants, health care, condo associations.
  - **Madison:** state associations, the health-tech orbit, restaurants, condos.
  - **Green Bay and the Fox Valley:** paper and food manufacturing, trades.
  - **Wisconsin Dells:** waterpark resorts, independent motels, campgrounds (D05).
  - **Door County:** seasonal lodging, marinas, wineries, tours.
  - **Northwoods:** resorts, campgrounds, snowmobile tourism, resident summer camps (I06).
  - **La Crosse and Eau Claire:** regional services.
- **Industries overweight vs. US:**
  - **Manufacturing:** the #1 small-business employer, with 206,231 employees (SBA).
  - **Construction:** 55,387 firms, #2 by count (SBA).
  - **Accommodation and food:** 161,274 small-business employees (SBA). This includes supper clubs and resort towns.
  - **Seasonal tourism and outdoor recreation:** campgrounds, camps, marinas (D05, D06, I06).
  - **Dairy and food processing** (estimate).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Wis. Stat. §134.49, auto-renewal of *business* contracts:** covers service and equipment-lease contracts used mainly in Wisconsin. The contract must carry a signed disclosure or customer initials. When the initial term and the renewal term each exceed one year, written notice is due **15–60 days before the decline deadline**. If the seller fails, "an automatic renewal... is not enforceable" and the contract ends at term. The customer can recover 2× damages (up to $1,000) plus attorney fees. Some telecom services are excluded ([WI Legislature](https://docs.legis.wisconsin.gov/statutes/statutes/134/49)) | Every WI SMB locked into multi-year SaaS, marketing or equipment contracts (Podium, Birdeye, Yext, copier and POS leases, ELD contracts) | In force | A03, B05, K03, D01, D09 |
| **Wis. Stat. §703.20(1r):** condo associations with **100+ units** must keep a website with a protected owner area holding all records owners may inspect. Required since **Apr 1 2023** (2021 Act 166) ([WI Legislature](https://docs.legis.wisconsin.gov/statutes/statutes/703/20)) | Large condo associations and their managers (Milwaukee, Madison) | In force | H02 |
| **Medicaid EVV:** providers may use the DHS-provided Sandata system or **an alternate EVV system**. Personal and supportive home care hard launch was May 1 2023; home health hard launch was Oct 1 2024 ([WI DHS](https://www.dhs.wisconsin.gov/evv/index.htm)) | Home-care and home-health agencies | In force | E07 |
| **Sales tax:** Wisconsin dropped the 200-transaction test (J01 list) | Remote sellers | In force | J01 |
| **Construction lien notices:** prime-contractor notice at contract, and sub and supplier notice within 60 days (verify) | Contractors, subs, suppliers | Ongoing | C06, C05 |
| **Parental Choice Programs** (Milwaukee, Racine, statewide vouchers) (verify) | Private and parochial schools | Each school year | F06, I07 |
| **Minimum wage** stays at the federal $7.25 (verify), so wage and tip-law pressure is low | Employers | n/a | Lowers D04 and G04 fit |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | A03 | LocalLoop | Scoreboard 22. The common complaints (12-month auto-renew, 90-day notice, ~8% uplift) meet §134.49, which can make a non-disclosed renewal unenforceable for Wisconsin businesses. Offer a free "Is your renewal enforceable in Wisconsin?" check that becomes the switch offer. |
| 2 | B04 | FirstCall | Scoreboard 23. Construction is #2 by count (55,387 firms). Fall furnace and roofing and the winter snow-contract flip keep phones busy. |
| 3 | C01 | FlatRate | Heating season (Oct–Mar) in a cold-climate state. The same §134.49 exit angle helps contractors leave ServiceTitan-style multi-year contracts (check each contract). |
| 4 | D06 | SiteLoop | Dells, Northwoods and Door County campgrounds are in their off-season switch window (Oct–Mar). D06 lists WI as a high campground-count state. |
| 5 | H02 | BoardBinder | A statutory website mandate for 100+ unit condos has been in force since 2023. Few small management companies have a clean statutory-records portal (estimate). A narrow market, but a clear compliance sale. |
| 6 | F01 | Chairly | High small-business employment share, and other services is #3 by count. Fresha and Vagaro anger (scoreboard 22). |
| 7 | I06 | CampFile | Wisconsin is a resident-camp belt state (I06). The only switch window for camps is Sep–Dec, before registration opens, and that is now. |

## State-only opportunities
- **"Wisconsin Contract Exit Kit" (lead magnet across A03, B05, B06, K03, D01):** upload a SaaS or lease contract, and the tool checks for the §134.49 disclosure or initials and the 15–60-day notice, then drafts a non-renewal letter. The statute covers business contracts, a rare protection for SMBs. It's a strong, free wedge but not a standalone product, so no separate idea file. Risks: choice-of-law clauses in vendor contracts and the telecom exclusion; needs counsel review before marketing claims.
- **Condo website compliance (H02 WI pack):** a §703.20(1r) checklist and a protected owner portal, for Milwaukee and Madison 100+ unit associations.
- **Door County and Northwoods seasonal bundle:** campgrounds plus marinas plus cabins under one owner. It's the same Great Lakes marina gap flagged in the Michigan file (unscored; needs evidence).

## Where to sell
- **Associations & events** (months to verify):
  - Hospitality and camps: Wisconsin Restaurant Association, Wisconsin Hotel & Lodging Association, Wisconsin Association of Campground Owners (verify), American Camp Association local section (verify).
  - Manufacturing and building: Wisconsin Manufacturers & Commerce, Wisconsin Builders Association, WI REALTORS Association.
  - Condos: Community Associations Institute Wisconsin chapter (verify).
  - Professionals: Wisconsin Institute of CPAs, State Bar of Wisconsin, Wisconsin Dental Association.
  - General business: Metropolitan Milwaukee Association of Commerce.
- **Online communities:** r/milwaukee, r/madisonwi, r/wisconsin, r/GreenBay, r/HVAC, r/campgroundowners (verify), and Wisconsin contractor and resort-owner groups on Facebook (names to verify).
- **Partners:**
  - Wisconsin SBDC network and regional chambers.
  - HVAC supply houses.
  - Condo management firms and association attorneys.
  - Tourism bureaus (Wisconsin Dells Visitor & Convention Bureau, Destination Door County; verify) for seasonal operators.
  - Business attorneys who already send §134.49 non-renewal letters (referral partners for the exit kit).

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law | PEN's Dec 2025 roundup doesn't list one for WI (verify). | n/a | R01 (weak) |
| **Science of reading / three-cueing: 2023 Wisconsin Act 20** | **Three-cueing:** literacy coaches may not use or promote it, and teacher licenses issued after Jul 1 2026 are tied to the ban. **State support:** an Office of Literacy and a council that recommends science-based curricula. Schools that adopt the recommended materials get **50% reimbursement** of eligible costs ([Legislative Council Act memo](https://docs.legis.wisconsin.gov/2023/related/lcactmemo/act020)). | 2023 → licenses Jul 1 2026 | P01, R08 |
| **3rd-grade reading plan / retention (Act 20)** | **Screening:** 4K twice a year and 5K–3 three times a year. **Plans:** personal reading plans list skill deficiencies, goals and benchmarks. Parents get a copy to sign, and a progress notice after 10 weeks of intervention. **Promotion gate:** from **Sep 1 2027**, public, charter and choice schools can't promote to 4th grade unless promotion criteria are met (LC memo). Reading Pacer notes that parents may refuse ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)). | Plans now; promotion gate Sep 1 2027 | P02 |
| Homeschool (HSLDA page: **low**) | Notice required, no assessment, no teacher qualifications, and state-mandated subjects ([HSLDA](https://hslda.org/legal/wisconsin)). The PI-1206 form (by Oct 15) and 875 hours a year are from background knowledge (verify). | Oct 15 yearly (verify) | P03 |
| ESA / scholarship money | No ESA. The Milwaukee, Racine and statewide parental choice programs are tuition vouchers (verify), so there's little family-directed book or curriculum money. | n/a | (weak) |
| Other | Wis. Stat. §134.49 (auto-renewal) covers business contracts, not family subscriptions (see table above). | n/a | n/a |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home.** Act 20's parent-signed personal reading plans and 10-week progress notices run now. The Sep 1 2027 promotion gate gives a 12-month selling runway.
- **P01 PhonicsPrep.** The three-cueing ban plus 50% curriculum reimbursement pushes districts and tutors toward structured-literacy materials.
- **R08 Readlings.** A decodable home-practice app that fits Act 20's "science-based" framing, sold to parents of students with plans.

**Where to sell** (names from background knowledge; verify months):
- Wisconsin Library Association (fall conference) and WEMTA (school library media).
- Wisconsin PTA.
- Wisconsin Parents Association (homeschool).
- The Reading League Wisconsin and the IDA Wisconsin branch (verify).
- Midwest Independent Booksellers Association (MIBA).

## Launch verdict
**Speed:** Medium.

**First city:** Milwaukee (then Madison and the Fox Valley).

**Lead offer:** LocalLoop plus the Wisconsin Contract Exit Kit. The pitch is "Your Podium or Birdeye auto-renewal may not be enforceable in Wisconsin: check it free, switch for $79/mo flat, month-to-month." Run FirstCall and FlatRate into heating season and SiteLoop and CampFile outbound through the Oct–Dec off-season.

## Sources
- [SBA Office of Advocacy: 2025 Wisconsin Small Business Profile (PDF)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Wisconsin_2025-State-Profile.pdf)
- [Wis. Stat. §134.49: Automatic renewal of business contracts](https://docs.legis.wisconsin.gov/statutes/statutes/134/49)
- [Wis. Stat. §703.20: Association records; large-association website requirement](https://docs.legis.wisconsin.gov/statutes/statutes/703/20)
- [Wisconsin DHS: Electronic Visit Verification](https://www.dhs.wisconsin.gov/evv/index.htm)
- [HHAeXchange: State-by-State EVV Status](https://www.hhaexchange.com/state-evv-status)
- Scoreboard and idea files A03, B04, C01, D06, H02, F01, I06, D05, J01 (internal).
- [Wisconsin Legislative Council: 2023 Act 20 memo (three-cueing, screening, reading plans, Sep 1 2027 promotion)](https://docs.legis.wisconsin.gov/2023/related/lcactmemo/act020)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [HSLDA: Wisconsin homeschool law](https://hslda.org/legal/wisconsin)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- Internal (education): ideas P01, P02, P03, R08
