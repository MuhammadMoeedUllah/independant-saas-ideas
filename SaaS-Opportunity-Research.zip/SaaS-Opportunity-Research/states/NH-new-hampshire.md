# New Hampshire (NH): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 145,314 small businesses, 99.0% of NH businesses, employing 309,420 people (50.3% of NH employees). 114,903 are nonemployer firms. ([SBA Advocacy 2025 NH profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_Hampshire_2025-State-Profile.pdf))
- **New-business momentum:** From Mar 2023 to Mar 2024, small businesses opened 6,479 establishments and closed 5,882, adding a net 6,023 jobs. 2,055 small exporters shipped $2.5B. ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_Hampshire_2025-State-Profile.pdf))
- **Buyer clusters:**
  - **Southern tier (Nashua, Manchester, Salem):** tax-free retail drawing Massachusetts shoppers, e-commerce and Shopify brands, advanced manufacturing, tech.
  - **Seacoast (Portsmouth):** restaurants, tourism, marine.
  - **Lakes Region and White Mountains:** campgrounds, lodging, overnight summer camps, ski.
  - **Concord:** professional services and government.

  These clusters are an estimate.
- **Industries overweight vs. US:**
  - By small-business employment, health care (46,052), accommodation and food (44,051), **retail (31,153)** and construction (30,244) lead. By firm count, professional services (22,542) and construction (20,672) lead ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_Hampshire_2025-State-Profile.pdf)).
  - Retail and e-commerce are overweight because NH has no sales tax (estimate).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Education Freedom Accounts (EFA).** 10,510 students used EFAs in 2025–26, and the program hit its **12,500-student enrollment cap in Aug 2026**. Families choose from **2,000+ education providers** ([CSF New Hampshire](https://nh.scholarshipfund.org/)). ClassWallet is the payment platform (category research, verify) | Private schools, microschools, tutors, music teachers, therapists | 2026–27 school year is live now | F06, F07 |
| **No state sales tax.** NH sellers have no in-house sales-tax habits but still owe collection in other states once they cross economic-nexus thresholds. TaxJar's month-to-month plans move to new pricing on **Oct 1 2026** (scoreboard J01) | NH e-commerce and Shopify sellers, manufacturers selling DTC | Oct 1 2026 | J01, L03 |
| NH consumer privacy law (RSA 507-H), effective Jan 1 2025, with a 35,000-consumer threshold (verify) | Mid-size e-commerce, clinics | In force | J02 |
| Meals and rooms tax (8.5%, verify). STR operators must register and remit (verify) | STR hosts, inns, campgrounds | Ongoing | H03, D06 |
| Youth recreation camp licensing via NH DHHS (verify) | Lakes Region and White Mountains overnight camps | Pre-season | I06 |
| Federal $7.25 minimum wage. There's no state paid-leave mandate (Granite State PFML is voluntary, verify) | Low compliance churn, which weakens J03/G04 here | n/a | (J03 weak) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | J01 | NexusBook | No-sales-tax NH is full of DTC sellers who never built sales-tax muscle, and TaxJar's Oct 1 2026 repricing (mid tiers up 110–128%) creates a switch window right now. |
| 2 | F06 | ESA Desk | The EFA is at its 12,500 cap with 2,000+ providers. Private schools and microschools need ESA-ready invoicing and ClassWallet-friendly billing. |
| 3 | B04 | FirstCall | Construction is the #2 firm count (20,672). Southern-tier contractors compete with the Boston metro for leads. Scoreboard 23. |
| 4 | L03 | StackSaver | Southern-tier Shopify brands can audit their app bill before Black Friday, which is the live window now. |
| 5 | D06 | SiteLoop | Lakes Region and White Mountains campgrounds. The winter off-season is the only time they switch systems. |
| 6 | F07 | LessonLedger | EFA-eligible tutors and music teachers who need clean ESA invoicing. |
| 7 | A03 | LocalLoop | Seacoast and southern-tier multi-location service businesses on Podium auto-renewals. Scoreboard 22. |

## State-only opportunities
1. **"EFA-ready provider" billing for NH (F06/F07 module).** NH has an active, capped ESA market with 2,000+ providers. A provider onboarding kit with invoices in the format ClassWallet requires (verify), enrollment verification and waitlist management (the program is capped) makes this a real niche. We don't need a new file, because F06 covers it.
2. **"Tax-free state, taxable everywhere else."** A J01 campaign aimed at NH sellers. It's positioning, not a new product.

## Where to sell
- **Associations & events:**
  - Hospitality: NH Lodging & Restaurant Association, NH Campground Owners Association (verify name), Ski NH.
  - Construction: Home Builders Association of NH (verify).
  - Professional services: NH Society of CPAs, NH Bar Association.
  - Other: NH Realtors, Business & Industry Association of NH, NH Tech Alliance, ACA New England (camps).
  - EFA providers: Children's Scholarship Fund NH provider community (verify vendor events).
- **Online communities:** r/newhampshire, r/Nashua, r/manchesternh, r/Portsmouth (verify), r/shopify, r/ecommerce. Facebook groups for NH homeschool and EFA families and NH contractors (search by name).
- **Partners:** NH SBDC, Greater Manchester, Nashua and Portsmouth chambers, e-commerce accountants (for J01), community banks.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | No statewide school-library catalog or freedom-to-read law was confirmed in this pass. NH is on neither category-research list (verify 2024–25 parental-objection bills) | — | R01 (low fit), R07 |
| Science-of-reading / three-cueing law | Not on the category-research three-cueing-ban or approved-curriculum lists (verify) | — | P01, R08 |
| 3rd-grade reading plan / retention law | No retention law on the category-research lists | — | P02 (low fit) |
| Homeschool rules (HSLDA tier: **low–moderate**, verify) | Notice required, and **assessment required** (annual evaluation; verify the options). No teacher qualifications and no immunization rule. Subjects are state-mandated. Compulsory ages 6–18. HSLDA headlines: "New Hampshire Law Brings 3 Significant Improvements to Homeschooling", "NH Proposes Testing Mandate, Homeschoolers Rally", and HB 1268 ([HSLDA NH](https://hslda.org/legal/new-hampshire)) | In force | P03 |
| ESA / scholarship money that can buy books, curriculum, classes | **Education Freedom Accounts (2021):** universal eligibility, an **average account of $4,795** and about **10,000 students** in 2025–26 (EdChoice). Allowed spending includes tuition, online programs, "software, tutoring, books," testing and therapies ([EdChoice EFA](https://www.edchoice.org/school-choice/programs/education-freedom-account-program/)). The program hit its 12,500 cap in Aug 2026 (see the laws table). There's also an **Education Tax Credit** (tax-credit ESA). NH **opted in to the federal tax-credit scholarship** (Ballotpedia: Jan 29 2026; IRS list, Jun 8 2026), which starts **Jan 1 2027** ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | EFA live for 2026–27; federal credit Jan 1 2027 | **P07**, P03, P04, R08, R05 |
| Other | Not on the CSG South list of statewide Imagination Library programs ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)). No state auto-renewal law is on the category-research list | — | P06 |

**Top 3 reading/education ideas here:**
- **P07 LearnLedger:** about 10k EFA families spend around $4.8k each on books, software and tutoring, and every dollar needs a receipt trail.
- **P03 HomeRoll:** homeschool annual-assessment records plus EFA spending in one log.
- **P04 ClassHouse:** EFA-eligible independent class teachers and tutors in a capped, provider-heavy market (2,000+ providers).

**Where to sell:**
- **Families and EFA:** Children's Scholarship Fund NH parent and provider communities; NH PTA.
- **Homeschool groups:** Christian Home Educators of NH; NH Homeschooling Coalition (verify).
- **Libraries:** New Hampshire Library Association; NH School Library Media Association (verify conference months).
- **Reading groups:** IDA Northern New England or Reading League contacts (verify).
- **Booksellers:** New England Independent Booksellers Association fall conference (verify month).

## Launch verdict
**Speed:** Medium. **First city:** Manchester and Nashua, then Portsmouth. **Lead offer:** J01 NexusBook's "No sales tax here doesn't mean none elsewhere. Free multi-state nexus scan." It's timed to TaxJar's Oct 1 2026 repricing. Second offer is F06 for EFA providers.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: New Hampshire](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_Hampshire_2025-State-Profile.pdf)
- [Children's Scholarship Fund New Hampshire (EFA program)](https://nh.scholarshipfund.org/)
- [EdChoice: New Hampshire Education Freedom Accounts](https://www.edchoice.org/school-choice/programs/education-freedom-account-program/)
- [EdChoice: New Hampshire programs](https://www.edchoice.org/school-choice/state/new-hampshire/)
- [HSLDA: New Hampshire homeschool law](https://hslda.org/legal/new-hampshire)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [Ballotpedia: state participation in the federal K-12 tax credit scholarship program](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
