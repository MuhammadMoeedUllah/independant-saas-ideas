# Tennessee (TN): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 741,196 small businesses (99.5% of TN businesses) employ 1.2 million people, or 41.5% of TN employees (2022). From Mar 2023 to Mar 2024, 24,569 establishments opened and 20,866 closed (net +3,703). Small firms produced a net 40,433 jobs, 80.7% of the total ([SBA Advocacy 2025 Tennessee profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Tennessee_2025-State-Profile.pdf)).
- **New-business momentum:**
  - **79,651 business applications in Jan–Aug 2026** (not seasonally adjusted), 1.8% of US applications, a little below population share (verify) ([Census BFS monthly CSV](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)).
  - Most small-business employees: accommodation and food (175,458), health care (157,314), retail (111,165) and construction (110,820).
  - **Top firm counts: other services 95,835, construction 85,179, professional services 83,716** (SBA profile).
  - Construction is unusually high in firm count, a good sign for trades software.
- **Buyer clusters:**
  - **Nashville/Middle TN** (Davidson, Williamson, Rutherford): in-migration from high-tax states, since TN has no wage income tax (verify). Also home services, live music and events, bachelorette tourism, health-care management companies, churches and Christian media, startups.
  - **Smoky Mountains** (Sevier County: Gatlinburg, Pigeon Forge, Sevierville): cabin rentals, attractions, tours, shops, dinner shows.
  - **Knoxville:** home services, university.
  - **Chattanooga:** outdoor tourism, logistics.
  - **Memphis:** logistics and trucking (FedEx hub), churches, restaurants.
- **Industries overweight vs. US** (inference, verify):
  - Music and live entertainment.
  - Health-care management (Nashville).
  - Logistics and freight (Memphis).
  - Mountain tourism and cabin short-term rentals.
  - Construction (high firm count).
  - Churches and faith organizations.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Tenn. Code 50-1-703, E-Verify for private employers with 35+ FTEs** hiring on or after Jan 1 2023. Smaller employers may E-Verify or keep ID documents. Civil penalties run **$500 (first) to $2,500 (third+)** per violation, plus per-employee amounts, and **$500/day** for knowing E-Verify violations ([Justia, 2025 code](https://law.justia.com/codes/tennessee/title-50/chapter-1/part-7/section-50-1-703/)). | Employers with 35+ FTE; document retention for smaller ones | In force | G04, J03, regional E-Verify kit |
| **Tennessee Information Protection Act**, in force **Jul 1 2025** ([privacyterms.io](https://privacyterms.io/us-state-privacy-laws-2026)). Thresholds are high, from memory about $25M revenue plus 175k consumers (verify), so it hits few SMBs. | Larger e-commerce and health-adjacent firms | In force | J02 (secondary) |
| **Education Freedom Scholarship** (signed Feb 12 2025). **$7,530 per student for 2026–27** at registered non-public schools, with tuition and fees prioritized. **Quarter 2 funding is projected for Oct 15 2026 (20%)** and Quarter 3 for Jan 15 2027 (20%) ([TN DOE EFS](https://www.tn.gov/education/efs.html)). The TN ESA runs on ClassWallet ([GetESAPaid](https://getesapaid.com/become-an-esa-vendor)). | Private and faith schools, microschools registered as non-public schools | **Oct 15 2026**, Jan 15 2027 | F06 |
| **Short-term rental taxes:** Airbnb collects the **7% state sales tax, 1.5–2.75% local sales tax and all local occupancy taxes** in TN ([Airbnb help 2330](https://www.airbnb.com/help/article/2330)). This takes away most of the tax pain for Airbnb bookings, but direct and VRBO bookings still need filing (verify VRBO). | Cabin owners and managers | Monthly | H03 (sell on ops, not tax) |
| **Minimum wage:** no state law; federal $7.25 ([DOL](https://www.dol.gov/agencies/whd/minimum-wage/state)). | n/a | n/a | n/a |
| **Medicaid EVV:** E07's table lists TN as HHAeXchange/open (conflicting sources). TennCare runs through MCOs, and TN is absent from HHAeXchange's hub list ([hub](https://www.hhaexchange.com/info-hub)). | Home care | Verify | E07 (hold) |
| **IFTA quarterly** returns. | Memphis and Nashville small carriers | **Oct 31 2026** | K03 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture) | 85,179 construction firms and fast-growing suburbs (Rutherford, Williamson, Knox) buy expensive Angi and LSA leads. |
| 2 | A03 | LocalLoop (reviews and texting) | Tourism and restaurants in the Smokies and Nashville live on reviews. Price plus an exit from Podium's auto-renew sells here. |
| 3 | H03 | StayDesk (STR PMS) | Sevier County has one of the densest cabin-rental markets in the US (verify count), with many 5–50-cabin managers. Airbnb's 15.5% host-only fee for PMS-connected hosts (Oct 27 2025) and Guesty/Hostaway pricing are the pain. Airbnb handles tax, so we sell on ops, cleaning and owner statements. |
| 4 | I04 | DoorList (event ticketing) | Nashville venues, writer's rounds, promoters and festivals. Bending Spoons took over Eventbrite in Mar 2026 and made layoffs, and the FTC all-in ticket rule adds pressure. |
| 5 | D07 | BookTrail (tours and activities) | Smokies attractions, whitewater and ziplines, Nashville pedal taverns, party buses and tours. FareHarbor's 6% guest fee is the hook. |
| 6 | F01 | Chairly (salon/barber booking) | Salon suites in Nashville, Memphis and Knoxville. Fresha's commissions and Vagaro's payout freezes open a switching window. |
| 7 | I02 | TitheBox (church giving) | A dense church market, with Nashville as a hub for Christian music and media. The Q4 giving season is the switch window now. |

Bench:
- **K03 HaulDesk:** Memphis freight.
- **F06 ESA Desk:** EFS private schools; the Oct 15 disbursement is a timing hook.
- **B07 StudioDesk:** Nashville weddings, bachelorette events and creatives.
- **C01 FlatRate:** home services.
- **G03 SeasonDesk:** income-tax-free migration brings multi-state filers to CPAs.

## State-only opportunities
1. **Smokies cabin-manager suite (H03 + D07, sold as one regional product with NC).** Cabin managers in Sevier County, and across the line in Bryson City and Cherokee NC, need:
   - Owner statements and cleaning/hot-tub maintenance schedules.
   - Direct booking.
   - Upsells for attraction tickets, which is where BookTrail plugs in.

   Tax is largely handled by Airbnb in TN, so the value is ops plus direct booking to escape the 15.5% fee. Count of managers and cabins not verified.
2. **Nashville music-and-events back office (I04 + B07).** Independent venues, songwriter-night promoters and bachelorette-party vendors need ticketing, deposits, contracts and payouts on one flat-priced tool. Estimate; not separately researched.
3. **EFS private-school billing split (F06).** Quarterly state disbursements (20% on Oct 15 and 20% on Jan 15) must be reconciled against tuition schedules and parent balances. A simple "EFS ledger" for small faith schools is a narrow but timely wedge.

## Where to sell
- **Associations & events** (verify names and dates):
  - **Hospitality:** Tennessee Hospitality & Tourism Association.
  - **Building and real estate:** Home Builders Association of Tennessee, Tennessee REALTORS.
  - **Professional:** Tennessee Society of CPAs, Tennessee Bar Association, Tennessee Dental Association.
  - **Health and trucking:** Tennessee Association for Home Care, Tennessee Trucking Association.
  - **Startup ecosystem:** Launch Tennessee's 36|86 conference (verify status) and the Nashville Entrepreneur Center.
  - **Smokies:** Gatlinburg and Pigeon Forge chambers or tourism offices.
- **Online communities:** r/nashville, r/Knoxville, r/memphis, r/Chattanooga and r/Tennessee; Smokies cabin owner and manager Facebook groups (names not verified); Nashville music-industry Slack and Facebook communities.
- **Partners:**
  - Tennessee SBDC network (TSBDC; verify host).
  - Banks: Pinnacle Financial (Nashville) and First Horizon (Memphis).
  - Cabin cleaning and hot-tub service companies as referrers.
  - Venue booking agents.
  - CPA firms serving in-migrants.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials law:** Age-Appropriate Materials Act (2022) + **HB 843 (2024)** | **Act (2022):** schools must post their library lists online and run a parent challenge process with a 60-day review, which can escalate to the state textbook commission ([WCYB, Jul 2024, via R01](https://wcyb.com/news/local/tennessee-adds-new-requirements-to-age-appropriate-materials-act-for-schools)). **HB 843 (2024):** adds a state-level mechanism for a board or commission to decide statewide removals ([PEN America, Dec 2025](https://pen.org/report/the-bills-igniting-book-bans/)). | 2022; amended 2024 | R01, R07 |
| Science-of-reading / three-cueing law | **Tennessee Literacy Success Act (2021):** foundational-skills (phonics) instruction, K–3 universal screeners and parent notices (verify details). Tennessee is on NCTQ's approved-curriculum mandate list (via P01). A three-cueing ban was not confirmed for TN (verify). | 2021 → | P01, R08 |
| 3rd-grade reading plan / retention law | **Mandatory retention**, based on TCAP ELA ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)). Summer-school and tutoring pathways to promotion were added by later amendments (verify). | In force | P02 |
| Homeschool (HSLDA page: **low**; verify tier) | **Rules:** three options, notice required, teacher qualifications required, no state-mandated subjects, and assessment only under options 1 and 2a ([HSLDA](https://hslda.org/legal/tennessee)). **Independent home school:** notice of intent to the district, a parent with a high-school diploma, and a nationally normed or state test in grades **5, 7 and 9**. **Church-related umbrella schools (Category IV):** no intent form, though the district may ask for proof of enrollment. **Accredited online schools:** these are private schools, not home schools ([TN DOE](https://www.tn.gov/education/families/school-options/home-schooling-in-tn.html)). | n/a | P03, S9-04 (umbrella-school admin) |
| **ESA: Education Freedom Scholarship (EFS)** | **Award:** **$7,530** for 2026–27 at registered non-public schools, with tuition and fees prioritized ([TN DOE](https://www.tn.gov/education/efs.html)). **Cap:** HB 2532 passed both chambers on Apr 16 2026 to raise the cap from 20,000 to **35,000**, after **56,442** applications (whether the governor signed it: verify) ([Nashville Catholic, Apr 16 2026](https://www.nashvillecatholic.org/news/posts/tennessee-lawmakers-pass-bill-to-increase-education-freedom-scholarships-to-35000)). **Platform:** ClassWallet (see table above). Homeschool families aren't covered as a category (verify). | 2026–27 disbursements Oct 15, Jan 15 | F06 (P03/P07 weak) |
| Other | **Imagination Library:** statewide coverage since 2004 ([Imagination Library](https://imaginationlibrary.com/usa/)), run with the Governor's Early Literacy Foundation (verify). Families already get free books, so P06 sells engagement and outcome data to county affiliates, not books. | Ongoing | P06 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home.** Mandatory retention with summer-school and tutoring pathways means parents need one place to track the plan, the evidence and the deadlines.
- **R01 ClearShelf.** Tennessee requires posted library lists, a 60-day challenge clock and escalation to the state, and TN is already a named pack in R01.
- **P03 HomeRoll + S9-04.** Church-related umbrella schools do attendance and enrollment paperwork for many families. It's the same B2B shape as South Carolina's Option 3 associations.

**Where to sell** (names from background knowledge; verify months):
- Tennessee Library Association (spring conference) and Tennessee Association of School Librarians (fall).
- Tennessee PTA.
- Tennessee Home Education Association and the umbrella-school networks.
- IDA Tennessee branch and The Reading League Tennessee (verify).
- Southern Independent Booksellers Alliance (SIBA).

## Launch verdict
**Speed:** Fast. **First city:** Nashville, then Sevier County for the Smokies vertical push in the winter off-season. **Lead offer:** FirstCall (B04) for Middle-TN trades, with DoorList (I04) as the Nashville-specific second offer ("Eventbrite refugee: free migration, flat fee").

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Tennessee](https://advocacy.sba.gov/wp-content/uploads/2025/06/Tennessee_2025-State-Profile.pdf)
- [US Census Bureau, Business Formation Statistics monthly CSV (Jan–Aug 2026)](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)
- [Tenn. Code 50-1-703 (Justia, 2025)](https://law.justia.com/codes/tennessee/title-50/chapter-1/part-7/section-50-1-703/)
- [TN Department of Education, Education Freedom Scholarship](https://www.tn.gov/education/efs.html)
- [Airbnb Help, occupancy tax collection in Tennessee](https://www.airbnb.com/help/article/2330)
- [privacyterms.io, US state privacy laws 2026](https://privacyterms.io/us-state-privacy-laws-2026)
- [GetESAPaid, ESA payment rails by state](https://getesapaid.com/become-an-esa-vendor)
- [HHAeXchange information hub (TN not listed)](https://www.hhaexchange.com/info-hub)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [WCYB: Tennessee adds new requirements to Age-Appropriate Materials Act (Jul 2024), via R01](https://wcyb.com/news/local/tennessee-adds-new-requirements-to-age-appropriate-materials-act-for-schools)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [HSLDA: Tennessee homeschool law](https://hslda.org/legal/tennessee)
- [TN DOE: Home schooling in Tennessee (options, grades 5/7/9 testing, Category IV)](https://www.tn.gov/education/families/school-options/home-schooling-in-tn.html)
- [Nashville Catholic: EFS increase to 35,000 passes (Apr 16 2026)](https://www.nashvillecatholic.org/news/posts/tennessee-lawmakers-pass-bill-to-increase-education-freedom-scholarships-to-35000)
- [Imagination Library USA (statewide Tennessee coverage since 2004)](https://imaginationlibrary.com/usa/)
- [US DOL, state minimum wage table](https://www.dol.gov/agencies/whd/minimum-wage/state)
