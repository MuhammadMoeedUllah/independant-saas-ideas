# Louisiana (LA): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:**
  - 511,235 small businesses, 99.5% of Louisiana businesses.
  - 889,431 small-business employees, **54.1% of Louisiana employees**. That is one of the highest small-business employment shares in the country (inference) ([SBA Advocacy 2025 Louisiana profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Louisiana_2025-State-Profile.pdf)).
- **New-business momentum:** weak.
  - Mar 2023–Mar 2024: 12,078 establishments opened and **12,456 closed, a net decline**. Among small businesses, 11,047 opened and 11,456 closed.
  - Small businesses added only a net 5,470 jobs (44.4% of the net total).
  - Banks lent $1.4B to firms with revenue under $1M in 2023 (same SBA profile).
  - Demand here is event-driven (storms, tourism seasons, program money) rather than growth-driven.
- **Buyer clusters:**
  - **New Orleans:** tourism, tours, restaurants, short-term rentals, hotels and events. Catholic and independent private schools.
  - **Baton Rouge:** state government, petrochemical contractors, restoration and insurance agencies.
  - **Lafayette and Acadiana:** oilfield services and restoration.
  - **Lake Charles and the Southwest:** hurricane rebuild (2020–21 storms) and LNG and industrial construction.
  - **Shreveport–Bossier:** casinos, health care and trucking (inference).
- **Industries overweight vs. US:** estimate, from SBA rankings.
  - **"Other services"** is the #1 small-business category: 66,737 firms, covering repair, personal care and religious and civic organizations.
  - **Administrative support and waste management** is #2, with 58,767 firms.
  - **Health care** is the largest small-business employer, with 149,910 employees.
  - **Accommodation & food** employs 122,119 people.
  - **Hurricane restoration and roofing.**
  - **Tourism.**

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **LA GATOR education savings accounts.** Run on **Odyssey**. 2025–26 awards: up to $15,253 for students with disabilities, $7,626 for families at or below 250% of the federal poverty line, and $5,243 for others. **All tuition and purchases go through Odyssey; families can't be reimbursed for out-of-pocket spending.** Eligible spending includes tuition, tutoring, educational therapies, curricula and before/after-school programs. The 2026–27 application window was Mar 1–16 2026 ([LDOE LA GATOR](https://doe.louisiana.gov/topic-pages/louisiana-school-choice/la-gator)). | Private schools, tutors, therapists, after-school programs | Awards Jun–Jul 2026. The next window is about Mar 2027 (verify). | F06, F07, E06, I06 |
| **Short-term rental marketplaces collect lodging tax.** Accommodation intermediaries collect occupancy taxes from Jan 6 2025 and sales tax from Jul 1 2025. Hosts still owe local taxes the platforms don't collect, plus all taxes on direct bookings ([Avalara MyLodgeTax, Nov 4 2025](https://www.avalara.com/mylodgetax/en/blog/2025/11/more-states-require-short-term-rental-marketplaces-like-airbnb-and-vrbo-to-collect-lodging-taxes.html)). | STR hosts and managers (New Orleans, Northshore, Gulf coast) | In force | H03 |
| **Louisiana Fortify Homes Program (LFHP).** Pays **up to $10,000 per roof** to meet FORTIFIED Roof standards. Contractors need an LSLBC residential roofing or construction license (with Act 422 of 2025 and R.S. 37:2156 cited), IBHS FORTIFIED certification with a directory listing, **$1M general liability** covering open-roof water intrusion, and workers' comp. Subcontractors need the same. Contractors can't act as public adjusters ([LDI LFHP](https://ldi.la.gov/fortifyhomes/), [LFHP contractor rules, Mar 17 2025](https://ldi.la.gov/docs/default-source/documents/fortifyhomes/lfhp-contractors-rules-and-requirements.pdf)). | Roofers, subcontractors | The lottery is closed; new rounds are "to be announced" | C02, **S4-01** |
| **Act 533 FORTIFIED discount report.** Louisiana's Department of Insurance (LDI) publishes approved insurer discounts every **Jul 1**. 60+ insurers take part, with discounts from 0.9% to 54% on wind and hail premium, for FORTIFIED Roof designations only ([LDI Act 533 report, Jul 1 2026](https://ldi.la.gov/docs/default-source/documents/propertycasualty/act-533-fortified-discount-report-2025.pdf)). | Roofers (sales tool), insurance agents | Jul 1 each year | C02, G05 |
| **Employer posters.** New mandatory Louisiana posters in **Sep 2026**: Earned Income Credit and Child Labor (per Poster Guard, in J03). | All employers | Sep 2026 | J03 |
| **Sales tax.** Louisiana dropped the 200-transaction economic-nexus test (Avalara, in J01). The state rate rose to 5% on Jan 1 2025 (verify). Local sales tax is still collected parish by parish (verify). | Retailers, remote sellers, contractors | In force | J01 |
| **Hurricane season** | Restoration, roofing, STR and tours | Jun 1–Nov 30 each year | C07, C02 |
| **Comprehensive privacy law.** J02 notes privacyterms.io lists Louisiana as passing one in 2026. **Not confirmed**: Bloomberg Law's tracker (last updated Apr 2025) lists LA only as having active bills (verify). | Websites | TBD | J02 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | C07 | ClaimKit (documentation + supplements) | Hurricane and flood restoration is recurring work across the Gulf parishes. Documentation volume spikes after each event. The LFHP rules ban public-adjusting, so a "documentation, not negotiation" design fits. |
| 2 | C02 (+ S4-01 module) | StormDesk + FortiFile | $10k LFHP grants need licensed, IBHS-certified, heavily insured contractors, which means a compliance binder plus a FORTIFIED photo trail. The Act 533 discount list gives roofers a savings pitch for homeowners. |
| 3 | B04 | FirstCall | Highest national score (23). Owner-operated trades and "other services" dominate the small-business count. |
| 4 | D07 | BookTrail (vs FareHarbor, Peek) | New Orleans is a named tour cluster in D07: swamp, ghost, food and walking tours. The Oct–May festival season (Mardi Gras early 2027) is when guest fees hurt most. |
| 5 | H03 | StayDesk | The marketplace-collection rules leave hosts owing local and direct-booking taxes. New Orleans has a strict STR regime (verify current permit rules). |
| 6 | F06 | ESA Desk | GATOR runs on the **same Odyssey rails as Texas TEFA**, so a single integration pattern serves both. Families can't be reimbursed, so providers must invoice through Odyssey. |
| 7 | D03 | TableKeep (vs OpenTable, Resy) | New Orleans is a destination dining city. The OpenTable deposit fee (Jan 2026) and the Resy–Tock merger (2026) give restaurants reasons to switch. Accommodation & food employs 122k people at small firms. |

Honorable mention: **G05** AgencyLite. Louisiana's hard property-insurance market drives heavy re-quoting (background, verify), but its national score is 14.

## State-only opportunities
1. **FORTIFIED-grant roofer workflow** (with Oklahoma) → **ideas/S4-01-fortified-roof-grant-documentation.md**.
   - LFHP adds a contractor-credential binder on top of the photo workflow: LSLBC license, IBHS listing, $1M CGL, workers' comp, and subcontractor credentials.
2. **Odyssey dual-state pack (GATOR + TEFA).** One product serves Louisiana private schools, tutors and therapists alongside Texas.
   - Louisiana adds a before/after-school category and a "no reimbursement" rule, which forces providers onto Odyssey invoicing.
3. **STR direct-booking tax helper.** A small H03 module that computes what the host still owes after Airbnb or VRBO collect: local taxes, and all taxes on direct bookings.

## Where to sell
- **Associations & events** (background knowledge; verify names and vendor programs):
  - **Restaurants and lodging:** Louisiana Restaurant Association (annual expo), Louisiana Hotel & Lodging Association.
  - **Tourism:** New Orleans & Company, Louisiana Travel Association.
  - **Home builders and roofers:** Home Builders Association of Greater New Orleans and state HBAs, Louisiana roofing contractors association.
  - **Real estate:** Louisiana REALTORS.
  - **Professional services:** Society of Louisiana CPAs, Louisiana State Bar Association, Independent Insurance Agents & Brokers of Louisiana.
  - **Schools:** diocesan Catholic school offices (the largest private-school systems) and nonpublic school associations.
- **Online communities:** r/NewOrleans, r/batonrouge, r/Louisiana, r/lafayettela; New Orleans STR host Facebook groups; LA GATOR parent groups (verify names).
- **Partners:**
  - **Business support:** Louisiana SBDC (verify host), The Idea Village and GNO Inc. (New Orleans), Baton Rouge Area Chamber.
  - **Storm-rebuild network:** FORTIFIED evaluators, restoration and roofing supply branches, and independent insurance agents who sell the Act 533 discounts.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **Library-materials law: Act 436 (2023), La. R.S. 25:225 (public libraries)** | Public library boards had to adopt policies by **Jan 1 2024** and put them in place by **Jun 1 2024** to restrict minors' access to sexually explicit material. The policies must include:<br>• acquisitions that consider community standards;<br>• a **minor library-card system** where a parent picks the access level (block flagged collections, or block individual flagged items);<br>• a parent choice on digital content, with a list of digital sources that contain flagged material;<br>• a reconsideration process with written decisions and an appeal to the board.<br>Designations are made by majority vote in open meetings. A noncompliant library can have local payments withheld after 60 days' notice and can be refused Bond Commission approvals ([La. R.S. 25:225](https://www.legis.la.gov/legis/Law.aspx?d=1336854)). A separate school-library rule was not confirmed this pass (verify) | Policies Jan 1 2024; in effect Jun 1 2024 | R03, R01, R07 |
| **Science of reading and three-cueing ban: Act 517 (2022) and others** | Act 517 bars instructional materials that use three-cueing or visual memory as the main basis for word recognition. Related rules ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/louisiana/)):<br>• **Act 108:** foundational-literacy training for K–3 teachers and principals.<br>• **Act 438:** evidence-based K–3 instruction and school literacy plans.<br>• **Bulletin 741:** K–3 **screeners 3 times a year** (first 30 days, December, April).<br>• **Act 448:** a science-of-reading test for elementary certification.<br>• **Act 266:** dyslexia screening.<br>• LDOE keeps an approved-curriculum list | In force | P01, R08 |
| **3rd-grade retention: Act 422 (HB 12, 2023)** | Starting **2024–25**, third graders must meet the minimum reading score to move up to 4th grade. They get up to 2 more test attempts. Exemptions cover English learners, students with IEPs, students with dyslexia and other listed cases. Retained students get small-group instruction, evidence-based tutoring and smaller classes, and **parents sign an at-home reading contract** ([KTAL](https://www.ktalnews.com/news/education/edwards-signs-louisiana-education-bill-to-retain-3rd-graders-who-fail-to-meet-reading-standard/)). An earlier BESE policy required 30 hours of summer literacy for 3rd and 4th graders below grade level ([LDOE, Oct 12 2022](https://doe.louisiana.gov/about/news-releases/release/2024/07/20/louisiana-adopts-summer-literacy-policy-to-support-third-and-fourth-graders-reading-behind-grade-level)) | Retention since 2024–25 | P02, P01 |
| **Tutoring vouchers: Steve Carter program (Act 415 of 2021; HB 244 of 2024)** | **$1,500 digital vouchers**, raised from $1,000. HB 244 added math and extended eligibility to K–12 students below mastery, making **369,033 students eligible**. The fiscal note assumed only **0.8% participation** (about 2,952 students) ([HB 244 fiscal note](https://www.legis.la.gov/Legis/ViewDocument.aspx?d=1380593)). Funding for 2025–26 was **$5M from the state plus a $5M LDOE match** ([LDOE newsroom, Aug 27 2025](https://doe.louisiana.gov/about/news-releases/louisiana-tutoring-initiative)). How it works ([LDOE FAQ](https://doe.louisiana.gov/docs/default-source/literacy/steve-carter-literacy-program-faq.pdf?sfvrsn=23166318_5)):<br>• Tutors must be certified teachers or hold a relevant degree.<br>• Families register at louisianatutoringinitiative.com with the student's ID.<br>• Funds are deducted as sessions are booked | 2025–26 funded; 2026–27 funding not confirmed (verify) | P01, P04, F07, **S9-02** |
| **Homeschool: HSLDA "Low regulation"** | Two options: a BESE-approved home study program, or registering as a private school ([HSLDA Louisiana](https://hslda.org/legal/louisiana)). Application deadlines and proof-of-progress rules were not on the page (verify) | In force | P03 |
| **ESA and scholarship money** | **LA GATOR ESA** (FutureEd calls it universal): up to $15,253 for students with disabilities, $7,626 for families at or below 250% of the poverty line, and $5,243 for others. All spending goes through **Odyssey**, with no reimbursement. It covers tuition, tutoring, therapies, curricula and before/after-school programs (see table above). **HB 186 (2026)**, which adds criminal penalties for deliberate misuse of GATOR funds, is listed as enacted ([FutureEd](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). Louisiana opted in to the federal tax-credit scholarship on Dec 17 2025 ([Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)) | Next GATOR window about Mar 2027 (verify) | P03, P04, P07, R05, R08, F06, F07 |
| **Other** | P07's sources say Louisiana has an app-store age-verification law like Utah's (verify the date). Imagination Library state funding was not checked (verify) | — | P07, P06 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home:** Act 422 retention comes with a required parent home-reading contract and retest attempts. Three screeners a year give a steady flow of results to explain to parents.
- **P01 PhonicsPrep (+ S9-02 state edition):** state tutoring money already exists. $1,500 Steve Carter vouchers and GATOR tutoring must go to qualified tutors using materials that are not three-cueing. See [S9-02](../ideas/S9-02-louisiana-reading-voucher-tutor-kit-steve-carter-gator.md).
- **P04 ClassHouse:** the "no reimbursement, Odyssey only" GATOR rule means independent teachers need clean vendor invoicing.

**Where to sell:**
- **Libraries:** Louisiana Library Association (annual conference, spring; verify) and the Louisiana Association of School Librarians (LASL; verify).
- **Parents:** Louisiana PTA (verify).
- **Homeschool:** Christian Home Educators Fellowship (CHEF) of Louisiana (verify).
- **Reading specialists:** IDA Louisiana branch and The Reading League Louisiana chapter (both verify), plus parish literacy coaches.
- **Booksellers:** SIBA (Southern Independent Booksellers Alliance).

## Launch verdict
**Speed:** Medium.
- Storm, tourism and program events create fast windows.
- The underlying business base is flat to shrinking, so expect slow organic growth outside those windows.

**First city:** New Orleans, for tours, STRs and restaurants. Run a Baton Rouge/Lafayette restoration push in parallel.

**Lead offer:**
- **Main offer: C07 ClaimKit + the S4-01 FORTIFIED module** for Gulf-parish roofers and restorers. The pitch: "Every photo the evaluator needs, every credential LFHP asks for, one flat price."
- **Alternative: D07 BookTrail** for New Orleans tour operators ahead of the festival season.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Louisiana](https://advocacy.sba.gov/wp-content/uploads/2025/06/Louisiana_2025-State-Profile.pdf)
- [Louisiana Department of Education: LA GATOR Scholarship Program](https://doe.louisiana.gov/topic-pages/louisiana-school-choice/la-gator)
- [Louisiana Department of Insurance: Louisiana Fortify Homes Program](https://ldi.la.gov/fortifyhomes/)
- [LDI: LFHP Contractor Rules and Requirements (Mar 17 2025)](https://ldi.la.gov/docs/default-source/documents/fortifyhomes/lfhp-contractors-rules-and-requirements.pdf)
- [LDI: Act 533 FORTIFIED discount report (Jul 1 2026)](https://ldi.la.gov/docs/default-source/documents/propertycasualty/act-533-fortified-discount-report-2025.pdf)
- [Avalara MyLodgeTax: Louisiana and Maryland require STR marketplaces to collect lodging taxes (Nov 4 2025)](https://www.avalara.com/mylodgetax/en/blog/2025/11/more-states-require-short-term-rental-marketplaces-like-airbnb-and-vrbo-to-collect-lodging-taxes.html)
- [Bloomberg Law: State privacy legislation tracker (updated Apr 7 2025)](https://pro.bloomberglaw.com/insights/privacy/state-privacy-legislation-tracker/)
- Internal: ideas/B04, C02, C07, D03, D07, F06, G05, H03, J01, J02, J03
- [Louisiana R.S. 25:225, library policy on minors' access (Act 436 of 2023)](https://www.legis.la.gov/legis/Law.aspx?d=1336854)
- [The Reading League Compass: Louisiana](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/louisiana/)
- [KTAL: Edwards signs bill to retain 3rd graders who miss the reading standard (Act 422, HB 12)](https://www.ktalnews.com/news/education/edwards-signs-louisiana-education-bill-to-retain-3rd-graders-who-fail-to-meet-reading-standard/)
- [LDOE: Summer literacy policy for 3rd and 4th graders (Oct 12 2022)](https://doe.louisiana.gov/about/news-releases/release/2024/07/20/louisiana-adopts-summer-literacy-policy-to-support-third-and-fourth-graders-reading-behind-grade-level)
- [LDOE: Steve Carter Literacy Tutoring Program FAQ (PDF)](https://doe.louisiana.gov/docs/default-source/literacy/steve-carter-literacy-program-faq.pdf?sfvrsn=23166318_5)
- [LDOE newsroom: Louisiana Tutoring Initiative ($5M match for 2025–26, Aug 27 2025)](https://doe.louisiana.gov/about/news-releases/louisiana-tutoring-initiative)
- [Legislative Fiscal Office: HB 244 (2024 RS) fiscal note, Steve Carter expansion](https://www.legis.la.gov/Legis/ViewDocument.aspx?d=1380593)
- [HSLDA: Louisiana homeschool law](https://hslda.org/legal/louisiana)
- [FutureEd: 2026 private school choice bill tracker (Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
- [Ballotpedia: Federal K-12 tax credit scholarship participation](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- Internal: ../ideas/S9-02, P01, P02, P04, P07
