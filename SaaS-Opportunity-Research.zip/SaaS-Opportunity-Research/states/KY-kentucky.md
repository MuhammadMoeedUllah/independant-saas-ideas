# Kentucky (KY): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:**
  - 393,860 small businesses, 99.3% of Kentucky businesses.
  - 710,613 small-business employees, 42.6% of Kentucky employees ([SBA Advocacy 2025 Kentucky profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Kentucky_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Mar 2023–Mar 2024: small businesses had 12,964 openings and 11,181 closings.
  - Small firms gained a net **22,043 jobs** (130,244 added minus 108,201 lost).
  - Banks lent $954.5M to firms with revenue under $1M in 2023 (same SBA profile).
  - Census BFS state counts were not retrieved.
- **Buyer clusters:**
  - **Louisville:** logistics (UPS Worldport), health care, restaurants, **bourbon** (urban distilleries on "Whiskey Row"), and trucking. The Mid-America Trucking Show is held here.
  - **Lexington and the Bluegrass:** horse farms and equine services, distilleries, University of Kentucky health care.
  - **Northern Kentucky:** Cincinnati-metro suburbs, logistics around CVG airport.
  - **Bardstown and the central Bourbon Trail:** distillery tourism, lodging.
  - **Bowling Green:** manufacturing growth (inference).
  - **Eastern Kentucky:** volunteer fire departments, small government (J07; verify).
- **Industries overweight vs. US:** estimates, except bourbon figures from the Kentucky Distillers' Association.
  - **Bourbon and spirits** (from the [Kentucky Distillers' Association](https://kybourbon.com/industry/impact/)):
    - Output: $10.6B, 23,935 jobs, 17.1M barrels aging.
    - Tourism: nearly **3M Kentucky Bourbon Trail visits**, and **74%+ of visitors come from out of state**.
    - Investment: $3.55B in capital projects completed or planned.
  - **Accommodation & food** is the *largest* small-business employer, with 105,644 employees. Health care follows with 104,712.
  - **Construction** is #1 by small-business count, with 50,958 firms.
  - **Equine and logistics** (inference).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Kentucky Consumer Data Protection Act** ([Bloomberg Law tracker](https://pro.bloomberglaw.com/insights/privacy/state-privacy-legislation-tracker/)). Background knowledge: it applies to controllers with 100k+ consumers, or 25k+ consumers plus 50% of revenue from data sales (verify). | Larger ecommerce, DtC bourbon clubs, healthcare-adjacent sites | In force **Jan 1 2026** | J02 |
| **Remote-seller nexus.** Kentucky dropped the **200-transaction test on Aug 1 2026**; only the $100k sales threshold remains (Avalara, as of Aug 1 2026, cited in J01). The Department of Revenue page still shows the old 2018 "200 or $100k" test ([KY DOR](https://revenue.ky.gov/Business/Sales-Use-Tax/Pages/default.aspx)). That mismatch creates buyer confusion. | Out-of-state and Kentucky online sellers | Aug 1 2026 | J01 |
| **Online filing and payment mandate.** Sales tax, use tax, **transient room tax** and other returns must be filed and paid in **MyTaxes**, for monthly, quarterly and annual filers ([KY DOR notice, May 2 2025](https://revenue.ky.gov/News/Pages/Online-Filing-and-Payment-Mandate-for-Sales-and-Excise-Tax-Returns.aspx)). | Retailers, hotels, short-term rentals, distillery gift shops | In force (2025) | J01, H03, D05 |
| **Services brought into sales tax** (2022–2023 legislation, e.g. HB 8). Many service businesses newly collect tax (background, verify the list). | Personal-care, pet, landscaping and marketing service SMBs | In force | J01, F01, F04 |
| **Direct-to-consumer spirits shipping** (2020 law allowing Kentucky distillers to ship where the destination state permits; background, verify) | Distilleries | In force | J05 |
| **IFTA Q3** | Carriers | Oct 31 2026 | K03 |
| **No state ESA.** School choice was not adopted (Amendment 2 failed in Nov 2024; background, verify). | n/a. F06 and F07 are weak in Kentucky. | n/a | (F06, F07) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | D07 | BookTrail (vs FareHarbor, Peek, and tasting-room booking tools) | About 3M Bourbon Trail visits a year, mostly from out of state, all booking tours and tastings online. It's a dense, reachable cluster through the KDA, which has an "Industry Member" class for non-distiller businesses ([KDA membership](https://kybourbon.com/industry/membership/)). The 6% guest fee and FareHarbor's platform change are the switch triggers. |
| 2 | B04 | FirstCall | Highest national score (23). Construction is the #1 small-business sector. |
| 3 | J01 | NexusBook (vs TaxJar, Avalara) | Kentucky's Aug 1 2026 threshold change plus **TaxJar's Oct 1 2026 repricing**. Newly taxable service businesses also need simple filing (verify). |
| 4 | K03 | HaulDesk | Louisville logistics, a Northern Kentucky freight hub, and the Mid-America Trucking Show (Louisville, spring) as the demo venue. IFTA is due Oct 31. |
| 5 | C01 | FlatRate | HVAC and plumbing shops in the Louisville and Lexington suburbs. Oct–Feb switch window. |
| 6 | J02 | SiteShield | The Kentucky privacy law took effect Jan 1 2026. It fits bourbon DtC clubs and multi-state ecommerce. The applicability thresholds limit how many small businesses it reaches (verify). |
| 7 | J05 | CellarPermit (vs ShipCompliant) | National score is low (14), but local fit is the best anywhere. Bourbon DtC and Q4 gifting peaks are now. We'd bundle it with D07 as a single "distillery suite." |

## State-only opportunities
1. **Distillery suite (D07 + J05 bundle).** Tour and tasting bookings, a bottle-release waitlist and lottery, and DtC shipping-state checks, at one flat price for the ~100+ small and craft distilleries (count unverified).
   - **Channel:** the KDA "Industry Member" tier, which is open to vendors but not to wholesale or retail.
   - A full idea file wasn't written because the pain evidence for the bundle wasn't gathered in this pass.
2. **Kentucky service-business sales-tax helper.** A lightweight J01 mode for local service SMBs that newly collect sales tax and must file online in MyTaxes (verify which services were added).
3. **Equine services (watch).** Boarding barns, farriers and breeding farms around Lexington use generic tools (inference). This needs incumbent and pain research before we act.

## Where to sell
- **Associations & events** (background knowledge; verify names and vendor programs):
  - **Bourbon and tourism:** Kentucky Distillers' Association (Industry Member tier), Kentucky Travel Industry Association.
  - **Restaurants and retail:** Kentucky Restaurant Association, Kentucky Retail Federation.
  - **Construction and real estate:** Home Builders Association of Kentucky, Kentucky REALTORS.
  - **Professional services:** Kentucky Society of CPAs, Kentucky Bar Association.
  - **Trucking:** Kentucky Trucking Association and the **Mid-America Trucking Show** (Louisville, spring).
  - **Equine and business networks:** Kentucky Thoroughbred Association, Kentucky Chamber of Commerce.
- **Online communities:** r/Louisville, r/lexington, r/Kentucky, r/bourbon (a huge DtC and tour audience, useful for demand-side marketing), r/cincinnati (Northern Kentucky).
- **Partners:**
  - **Business support:** Kentucky SBDC (verify host), Greater Louisville Inc., Commerce Lexington, Kentucky Innovation network (verify).
  - **Referrers:** accountants who serve hospitality and service businesses (sales-tax changes), and bourbon tourism operators (hotel, transport and tour-bus companies).

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School materials law: SB 5 (2023)** | Schools must have a process for parents to challenge books, instructional materials and school events as "harmful to minors" under a three-part test: obscene depiction of nudity or sex acts, prurient appeal taken as a whole, and patently offensive to standards for minors ([WKYU, Mar 16 2023](https://www.wkyufm.org/news/2023-03-16/bill-targeting-obscene-books-in-schools-clears-kentucky-legislature)). Who decides, the timelines and the appeal route were not confirmed (verify). Separately, PEN reports that about 100 books were pulled under **SB 150 (2023)** and later returned after the state clarified that SB 150 did not apply to libraries ([PEN America, Dec 18 2025](https://pen.org/report/the-bills-igniting-book-bans/)) | In force since 2023 (verify effective date) | R01, R07 |
| **Science of reading: Read to Succeed Act (SB 9, 2022)** | Requires K–3 early-literacy screening, evidence-based instruction within MTSS (tiered support), and teacher preparation aligned to reading science. A **$54.9M, 5-year federal Comprehensive Literacy State Development grant** (KyCL25) was awarded in Sep 2024, and Read to Achieve grants fund K–3 intervention. Reading standards are being revised for 2026 ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/kentucky/)). Category research lists Kentucky among the three-cueing bans, but the Compass page shows no explicit ban (verify) | In force; grant runs to about 2029 | P01, R08 |
| **3rd-grade reading plan or retention law** | No mandatory retention found. Reading-improvement-plan and parent-notice details under SB 9 were not confirmed (verify) | — | P02 |
| **Homeschool: HSLDA "Low regulation"** | Notice to the local board is required, state-mandated subjects apply, and there is no testing ([HSLDA Kentucky](https://hslda.org/legal/kentucky)). The notice deadline and attendance/grade-report rules were not on the page (verify) | In force | P03 |
| **ESA and scholarship money** | Kentucky has **no ESA** (Amendment 2 failed in Nov 2024; see above). **HB 1 (2026)** opted Kentucky into the federal tax-credit scholarship by overriding a veto on **Mar 17 2026** ([Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program); [FutureEd](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). Kentucky was not on the IRS list as of Jun 8 2026 (verify) | Federal credit from Jan 1 2027 (verify) | P07 (weak), F06 (weak) |
| **Other** | A statewide Imagination Library program with state match funding is reported but not checked (verify) | — | P06 |

**Top 3 reading/education ideas here:**
- **P01 PhonicsPrep:** $54.9M in federal literacy grant money flows to districts through about 2029, alongside Read to Achieve intervention grants.
- **R08 Readlings:** K–3 screening under Read to Succeed identifies readers who need home practice.
- **R01 ClearShelf:** SB 5 requires a formal parent challenge process, and a clean challenge log and catalog record helps schools run it.

**Where to sell:**
- **Libraries:** Kentucky Library Association and the Kentucky Association of School Librarians (KASL) (both verify).
- **Parents:** Kentucky PTA.
- **Homeschool:** Christian Home Educators of Kentucky (CHEK; verify).
- **Reading specialists:** IDA Kentucky branch (verify), plus KDE literacy grant cohorts.
- **Booksellers:** SIBA.

## Launch verdict
**Speed:** Medium. A mid-sized market with one unusually dense, reachable cluster (bourbon tourism) and a fresh tax change.

**First city:** Louisville, reaching Bardstown and Lexington distilleries along the Bourbon Trail.

**Lead offer:** D07 BookTrail for distilleries and bourbon tour operators. The pitch: "No 6% guest fee on your tastings, bottle-release waitlists included, set up before holiday season." J05 DtC compliance is the upsell. J01 NexusBook runs as a parallel offer to Kentucky online sellers after the Aug 1 threshold change.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Kentucky](https://advocacy.sba.gov/wp-content/uploads/2025/06/Kentucky_2025-State-Profile.pdf)
- [Kentucky Distillers' Association: Economic impact](https://kybourbon.com/industry/impact/)
- [Kentucky Distillers' Association: Membership](https://kybourbon.com/industry/membership/)
- [Kentucky Department of Revenue: Sales & Use Tax](https://revenue.ky.gov/Business/Sales-Use-Tax/Pages/default.aspx)
- [Kentucky DOR: Online filing and payment mandate for sales and excise tax returns](https://revenue.ky.gov/News/Pages/Online-Filing-and-Payment-Mandate-for-Sales-and-Excise-Tax-Returns.aspx)
- [Bloomberg Law: State privacy legislation tracker (Kentucky effective Jan 1 2026)](https://pro.bloomberglaw.com/insights/privacy/state-privacy-legislation-tracker/)
- [Avalara: States eliminating economic-nexus transaction thresholds (as of Aug 1 2026), via J01](https://www.avalara.com/blog/en/north-america/2025/06/states-eliminating-economic-nexus-transaction-thresholds.html)
- Internal: ideas/B04, C01, D07, J01, J02, J05, K03
- [WKYU: Bill targeting 'obscene' books in schools clears Kentucky legislature (SB 5, Mar 16 2023)](https://www.wkyufm.org/news/2023-03-16/bill-targeting-obscene-books-in-schools-clears-kentucky-legislature)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [The Reading League Compass: Kentucky](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/kentucky/)
- [HSLDA: Kentucky homeschool law](https://hslda.org/legal/kentucky)
- [Ballotpedia: Federal K-12 tax credit scholarship participation](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [FutureEd: 2026 private school choice bill tracker (Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
- [IRS: Federal scholarship tax credit participating states (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
