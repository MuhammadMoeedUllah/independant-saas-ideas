# State file template (use these exact headings)

```
# <State> (<XX>): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** <# of small businesses, % of private workforce> ([SBA Advocacy 2025 profile or other source](url))
- **New-business momentum:** <business applications trend, fastest-growing sectors> (source, or "estimate")
- **Buyer clusters:** <metros/regions and what they're heavy in, e.g. "Houston: HVAC, energy services, restaurants">
- **Industries overweight vs. US:** <3–6 sectors where this state has unusually many buyers>

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|

## State-only opportunities
<1–3 ideas that exist because of this state's specific laws, industries, or geography. If one is strong, also write a full idea file for it.>

## Where to sell
- **Associations & events:** <state restaurant/lodging assoc, home builders, REALTORS, CPA society, bar, dental/vet assoc, state trade shows with months>
- **Online communities:** <city/state subreddits, FB groups, local business networks>
- **Partners:** <SBDCs, chambers, accountants, supply houses, banks/credit unions>

## Launch verdict
**Speed:** Fast / Medium / Slow. **First city:** <city>. **Lead offer:** <which idea + hook>.

## Sources
- [Title](url)
```
