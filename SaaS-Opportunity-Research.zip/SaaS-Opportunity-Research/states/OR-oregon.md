# Oregon (OR): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 417,747 small businesses, which is 99.4% of Oregon businesses. They employ 889,528 people, or **53.4% of the private workforce** (above the CA and WA shares). 320,778 have no employees (2022), which leaves roughly 97k small employers (our subtraction, an estimate) ([SBA Advocacy 2025 Oregon profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Oregon_2025-State-Profile.pdf)).
- **New-business momentum:** Flat to soft. From March 2023 to March 2024, small firms opened 17,826 establishments and closed 18,063, a net loss of 368 establishments and 548 jobs (SBA profile). This is a cost-cutting market, and "save money" beats "grow faster" in the pitch. Census Business Formation Statistics were not pulled.
- **Largest small-business employers:** Accommodation & food services (130,525), health care & social assistance (126,802), construction (93,308), retail (86,870) (SBA profile).
- **Buyer clusters:**
  - **Portland metro (Multnomah/Washington/Clackamas):** restaurants, food carts and breweries; salons; landlords; trades; therapy practices.
  - **Salem/Willamette Valley:** wineries, nurseries, ag services, state contractors.
  - **Eugene/Springfield:** university-town services, landlords.
  - **Bend/Central Oregon:** construction boom, outdoor outfitters, vacation rentals.
  - **Medford/Ashland/Rogue Valley:** wine, tourism, cannabis cultivation.
  - **Oregon Coast and Columbia Gorge/Hood River:** lodging, tours, charters, rentals.
- **Industries overweight vs. US** (qualitative estimate):
  - Craft beer and wine (Willamette Valley).
  - Cannabis (OLCC-licensed, Metrc; an oversupplied, distressed market).
  - Outdoor recreation and tourism.
  - Nursery and greenhouse agriculture.
  - Wood products.
  - Food carts and independent restaurants.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Paid Leave Oregon.** Contributions are "1% of gross wages up to $184,500" (2026). Employers with 25+ employees pay 40% and employees pay 60%. Employers with **fewer than 25** skip the employer share but must still "withhold… report and pay." Small-employer assistance grants are available ([Paid Leave Oregon](https://paidleave.oregon.gov/employers/)) | Every employer | 2026 rate in force. Quarterly reporting | G04 StatePay, D04 ShiftTip |
| **Three-tier minimum wage and no tip credit.** From **Jul 1 2026**: standard $15.55, Portland metro $16.80, nonurban $14.55 (Jul 2025: $15.05 / $16.30 / $14.05) ([BOLI](https://www.oregon.gov/boli/workers/pages/minimum-wage-schedule.aspx)). Oregon does not allow a tip credit (state leads; verify statute) | Restaurants, retail, salons, seasonal tourism | Every Jul 1 | D04 ShiftTip, G04, J03 PostedUp |
| **Statewide rent stabilization.** The 2026 cap is 9.5% under "7% + CPI, capped at 10%." There is a separate 6% cap for manufactured-dwelling parks with 30+ spaces. The 2027 figure is not yet published ([Oregon OEA](https://www.oregon.gov/das/oea/pages/rent-stabilization.aspx); verify tier labels) | Residential landlords, MH park owners | Calendar 2026. The 2027 cap should be published in fall 2026 (verify) | H01 DoorLedger |
| **Oregon Consumer Privacy Act.** Effective Jul 1 2024 and covers nonprofits too. From **Jan 1 2026**, businesses must honor universal opt-out signals such as Global Privacy Control ([Oregon DOJ](https://www.doj.state.or.us/consumer-protection/id-theft-data-breaches/privacy/)) | Businesses over the data thresholds (verify: 100k consumers), plus all automakers | Jan 1 2026 | J02 SiteShield, I01 GiftLedger (nonprofits) |
| **Construction lien "notice of right to lien."** Due within 8 business days of first furnishing, one of the country's shortest windows (ORS 87.021; verify). Residential contracts carry CCB-required notices (verify) | Subs, suppliers, rental yards, residential contractors | Every job | C06 LienClock, C05 FlatBuild |
| **Portland-area local taxes.** Portland Business License Tax and Multnomah County Business Income Tax (combined filing), Metro Supportive Housing Services tax, Multnomah Preschool for All tax, and Portland Clean Energy Surcharge (verify rates and thresholds) | Portland-metro businesses and self-employed owners, plus their CPAs | Annual (Apr 15) with estimates | G03 SeasonDesk, G02 PlainLedger, G04 |
| **Metrc track-and-trace (OLCC).** Oversupply and price collapse (background; verify) | Dispensaries, producers, processors | Ongoing. The federal hemp cap is around Nov 2026 (verify) | J04 TagTrue |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture for trades) | Construction is Oregon's #3 small-business employer (93,308), and there's a rain-season service rush Oct–Mar. In a flat economy, owners cut lead-gen fees first, and a "true cost per booked job" report is the sales tool. |
| 2 | F01 | Chairly (salon/barber booking) | No tip credit and $16.80 Portland minimum wage squeeze salon margins. Booth-rent and suite models are common in Portland (estimate). Commission-free booking with each renter's own processor is a direct cost save. |
| 3 | H01 | DoorLedger (small-landlord PM) | Every Oregon rent increase must fit the annual OEA cap (9.5% for 2026, 2027 cap due soon). Portland adds its own deposit, screening and relocation rules (verify). The best timing is to sell a "2027 cap notice" feature when OEA publishes. |
| 4 | G04 | StatePay (state-compliance copilot beside payroll) | Paid Leave Oregon withholding for employers under 25 (who skip the employer share but still must withhold and report), three wage zones, and stacked Portland/Metro/Multnomah taxes. It's a compliance-heavy stack for a 5–20-person employer. |
| 5 | D04 | ShiftTip (scheduling + tip pooling) | Food & drink is the #1 small-business employer (130,525). No tip credit plus zone-based wages make labor-cost control vital. The Jul 1 wage step is an annual re-scheduling moment. |
| 6 | D07 | BookTrail (tours/rentals booking) | Rafting on the Deschutes and Rogue, Gorge and Hood River rentals, coast charters, Willamette wine tours. Summer operators switch in the off-season (Oct–Mar), which starts now. No guest booking fee is a selling point against FareHarbor/Peek. |
| 7 | C06 | LienClock (lien deadlines & notices) | Oregon's notice-of-right-to-lien window (8 business days; verify) is among the strictest, so suppliers and subs miss it constantly. It's a sharp, state-specific pain for a cheap per-notice product. |

*Just outside the Top 7:* **C05 FlatBuild** (Portland/Bend remodelers and the CoConstruct sunset), **J04 TagTrue** (Metrc + oversupply), **J05 CellarPermit** (Willamette wineries, weak trigger).

## State-only opportunities
1. **"Portland stack" tax-and-payroll checklist** (fold into G04 and G03). One place for Paid Leave Oregon, the three minimum-wage zones, and Portland/Multnomah/Metro business and personal taxes, with deadlines and estimated-payment reminders. There's no full idea file because rates need verifying and it's a module, not a product.
2. **Oregon rent-cap notice service** (H01 module). It pushes the new cap into lease-renewal and notice templates, with MH-park tiering.
3. **Short-window lien notices** (C06 module): an 8-business-day timer that starts on the first delivery ticket.

## Where to sell
- **Associations & events:** Oregon Restaurant & Lodging Association (ORLA), Home Builders Association of Metro Portland and Oregon Home Builders Association, Central Oregon Builders Association (Bend), Multifamily NW (landlords; annual conference, verify month), Rental Housing Alliance Oregon, Oregon Society of CPAs (OSCPA), Oregon State Bar sections, Oregon Dental Association, Oregon Wine Board, Oregon Brewers Guild, Travel Oregon industry events, Oregon Cannabis Association (verify).
- **Online communities:** r/Portland, r/oregon, r/Bend, r/Eugene, r/salem, r/smallbusiness. Facebook groups for Portland small businesses, food-cart owners, Oregon landlords and salon suites (verify names).
- **Partners:** Oregon SBDC Network (community-college-hosted centers), Business Oregon, Prosper Portland, local chambers (Portland Business Alliance, Bend Chamber), credit unions (OnPoint, Rogue Credit Union; verify SMB programs), CPA firms handling Portland-metro combined filings, supply houses (for B04 and C06).

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| Freedom-to-read law: **SB 1098 (2025)** | Schools may not remove materials because of the subject matter or author's membership in a protected class. The complaint and reconsideration process remains, so districts need written processes that record the reason for every decision ([RV Times, Jun 10 2025, via R01](https://rv-times.com/2025/06/10/oregon-freedom-to-read-library-bill-heads-to-governors-desk/)). Signing date and effective date to be verified | 2025 (verify effective date) | **R01**, R07 |
| Science-of-reading / three-cueing law | Early Literacy Success Initiative (2023) grants for schools, community groups and tribes (verify bill number and 2025–27 funding). Not on the category-research three-cueing-ban or approved-curriculum lists | 2023– (verify) | P01, R08, P06 |
| 3rd-grade reading plan / retention law | No retention law on the category-research lists | — | P02 (low fit) |
| Homeschool rules (HSLDA tier: **low–moderate**, verify) | Notice required, and **testing required** (the HSLDA summary doesn't give grades; category research says grades 3, 5, 8 and 10, verify). No mandated subjects, teacher qualifications or immunization rule. Compulsory ages 6–18 ([HSLDA OR](https://hslda.org/legal/oregon)) | In force | P03 |
| ESA / scholarship money that can buy books, curriculum, classes | **None.** No private-choice program (verify on EdChoice). Ballotpedia lists Oregon as **declining** the federal tax-credit scholarship (Aug 2025) ([Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)), and it isn't on the IRS list of 27 states (Jun 8 2026) | — | (P07 weak) |
| Other | Not on the CSG South list of statewide Imagination Library programs ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)). OR is not on the category-research auto-renewal list | — | P06 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf:** SB 1098 means every challenge must be decided and documented under a written, non-discriminatory process. A reconsideration-workflow and policy pack fits. Bundle it with WA (HB 2331) as one Pacific Northwest freedom-to-read pack.
- **P03 HomeRoll:** a testing-grade tracker for Oregon homeschool families (verify grades).
- **R02 ReadRally:** Oregon's many small library districts run summer reading on tight budgets.

**Where to sell:**
- **Libraries:** Oregon Library Association annual conference (spring, verify); Oregon Association of School Libraries fall conference (verify).
- **Families:** Oregon PTA.
- **Homeschool groups:** Oregon Christian Home Education Association Network (OCEAN) (verify).
- **Reading groups:** IDA Oregon Branch (verify).
- **Booksellers:** Pacific Northwest Booksellers Association (verify).

## Launch verdict
**Speed:** Medium. The workforce share is high, but net business counts are shrinking. Owners are price-sensitive and can be won by switching savings, but there are fewer new formations than in WA or CA. **First city:** Portland (then Bend/Eugene). **Lead offer:** DoorLedger's "Oregon 2027 rent-cap notice kit" (free calculator, then per-door PM). For employers, pair it with the StatePay compliance calendar for Paid Leave Oregon and Portland taxes. Bundle Oregon with the WA launch as a single "Pacific Northwest" campaign.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Oregon (Jun 2025)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Oregon_2025-State-Profile.pdf)
- [Oregon BOLI: Minimum wage schedule (Jul 1 2025 and Jul 1 2026 rates)](https://www.oregon.gov/boli/workers/pages/minimum-wage-schedule.aspx)
- [Paid Leave Oregon: Employers (2026 contribution rate, small-employer rules)](https://paidleave.oregon.gov/employers/)
- [Oregon DAS Office of Economic Analysis: Rent stabilization](https://www.oregon.gov/das/oea/pages/rent-stabilization.aspx)
- [Oregon DOJ: Oregon Consumer Privacy Act](https://www.doj.state.or.us/consumer-protection/id-theft-data-breaches/privacy/)
- Internal: `_scoreboard.csv`, `_state_leads_from_category_research.md` (no tip credit, Metrc), ideas B04, F01, H01, G04, D04, D07, C06.
- [Rogue Valley Times: Oregon SB 1098 freedom-to-read bill (Jun 10 2025)](https://rv-times.com/2025/06/10/oregon-freedom-to-read-library-bill-heads-to-governors-desk/)
- [HSLDA: Oregon homeschool law](https://hslda.org/legal/oregon)
- [Ballotpedia: state participation in the federal K-12 tax credit scholarship program](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
