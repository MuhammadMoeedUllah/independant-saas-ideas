# Washington (WA): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 695,695 small businesses, which is 99.5% of Washington businesses. They employ 1.5 million people, or 48.7% of the private workforce. Small-business employment grew 20.9% between 1998 and 2022 ([SBA Advocacy 2025 Washington profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Washington_2025-State-Profile.pdf)).
- **New-business momentum:** Strong. From March 2023 to March 2024, small firms opened 22,873 establishments and closed 13,036, a net gain of 9,837. They produced 27,671 net new jobs, or 70.4% of the state's gain (SBA profile). Census Business Formation Statistics were not pulled in this pass.
- **Largest small-business employers:** Health care & social assistance (199,949), accommodation & food services (193,671), **construction (184,579, ranked above professional services and retail)**, professional/scientific/technical (138,907), retail (134,179) (SBA profile).
- **Buyer clusters:**
  - **Seattle/King County:** independent restaurants and cafés, IT and digital-agency microfirms (newly charged sales tax), therapy and wellness practices, landlords, remodelers.
  - **Tacoma/Pierce and JBLM:** home services, logistics, auto repair.
  - **Snohomish/Everett:** aerospace suppliers, trades.
  - **Spokane:** health care, trades, landlords.
  - **Tri-Cities/Yakima/Wenatchee:** tree fruit and ag services, wineries.
  - **Vancouver WA:** Portland-metro trades and retail.
  - **Bellingham and the Olympic Peninsula:** tourism, marine trades.
- **Industries overweight vs. US** (qualitative estimate):
  - Construction and remodeling.
  - Software, IT services and digital agencies.
  - Aerospace supply chain.
  - Tree fruit and agriculture.
  - Wineries.
  - Maritime and fishing.
  - Health and wellness (the state's health-data law makes this segment compliance-hungry).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **My Health My Data Act.** Covers **small businesses too** ([WA AG](https://www.atg.wa.gov/protecting-washingtonians-personal-health-data-and-privacy)). Requires a consumer health data privacy policy "prominently" linked from the homepage, consent to collect or share, "valid authorization" to sell, and deletion rights. Any violation is a per se Consumer Protection Act violation, enforceable by the AG **and by private lawsuit** | Clinics, therapists, med spas, gyms and studios, salons doing skin or health intake, supplement and wellness e-commerce, apps | Small businesses since **Jun 30 2024**. Class-action exposure is ongoing | A01 FormFlare, E08 Clipboardless, E01 Hearth EHR, E04 Glowchart, F02 OpenStudio, J02 SiteShield |
| **HB 1217 rent stabilization (RCW 59.18.700).** Caps rent increases at "seven percent plus the consumer price index, or 10 percent, whichever is less." No increase in the first 12 months. Exemption facts must appear in the notice ([RCW 59.18.700](https://app.leg.wa.gov/RCW/default.aspx?cite=59.18.700); [HB 1217 bill page](https://app.leg.wa.gov/billsummary?BillNumber=1217&Year=2025)). The bill also limits fees and deposits and adds AG enforcement. The 90-day notice rule, the exemption for newer buildings and the manufactured-home cap are not confirmed (verify) | Every residential landlord, including mom-and-pop landlords, and manufactured-home park owners | Effective **May 7 2025**, expires 2040 | H01 DoorLedger |
| **ESSB 5129 common-interest communities.** Chapter 119, Laws of 2025 ([bill page](https://app.leg.wa.gov/billsummary?BillNumber=5129&Year=2025)). It extends WUCIOA-style rules for budgets, records and meetings to older HOAs. Some provisions apply from Jan 1 2026 (verify) | HOAs, condos and their self-managed boards and small management companies | Effective **Jul 27 2025**, with phased provisions (verify) | H02 BoardBinder |
| **ESSB 5814 services sales tax.** From **Oct 1 2025**, retail sales tax applies to advertising services, IT services, custom website development, live presentations, security and investigation, temporary staffing, and custom software ([WA DOR](https://dor.wa.gov/taxes-rates/retail-sales-tax/services-newly-subject-retail-sales-tax)). New exclusions start **Jul 1 2026** (including telehealth) | Digital agencies, web developers, MSPs, IT consultants, trainers, security firms, staffing firms. Thousands of microfirms now invoice sales tax for the first time | Oct 1 2025 / Jul 1 2026 | J01 NexusBook, G02 PlainLedger, G03 SeasonDesk, G07 BenchBoard |
| **Notice to owner / lien rights (RCW 60.04.031).** A notice protects only materials and equipment supplied within **60 days before** it is given, and 10 days for new single-family construction. Without compliance, "a lien… shall not be enforced" ([RCW 60.04.031](https://app.leg.wa.gov/RCW/default.aspx?cite=60.04.031)) | Suppliers, equipment rental, lower-tier subs | Every job | C06 LienClock |
| **Pay transparency (Equal Pay and Opportunities Act).** Job ads must show a wage scale or salary range plus benefits. The 2025 amendment added a 5-business-day cure period (verify). Washington saw a wave of class actions over job postings (verify counts) | Employers with 15+ employees | Cure period since Jul 27 2025 (verify) | J03 PostedUp, G07 BenchBoard |
| **Minimum wage and no tip credit.** Statewide 2026 rate $17.13, Seattle about $21.30 (verify). Tip credits are not allowed | Restaurants, retail, salons | Jan 1 each year | D04 ShiftTip, J03 |
| **Payroll programs.** WA Paid Family & Medical Leave premiums, WA Cares long-term-care premium, Seattle ordinances (verify 2026 rates) | All employers | Quarterly | G04 StatePay |
| **Economic nexus** without a 200-transaction test (per state leads) | Remote sellers into WA | In force | J01 NexusBook |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture for trades) | Construction is WA's #3 small-business employer (184,579 workers), and many firms opened in 2023–24 (net +9,837 establishments). Rain-season plumbing, roofing and HVAC call spikes (Oct–Mar) hurt most when calls go unanswered. |
| 2 | A01 | FormFlare (forms, HIPAA/health mode) | The WA-only **My Health My Data** rules (separate consent, homepage policy, deletion, private right of action) also cover small businesses. Clinics, med spas, gyms and wellness brands need consent-logged intake forms. A "MHMDA mode" with a consent ledger and deletion workflow is a unique selling point, cheaper than Jotform HIPAA tiers. |
| 3 | H01 | DoorLedger (small-landlord PM) | **HB 1217** makes every rent increase a legal calculation (7% + CPI, capped at 10%, with exemption facts in the notice). Mom-and-pop landlords in Seattle, Spokane and Tacoma need a notice generator and a fee/deposit checker. Buildium and AppFolio price hikes provide the push. |
| 4 | J03 | PostedUp (posters + pay-transparency checker) | Washington's job-posting class actions made salary-range compliance a real fear. The cure period only helps if you catch the problem quickly. Local minimum wages (Seattle, SeaTac, Tukwila, Bellingham, Renton, King County; verify list) change every Jan 1. |
| 5 | J01 | NexusBook (sales tax) | **ESSB 5814** turned agencies, IT shops, web developers and staffing firms into sales-tax collectors in Oct 2025, with changes again in Jul 2026. WA is destination-based with hundreds of local rates. Flat-fee filing beats Avalara quotes, and TaxJar repricing lands Oct 1 2026. |
| 6 | F01 | Chairly (salon/barber booking) | High service wages and no tip credit squeeze salon margins, so Fresha's 20% new-client commissions hurt. Health-intake forms for skin and brow services touch MHMDA, so a bundled consent form is an edge. |
| 7 | C05 | FlatBuild (Buildertrend/CoConstruct replacement) | Seattle-area remodeling is high-ticket, and the CoConstruct Mar 31 2027 cutoff hits here too. Pair it with C06's 60-day-lookback reminders for WA suppliers and subs. |

*Just outside the Top 7:* **C06 LienClock** (60-day lookback), **H02 BoardBinder** (ESSB 5129), **E04 Glowchart** (MHMDA-heavy med spas), **D04 ShiftTip** (no tip credit, Seattle scheduling rules).

## State-only opportunities
1. **MHMDA compliance mode across our health-adjacent products** (A01, E08, F02, E04). One consent ledger records separate consent to collect and to share and signed authorization for any "sale", with 6-year retention. It adds a homepage policy generator and a deletion-request workflow that covers backups. No full idea file: it is a feature wedge, not a standalone product, but it is the strongest WA-specific hook.
2. **"Now you collect sales tax" kit for service microfirms (ESSB 5814).** WA-correct invoicing with DOR location-based rate lookup, an exemption-certificate inbox for B2B resale, and filing reminders. Fold it into J01 and G02 as a WA onboarding flow. A new idea file wasn't justified without fresh complaint evidence.
3. **HB 1217 rent-increase notice builder** for H01. It computes the allowed cap, fills in exemption facts, sets service timing, and runs a fee/deposit check (verify final notice-period rule).

## Where to sell
- **Associations & events:**
  - **Construction:** Master Builders Association of King & Snohomish Counties (MBAKS), BIAW (Building Industry Association of Washington), Seattle Home Show (spring; verify).
  - **Landlords and HOAs:** Rental Housing Association of Washington (RHAWA), Washington Landlord Association (verify), WSCAI (Washington State Community Associations Institute) for HOA/condo boards.
  - **Hospitality, retail and wine:** Washington Hospitality Association, Washington Retail Association, Washington Wine Industry Foundation's WineVit (Feb, Tri-Cities; verify).
  - **Professional:** WSCPA (Washington Society of CPAs; our channel for ESSB 5814 clients), WSBA sections, Washington State Dental Association's Pacific Northwest Dental Conference (June, Bellevue; verify).
- **Online communities:** r/Seattle, r/SeattleWA, r/Tacoma, r/Spokane, r/Bellingham, r/Washington, r/smallbusiness. Facebook groups for Seattle small-business owners, landlords and salon owners (verify names). Seattle Met / Puget Sound Business Journal events.
- **Partners:** Washington SBDC network; City of Seattle Office of Economic Development; Tacoma-Pierce County Chamber; credit unions (BECU, WSECU; verify SMB programs); CPA firms swamped by ESSB 5814 questions; IT and MSP peer groups.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **Freedom-to-read law: HB 2331 (2024)** | Districts must have written review policies, and only parents may file challenges (via R01) | 2024 | R01 (policy pack) |
| Science-of-reading / three-cueing law | No three-cueing ban was confirmed for WA. Dyslexia-screening requirements are from background knowledge (verify). | n/a | P01 |
| 3rd-grade reading plan / retention law | **Conditional:** a parent meeting is required, and if the school and parents disagree, the parent's preference prevails ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)). | In force | P02 (weak) |
| Homeschool (FreedomRankings: high; HSLDA tier: verify) | **Notice:** a declaration of intent filed annually by **Sep 15** (or within 2 weeks of a term start). **Assessment:** each year, either an approved standardized test or a written assessment "by a certificated person who is currently working in the field of education." **Records:** parents keep scores and assessments ([RCW 28A.200.010](https://app.leg.wa.gov/RCW/default.aspx?cite=28A.200.010)). **Parent qualification:** required, per RCW 28A.225.010 (verify details). | Sep 15 yearly | P03 |
| ESA / scholarship money | None | n/a | n/a |
| Other | **Imagination Library of Washington** got **$0** of its $7M 2025–27 request, putting books for 121,000 children and 46 partners at risk (via P06). | 2025–27 biennium | P06, R02 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll.** The annual declaration plus the annual test or certificated-teacher assessment is a yearly filing loop. Add an evaluator-booking marketplace, P03's V2.
- **P06 StoryNest.** Imagination Library affiliates lost state money and need outcome data to fund-raise locally.
- **R01 ClearShelf.** An HB 2331 written-policy and parent-only challenge pack for 295 districts (verify count).

**Where to sell** (names from background knowledge; verify months):
- Washington Library Association (spring conference, including its school-library division).
- Washington State PTA.
- Washington Homeschool Organization (WHO).
- IDA Washington State Branch (verify).
- Pacific Northwest Booksellers Association.

## Launch verdict
**Speed:** Fast to medium. A healthy, growing SMB base (net +9,837 establishments), several fresh WA-only laws, and card-buying service owners. The market is about a sixth the size of CA. **First city:** Seattle (then Tacoma/Spokane). **Lead offer:** DoorLedger with a free "HB 1217 rent-increase calculator and compliant notice," upsold to flat per-door PM. Run a second wedge in parallel: FormFlare "MHMDA mode" for wellness and clinic intake.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Washington (Jun 2025)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Washington_2025-State-Profile.pdf)
- [WA Attorney General: Protecting Washingtonians' personal health data and privacy (My Health My Data Act)](https://www.atg.wa.gov/protecting-washingtonians-personal-health-data-and-privacy)
- [WA Legislature: HB 1217 (2025) bill summary, Chapter 209, Laws of 2025](https://app.leg.wa.gov/billsummary?BillNumber=1217&Year=2025)
- [RCW 59.18.700: Rent increase limits](https://app.leg.wa.gov/RCW/default.aspx?cite=59.18.700)
- [WA Legislature: ESSB 5129 (2025) bill summary, Chapter 119, Laws of 2025](https://app.leg.wa.gov/billsummary?BillNumber=5129&Year=2025)
- [WA Department of Revenue: Services newly subject to retail sales tax (ESSB 5814)](https://dor.wa.gov/taxes-rates/retail-sales-tax/services-newly-subject-retail-sales-tax)
- [RCW 60.04.031: Notices, exceptions](https://app.leg.wa.gov/RCW/default.aspx?cite=60.04.031)
- Internal: `_scoreboard.csv`, `_state_leads_from_category_research.md` (pay transparency, 200-transaction test), ideas A01, H01, J01, J03, C05, C06, F01.
- [RCW 28A.200.010: Home-based instruction, duties of parents](https://app.leg.wa.gov/RCW/default.aspx?cite=28A.200.010)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [Imagination Library of Washington: state budget shuts out funding (Apr 2025), via P06](https://www.imaginationlibrarywashington.org/state_budget_shuts_out_funding_for_dolly_parton_s_imagination_library_of_washington)
- [FreedomRankings: homeschool laws by state (Sep 13 2026)](https://freedomrankings.com/learn/homeschool-laws-by-state)
- Internal (education): ideas R01, P03, P06
