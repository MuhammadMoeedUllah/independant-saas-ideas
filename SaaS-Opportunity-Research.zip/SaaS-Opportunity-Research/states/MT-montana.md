# Montana (MT): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** **141,011** small businesses, 99.2% of Montana firms. They employ **264,567** people, or **66.3%** of Montana employees. That share is the **highest small-business employment share in the US**. **105,934** have no employees ([SBA Advocacy 2026 Montana profile, Sep 2026](https://advocacy.sba.gov/wp-content/uploads/2026/09/Montana.pdf); [2026 profiles landing page](https://advocacy.sba.gov/2026/09/17/2026-small-business-profiles-for-the-states-territories-nation/); [2025 profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Montana_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Small businesses had **5,853 openings vs 5,252 closings** and added **1,926 net jobs** (61.8% of net growth, Mar 2024–Mar 2025) ([SBA 2026 profile](https://advocacy.sba.gov/wp-content/uploads/2026/09/Montana.pdf)).
  - Largest small-business employers:
    - **Accommodation and food services: 44,677**
    - Health care: 41,126
    - Retail: 31,891
- **Buyer clusters (estimate):**
  - **Bozeman/Big Sky/Livingston:** fly-fishing outfitters, ski and resort services, STRs, builders.
  - **Missoula:** outfitters, rafting, restaurants, breweries.
  - **Flathead** (Whitefish, Kalispell, Glacier gateway): lodging, tours, STRs, seasonal retail.
  - **Billings:** trades, health care, energy and ag services, trucking.
  - **West Yellowstone/Gardiner:** motels, campgrounds, tours.
- **Industries overweight vs. US (estimate):**
  - Accommodation and food (the #1 small-business employer here)
  - Outfitting, hunting and fishing guiding
  - Campgrounds and RV parks near Glacier and Yellowstone
  - Seasonal tourist-town retail
  - Craft beverage
  - Ranching and ag services

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Outfitter and guide licensing** (Montana Board of Outfitters, Dept of Labor & Industry): licenses, guide endorsements, client and operations records (verify specifics; the board page fetched this pass had no detail) | Hunting and fishing outfitters and guides | Annual renewal | **S7-01** GuideLedger |
| **EXPLORE Act (P.L. 118-234)**: Title III outfitter permit and fee changes; **BLM implementing since Feb 2 2026** ([BLM](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits); [GovInfo](https://www.govinfo.gov/app/details/PLAW-118publ234)) | Outfitters on national forests (e.g., Custer Gallatin, Flathead) and BLM land | 2026 rollout | **S7-01** |
| **Montana Consumer Data Privacy Act** (in force Oct 1 2024). 2025 amendments lowered the applicability thresholds (reportedly to 25,000 consumers) effective Oct 1 2025 (verify) | Montana e-commerce, lodging chains, larger SMBs | In force | **J02** SiteShield |
| **No tip credit.** State minimum wage indexed yearly (about $10.55 in 2026; verify) | Restaurants, bars | Jan 1 yearly | **D04** ShiftTip |
| **Wrongful Discharge from Employment Act**: the only US state without default at-will employment after probation (verify). Documentation of cause matters. | All employers | In force | **J03** PostedUp, **G04** (write-up and handbook templates) |
| **Local resort taxes** (Whitefish, Big Sky, West Yellowstone and others, under a state resort-tax law) in a no-sales-tax state (verify) | Resort-town lodging, restaurants, retail | Monthly remittance | **D09** ShelfPOS, **D05**, **H03** |
| **Metrc** cannabis tracking (per the state-leads file) | Dispensaries | Ongoing | **J04** (low) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **S7-01** | GuideLedger (outfitters) | Montana is the country's fly-fishing and elk-hunting outfitter capital (estimate), with FOAM and MOGA as ready channels. Fall hunting season ends Nov–Dec, and the switch window is Dec–Mar. |
| 2 | **H03** | StayDesk (STR PMS) | Big Sky, Whitefish, West Yellowstone and Bozeman STR managers, plus Airbnb's 15.5% host-only fee (Oct 27 2025, per H03) and local resort-tax handling. |
| 3 | **D06** | SiteLoop (campgrounds/RV parks) | Glacier and Yellowstone gateway campgrounds and RV parks, all-in pricing (FTC lodging rule), and Campspot camper fees (per D06). Owners switch in the winter off-season. |
| 4 | **B04** | FirstCall (owned leads) | Bozeman, Missoula and Kalispell construction booms, with owner-operated trades everywhere. Scoreboard 23. |
| 5 | **D04** | ShiftTip | Accommodation and food is the #1 small-business employer. No tip credit plus seasonal hiring spikes. |
| 6 | **A03** | LocalLoop | A 66% small-business employment share means owner-operators everywhere, and reviews drive tourist-town traffic. Scoreboard 22. |
| 7 | **D09** | ShelfPOS (tourist-town retail POS) | Retail is the #3 small-business employer. Gateway-town shops are seasonal and resort-tax aware (verify), and Clover/Lightspeed contracts are expiring (per D09). |

Runners-up: **D05** InnDesk (independent motels and lodges), **J05** CellarPermit (breweries and distilleries), **K03** HaulDesk (Billings trucking, IFTA Oct 31).

## State-only opportunities
1. **Outfitters: [S7-01 GuideLedger](../ideas/S7-01-outfitter-guide-booking-permit-reporting.md) (16/25).** Montana is its largest likely market (estimate), with fishing plus hunting and two strong associations.
2. **Resort-tax-aware POS and booking (D09/D05 feature).** In a no-sales-tax state, the only point-of-sale tax many resort-town merchants handle is a local resort tax (verify). A simple per-town resort-tax setting and monthly remittance report is a small but specific wedge.
3. **Gateway campground bundle (D06 variant):** Glacier and Yellowstone gateway parks need timed-entry-season demand planning and all-in nightly pricing (verify local demand).

## Where to sell
- **Associations & events (verify names/dates):**
  - Montana Outfitters & Guides Association (MOGA)
  - Fishing Outfitters Association of Montana (FOAM)
  - Montana Lodging & Hospitality Association
  - Montana Restaurant Association
  - Montana Office of Tourism's Governor's Conference on Tourism & Recreation (spring)
  - Montana Association of REALTORS
  - Montana Society of CPAs
  - Montana Building Industry Association
  - Montana Chamber of Commerce
  - Montana Brewers Association
- **Online communities:**
  - Reddit: r/Montana, r/Bozeman, r/missoula, r/billings, r/flyfishing
  - Facebook: Montana fishing-guide groups and Flathead/Big Sky STR host groups
- **Partners:**
  - Montana SBDC network (Dept of Commerce)
  - First Interstate Bank and Glacier Bank (Montana-based; verify)
  - Outfitter insurance brokers
  - Tourism regions (Glacier Country, Yellowstone Country)

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | No statewide school-library catalog or reconsideration-process law was confirmed in this pass. Montana is not on the category-research lists of library-materials or freedom-to-read states (verify 2023–25 bills on obscenity exemptions) | — | R01 (low fit) |
| Science-of-reading / three-cueing law | Not on the category-research three-cueing-ban or approved-curriculum lists. A 2023 early-literacy law funds early and K–3 interventions (verify) | — | P01, R08 |
| 3rd-grade reading plan / retention law | No retention law. Montana is not on the mandatory, conditional or "coming" retention lists (category research) | — | P02 (low fit) |
| Homeschool rules (HSLDA tier: **low**) | Notice required. No assessment, no teacher qualifications, no immunization rule. Subjects are state-mandated. Compulsory ages 7–16 (with exceptions). HSLDA lists HB 778 as "cutting red tape for homeschool families" (year and details to verify) ([HSLDA MT](https://hslda.org/legal/montana)) | In force | P03 |
| ESA / scholarship money that can buy books, curriculum, classes | **Special Needs Equal Opportunity ESA**, plus tax credits for gifts to Student Scholarship Organizations ([EdChoice MT](https://www.edchoice.org/school-choice/state/montana/); amounts not shown, verify). Montana **opted in to the federal tax-credit scholarship** (Ballotpedia: Jan 21 2026; on the IRS list of 27 states, Jun 8 2026). Donors get up to $1,700 in credits from **Jan 1 2027**, and scholarships can pay for tutors, textbooks and supplies, including for homeschool families ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill); [Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)) | ESA in force; federal credit Jan 1 2027 | P07, P03, P04, R08 |
| Other | Dolly Parton's Imagination Library has been **statewide since 2023** ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)). Current state funding is not confirmed; several states cut their share in 2025–26 (verify) | 2023– | P06, R02 |

**Top 3 reading/education ideas here:**
- **P07 LearnLedger:** federal scholarship money starts in 2027 and flows to homeschool and ESA families, who will need receipts.
- **P03 HomeRoll:** a low-rule homeschool state (notice only) where families still want records for 2027 scholarship spending.
- **R02 ReadRally:** small rural libraries run summer reading on thin budgets and can use a cheap Beanstack alternative.

**Where to sell:**
- **Libraries:** Montana Library Association, annual conference in spring, and its school-library division (verify both).
- **Families:** Montana PTA; Montana Coalition of Home Educators (verify).
- **Reading groups:** Reading League or IDA state contacts, if any (verify).
- **Booksellers:** Pacific Northwest Booksellers Association or Mountains & Plains Independent Booksellers Association (verify which region covers MT).

## Launch verdict
**Speed:** Slow-Medium. The buyer pool is small and seasonal, but owner density is the highest in the US. **First city:** Bozeman (then Missoula, Whitefish).

**Lead offer:** **S7-01 GuideLedger** in Dec–Mar via FOAM and MOGA. The hook: "No 6% fee on your clients, and your agency reports write themselves." Pair it with **H03 StayDesk** for Big Sky and Whitefish managers.

## Sources
- [SBA Office of Advocacy, 2026 Small Business Profile: Montana (Sep 2026)](https://advocacy.sba.gov/wp-content/uploads/2026/09/Montana.pdf)
- [SBA Office of Advocacy, 2026 profiles landing page (Montana leads US in small-business employment share)](https://advocacy.sba.gov/2026/09/17/2026-small-business-profiles-for-the-states-territories-nation/)
- [SBA Office of Advocacy, 2025 Montana profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Montana_2025-State-Profile.pdf)
- [BLM Special Recreation Permits (EXPLORE Act Title III updates, Feb 2 2026)](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits)
- [GovInfo: Public Law 118-234, EXPLORE Act](https://www.govinfo.gov/app/details/PLAW-118publ234)
- Internal: ideas D04, D06, D09, H03, S7-01; `_state_leads_from_category_research.md`; `_scoreboard.csv`
- [HSLDA: Montana homeschool law](https://hslda.org/legal/montana)
- [EdChoice: Montana school choice programs](https://www.edchoice.org/school-choice/state/montana/)
- [IRS IR-2026-76: 27 states signed up for the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [Ballotpedia: state participation in the federal K-12 tax credit scholarship program](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
