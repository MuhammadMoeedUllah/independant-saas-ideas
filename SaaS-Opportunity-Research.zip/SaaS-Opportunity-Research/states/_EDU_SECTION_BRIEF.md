# Brief: add a books/reading/family-education section to each state file

Insert this section into each assigned state file, directly ABOVE the "## Launch verdict" heading (use the Edit tool; do not rewrite the rest of the file). Add any new sources to the file's "## Sources" list.

```
## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | ... | ... | R01 |
| Science-of-reading / three-cueing law | ... | ... | P01, R08 |
| 3rd-grade reading plan / retention law | ... | ... | P02 |
| Homeschool rules (HSLDA tier: none/low/moderate/high) | notice, testing, portfolio... | ... | P03 |
| ESA / scholarship money that can buy books, curriculum, classes | amount, platform | ... | P03, P04, P07, R05, R08 |
| Other (Imagination Library state funding, library funding, auto-renewal law for family subscriptions, etc.) | ... | ... | ... |

**Top 3 reading/education ideas here:** <ID — one-line reason each>
**Where to sell:** <state library association + conference month, state school library association, state PTA, state homeschool association, IDA branch / Reading League chapter, regional bookseller association>
```

Rules:
- Neutral language on library-materials laws: describe what the law requires, not whether it is good.
- Mark facts not confirmed on a fetched page "(verify)". Never invent bill numbers, dates, amounts, or URLs.
- Good sources: HSLDA state pages (https://hslda.org/legal/<state-name>), Education Commission of the States 50-state comparisons, ExcelinEd, NCTQ state reading policy, EdWeek science-of-reading tracker, EveryLibrary, PEN America, ALA, state DOE literacy pages, Imagination Library (imaginationlibrary.com/usa), state library association sites, EdChoice (edchoice.org) for ESA programs.
- Idea IDs and scores: see _scoreboard.csv rows R01–R08 and P01–P07; known state facts: see the last section of _state_leads_from_category_research.md.
