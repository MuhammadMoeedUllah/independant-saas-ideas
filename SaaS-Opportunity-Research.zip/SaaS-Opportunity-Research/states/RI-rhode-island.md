# Rhode Island (RI): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 116,149 small businesses, 98.9% of RI businesses, employing 224,480 people (51.1% of RI employees). 92,358 are nonemployer firms. ([SBA Advocacy 2025 RI profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Rhode_Island_2025-State-Profile.pdf))
- **New-business momentum:** From Mar 2023 to Mar 2024, 5,385 establishments opened and 4,854 closed (net +531). Small firms had 5,144 openings and 4,644 closings and produced 79.8% of net new jobs (+4,102). ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Rhode_Island_2025-State-Profile.pdf))
- **Buyer clusters:**
  - **Providence metro:** a dense independent restaurant scene, universities, health care.
  - **Newport:** hospitality, weddings, sailing and charters, short-term rentals.
  - **South County, Narragansett and Block Island:** a heavily seasonal summer economy.
  - **Warwick and Cranston:** retail and trades.
  - **Bristol and Portsmouth:** marine trades.

  These clusters are an estimate.
- **Industries overweight vs. US:**
  - By small-business employment, health care (40,048), accommodation and food (36,084) and construction (18,856) lead ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Rhode_Island_2025-State-Profile.pdf)).
  - Also overweight (estimate): marine trades and boatbuilding, jewelry manufacturing.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **RI Data Transparency and Privacy Protection Act (R.I. Gen. Laws ch. 6-48.1),** effective **Jan 1 2026**. **§6-48.1-3 has no size threshold.** Any commercial website or ISP doing business in RI or with RI customers that collects, stores and sells personal data must disclose the categories collected, every third party it sells to, and a working contact. It must also say clearly whether it sells data or uses it for targeted ads ([RI Legislature §6-48.1-3](http://webserver.rilegislature.gov/Statutes/TITLE6/6-48.1/6-48.1-3.htm)). The full controller duties apply at 35,000 customers, or at 10,000 when more than 20% of revenue comes from data sales ([§6-48.1-4](http://webserver.rilegislature.gov/Statutes/TITLE6/6-48.1/6-48.1-4.htm)) | Every SMB website using ad pixels, whether it's a restaurant, shop or contractor | In force since Jan 1 2026 | J02 |
| Short-term rental registration with the Dept. of Business Regulation, plus state and local hotel tax (verify) | Newport, Block Island and Narragansett STR hosts and small managers | Ongoing | H03 |
| Minimum wage steps: $16 on Jan 1 2026 and $17 on Jan 1 2027 (verify) | All employers, especially restaurants | Jan 1 2027 | J03, D04, G04 |
| TCI/TDI payroll (temporary caregiver insurance) (verify rate) | All employers | Ongoing | G04 |
| Pay-range disclosure law (in force since Jan 1 2023) (verify) | Employers hiring | In force | J03 |
| Metrc cannabis tracking state (category research) | Cannabis retailers | Ongoing | J04 |
| Sales tax economic nexus: $100k or 200 transactions (verify) | Remote sellers | Ongoing | J01 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | J02 | SiteShield | RI's privacy law requires sell/share disclosures from **every** commercial website with RI customers, with no minimum size. Few SMBs know this. A $X/mo "RI-compliant privacy notice plus pixel audit" is a simple card purchase. |
| 2 | D02 | DirectPlate | Providence's dense independent restaurant scene plus Newport's seasonal volume. App commissions hit hardest in summer. |
| 3 | H03 | StayDesk | Newport and Block Island STR hosts face state registration and tax (verify), plus Airbnb's 15.5% host-only fee for PMS-connected hosts (Oct 2025). |
| 4 | D07 | BookTrail | Newport sailing, harbor tours and Block Island charters. Get rid of FareHarbor-style guest fees. |
| 5 | B04 | FirstCall | Coastal home services such as docks, roofing and HVAC, with a construction-heavy small-firm base. Scoreboard 23. |
| 6 | D03 | TableKeep | Providence restaurants and Newport's wedding and dining season. OpenTable's 2% deposit fee (Jan 2026). |
| 7 | J03 | PostedUp | The $17 minimum wage on Jan 1 2027 (verify) triggers poster and notice updates for every employer. |

## State-only opportunities
1. **RI "every website" privacy notice.** This is the cleanest state-only hook in New England. RI §6-48.1-3 has no threshold, so a restaurant with a Meta pixel is in scope. Ship it as a J02 RI module, with a one-page generator and a pixel and third-party scanner. Not a separate file, because it's a feature of J02.
2. **Marine-trades service scheduling (Bristol, Portsmouth, Newport).** Boatyards doing haul-out, storage and winterization is a possible vertical under C01/H06 patterns. It needs pain research before we spec it.

## Where to sell
- **Associations & events:**
  - Hospitality: Rhode Island Hospitality Association (restaurants and lodging).
  - Construction and marine: RI Builders Association, RI Marine Trades Association.
  - Professional services: RI Society of CPAs, RI Bar Association.
  - Other: RI Realtors (verify), RI Business Coalition, ACA New England (camps).
- **Online communities:** r/RhodeIsland, r/providence, r/Newport (verify activity), r/smallbusiness. Facebook groups for Newport STR hosts and RI restaurant owners (search by name).
- **Partners:** RI SBDC, Greater Providence Chamber and Newport County Chamber, RI Commerce small-business programs, CPA firms, community banks and credit unions.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **Freedom-to-read law: SB 238 (2025)** | A right-to-read law. Readers and writers get a private right of action to keep books on shelves, libraries must follow best practices, and staff get defenses against criminal prosecution ([PEN America, Dec 2025](https://pen.org/report/the-bills-igniting-book-bans/)). | 2025 | R01 (freedom-to-read policy pack) |
| Science-of-reading / three-cueing law | The Right to Read Act (2019) requires structured-literacy training for teachers. That comes from background knowledge (verify). A three-cueing ban was not confirmed. | 2019 → | P01 |
| 3rd-grade reading plan / retention law | **Conditional:** retention is possible in grades 3–8 when a student is chronically absent **and** below grade level in reading or math ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)). | In force | P02 (weak) |
| Homeschool (FreedomRankings/P03: **high**; HSLDA page extraction unclear, verify) | Notice required, subjects required, no state assessment requirement ([HSLDA](https://hslda.org/legal/rhode-island)). "Notice plus testing or professional evaluation" in FreedomRankings' summary ([FreedomRankings, Sep 2026](https://freedomrankings.com/learn/homeschool-laws-by-state)). Approval by the local school committee and an attendance register are from background knowledge (verify). | Yearly | P03 |
| ESA / scholarship money | None. A corporate tax-credit scholarship program exists (verify). | n/a | n/a |
| Other | The RI privacy law (Jan 1 2026) is in the table above, but it isn't education-specific. Statewide Imagination Library funding (verify). | n/a | P06 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf.** SB 238's private right of action makes a documented reconsideration policy and log worth paying for.
- **P03 HomeRoll.** A high-regulation state where each district approves homeschools on its own terms.
- **R02 ReadRally.** A small, compact public-library network (statewide consortium; verify) that a single deal can cover.

**Where to sell** (names from background knowledge; verify months):
- Rhode Island Library Association and School Librarians of Rhode Island.
- RI PTA.
- Rhode Island Guild of Home Teachers (RIGHT).
- IDA New England branch (verify).
- New England Independent Booksellers Association (NEIBA).

## Launch verdict
**Speed:** Medium. The market is small, but it's compact, so one rep can cover it in a day. **First city:** Providence, then Newport in spring. **Lead offer:** J02 SiteShield "RI Privacy Notice in 5 minutes." The law has no threshold, it's been in force since Jan 1 2026, and it comes with a free pixel scan. Upsell D02 and D03 to the same restaurants.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Rhode Island](https://advocacy.sba.gov/wp-content/uploads/2025/06/Rhode_Island_2025-State-Profile.pdf)
- [RI Data Transparency and Privacy Protection Act, ch. 6-48.1 index](http://webserver.rilegislature.gov/Statutes/TITLE6/6-48.1/INDEX.htm)
- [R.I. Gen. Laws §6-48.1-3: information-sharing disclosures](http://webserver.rilegislature.gov/Statutes/TITLE6/6-48.1/6-48.1-3.htm)
- [R.I. Gen. Laws §6-48.1-4: applicability thresholds](http://webserver.rilegislature.gov/Statutes/TITLE6/6-48.1/6-48.1-4.htm)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [HSLDA: Rhode Island homeschool law](https://hslda.org/legal/rhode-island)
- [FreedomRankings: homeschool laws by state (Sep 13 2026)](https://freedomrankings.com/learn/homeschool-laws-by-state)
- Internal (education): ideas R01, R02, P03
