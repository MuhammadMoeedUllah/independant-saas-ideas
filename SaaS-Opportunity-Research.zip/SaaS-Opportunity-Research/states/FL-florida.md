# Florida (FL): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 3.5 million small businesses (99.8% of FL businesses) employ 3.8 million people, or 39.6% of FL employees (2022 data). From Mar 2023 to Mar 2024, 111,346 establishments opened and 94,744 closed, a net gain of 16,602. Small firms produced a net 139,887 jobs, 77.4% of net job growth ([SBA Advocacy 2025 Florida profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Florida_2025-State-Profile.pdf)).
- **New-business momentum:** Florida is the #1 state for new business formation. It logged **514,279 business applications in Jan–Aug 2026** (not seasonally adjusted), ahead of CA (439,856) and TX (403,187). That is **11.8% of the US total (4,345,310)**, from about 7% of US population (population share is from memory, verify). Monthly volume ran 54k–83k, peaking in April 2026 at 83,425 ([Census BFS monthly CSV, Aug 2026 release of Sep 11 2026](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv); [release](https://www.census.gov/econ/bfs/current/index.html)). The largest small-business industries by employment are professional/scientific/technical services, construction, and health care and social assistance (SBA profile above).
- **Buyer clusters:**
  - **Tampa Bay (Tampa, St. Pete, Clearwater):** HVAC, roofing and restoration after the 2024 Helene/Milton storms (verify), plus older Pinellas condos, insurance agencies and salon suites.
  - **Orlando/Kissimmee:** tours and attractions, vacation homes in Osceola County, salons and beauty (Premiere Orlando show), and event and convention vendors.
  - **Miami-Dade, Broward, Palm Beach:** 25+ unit condos, med-spas, restaurants, Spanish-first owner-operators, creators and agencies, and the most ADA web-suit exposure.
  - **Jacksonville:** logistics and trucking, home services and military families.
  - **SW Florida (Fort Myers, Naples):** post-hurricane rebuild, pool routes, snowbird RV parks and condos.
  - **Panhandle (Destin, 30A, Panama City Beach) and the Keys:** vacation rentals, fishing charters and boat tours.
- **Industries overweight vs. US** (inference, verify with County Business Patterns):
  - Construction and roofing, with storm-driven demand.
  - Community associations (condos and HOAs).
  - Tourism and vacation rentals.
  - Health care for an older population (home care, therapy, med-spa).
  - Insurance agencies in a hard property market.
  - Pool service.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Florida Telephone Solicitation Act (FS 501.059).** Automated sales texts and calls need prior express written consent with a signature. After a "STOP" reply the sender has 15 days to stop. Damages are $500 per violation, or actual damages if greater, and can be trebled if willful. Calls to any FL area code carry a rebuttable presumption that they reach a FL resident ([statute](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0500-0599/0501/Sections/0501.059.html)). Quiet hours and the 3-calls-per-24h limit sit in FS 501.616 (verify). | Every SMB that texts or dials marketing: home services, med-spas, salons, dealers, agents | In force (the 15-day STOP cure came in the 2023 amendment, ch. 2023-150) | A03, B01, B04, B06 |
| **Condo/HOA records and website laws.** HOAs with 100+ parcels needed a website by Jan 1 2025 (HB 1203), and condos with 25+ units by Jan 1 2026 (HB 1021). **HB 913 (dated Jun 23 2025 by DBPR; effective Jul 1 2025)** extended the SIRS deadline from Dec 31 2024 to Dec 31 2025. Every condo and co-op had to create a DBPR Division account by **Oct 1 2025** and report annually ([DBPR condos portal](https://condos.myfloridalicense.com/); [FL Senate HB 913 summary](https://flsenate.gov/Committees/BillSummaries/2025/html/913)). | Condo and co-op boards, HOAs, and CAM firms | Deadlines already passed, so laggards are out of compliance; annual Oct 1 reporting | H02 |
| **Sunbiz annual report.** Due **May 1** each year; LLCs pay $138.75 and corporations $150, plus a **$400 late fee** after May 1. Entities that haven't filed are **administratively dissolved at close of business on the 4th Friday of September (Sep 25 2026)**; card payments are taken until 5 pm ET that day ([FL Division of Corporations](https://dos.fl.gov/sunbiz/manage-business/efile/annual-report/)). | Every FL LLC and corporation, with the nation's highest formation volume | May 1 2027 next; the dissolution wave is **this week** | J06 |
| **Health-license CE audit at renewal.** CE records are checked automatically through CE Broker when a license is renewed, across "200+ license types in more than 40 health care professions" ([FL HealthSource](https://www.flhealthsource.gov/)). | Nurses, therapists, dental, pharmacy, massage, and other licensees, plus practices tracking staff | Rolling biennial renewals | J06, E01, E02 |
| **E-Verify mandate (FS 448.095).** Private employers with **25+ employees** must E-Verify new hires (since Jul 1 2023) and keep records for 3 years. Employers certify compliance on their first reemployment-tax return each year. After 3 violations in 24 months the fine is **$1,000/day** and all state licenses can be suspended ([statute](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0400-0499/0448/Sections/0448.095.html)). | Employers with 25+ staff: construction, restaurants, hospitality, landscaping | In force | G04, J03, regional E-Verify kit (below) |
| **Minimum wage step to $15.00/hr on Sep 30 2026**, with tipped wage at $11.98 under the constitutional schedule (from memory, verify). The US DOL table still shows FL at $14.00 ([DOL](https://www.dol.gov/agencies/whd/minimum-wage/state)). | Restaurants, retail, home care, cleaning | **Sep 30 2026** | D04, G04, D01 |
| **Medicaid EVV via HHAeXchange (state aggregator).** AHCA home-health fee-for-service went live Oct 1 2024. **Children's Medical Services moves to Molina, with go-live Oct 1 2026.** Agencies can use the free HHAX portal or send data from their own EVV over EDI ([HHAeXchange FL](https://www.hhaexchange.com/info-hub/florida)). | Home care, private duty nursing and personal care agencies | **Oct 1 2026** | E07 |
| **Tourist development tax (TDT).** **35 counties self-administer TDT**, with rates set by ZIP in Walton, Bay and Okaloosa ([FL DOR DR-15TDT, rev. 03/25](https://floridarevenue.com/Forms_library/current/dr15tdt.pdf)). Osceola says it is "NOT CONTRACTED with Airbnb, VRBO, Evolve", so owners collect and remit its 6% themselves ([Osceola Tax Collector](https://www.osceolataxcollector.org/tourist-development-tax/)). Airbnb's FL tax page does not list Osceola, Walton, Okaloosa, Bay, Monroe or Escambia among the counties it collects for ([Airbnb help 2301](https://www.airbnb.com/help/article/2301)). | Self-managing vacation-rental owners and small property managers | Monthly filings | H03 (+ FL tax module) |
| **Construction lien law.** Notice to Owner is due within **45 days** of first furnishing, and the lien within 90 days (per C06 research). | Subcontractors and suppliers | Ongoing | C06 |
| **ADA website suits.** **961 federal web-accessibility suits in FL in 2025**, second only to NY ([Seyfarth, Mar 2026](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)). | Restaurants, retail and e-commerce, hotels, clinics | Ongoing | J02 |
| **My Safe Florida Home.** Free wind-mitigation inspections and **up to $10,000 in grants** for roof, opening and garage-door upgrades, done by authorized wind-mitigation inspectors and licensed contractors ([MSFH](https://mysafeflhome.com/)). | Home inspectors, roofers, window and door contractors | Funding rounds set by the Legislature | H05, C02 |
| **Hurricane season** (Jun 1–Nov 30) and the 2022 ban on assigning residential property-insurance benefits (AOB) to contractors (SB 2-A, verify). | Roofers, restoration firms, public adjusters, agencies | Every year | C02, C07, G05, B04 |
| **FL Digital Bill of Rights** (Jul 1 2024), with a **$1B revenue threshold**, so it is narrow for SMBs ([privacyterms.io](https://privacyterms.io/us-state-privacy-laws-2026)). | Rarely SMBs | In force | J02 (weak; lead with ADA instead) |
| **K-12 scholarships (FES/FTC/PEP/New Worlds)** run through Step Up For Students, which reports "1M+" scholarships funded ([Step Up](https://www.stepupforstudents.org/); [FLDOE list of 6 programs](https://www.fldoe.org/schools/school-choice/k-12-scholarship-programs/)). | Private schools, microschools, tutors and therapists paid by ESA | Every school year | F06, F07 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture vs Angi/Thumbtack/LSA) | Year-round HVAC, pool and roof work plus storm surges put FL contractors among the heaviest lead buyers. Google ended LSA disputes in Nov 2025. We ship FTSA-grade consent capture on every form, so the lead is "legal to text." |
| 2 | A03 | LocalLoop (reviews and texting vs Podium/Birdeye) | FL is the FTSA state: $500 per text, trebled if willful, a 15-day STOP rule and an area-code presumption. A "consent log + STOP handling + quiet hours" pitch sells on fear as well as price, in Tampa, Orlando, Miami and Jacksonville. |
| 3 | H02 | BoardBinder (condo/HOA compliance portal) | The only state where statute forces the purchase: 25+ unit condo websites (Jan 1 2026), 100+ parcel HOA websites (Jan 1 2025), annual DBPR reporting and SIRS. Thousands of self-managed boards are out of compliance now. |
| 4 | J06 | LicenseLedger (CE plus entity compliance) | CE Broker gates renewal for 200+ health license types. Sunbiz charges a $400 late fee and **dissolves unfiled entities Sep 25 2026**, so "reinstatement rescue" and "never miss May 1" campaigns fit the biggest LLC formation market in the US. |
| 5 | F01 | Chairly (salon/barber booking) | Salon-suite density in Tampa, Orlando and Miami, with Premiere Orlando as a trade show to work. Fresha and Vagaro fee anger is a nationwide switching window, and many owner-operators need Spanish-language booking. |
| 6 | D07 | BookTrail (tours and charters vs FareHarbor/Peek) | Orlando attractions, Keys and Gulf fishing charters, eco and boat tours. FareHarbor's 6% guest fee and 2026 platform change open a switching window. The Jun–Sep slow season suits migrations. |
| 7 | J02 | SiteShield (ADA and privacy) | 961 federal ADA web suits in 2025, and repeat plaintiffs target restaurants and retail. Sell a code-level fix plus a monitoring report, not an overlay. Privacy is secondary because FL's law barely touches SMBs. |

Bench (strong FL fit, lower national score):
- **H03 StayDesk with a FL TDT module:** see state-only opportunities below.
- **H05 InspectKit:** wind-mitigation (OIR-B1-1802) and 4-point forms, plus MSFH free inspections.
- **E07 Shiftwell:** HHAeXchange EDI, with the CMS-to-Molina go-live on Oct 1 2026.
- **D04 ShiftTip:** the $15 minimum wage and $11.98 tipped wage on Sep 30 2026.
- **F06 ESA Desk:** the largest ESA market in the US.
- **C07 ClaimKit:** hurricane claims.
- **G05 AgencyLite:** remarketing work driven by carrier non-renewals.

## State-only opportunities
1. **Florida tourist-tax desk (add-on to H03, candidate for a standalone idea).**
   - **The burden:** 35 counties self-administer TDT at county- and ZIP-specific rates. Osceola, the Disney-area vacation-home capital, is contracted with **no** booking platform. Airbnb's FL page leaves out Walton/30A, Okaloosa/Destin, Bay/PCB, Monroe/Keys and Escambia. Owners must still file the state DR-15 for direct bookings.
   - **The product:**
     - Connect Airbnb, VRBO and direct-booking payouts.
     - Show which taxes the platform already remitted.
     - Compute the county TDT owed by ZIP.
     - Produce ready-to-file county returns and a DR-15 worksheet.
     - Track the DBPR vacation-rental license and guest-register records.
   - **Price:** about $15–25/property/mo, sold to self-managing owners and 5–50-unit managers.
   - **Gaps:** Avalara MyLodgeTax pricing is not published (sales call or JS cart), and review complaints were not mined in this pass. Validate both before writing a full idea file.
   - **Estimated score:** about 16/25.
2. **Condo/HOA compliance** (fully specced in H02) is the one purchase that statute forces. Two wedges:
   - Sell the compliance website alone for boards that keep their management company.
   - Offer a free "Is your condo website compliant?" scan tied to the FS 718.111(12)(g) checklist.
3. **Southeast E-Verify and I-9 kit (regional).** FL's 25+ employee mandate, with $1,000/day fines and license suspension, joins GA, NC, SC, AL, MS and TN mandates. We would sell I-9 plus E-Verify case logging, re-verification alerts, an audit binder and the annual FL certification reminder, as a $19/mo add-on to G04 or J03.
   - **Caveat:** E-Verify itself is free, and USCIS is rolling out a free E-Verify+, so the price gap is thin. Keep it as an add-on, not a standalone.

## Where to sell
- **Associations & events** (all verify names and dates):
  - **Hospitality and beauty:** Florida Restaurant & Lodging Association (FRLA), Premiere Orlando (beauty, early summer).
  - **Building and property:** Florida Home Builders Association, Florida Roofing & Sheet Metal Contractors Association (FRSA convention, summer), FRACCA (HVAC), Florida Pest Management Association, Florida Swimming Pool Association, CAI Florida chapters and the CAM licensing/CE ecosystem.
  - **Real estate, finance and insurance:** Florida REALTORS (annual convention, August, Orlando), FICPA, The Florida Bar (LegalFuel practice management), Florida Association of Insurance Agents (FAIA).
  - **Health care:** Florida Dental Association (Florida Dental Convention, June), Florida Veterinary Medical Association, Home Care Association of Florida.
  - **Tourism and outdoor:** Florida Association of RV Parks & Campgrounds, Florida Attractions Association.
  - **National shows held in FL:** VMX (vet) and the PGA Show (golf) in Orlando each January.
- **Online communities:**
  - Subreddits: r/florida, r/tampa, r/orlando, r/miami, r/jacksonville, r/fortmyers, r/condo, r/HOA.
  - Facebook: county-level condo owner and vacation-rental owner groups (search "Osceola vacation home owners" and "30A rental owners"; group names not verified).
  - Nextdoor, for condo boards.
  - Spanish-language owner groups in Miami-Dade and Orlando.
- **Partners:**
  - Florida SBDC Network (verify host institution).
  - Condo and HOA law firms that run HB 913 seminars.
  - CAM firms.
  - HVAC and pool supply houses: Watsco/Gemaire, Carrier Enterprise, SCP/POOLCORP and Leslie's (verify local branches).
  - Wind-mitigation inspector schools.
  - Community banks: Seacoast, SouthState, Truist.
  - CPA firms for the Sunbiz/entity angle.
  - County tax collectors' TDT outreach pages, for listing as a resource.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials law: HB 1069 (2023)**, plus HB 1467 (2022) (verify) | Districts must follow a state objection process for library and classroom materials. Objections may be based on obscenity (Miller test) or age-appropriateness. HB 1467 requires a searchable list of library and classroom materials (verify). **Court status:** on Aug 13 2025, Judge Carlos Mendoza (M.D. Fla.) struck the provision allowing removal within 5 days of an objection. The challenge procedures and objection grounds were upheld. Florida appealed on Sep 11 2025. Librarians told WLRN they would wait for the appeal before restoring titles ([WLRN, Sep 19 2025](https://www.wlrn.org/light/law-justice/2025-09-19/federal-judge-overturns-part-of-floridas-book-ban-law-drawing-on-precedent-protecting-first-amendment)). Districts are still removing titles under state guidance (Polk County, Apr 2026, per [Book Riot](https://bookriot.com/dollys-imagination-library-state-funding/)). | 2023. Partly enjoined Aug 2025; appeal pending (verify outcome) | R01, R07, R04 (pre-published fair lists) |
| Science of reading / three-cueing law | A three-cueing ban and an approved-curriculum mandate (per the category lead list; verify the bill). **New Worlds Reading Initiative** (UF Lastinger Center) mails free Scholastic books each month to VPK–5 public and charter students who "tested below grade level in reading at any point since August 2021": 9 books at enrollment and up to 63 by the end of 5th grade, in English, Spanish, Haitian Creole or braille. It says 80% of public and charter students qualify ([New Worlds Reading](https://www.newworldsreading.com/)). | In force | P01, R08, P06 |
| 3rd-grade reading plan / retention law | Mandatory 3rd-grade retention state (per the lead list; verify statute detail) | In force | P02 |
| Homeschool rules (HSLDA tier: **low**) | Three legal options. Notice and a yearly evaluation are required only under option 1, the home-education statute (notice to the district superintendent). No state-mandated subjects and no parent teacher qualifications ([HSLDA FL](https://hslda.org/legal/florida)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **Step Up For Students** runs FTC and FES-EO (about $8,000 average), FES-UA (about $10,000 average) and **PEP, the homeschool ESA (about $8,000; capacity expanded to 140,000 for 2026–27)**. Families pay through the EMA wallet, by reimbursement, or through MyScholarShop. Outschool is listed as an approved Home Education Instructional Program provider ([Outschool FL guide, Sep 14 2026](https://outschool.com/esa-guides/florida-step-up-for-students); vendor-written, verify amounts). **New Worlds Scholarship Accounts** give $1,200/yr to VPK–5 students not reading on grade level, for tutoring, reading/math materials and summer programs through the EMA. Step Up's page says it is taking no new applications "due to the lack of new funding for the 2025-26 school year" ([Step Up NWSA](https://www.stepupforstudents.org/scholarships/new-worlds-scholarship-accounts/); 2026–27 status verify). | 2026–27 school year now running | P03, P04, P07, R05, R08 |
| Other | The Florida PTA requires Givebacks/MemberHub for its units ([FL PTA](https://www.floridapta.org/memberhub-givebacks/), via P05). The "1M+" scholarships funded (Step Up, above) is the largest ESA-style pool in the US. | Now | P05 |

**Top 3 reading/education ideas here:**
- **P04 ClassHouse:** PEP alone has room for 140,000 homeschool ESA students at about $8,000 each. Independent class teachers and tutors need an EMA/HEIP-listable storefront with scholarship-ready invoices instead of Outschool's cut.
- **P03 HomeRoll:** it covers FL's three options (option 1 notice plus yearly evaluation) and PEP spending records in one place.
- **R01 ClearShelf:** the HB 1069 objection process still applies, and the removal rule could change on appeal. Districts need a documented, neutral challenge log that can adapt to the ruling.
- **Bench:** P01 and R08 (New Worlds and the three-cueing ban).

**Where to sell:**
- **Libraries:** Florida Library Association (annual conference, spring; verify) and the Florida Association for Media in Education (FAME; fall conference, verify).
- **Parents:** Florida PTA and the Florida Parent-Educators Association (FPEA convention, Orlando, May; verify).
- **Scholarships:** Step Up For Students provider onboarding.
- **Reading:** IDA Florida branch and The Reading League Florida (verify).
- **Booksellers:** SIBA (Southern Independent Booksellers Alliance).

## Launch verdict
**Speed:** Fast. **First city:** Tampa Bay, then Orlando/Kissimmee and Miami. **Lead offer:** FirstCall (B04) plus LocalLoop (A03) bundled as **"FTSA-safe leads and texting"** for home-service contractors, with a free FTSA consent audit of their web forms. Run H02 (condo website compliance scan) in parallel in Pinellas, Miami-Dade and Broward.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Florida](https://advocacy.sba.gov/wp-content/uploads/2025/06/Florida_2025-State-Profile.pdf)
- [US Census Bureau, Business Formation Statistics monthly CSV (Jan–Aug 2026)](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv) and [BFS release, Sep 11 2026](https://www.census.gov/econ/bfs/current/index.html)
- [Florida Statutes 501.059, Telephone Solicitation](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0500-0599/0501/Sections/0501.059.html)
- [Florida Statutes 448.095, Employment eligibility (E-Verify)](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0400-0499/0448/Sections/0448.095.html)
- [FL Division of Corporations, annual report rules and 2026 dates](https://dos.fl.gov/sunbiz/manage-business/efile/annual-report/)
- [FL DBPR Division of Condominiums portal (Oct 1 2025 account deadline; SB 4D, SB 154, HB 1021, HB 913)](https://condos.myfloridalicense.com/)
- [Florida Senate, CS/CS/HB 913 (2025) bill summary](https://flsenate.gov/Committees/BillSummaries/2025/html/913)
- [FL HealthSource (DOH MQA), CE tracking at renewal](https://www.flhealthsource.gov/)
- [US DOL, state minimum wage table](https://www.dol.gov/agencies/whd/minimum-wage/state)
- [HHAeXchange Florida information center](https://www.hhaexchange.com/info-hub/florida)
- [FL DOR, DR-15TDT local option transient rental tax rates (rev. 03/25)](https://floridarevenue.com/Forms_library/current/dr15tdt.pdf)
- [Osceola County Tax Collector, Tourist Development Tax](https://www.osceolataxcollector.org/tourist-development-tax/)
- [Airbnb Help, occupancy tax collection in Florida](https://www.airbnb.com/help/article/2301)
- [Seyfarth ADA Title III blog, 2025 federal web-accessibility filings by state](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)
- [My Safe Florida Home](https://mysafeflhome.com/)
- [privacyterms.io, US state privacy laws 2026](https://privacyterms.io/us-state-privacy-laws-2026)
- [Step Up For Students](https://www.stepupforstudents.org/) and [FLDOE K-12 scholarship programs](https://www.fldoe.org/schools/school-choice/k-12-scholarship-programs/)
- [WLRN: Federal judge overturns part of Florida's book ban law (Sep 19 2025)](https://www.wlrn.org/light/law-justice/2025-09-19/federal-judge-overturns-part-of-floridas-book-ban-law-drawing-on-precedent-protecting-first-amendment)
- [Book Riot: Book Censorship News, Apr 17 2026](https://bookriot.com/dollys-imagination-library-state-funding/)
- [New Worlds Reading Initiative (UF Lastinger Center)](https://www.newworldsreading.com/)
- [Step Up For Students: New Worlds Scholarship Accounts](https://www.stepupforstudents.org/scholarships/new-worlds-scholarship-accounts/)
- [Outschool: Florida Step Up For Students 2026–27 guide (Sep 14 2026)](https://outschool.com/esa-guides/florida-step-up-for-students)
- [HSLDA: Florida homeschool laws](https://hslda.org/legal/florida)
- [Florida PTA: MemberHub/Givebacks](https://www.floridapta.org/memberhub-givebacks/) (via P05)

## Verification (Sep 24 2026)
- ✅ FTSA (FS 501.059): prior express written consent must include the called party's signature (e-signatures and checkboxes count), a 15-day window after a "STOP" reply before suit, the greater of actual damages or $500, up to treble if willful or knowing, and a *rebuttable* presumption that calls to FL area codes reach FL residents. Last amended by ch. 2023-150 ([FS 501.059](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0500-0599/0501/Sections/0501.059.html))
- ⚠️ Quiet hours and the 3-calls-per-24h limit are **not** in 501.059. The 501.616 cite still needs checking ([FS 501.059](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0500-0599/0501/Sections/0501.059.html))
- ✅ Condo/HOA websites: FS 720.303(4)(b) requires "by January 1, 2025, an association that has 100 or more parcels" to post records. FS 718.111(12)(g) covers condos with "25 or more units", with a 30-day posting window (the 25-unit change is in ch. 2024-244). HB 913 is effective Jul 1 2025 (passed 37-0 and 112-0), moved the SIRS deadline from Dec 31 2024 to Dec 31 2025, and set the DBPR account and report for Oct 1 2025 and annually after ([718.111](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0700-0799/0718/Sections/0718.111.html); [720.303](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0700-0799/0720/Sections/0720.303.html); [FL Senate HB 913](https://flsenate.gov/Committees/BillSummaries/2025/html/913))
- ✅ Sunbiz fees are LLC $138.75 and corp $150, with a $400 late fee after May 1. Non-filers are dissolved "at the close of business on the fourth Friday of September", and card payments are taken "through 5:00pm EST, September 25, 2026" (the launch-week hook). The page also says to file by the third Friday (Sep 18) to avoid dissolution ([Sunbiz](https://dos.fl.gov/sunbiz/manage-business/efile/annual-report/))
- ✅ E-Verify (FS 448.095): private employers with 25+ employees since Jul 1 2023, records kept 3 years, certification on the first reemployment-tax return each year, and after 3 violations in 24 months a $1,000/day fine plus possible license suspension ([FS 448.095](http://www.leg.state.fl.us/statutes/index.cfm?App_mode=Display_Statute&URL=0400-0499/0448/Sections/0448.095.html))
- ✅ HHAeXchange: AHCA home-health FFS EVV went live Oct 1 2024, and "Children's Medical Services will be transitioned to Molina on October 1, 2026". Agencies can use the free portal or send EDI from their own EVV ([HHAeXchange FL](https://www.hhaexchange.com/info-hub/florida))
- ⚠️ The minimum wage rises to $15.00 on Sep 30 2026 (tipped wage $11.98). US DOL still shows $14.00 (last updated Jul 1 2026), and the constitutional schedule was not fetched, so this stays (verify) ([DOL](https://www.dol.gov/agencies/whd/minimum-wage/state))
