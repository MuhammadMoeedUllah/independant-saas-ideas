# North Dakota (ND): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 78,219 small businesses employing 197,212 people, or **57.6% of North Dakota employees**, far above the US share. 19,113 small employer firms. Data year 2022. ([SBA Advocacy 2025 North Dakota profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/North_Dakota_2025-State-Profile.pdf))
- **New-business momentum:** From March 2023 to March 2024, small businesses gained 29,523 jobs and lost 23,165, a net gain of 6,358. Small-business employment grew 20.7% from 1998 to 2022, faster than the US ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/North_Dakota_2025-State-Profile.pdf)). The largest small-business employers are health care and social assistance (28,126), retail (23,254) and construction (20,264). Census BFS was not fetched in this pass.
- **Buyer clusters:**
  - **Fargo/West Fargo:** tech and software (a Bushel/Microsoft presence; verify), health care, ag-equipment dealers, construction, restaurants.
  - **Bismarck/Mandan:** state government, health care, trades.
  - **Williston, Watford City, Dickinson and Minot (Bakken):** oil-field services, water and crude hauling, hot-shot trucking, man-camps and workforce housing, staffing, equipment rental, HVAC/electrical.
  - **Grand Forks:** university, Air Force base, services.
  - **Devils Lake and rural ND:** fishing guides, duck and pheasant outfitters; co-ops and grain elevators.
- **Industries overweight vs. US:** oil and gas extraction and services, agriculture and ag retail/equipment, trucking, retail (the #2 small-business employer), construction. Overweights are estimates.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **IFTA quarterly return**; seasonal spring load restrictions ("frost laws") on ND roads (verify) | Oil-field haulers, ag haulers, hot-shot operators | **Oct 31 2026**, then Jan 31; frost laws each spring | K03 |
| **Contractor license** through the ND Secretary of State, required above a job-value threshold with annual renewal (from knowledge; the SOS page was not reachable, verify threshold and date) | Trades, oil-field construction, roofers | Annual (verify) | C01, J06 |
| **Sales tax:** remote-seller 200-transaction test dropped (per J01) | E-commerce sellers | In force | J01 |
| **NFIRS retired Jan 31 2026 → NERIS** (federal). ND fire service is mostly rural and volunteer (verify). | Volunteer fire departments | Jan 31 2026 (passed) | J07 |
| **Medicaid EVV:** Sandata (both sources agree; appears closed) | Home care | In force | E07 (weak: closed model) |
| **No comprehensive state privacy law** found (verify) | n/a | n/a | J02 (weak) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | K03 | HaulDesk | Bakken water, crude and sand hauling plus harvest-season ag hauling means many 1–20 truck carriers. IFTA is due Oct 31 2026 and DAT renewals are up 25–45%. Owner-operators buy by card. |
| 2 | C01 | FlatRate | Oil-patch HVAC, electrical, plumbing and equipment-service shops, plus Fargo trades. ServiceTitan exit fees and Housecall Pro bill creep drive switching. |
| 3 | B04 | FirstCall | Score 23. Fargo and Bismarck home-service growth. |
| 4 | A03 | LocalLoop | Score 22. Retail, the #2 small-business employer, plus restaurants and clinics. |
| 5 | G07 | BenchBoard | Oil-field and construction staffing agencies (Williston/Dickinson) ramp headcount with rig counts. Bullhorn auto-renewals and Indeed per-application billing. |
| 6 | F01 | Chairly | Score 22. Fargo, Bismarck and Grand Forks salons. |
| 7 | D07 | BookTrail | Devils Lake fishing guides and waterfowl and pheasant outfitters take multi-day packages, deposits and license capture. |

Close alternates: J07 StationLog (volunteer fire departments after NERIS), C03 SprayLog (ag applicators, including drone spraying).

## State-only opportunities
1. **Bakken oil-field service back office (K03 + C01 variant).** Run tickets and field tickets signed on a phone, per-well job costing, driver hours and IFTA, and fast invoicing to operators, who often pay only against a clean field ticket. Target 5–50 person water haulers, roustabout crews and hot-shot operators in Williston and Watford City. It needs a separate idea file with complaint evidence on the incumbents (not researched in this pass).
2. **Outfitter booking for waterfowl, pheasant and Devils Lake fishing (D07 variant).** Seasonal owner-operators with deposit-heavy packages. Sell in the winter off-season.

## Where to sell
- **Associations & events** (from knowledge, verify):
  - North Dakota Petroleum Council (Williston Basin Petroleum Conference, Bismarck)
  - North Dakota Motor Carriers Association
  - North Dakota Hospitality Association
  - North Dakota Association of Builders and Home Builders Association of Fargo-Moorhead
  - North Dakota Association of REALTORS
  - North Dakota CPA Society
  - State Bar Association of North Dakota
  - North Dakota Agricultural Association
  - Big Iron Farm Show (West Fargo, September)
  - North Dakota Firefighter's Association
- **Online communities:** r/fargo, r/northdakota, r/bismarck. Williston/Bakken jobs and oil-field Facebook groups (verify). Emerging Prairie / 1 Million Cups Fargo.
- **Partners:**
  - North Dakota SBDC
  - Bank of North Dakota partner lenders (state-owned bank; verify programs)
  - Community banks (Bell, Gate City; verify)
  - Oil-field insurance agents
  - IFTA/permit filing services in Williston and Dickinson
  - Fargo Moorhead West Fargo Chamber

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | A 2023 law on sexually explicit material in public and school library children's collections (verify bill number, scope and any court challenge). ND isn't on the category-research process-law lists | 2023 (verify) | R01, R07 |
| Science-of-reading / three-cueing law | Not on the category-research three-cueing-ban or approved-curriculum lists (verify 2023–25 literacy bills) | — | P01, R08 |
| 3rd-grade reading plan / retention law | No retention law on the category-research lists | — | P02 (low fit) |
| Homeschool rules (HSLDA tier: **high**, per category research; the HSLDA page label couldn't be confirmed) | Notice required. **Teacher qualifications apply**, subjects are state-mandated, assessment is "Yes, with exceptions," and immunization rules apply. Compulsory ages 7–16. Two legal options ([HSLDA ND](https://hslda.org/legal/north-dakota)). Test grades and monitoring rules to verify | In force | **P03** |
| ESA / scholarship money that can buy books, curriculum, classes | **None:** "North Dakota does not have a private school choice program" ([EdChoice ND](https://www.edchoice.org/school-choice/state/north-dakota/)). A 2025 ESA bill was vetoed (verify). ND **opted in to the federal tax-credit scholarship** (Ballotpedia: Jan 26 2026; IRS list, Jun 8 2026). SGO scholarships can pay for tutors, textbooks and supplies, including for homeschoolers, from **Jan 1 2027** ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | Jan 1 2027 | P07, P03, P04 |
| Other | Not on the CSG South list of statewide Imagination Library programs ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)) | — | P06 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll:** ND is one of the few states with teacher-qualification and assessment rules for homeschoolers, so it's a records-heavy regime in a small market.
- **P07 LearnLedger:** federal scholarship dollars from 2027 are the only outside education money, and families will need receipt logs.
- **R02 ReadRally:** small-town libraries need a cheap summer-reading platform.

**Where to sell:**
- **Libraries:** North Dakota Library Association annual conference (fall, verify); ND school-library section (verify).
- **Homeschool groups:** North Dakota Home School Association (verify).
- **Families:** state PTA/PTO contacts (verify whether an ND PTA exists).
- **Booksellers:** Midwest-region bookseller association (verify which covers ND).

## Launch verdict
**Speed:** Slow (smallest market of the seven). The oil-patch trucking niche is Medium. **First city:** Fargo for general SaaS; Williston/Watford City for the oil-field wedge. **Lead offer:** K03 HaulDesk for Bakken and ag carriers: "file your Oct 31 IFTA in minutes, drop the DAT/Motive bloat."

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: North Dakota](https://advocacy.sba.gov/wp-content/uploads/2025/06/North_Dakota_2025-State-Profile.pdf)
- Internal: ../ideas/K03, C01, G07, D07, J07, E07 idea files; ../_state_leads_from_category_research.md (sales-tax threshold list, IFTA dates, NERIS)
- [HSLDA: North Dakota homeschool law](https://hslda.org/legal/north-dakota)
- [EdChoice: North Dakota](https://www.edchoice.org/school-choice/state/north-dakota/)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [Ballotpedia: state participation in the federal K-12 tax credit scholarship program](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
