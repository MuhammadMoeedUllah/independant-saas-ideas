# Colorado (CO): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** **730,887** small businesses, 99.5% of Colorado firms. They employ **1.2 million** people, or **48.6%** of Colorado employees. **583,986** have no employees ([SBA Advocacy 2026 Colorado profile, Sep 2026](https://advocacy.sba.gov/wp-content/uploads/2026/09/Colorado.pdf); [2025 profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Colorado_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Small businesses opened **15,114** establishments (Mar 2024–Mar 2025).
  - Colorado small businesses had a **net loss of 5,789 jobs**: 203,191 gained vs 208,980 lost ([SBA 2026 profile](https://advocacy.sba.gov/wp-content/uploads/2026/09/Colorado.pdf)). Squeezed owners are receptive to "cut your software bill."
  - Largest small-business employers:
    - Accommodation and food services: 181,414 employees
    - Health care: 163,267
    - Construction: 138,584
- **Buyer clusters (estimate):**
  - **Denver metro** (Denver, Aurora, Lakewood, Arvada, Westminster): landlords and property managers, restaurants, dog daycares, boutique fitness, therapists, roofing and restoration after hail, breweries.
  - **Colorado Springs:** hail roofing, military-family services.
  - **Boulder and Fort Collins:** fitness, therapy, breweries, tech-savvy owners.
  - **Mountain towns** (Summit County, Vail, Aspen, Steamboat, Durango): STRs, tours, rafting and ski rentals, lodging.
  - **Western Slope:** outfitters and hunting units.
- **Industries overweight vs. US (estimate):**
  - Accommodation, food and mountain tourism (the largest small-business employer here)
  - Roofing, restoration and insurance work in hail alley
  - Rental housing (a new junk-fee regime)
  - Craft beverage
  - Outdoor recreation
  - Health and wellness

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **HB25-1090, Protections Against Deceptive Pricing Practices.** Bans advertising a price unless the business "clearly and conspicuously" discloses the **maximum total** of all amounts. Violations are deceptive practices under the CO Consumer Protection Act, and a business that doesn't answer a written demand within 14 days owes damages plus 18% interest ([leg.colorado.gov](https://leg.colorado.gov/bills/hb25-1090)). | Named sectors: **landlords, food and beverage establishments**, delivery network companies, real estate settlement services, and broadband/cable/satellite providers. The legislature's summary does **not** name ticket sellers, so they are covered only by the general "maximum total price" rule. | In force **Jan 1 2026** (verify; the date is not on the leg.colorado.gov summary. Per [Otten Johnson](https://www.ottenjohnson.com/news/hb25-1090-colorados-residential-landlords-must-eliminate-junk-fees-in-2026-including-cam-char), via H01) | **H01** DoorLedger, **I04** DoorList, **D02**/**D03**, **D07** BookTrail (fee-on-top checkouts), **D05**/**D06** |
| **Colorado AI Act (SB24-205)**, delayed by **SB25B-004** (signed Aug 28 2025) to **June 30 2026** ([SB25B-004](https://leg.colorado.gov/bills/sb25b-004); [SB24-205](https://leg.colorado.gov/bills/sb24-205)). Covers developers and **deployers of high-risk AI** used in consequential decisions such as hiring, housing and lending. A small-deployer carve-out (<50 FTE, not training on own data) and any 2026-session amendments need checking (verify). | Staffing firms, landlords and tenant screening, lenders and insurers using AI scoring | June 30 2026 (verify current status) | **G07** BenchBoard, **H01**. Ship AI-Act notices and impact-assessment templates as a feature. |
| **Colorado Privacy Act** (in force Jul 1 2023; applies at 100k+ consumers, or 25k+ with sale revenue). SB24-041 added biometric (Jul 1 2025) and minors' data (Oct 1 2025) duties. Universal opt-out list is live ([CO AG](https://coag.gov/resources/colorado-privacy-act/)). | E-commerce and multi-location businesses above the thresholds | In force | **J02** SiteShield (only for larger SMBs) |
| **Equal Pay for Equal Work Act: pay ranges in job postings**, plus promotion-opportunity notices. Applies to employers with 1+ Colorado employee. Amended by SB23-105 (Jan 1 2024) (verify). | Every hiring SMB, staffing agencies | In force | **J03** PostedUp, **G07** |
| **FAMLI paid family leave** premiums and benefits (benefits since Jan 2024), plus HFWA paid sick leave (verify) | All employers | Quarterly premiums | **G04** StatePay |
| **Home-rule city sales tax**: roughly 70 self-collecting home-rule cities with their own licenses and returns, partly covered by the SUTS portal. Colorado also dropped the 200-transaction nexus test (per the state-leads file) (verify). | Retailers, e-commerce, contractors buying materials | Monthly/quarterly | **J01** NexusBook, **G02** |
| **Roofing contractor law (C.R.S. 6-22)**: written contracts, cancellation rights after an insurer denial, no deductible waivers (verify) | Storm roofers | Every job; hail season Apr–Sep | **C02** StormDesk, **A04** SignFlat, **C07** |
| **Pet Animal Care Facilities Act (PACFA)** license and inspection for boarding, daycare and grooming (verify) | Dog daycares, boarders, groomers | Annual license | **F04** PackLeader |
| **Denver minimum wage** (about $19+ in 2026) and **Denver STR licensing** (primary-residence rule) (verify) | Denver restaurants, STR hosts | Jan 1 yearly | **D04**, **H03** |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **H01** | DoorLedger (small-landlord PM) | HB25-1090 is **in force now**. Landlords can't tack on payment-processing, CAM or tax pass-through fees and must advertise all-in rent. A "Colorado listing and fee checker" lead magnet plus automatic fee blocking is a compliance sale, not a nice-to-have. The H01 file already names CO as its #1 market. |
| 2 | **B04** | FirstCall (owned leads vs Angi) | **Angi is headquartered in Denver** and faces the *Airquip v. HomeAdvisor* contractor class action (per B04). Front Range contractors know the brand's problems firsthand. Hail-season roofers pay for shared leads. Scoreboard 23. |
| 3 | **D07** | BookTrail (tours/activities, no guest fee) | FareHarbor's 6% fee added at checkout is exactly the drip pricing HB25-1090 targets for "other service providers" (legal check needed). Rafting, jeep, fly-fishing and ski-rental operators are in their **Oct–Mar off-season switch window now**. |
| 4 | **C02** | StormDesk (roofing/storm CRM) | Colorado sits in hail alley, and the Front Range storm season (Apr–Sep) just ended. Winter is when roofers re-tool. C.R.S. 6-22 contract rules (verify) make e-sign templates and cancellation notices a feature. |
| 5 | **J03** | PostedUp (posters and pay transparency) | Colorado's pay-range rule covers employers with even **one** Colorado employee, plus FAMLI and HFWA notices. That's a cheap, repeatable compliance sale to every hiring small business. |
| 6 | **I04** | DoorList (ticketing vs Eventbrite) | HB25-1090's general all-in "maximum total price" rule reaches ticketing, although the bill summary does not list ticket sellers as a named sector. Denver, Boulder and mountain-town event organizers need all-in pricing, and Eventbrite's Bending Spoons takeover (Mar 2026) is a switching window. |
| 7 | **F02** | OpenStudio (gym/studio vs Mindbody/Glofox) | The F02 file lists Denver as a high boutique-studio-density metro. Glofox hikes of 70–300% and the Mindbody discovery fee are live pain. |

Runners-up: **C07** ClaimKit (hail restoration), **F04** PackLeader (Denver dog daycares plus PACFA), **J01** NexusBook (home-rule sales tax), **H03** StayDesk (mountain-town STRs), **J05** CellarPermit (craft breweries).

## State-only opportunities
1. **"All-in price" compliance kit across verticals (HB25-1090).** One free Colorado price-display checker for landlords, restaurants, ticketing and tour operators. It feeds H01, D02, D03, I04 and D07 with the same message: "Colorado made drip pricing illegal; our checkout shows the total from the first screen." We are building checkouts anyway, so the marginal build cost is low. Not written as a separate idea file because it is a GTM wedge for existing ideas.
2. **Home-rule sales-tax filer (J01 variant).** Colorado's self-collecting home-rule cities are a uniquely painful patchwork (verify count). A "which Colorado cities do I owe and when" calendar plus return prep for Denver, Aurora, Colorado Springs and Boulder could open J01 in CO ahead of the TaxJar Oct 1 2026 repricing.
3. **AI Act-ready HR and tenant screening (G07/H01 feature).** If the June 30 2026 date held (verify), small staffing firms and landlords using AI screening need notices, adverse-decision explanations and a yearly impact assessment. Ship templates inside G07 and H01 rather than as a standalone product. The market is uncertain because of carve-outs.

## Where to sell
- **Associations & events (verify names/dates):**
  - Apartment Association of Metro Denver and Colorado Apartment Association (landlord law seminars)
  - Colorado Restaurant Association
  - Colorado Hotel & Lodging Association
  - Colorado Roofing Association (winter trade show)
  - Home Builders Association of Metro Denver
  - COCPA (Colorado Society of CPAs)
  - Colorado Bar Association
  - Colorado Dental Association
  - Colorado Brewers Guild
  - Colorado Outfitters Association
  - Colorado River Outfitters Association (rafting)
  - Colorado Governor's Tourism Conference (fall)
- **Online communities:**
  - Reddit: r/Denver, r/Colorado, r/ColoradoSprings, r/Boulder, r/FortCollins, r/Landlord (CO threads on HB25-1090), r/Roofing
  - Facebook: Colorado landlord/REIA groups and Front Range contractor groups
- **Partners:**
  - Colorado SBDC Network and Denver Metro Chamber
  - Credit unions: Elevations, Ent, Canvas (verify)
  - Roofing supply: ABC Supply, SRS/Beacon Denver branches
  - Landlord-tenant attorneys who run HB25-1090 seminars
  - Local REIAs

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| Freedom-to-read law | R07's sources list Colorado among 2025 protective laws that require written collection and reconsideration policies. It is not confirmed on a fetched page, and the bill number is unknown (verify). | 2025 (verify) | R01, R07 |
| Science of reading / three-cueing law | READ Act, with an approved-curriculum mandate (per the lead list; verify current list and deadlines) | In force | P01, R08 |
| 3rd-grade reading plan / retention law | Conditional retention under the READ Act; READ plans for students with significant reading deficiencies (per the lead list; verify) | In force | P02 |
| Homeschool rules (HSLDA tier: **moderate**) | Three options. Notice, assessment and state-mandated subjects are required; teacher qualifications apply only under option 3. Keeping records is emphasized ([HSLDA CO](https://hslda.org/legal/colorado)). Which grades are tested and the deadlines are not confirmed (verify). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **No ESA.** Colorado is one of the 13 states that do not conform to federal K–12 529 treatment (via P03/P07, Savingforcollege Jan 5 2026). | — | P07 |
| Other | Colorado's auto-renewal law took effect Aug 6 2025 (via R08). **Imagination Library of Colorado:** a statewide expansion to all children 0–5 in all 64 counties was announced Dec 1 2021 with Gov. Polis and CDE, when 4% of eligible children were enrolled. Funding is "shared by local community partners" ([Imagination Library CO](https://imaginationlibrary.com/colorado/)). | 2021–; 2025 | R08, P06 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll:** a moderate-regulation state with notice, required testing and required subjects. Record-keeping is the job homeschool families pay for.
- **P01 PhonicsPrep:** READ Act plans and approved programs push families toward private structured-literacy tutors, whose tools are costly.
- **P07 LearnLedger:** 529 non-conformity means a K–12 withdrawal can create a state-tax problem, and the Aug 2025 auto-renewal law adds a "cancel forgotten kid apps" angle.

**Where to sell:**
- **Libraries:** Colorado Association of Libraries (conference, fall; verify) and the Colorado Association of School Librarians (verify).
- **Parents:** Colorado PTA and Christian Home Educators of Colorado (CHEC conference, summer; verify).
- **Reading:** IDA Rocky Mountain Branch and The Reading League Colorado (verify).
- **Booksellers:** MPIBA (Denver-based).

## Launch verdict
**Speed:** Fast. **First city:** Denver.

**Lead offer:** **H01 DoorLedger** with a free "HB25-1090 all-in rent listing and fee checker." The hook: "Colorado banned your pass-through fees in January (Jan 1 2026 effective date per Otten Johnson; verify); move to $1/door/mo with fees blocked automatically." Run **B04 FirstCall** in parallel in Angi's home market ("Angi's HQ is here, and so are its exit fees").

## Sources
- [SBA Office of Advocacy, 2026 Small Business Profile: Colorado (Sep 2026)](https://advocacy.sba.gov/wp-content/uploads/2026/09/Colorado.pdf)
- [SBA Office of Advocacy, 2025 Colorado profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Colorado_2025-State-Profile.pdf)
- [Colorado General Assembly, HB25-1090 Protections Against Deceptive Pricing Practices](https://leg.colorado.gov/bills/hb25-1090)
- [Otten Johnson: HB25-1090, landlords must eliminate junk fees in 2026 (Sep 24 2025)](https://www.ottenjohnson.com/news/hb25-1090-colorados-residential-landlords-must-eliminate-junk-fees-in-2026-including-cam-char) (via idea H01)
- [Colorado General Assembly, SB25B-004 (AI Act delay to Jun 30 2026; signed Aug 28 2025)](https://leg.colorado.gov/bills/sb25b-004)
- [Colorado General Assembly, SB24-205 Consumer Protections for AI](https://leg.colorado.gov/bills/sb24-205)
- [Colorado Attorney General, Colorado Privacy Act](https://coag.gov/resources/colorado-privacy-act/)
- Internal: ideas B04 (Angi HQ, Airquip), C02, D07, F02, H01, I04, J01, J03; `_state_leads_from_category_research.md`; `_scoreboard.csv`
- [HSLDA: Colorado homeschool laws](https://hslda.org/legal/colorado)
- [Dolly Parton's Imagination Library: Colorado (statewide expansion, Dec 1 2021)](https://imaginationlibrary.com/colorado/)
- Internal: ideas P03, P07 (529 non-conformity, Savingforcollege Jan 5 2026), R07, R08 (auto-renewal dates)

## Verification (Sep 24 2026)
- ✅ HB25-1090 requires sellers to "clearly and conspicuously disclose[] the maximum total (total price)". A business that fails to act within 14 days of a written demand is liable for "actual damages plus 18% interest" ([leg.colorado.gov](https://leg.colorado.gov/bills/hb25-1090))
- ❌ HB25-1090's named sectors are food and beverage, delivery network companies, landlords, real estate settlement, and broadband/cable/satellite. **Ticket sellers are not named**, so the table and the I04 row were corrected ([leg.colorado.gov](https://leg.colorado.gov/bills/hb25-1090))
- ⚠️ HB25-1090's Jan 1 2026 effective date (the lead-offer hook) is not shown on the legislature's summary and rests on a law-firm post. It is now tagged (verify) ([Otten Johnson](https://www.ottenjohnson.com/news/hb25-1090-colorados-residential-landlords-must-eliminate-junk-fees-in-2026-including-cam-char))
- ✅ SB25B-004 ("Increase Transparency for Algorithmic Systems") was signed Aug 28 2025 and "extends the effective date of the requirements of Senate Bill 24-205 to June 30, 2026" ([SB25B-004](https://leg.colorado.gov/bills/sb25b-004))
- ⚠️ The AI Act's status after Jun 30 2026 is unknown. The SB24-205 page shows no 2026-session amendment or delay, but that does not prove none exists. It is still tagged (verify current status) ([SB24-205](https://leg.colorado.gov/bills/sb24-205))
