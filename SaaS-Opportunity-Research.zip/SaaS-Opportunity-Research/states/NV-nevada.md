# Nevada (NV): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** **353,621** small businesses employing **578,767** people, or **45.0%** of Nevada employees. **294,529** have no employees ([SBA Advocacy 2026 Nevada profile, Sep 2026](https://advocacy.sba.gov/wp-content/uploads/2026/09/Nevada.pdf); [2025 profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Nevada_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Small businesses opened **13,228** establishments and added **5,233 net jobs** (Mar 2024–Mar 2025) ([SBA 2026 profile](https://advocacy.sba.gov/wp-content/uploads/2026/09/Nevada.pdf)).
  - Largest small-business employers:
    - Construction: 75,559
    - Health care: 73,969
    - Professional services: 49,792
  - Most hospitality employment sits in large resorts, so the small-business hospitality buyer is the restaurant, tour, wedding and event vendor around them.
- **Buyer clusters (estimate):**
  - **Las Vegas/Henderson/North Las Vegas:** year-round HVAC and pool service, roofing and solar, huge master-planned HOAs (Summerlin, Green Valley, Inspirada), med-spas, IV/wellness bars, tours and activities, wedding chapels and vendors, event and convention services, restaurants with no tip credit.
  - **Reno/Sparks/Tahoe:** logistics and warehousing, trades, Tahoe STRs and tours.
  - **Rural:** mining services, ranch and outfitter work.
- **Industries overweight vs. US (estimate):**
  - Hospitality and events (weddings, tours, conventions)
  - Construction and year-round home services
  - Community associations (HOAs)
  - Health and wellness cash-pay (med-spa, IV, aesthetics)
  - Entity-formation and registered-agent services (Nevada is a popular incorporation state; verify)

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **SB 370 (2023), consumer health data privacy.** Requires a consumer health data privacy policy and **affirmative, voluntary consent**, with separate consent for collection and sharing. A **signed written authorization** that expires after one year is needed to sell. Geofences within **1,750 feet** of health-care facilities are banned. Exempts HIPAA- and GLBA-covered entities ([SB 370 enrolled text](https://archive.leg.state.nv.us/Session/82nd2023/Bills/SB/SB370_EN.pdf)). | Cash-pay wellness businesses that are **not** HIPAA covered entities: med-spas that don't bill insurance, IV bars, gyms, supplement and fitness apps, fertility and wellness coaches (legal check per business) | In force since **Mar 31 2024** | **A01** FormFlare, **E04** Glowchart, **E08** Clipboardless, **F02** |
| **NRS 116.31069, association website/electronic portal** (plus NRS 116.310695 on portal cybersecurity and e-payments) ([NRS 116](https://www.leg.state.nv.us/NRS/NRS-116.html)). The threshold (150+ units) and the Jan 1 2023 date come from the H02 source (verify). | Large HOAs and their CAM firms; Las Vegas master-planned communities | In force | **H02** BoardBinder |
| **No tip credit.** Minimum wage **$12.00/hr** (since Jul 1 2024; verify) | Restaurants, bars, salons | In force | **D04** ShiftTip |
| **Paid leave (NRS 608.0197)** for employers with 50+ employees (verify) | Mid-size restaurants, home care, staffing | In force | **G04** StatePay |
| **STR licensing.** AB 363 (2021) required county STR regimes. Clark County's ordinance caps and spaces permits (verify). | Las Vegas-area STR hosts and co-hosts | Annual renewal | **H03** StayDesk |
| **State Business License and annual list** (SilverFlume) plus registered-agent requirement (verify). BOI domestic exemption final Aug 11 2026 ([FinCEN](https://www.fincen.gov/boi), via J06). | Every NV entity, including out-of-state owners of NV shells | Anniversary month | **J06** LicenseLedger |
| **Metrc** cannabis tracking (per the state-leads file) | Dispensaries, cultivators | Ongoing | **J04** (low priority) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **B04** | FirstCall (owned leads) | Las Vegas HVAC, pool, plumbing and roofing run year-round in extreme heat, and construction is the largest small-business employer. Owners pay Angi, Thumbtack and LSA for shared leads. Scoreboard 23. |
| 2 | **A01** | FormFlare (forms/intake) | SB 370 turns intake forms into a compliance product for **non-HIPAA** cash-pay wellness: separate collection and sharing consents, a published health-data policy, consent logs. Las Vegas has a dense med-spa and IV-bar scene. The A01 file already names NV. |
| 3 | **H02** | BoardBinder (HOA portal) | NRS 116.31069 portal duty plus some of the biggest HOAs in the US. Self-managed boards and small CAM firms want a cheap compliant portal. |
| 4 | **D07** | BookTrail (tours/activities) | D07 lists Las Vegas as a top tourism cluster: helicopter, Hoover Dam, Red Rock, off-road, shooting ranges, escape rooms. A no-guest-fee checkout gives Nevada operators all-in pricing. |
| 5 | **B07** | StudioDesk (vs HoneyBook/Dubsado) | Las Vegas is a wedding capital, with chapels, photographers, officiants and planners, and hosts the WPPI photographers' show (per B07). The HoneyBook +51–89% hike (Feb 2025) and the end of the loyalty discount (Feb 2026) are live. |
| 6 | **D04** | ShiftTip (scheduling and tips) | No tip credit plus a 24/7 shift economy (graveyard shifts, tip pooling) makes tip math and scheduling heavier than average. D04 names NV. |
| 7 | **C01** | FlatRate (FSM) | Year-round HVAC and plumbing dispatch. ServiceTitan exit fees and Housecall Pro bill creep (per C01) hit mid-size Las Vegas shops. |

Runners-up: **E04** Glowchart (med-spa), **C04** RouteBook (Las Vegas pools), **I04** DoorList (event organizers), **H03** StayDesk.

## State-only opportunities
1. **SB 370 consent pack for non-HIPAA wellness (A01/E04 wedge).** Many cash-pay aesthetics, IV-hydration and fitness businesses assume "we're not HIPAA, so no rules." In Nevada, SB 370 says otherwise. A $29–49/mo "Nevada health-data compliant intake" bundle includes separate consents, a hosted privacy policy, a consent-revocation link, a one-year authorization tracker and a data-sharing log. It is narrow to one state (and WA's MHMDA) but very easy to build. It rides on A01, so no separate idea file.
2. **Las Vegas trade-show circuit as a national GTM channel.** Las Vegas hosts many of the verticals' national shows named in our idea files: WPPI (photographers), SuperZoo (pet), Parker Seminars (chiropractors), AICPA ENGAGE (CPAs), the Pizza Expo, WVC (vets), The Aesthetic Show (med-spa) and IBS Las Vegas (salon). A Las Vegas-based rep can demo to national buyers every month. This is a sales advantage for opening a NV office, not a product.
3. **Wedding-vendor bundle (B07 variant):** chapel and officiant booking, marriage-license appointment reminders, package upsells and photographer delivery galleries (verify market size).

## Where to sell
- **Associations & events (verify names/dates):**
  - Nevada Restaurant Association
  - Vegas Chamber
  - Latin Chamber of Commerce Nevada
  - Las Vegas REALTORS
  - Nevada Society of CPAs
  - State Bar of Nevada
  - Nevada Dental Association
  - CAI Nevada Chapter (HOA managers)
  - Southern Nevada Home Builders Association
  - Nevada Medical Spa and Aesthetics community events
  - The Las Vegas convention circuit above (WPPI, SuperZoo, IBS, The Aesthetic Show, AICPA ENGAGE, Pizza Expo, WVC, Parker)
- **Online communities:**
  - Reddit: r/vegas, r/LasVegas, r/henderson, r/Reno, r/HVAC
  - Facebook: Las Vegas wedding vendor groups, Las Vegas med-spa owner groups, Summerlin/Henderson HOA groups
- **Partners:**
  - Nevada SBDC and the Vegas Chamber
  - POOLCORP/SCP and Johnstone branches
  - Clark County Credit Union and Silver State Schools Credit Union (verify)
  - HOA management attorneys
  - Registered-agent firms (as a J06 channel)

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | No statewide school-library catalog or freedom-to-read law was confirmed in this pass. Nevada is on neither category-research list (verify) | — | R01 (low fit) |
| Science-of-reading / three-cueing law | Read by Grade 3 program. The statewide literacy plan was updated **May 2025**. Clark County's "Read With Me NV" targets 64% third-grade proficiency by 2030 ([Nevada Independent, Oct 26 2025](https://thenevadaindependent.com/article/nevada-3rd-grade-reading-rates-up-but-fewer-than-half-proficient-as-retention-rule-looms)). Not on the three-cueing-ban list (verify) | In force | P01, R08 |
| 3rd-grade reading plan / retention law | **AB 400 (2023)** brings back third-grade retention starting in **2028–29**. Only **45%** of third graders were proficient in 2024–25. The State Board has "no timeline" for final retention standards ([Nevada Independent](https://thenevadaindependent.com/article/nevada-3rd-grade-reading-rates-up-but-fewer-than-half-proficient-as-retention-rule-looms)) | 2028–29 | **P02**, R08, P01 |
| Homeschool rules (HSLDA tier: **low**) | Notice required. No assessment, teacher qualifications or immunization rule. Subjects are state-mandated. Compulsory ages 6–18 ([HSLDA NV](https://hslda.org/legal/nevada)) | In force | P03 |
| ESA / scholarship money that can buy books, curriculum, classes | The **Nevada Educational Choice Scholarship**, a tax-credit scholarship ([EdChoice NV](https://www.edchoice.org/school-choice/state/nevada/); amounts not shown, verify). Nevada **opted in to the federal tax-credit scholarship** (IRS list, Jun 8 2026; governor's release Jan 23 2026). From **Jan 1 2027**, scholarships can pay for tutors, textbooks and supplies, including for homeschoolers ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | Jan 1 2027 | P07, P04, R08 |
| Other | Not on the CSG South list of statewide Imagination Library programs ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)) | — | P06 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home:** retention returns in 2028–29 with 55% of third graders not proficient. Parents of 2025–26 first graders are the retention cohort, so sell now.
- **R08 Readlings:** a cheap at-home decodable practice app for Las Vegas families as retention approaches.
- **P07 LearnLedger:** receipt tracking once federal scholarship dollars begin in 2027.

**Where to sell:**
- **Libraries:** Nevada Library Association annual conference (fall, verify); Clark County School District library services; Las Vegas-Clark County Library District.
- **Families:** Nevada PTA; Nevada Homeschool Network (verify).
- **Reading groups:** Read With Me NV and United Readers (Northern Nevada) as local literacy partners; IDA or Reading League contacts (verify).
- **Booksellers:** Mountains & Plains Independent Booksellers Association (verify region).

## Launch verdict
**Speed:** Medium-Fast. The buyer pool is smaller than AZ or CO, but year-round demand and the convention circuit shorten sales cycles. **First city:** Las Vegas (Henderson/Summerlin).

**Lead offer:** **B04 FirstCall** for HVAC and pool shops, paired with **A01 FormFlare "SB 370-ready intake"** for cash-pay med-spas and IV bars. The SB 370 hook ("not HIPAA? Nevada still requires separate consent") is the most distinctive message in this state.

## Sources
- [SBA Office of Advocacy, 2026 Small Business Profile: Nevada (Sep 2026)](https://advocacy.sba.gov/wp-content/uploads/2026/09/Nevada.pdf)
- [SBA Office of Advocacy, 2025 Nevada profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Nevada_2025-State-Profile.pdf)
- [Nevada Legislature, SB 370 (2023) enrolled text: consumer health data](https://archive.leg.state.nv.us/Session/82nd2023/Bills/SB/SB370_EN.pdf)
- [Nevada Revised Statutes, Chapter 116 (NRS 116.31069, 116.310695, 116.4109)](https://www.leg.state.nv.us/NRS/NRS-116.html)
- [FinCEN BOI page](https://www.fincen.gov/boi) (via idea J06)
- Internal: ideas A01, B04, B07, C01, D04, D07, H02 and trade-show references in B07, D02, E02, E04, E05, F01, F04 and G03; `_state_leads_from_category_research.md`
- [Nevada Independent: 3rd-grade reading rates and the AB 400 retention rule (Oct 26 2025)](https://thenevadaindependent.com/article/nevada-3rd-grade-reading-rates-up-but-fewer-than-half-proficient-as-retention-rule-looms)
- [HSLDA: Nevada homeschool law](https://hslda.org/legal/nevada)
- [EdChoice: Nevada](https://www.edchoice.org/school-choice/state/nevada/)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [Governor Lombardo opts in to the federal tax credit scholarship program (Jan 23 2026)](https://gov.nv.gov/Newsroom/PRs/2026/2026-01-23_governor_opts-in_to_federal_tax_credit_scholarship_program)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
