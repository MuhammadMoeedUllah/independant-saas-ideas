# New Mexico (NM): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** **172,113** small businesses, 99.0% of New Mexico firms. They employ **340,706** people, or **53.3%** of New Mexico employees. **138,557** have no employees ([SBA Advocacy 2026 New Mexico profile, Sep 2026](https://advocacy.sba.gov/wp-content/uploads/2026/09/New_Mexico.pdf); [2025 profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_Mexico_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Flat: small businesses opened **5,676** and closed **5,723** establishments, but gained a net **3,332 jobs** (Mar 2024–Mar 2025) ([SBA 2026 profile](https://advocacy.sba.gov/wp-content/uploads/2026/09/New_Mexico.pdf)).
  - Most common small-business types:
    - Professional and technical services: 22,160
    - Other services (repair, personal care): 17,523
    - Construction: 17,222
    - Health care: 16,647
    - Real estate: 15,296
- **Buyer clusters (estimate):**
  - **Albuquerque/Rio Rancho:** trades, health care and home care, child care, film production services (Netflix and NBCUniversal studios; verify), restaurants.
  - **Santa Fe/Taos:** inns and B&Bs, galleries, tours, STRs, spas, ski.
  - **Las Cruces:** agriculture, health care, cross-border logistics.
  - **Southeast (Hobbs/Carlsbad):** oilfield services and trucking.
- **Industries overweight vs. US (estimate):**
  - Child care (now universal and state-funded)
  - Health care and Medicaid home care
  - Tourism and arts
  - Film and TV production services
  - Oil-and-gas services
  - Government contracting

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Universal Child Care (UCC).** New Mexico became "the first state in the nation to offer no-cost Universal Child Care" on **Nov 1 2025**. The state pays licensed and registered providers directly, with rates from a cost-estimation model. Enhanced rates require paying entry-level staff **at least $16/hr** and offering care **10+ hours a day, 5 days a week**. The expansion targets about **12,000 more children** (6,600 center, 1,400 licensed-home, 4,000 registered-home slots). **SB 241 (2026), the Child Care Assistance Program Act**, wrote it into law ([NM ECECD Universal Child Care](https://www.nmececd.org/universal/); [ECECD home](https://www.nmececd.org/)). | Every licensed center, licensed home and registered home in NM, including thousands of new providers | Live since Nov 1 2025; codified 2026 | **F05** RollCall (attendance, subsidy billing, wage-floor proof) |
| **Healthy Workplaces Act paid sick leave**: 1 hr per 30 worked, all employers (since Jul 1 2022) (verify) | All employers | In force | **G04** StatePay, **J03** PostedUp |
| **Gross Receipts Tax with destination sourcing** (since Jul 1 2021) (verify) | Contractors, service businesses, remote sellers | Monthly/quarterly | **G02** PlainLedger, **J01** NexusBook |
| **Medicaid EVV**. Per the E07 table, NM runs a closed state EVV model. | Home-care and personal-care agencies | In force | **E07** Shiftwell |
| **Minimum wage** $12.00 statewide; Santa Fe and Albuquerque set their own (verify) | Restaurants, retail | Jan 1 yearly | **D04** ShiftTip |
| **Santa Fe STR permit cap and lodgers' tax** (verify) | Santa Fe/Taos STR hosts | Annual | **H03** StayDesk |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **F05** | RollCall (child-care attendance and subsidy billing) | UCC makes the **state the payer for nearly every child** at participating providers. About 12,000 new slots are coming online, many at new home-based providers who have no software yet. Enhanced rates depend on proving the **$16 wage floor and 10-hr/5-day hours**. RollCall can log staff wages and hours alongside child attendance and build the proof pack. This is the clearest law-driven buyer in NM. |
| 2 | **B04** | FirstCall | Construction and "other services" (repair) are top small-business categories in Albuquerque and Las Cruces. Scoreboard 23. |
| 3 | **A03** | LocalLoop | Owner-operated services and clinics everywhere. Scoreboard 22. |
| 4 | **D07** | BookTrail | Santa Fe and Taos tours, rafting (Rio Grande), ski rentals and Balloon Fiesta (October) ride operators. The off-season switch window is Nov–Mar for summer operators. |
| 5 | **G04** | StatePay (payroll/state compliance) | Healthy Workplaces Act sick-leave accrual for all employers, plus UCC wage-floor documentation for child-care employers (verify). |
| 6 | **H03** | StayDesk | Santa Fe/Taos STR permit caps and lodgers' tax (verify) plus Airbnb's 15.5% host-only fee (Oct 27 2025, per H03). |
| 7 | **E07** | Shiftwell (home care/EVV) | NM has heavy Medicaid personal-care volume (verify). Small agencies pay WellSky/AxisCare prices for EVV-compatible scheduling. |

Runners-up: **D05** InnDesk (Santa Fe inns), **K03** HaulDesk (Permian trucking, IFTA Oct 31), **J01** (GRT).

## State-only opportunities
1. **UCC provider pack (F05 variant). This is the strongest NM-only hook.** Offer "New Mexico UCC-ready" check-in/out, monthly attendance export for ECECD billing, and **$16 wage-floor and 10×5 hours evidence** per pay period. Add onboarding for newly **registered homes** (4,000 target slots): license checklist, PDIS staff records reminders and parent messaging. Price at $29/mo for homes and $79/mo for centers. It is written as a GTM variant of F05 rather than a new file because the NM market alone is small (estimate: low thousands of providers). But it proves a model other states may copy.
2. **Film production vendor invoicing (weak).** Albuquerque crews and vendors invoicing productions under the film tax credit need clean NM-resident vendor documentation (verify). Probably too niche.

## Where to sell
- **Associations & events (verify names/dates):**
  - New Mexico Early Childhood Education and Care Department (ECECD) provider trainings and town halls
  - NM Association for the Education of Young Children
  - New Mexico Child Care & Education Association
  - New Mexico Hospitality Association (restaurants and lodging)
  - New Mexico Association of REALTORS
  - NM Society of CPAs
  - Home Builders Association of Central New Mexico
  - Albuquerque Hispano Chamber of Commerce
  - Santa Fe Chamber
  - Albuquerque International Balloon Fiesta (October) vendor community
- **Online communities:**
  - Reddit: r/NewMexico, r/Albuquerque, r/SantaFe, r/LasCruces
  - Facebook: NM child-care provider groups and home child-care provider groups
- **Partners:**
  - NM SBDC network, WESST (NM small-business lender and trainer), Accion
  - Nusenda Credit Union (verify)
  - Child-care resource and referral agencies and quality-rating coaches (FOCUS TQRIS; verify)

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | No statewide school-library catalog or freedom-to-read law was confirmed in this pass. NM is on neither category-research list (verify) | — | R01 (low fit) |
| Science-of-reading / three-cueing law | NM PED structured-literacy initiatives (verify statute and three-cueing status). Not on the category-research ban or approved-curriculum lists | — | P01, R08 (bilingual decodables) |
| 3rd-grade reading plan / retention law | Category research lists NM as **conditional** retention (verify statute and parent-waiver rules) | In force (verify) | P02 |
| Homeschool rules (HSLDA tier: **low**) | Notice required. The teacher needs a qualification (verify level). Subjects are state-mandated and immunization rules apply. **No assessment.** Compulsory ages 5–18. One legal option ([HSLDA NM](https://hslda.org/legal/new-mexico)) | In force | P03 |
| ESA / scholarship money that can buy books, curriculum, classes | **None.** NM has no private-choice program (verify on EdChoice), and Ballotpedia lists it as **declining** the federal tax-credit scholarship ([Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)). NM is not on the IRS list of 27 states (Jun 8 2026) | — | (P07 weak) |
| Other | **Universal Child Care** since Nov 1 2025 (see the laws table) makes state-paid providers the main early-learning channel. NM is not on the CSG South list of statewide Imagination Library programs ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)) | Nov 1 2025– | **P06**, F05 |

**Top 3 reading/education ideas here:**
- **P06 StoryNest:** sell an English/Spanish family-reading and book-lending add-on to UCC providers, who are already buying F05. Pitch it as the same login.
- **R08 Readlings:** bilingual decodable readers for a Spanish-speaking family base (estimate).
- **R02 ReadRally:** summer reading challenges for small rural and tribal-area public libraries (verify library counts).

**Where to sell:**
- **Early childhood:** ECECD provider trainings; NM AEYC.
- **Libraries:** New Mexico Library Association annual conference (spring, verify).
- **Families:** NM PTA; Christian Association of Parent Educators of NM (verify).
- **Reading groups:** IDA Southwest Branch (verify).
- **Booksellers:** Mountains & Plains Independent Booksellers Association (verify).

## Launch verdict
**Speed:** Medium. The market is small, but UCC is a strong, fresh, state-funded trigger. **First city:** Albuquerque.

**Lead offer:** **F05 RollCall "UCC-ready."** The hook: "Get every UCC dollar you've earned: attendance export plus $16 wage-floor proof, set up in a day, $29/mo for home providers."

## Sources
- [SBA Office of Advocacy, 2026 Small Business Profile: New Mexico (Sep 2026)](https://advocacy.sba.gov/wp-content/uploads/2026/09/New_Mexico.pdf)
- [SBA Office of Advocacy, 2025 New Mexico profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_Mexico_2025-State-Profile.pdf)
- [NM Early Childhood Education and Care Department: Universal Child Care (start date, wage floor, slots, SB 241)](https://www.nmececd.org/universal/)
- [NM ECECD home page (UCC description, 2026 legislative session)](https://www.nmececd.org/)
- Internal: ideas F05, E07, D07, H03, G04; `_scoreboard.csv`
- [HSLDA: New Mexico homeschool law](https://hslda.org/legal/new-mexico)
- [Ballotpedia: state participation in the federal K-12 tax credit scholarship program](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
