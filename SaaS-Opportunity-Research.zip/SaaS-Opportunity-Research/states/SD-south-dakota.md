# South Dakota (SD): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 96,770 small businesses employing 216,705 people, or **58.0% of South Dakota employees**, one of the highest small-business shares in the US. 22,742 small employer firms. Data year 2022. ([SBA Advocacy 2025 South Dakota profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/South_Dakota_2025-State-Profile.pdf))
- **New-business momentum:** Strong. Small businesses produced a net gain of 6,662 jobs, **89.4% of net job growth** (March 2023–March 2024). Small-business employment grew 21.3% from 1998 to 2022, faster than the US ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/South_Dakota_2025-State-Profile.pdf)). The largest small-business employers are health care and social assistance (32,254), **accommodation and food services (32,033)** and retail (27,281). Census BFS was not fetched in this pass.
- **Buyer clusters:**
  - **Sioux Falls:** banking and credit-card banks, trust companies, health care, construction, restaurants. It is the fastest-growing metro in the region (verify).
  - **Rapid City and the Black Hills (Keystone, Custer, Hill City, Deadwood, Sturgis, Wall):** campgrounds and RV parks, motels, tours, attractions, the Sturgis Motorcycle Rally in August.
  - **Aberdeen, Pierre, Huron, Mitchell and Chamberlain:** pheasant-hunting lodges and outfitters, and Missouri River fishing.
  - **Brookings and Watertown:** ag, university, manufacturing.
- **Industries overweight vs. US:** accommodation and food services and tourism (nearly tied with health care as the top small-business employer), campgrounds and outfitters, banking and trust (no state income tax, trust-friendly law; verify), agriculture and ag retail, retail.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **FTC all-in pricing rule** for short-term lodging and live-event tickets (federal) | Black Hills motels and lodges, and campgrounds if covered (verify scope), event and rally organizers | May 2025 | D05, D06, I04 |
| **Sales tax:** remote sellers only need to meet the $100k test; the 200-transaction test was dropped (per J01) | SD e-commerce sellers, out-of-state sellers into SD | In force | J01 |
| **Medical cannabis (Metrc state)**; federal hemp THC cap (H.R. 5371, about Nov 2026; verify) | Dispensaries, hemp retailers | Nov 2026 (verify) | J04 |
| **IFTA quarterly return** | Carriers (ag and livestock hauling) | **Oct 31 2026** | K03 |
| **Medicaid EVV:** sources conflict (Therap vs Sandata) | Home care | In force | E07 (weak) |
| **No state-specific SMB software mandate found.** SD demand is **seasonal (tourism, hunting)** rather than regulatory. | n/a | n/a | n/a |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | D06 | SiteLoop (campground/RV park) | The Black Hills are one of the densest campground clusters in the Plains, with Sturgis Rally demand spikes. Camper booking fees conflict with all-in pricing expectations. The Oct–Apr off-season is the switch window, and it is open now. |
| 2 | D07 | BookTrail (tours/activities) | Black Hills tours, attractions and trail rides, plus pheasant and fishing outfitters, pay FareHarbor's 6% guest fee. It is a seasonal owner-operator buyer. |
| 3 | A03 | LocalLoop | Score 22. Tourism and restaurant businesses live on reviews, and SD's small-business share is 58%. |
| 4 | B04 | FirstCall | Score 23. Sioux Falls' construction boom plus hail. |
| 5 | D05 | InnDesk (independent motel PMS) | Mom-and-pop motels along I-90 and in the Black Hills. Channel-sync failures during Sturgis week are costly. The FTC all-in rule adds pressure. |
| 6 | F01 | Chairly | Score 22. Sioux Falls and Rapid City salons. |
| 7 | C02 | StormDesk | Sioux Falls and Rapid City hail. Smaller roofer pool than KS/NE. |

Close alternates: G06 AdvisorVault (Sioux Falls trust companies and RIAs; niche), J04 TagTrue (medical cannabis), D08 TeeFree (resort golf).

## State-only opportunities
1. **Black Hills campground + tour bundle (D06 + D07).** One flat-price system for a campground that also rents cabins, runs trail rides or sells rally passes. It shows the all-in price with no camper booking fee and handles Sturgis-week minimum stays and deposits. Sell Oct–Apr through Black Hills tourism associations.
2. **Pheasant-lodge and outfitter booking (D07 variant).** Multi-day hunt packages with lodging, meals, dogs and guides; deposits and waiver/license capture; group roommate splits. The season opens in mid-October (verify date), so pitch now for the 2027 season while lodges are busy but feeling the pain.
3. **Trust-company back office (G06 variant, niche).** Many small private trust companies are chartered in SD (verify count with the SD Division of Banking). Pain and incumbents were not researched in this pass.

## Where to sell
- **Associations & events** (from knowledge, verify):
  - South Dakota Retailers Association (covers restaurants and lodging)
  - Black Hills & Badlands Tourism Association
  - Visit Rapid City
  - SD Governor's Conference on Tourism (winter)
  - South Dakota campground owners group (verify name)
  - Home Builders Association of the Sioux Empire
  - South Dakota REALTORS
  - South Dakota CPA Society
  - State Bar of South Dakota
  - South Dakota Bankers Association and South Dakota Trust Association
  - South Dakota Agri-Business Association
  - Dakota Farm Show (January)
- **Online communities:** r/SiouxFalls, r/RapidCity, r/southdakota. Black Hills business Facebook groups, Sturgis vendor groups, pheasant-hunting forums (verify).
- **Partners:**
  - South Dakota SBDC
  - Sioux Falls Development Foundation
  - Zeal Center for Entrepreneurship, Sioux Falls (verify)
  - Rapid City Economic Development Partnership
  - Community banks (Dacotah, First Interstate; verify programs)
  - Tourism marketing agencies

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law | PEN's Dec 2025 roundup doesn't list one for SD (verify 2025–26 sessions). | n/a | R01 (weak) |
| Science-of-reading / three-cueing law | None confirmed in this pass (verify) | n/a | P01 |
| 3rd-grade reading plan / retention law | **None** ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)) | n/a | P02 (none) |
| Homeschool (HSLDA page: **low**) | Notice required, no assessment, no teacher qualifications, and state-mandated subjects ([HSLDA](https://hslda.org/legal/south-dakota)) | Yearly notice | P03 |
| ESA / scholarship money | No ESA found (verify) | n/a | n/a |
| Other | Statewide Imagination Library funding (verify). SD's rural libraries are mostly small, single-branch operations (inference). | n/a | R03, R02, P06 |

**Top 3 reading/education ideas here:**
- **R03 Branchline.** Small rural public libraries, a buyer the IMLS cuts hit hardest.
- **R02 ReadRally.** Summer-reading and read-a-thon programs for small libraries and schools.
- **P03 HomeRoll.** Low regulation with a yearly notice, so demand for records is modest.

South Dakota has **no forcing education law** in this set. It's a low-priority state for R/P ideas.

**Where to sell** (names from background knowledge; verify months):
- South Dakota Library Association (fall conference).
- SD PTA.
- South Dakota Christian Home Educators.
- The regional bookseller association (verify: MIBA or MPIBA).

## Launch verdict
**Speed:** Medium for the Black Hills tourism niche; Slow for general SaaS (the market is small). **First city:** Rapid City (Black Hills). **Lead offer:** D06 SiteLoop plus D07 BookTrail: "switch before next season, no camper booking fees, all-in pricing, free migration." Sell during the Oct–Apr off-season.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: South Dakota](https://advocacy.sba.gov/wp-content/uploads/2025/06/South_Dakota_2025-State-Profile.pdf)
- Internal: ../ideas/D05, D06, D07, J01, J04, G06, E07 idea files; ../_state_leads_from_category_research.md (FTC all-in rule, Metrc state list, sales-tax threshold list)
- [HSLDA: South Dakota homeschool law](https://hslda.org/legal/south-dakota)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- Internal (education): ideas R02, R03, P03
