# Wyoming (WY): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** **81,924** small businesses, 98.9% of Wyoming firms. They employ **135,636** people, or **65.2%** of Wyoming employees, the second-highest share in this batch after Montana ([SBA Advocacy 2026 Wyoming profile, Sep 2026](https://advocacy.sba.gov/wp-content/uploads/2026/09/Wyoming.pdf); [2025 profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Wyoming_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Contracting: small businesses had **2,648 openings vs 2,832 closings** and a **net loss of 1,059 jobs** (Mar 2024–Mar 2025) ([SBA 2026 profile](https://advocacy.sba.gov/wp-content/uploads/2026/09/Wyoming.pdf)).
  - Largest small-business employers:
    - Accommodation and food: 22,304
    - Health care: 21,297
    - Construction: 16,189
    - Retail: 14,451
  - The Census small-business counts **exclude the large number of out-of-state-owned Wyoming LLCs** served by the registered-agent industry (see below).
- **Buyer clusters (estimate):**
  - **Jackson/Teton County:** luxury lodging, STRs, tours, outfitters, ski.
  - **Cody/Park County:** Yellowstone east gate, dude ranches, outfitters.
  - **Sheridan and Cheyenne:** registered-agent and LLC-formation firms, plus trades.
  - **Casper/Gillette/Rock Springs:** energy services, trucking, construction.
  - **Pinedale/Dubois:** hunting outfitters.
- **Industries overweight vs. US (estimate):**
  - Accommodation and tourism (Yellowstone and Grand Teton)
  - Outfitting, guest and dude ranches
  - Oil, gas, coal and trona services
  - Trucking (I-80 corridor)
  - Entity formation and registered agents

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Education Savings Accounts (Steamboat Legacy Scholarship):** **$7,000/yr** per student on the **Odyssey** platform. The Wyoming Education Association sued (Jun 13 2025). The Wyoming Supreme Court denied a stay (Oct 7 2025) but later lifted the injunction. **2026–27 quarterly disbursements run early Sep 2026–early May 2027**, and litigation over funding continues ([WY Dept of Education ESA](https://edu.wyoming.gov/esa/)). | Private schools, micro-schools, tutors and curriculum vendors registered as ESA providers | Now (Q1 funds flowing) | **F06** ESA Desk, **F07** LessonLedger |
| **Registered Offices and Agents Act (W.S. Title 17, Ch. 28).** Commercial registered agents register with the Secretary of State ([WY SOS Business](https://sos.wyo.gov/Business/Default.aspx); [statute](http://legisweb.state.wy.us/statutes/statutes.aspx?file=titles/Title17/T17CH28.htm)). Quarterly filing statistics are published ([WY SOS statistics](https://sos.wyo.gov/Business/Statistics.aspx)). | Registered-agent firms and their LLC clients | Ongoing | **J06** LicenseLedger |
| **Annual report license tax**: $60 minimum, due the first day of the anniversary month (verify on the [fee schedule](https://sos.wyo.gov/Business/docs/BusinessFees.pdf)) | Every WY LLC and corporation (including non-resident owners) | Anniversary month | **J06** |
| **FinCEN BOI domestic exemption, final Aug 11 2026** ([FinCEN](https://www.fincen.gov/boi), via J06). "BOI filing" upsells sold to Wyoming shells are now dead weight. | Owners of Wyoming LLCs, agents selling compliance bundles | Now | **J06** |
| **EXPLORE Act (P.L. 118-234)**: Title III outfitter permit and fee changes; BLM implementing since Feb 2 2026 ([BLM](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits)). Wyoming Board of Outfitters and Professional Guides licensing (verify). | Hunting and pack outfitters on BLM and USFS land | 2026 | **S7-01** GuideLedger |
| **IFTA quarterly returns** (Oct 31, Jan 31, Apr 30, Jul 31; per the state-leads file) | Small fleets, energy-service trucking | **Oct 31 2026** next | **K03** HaulDesk |
| **Remote-seller nexus**: Wyoming dropped the 200-transaction test (per the state-leads file) (verify) | E-commerce sellers | In force | **J01** |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **J06** | LicenseLedger (entity plus license calendar) | Wyoming is a top LLC-formation state (verify volumes via the SOS quarterly reports). The Aug 11 2026 BOI exemption leaves owners unsure what they still owe. "Your Wyoming annual report due date plus $0 BOI" is a clean national SEO and partner play through Sheridan and Cheyenne registered agents. Scoreboard 20. |
| 2 | **S7-01** | GuideLedger (outfitters) | Jackson, Cody and Pinedale hunting and pack outfitters, EXPLORE Act permit changes, and a Dec–Mar switch window. |
| 3 | **F06** | ESA Desk | The $7,000 ESA on Odyssey is funding again for 2026–27. Providers are new to ESA invoicing, and the same Odyssey engine serves TX, UT, IA and others. |
| 4 | **H03** | StayDesk (STR PMS) | Teton County/Jackson STR managers (tight local rules; verify) plus Airbnb's 15.5% host-only fee (Oct 27 2025, per H03). |
| 5 | **D06** | SiteLoop (campgrounds/RV parks) | Yellowstone and Grand Teton gateway campgrounds, all-in pricing (FTC lodging rule), and a winter switch window. |
| 6 | **D05** | InnDesk (independent lodging/guest ranches) | Accommodation is the #1 small-business employer, with many independent motels, lodges and dude ranches. Cloudbeds channel-sync failures (per D05). |
| 7 | **K03** | HaulDesk (small fleet back office) | I-80 and energy-service trucking. **IFTA due Oct 31** and DAT renewals up 25–45% (per K03). Scoreboard 19. |

Runners-up: **D07** BookTrail (Jackson tours), **B04** FirstCall (Casper/Cheyenne trades).

## State-only opportunities
1. **Registered-agent white-label compliance portal (J06 variant).** Dozens of Wyoming registered-agent firms (verify count via the SOS commercial registered agent list) serve non-resident LLC owners worldwide. Sell them a **white-label client portal**: annual-report reminders, license-tax calculation, document inbox (service of process and mail scans), and "BOI no longer required" messaging, at $1–2 per entity per month. This is one sale per agent that reaches thousands of LLCs. It is a strong channel for J06, not a separate idea file (verify market size first).
2. **Dude and guest ranch booking (D05 + S7-01 blend).** Week-long all-inclusive stays, horse assignments, activity rosters and waivers. The Dude Ranchers' Association (verify HQ) is a ready channel, but the market is small.

## Where to sell
- **Associations & events (verify names/dates):**
  - Wyoming Outfitters & Guides Association (WYOGA)
  - Dude Ranchers' Association
  - Wyoming Lodging & Restaurant Association
  - Wyoming Office of Tourism's Governor's Hospitality & Tourism Conference
  - Wyoming Trucking Association
  - Wyoming Association of REALTORS
  - Wyoming Society of CPAs
  - Wyoming Business Council events
  - Jackson Hole Chamber
- **Online communities:**
  - Reddit: r/wyoming, r/JacksonHole, r/cheyenne, r/Casper, r/LLC and r/smallbusiness (Wyoming LLC questions are national)
  - Facebook: Wyoming outfitter and hunting groups, Jackson STR hosts
- **Partners:**
  - **Registered-agent firms in Sheridan and Cheyenne** (channel for J06)
  - Wyoming SBDC Network (University of Wyoming) and the Wyoming Business Council
  - First Interstate Bank (verify)
  - Trucking insurance agents (K03)

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law | PEN's Dec 2025 roundup doesn't list one for WY (verify 2025–26 sessions). | n/a | R01 (weak) |
| Science-of-reading / three-cueing law | None confirmed in this pass (verify) | n/a | P01 |
| 3rd-grade reading plan / retention law | **None** ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)) | n/a | P02 (none) |
| Homeschool (HSLDA page: **no notice, low regulation**) | Two options, no notification, no assessment, and state-mandated subjects ([HSLDA](https://hslda.org/legal/wyoming)). Wyoming set record-high homeschool numbers in 2024–25 (JHU, via P03). | n/a | P03 |
| **ESA: Steamboat Legacy Scholarship** | **Award:** **$7,000** a year on the **Odyssey** platform. **Covered:** tuition, curriculum, tutoring, extracurriculars, ed tech and transport ([WY DOE](https://edu.wyoming.gov/parents/education-savings-accounts/)). It also covers internet costs for homeschooled children not enrolled in public school. **History:** nearly 4,000 applied for 2025–26. The Wyoming Supreme Court ended the injunction in **May 2026**, and new applications opened **Jul 6 2026** ([KOTA, Jul 7 2026](https://www.kotatv.com/2026/07/07/wyoming-opens-school-choice-vouchers-new-applicants-court-challenge-lingers/)). The constitutional challenge continues in district court. | 2026–27 quarterly disbursements | P07, P03, P04, R08 |
| Other | Statewide Imagination Library funding (verify) | n/a | P06 |

**Top 3 reading/education ideas here:**
- **P07 LearnLedger.** $7,000 Odyssey accounts, rocky rollout, litigation still running: families need clean receipts and a record of what they spent.
- **P03 HomeRoll.** No notice required, but record-high homeschool numbers and ESA money make records useful rather than mandatory.
- **P04 ClassHouse.** Rural families buy online classes and tutoring with ESA dollars, so independent teachers need to be approved Odyssey vendors.

**Where to sell** (names from background knowledge; verify months):
- Wyoming Library Association (fall).
- Wyoming PTA.
- Wyoming homeschool networks (verify names) and ESA parent groups.
- Mountains & Plains Independent Booksellers Association.

## Launch verdict
**Speed:** Slow as a local market. Only ~82k small businesses, and they are shrinking. But the entity-formation industry makes it a fast **national** channel for J06. **First city:** Sheridan/Cheyenne for the registered-agent channel; Jackson for tourism.

**Lead offer:** **J06 LicenseLedger** white-labeled through Wyoming registered agents. The hook: "BOI is gone for US companies (Aug 11 2026). Here's exactly what your Wyoming LLC still owes, with a reminder before every due date."

## Sources
- [SBA Office of Advocacy, 2026 Small Business Profile: Wyoming (Sep 2026)](https://advocacy.sba.gov/wp-content/uploads/2026/09/Wyoming.pdf)
- [SBA Office of Advocacy, 2025 Wyoming profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Wyoming_2025-State-Profile.pdf)
- [Wyoming Dept of Education: Education Savings Accounts (Steamboat Legacy Scholarship)](https://edu.wyoming.gov/esa/)
- [Wyoming Secretary of State: Business Division](https://sos.wyo.gov/Business/Default.aspx)
- [Wyoming Secretary of State: Business statistics (quarterly 2026 reports)](https://sos.wyo.gov/Business/Statistics.aspx)
- [Wyoming Statutes Title 17, Ch. 28: Registered Offices and Agents Act](http://legisweb.state.wy.us/statutes/statutes.aspx?file=titles/Title17/T17CH28.htm)
- [FinCEN BOI page (domestic exemption final Aug 11 2026)](https://www.fincen.gov/boi) (via idea J06)
- [BLM Special Recreation Permits (EXPLORE Act Title III updates, Feb 2 2026)](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits)
- Internal: ideas J06, K03, F06, H03, D05, D06, S7-01; `_state_leads_from_category_research.md`
- [Wyoming DOE: Education Savings Accounts parent page ($7,000, Odyssey, eligible expenses, injunction lifted)](https://edu.wyoming.gov/parents/education-savings-accounts/)
- [KOTA: Wyoming opens school-choice vouchers to new applicants (Jul 7 2026)](https://www.kotatv.com/2026/07/07/wyoming-opens-school-choice-vouchers-new-applicants-court-challenge-lingers/)
- [HSLDA: Wyoming homeschool law](https://hslda.org/legal/wyoming)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- Internal (education): ideas P03, P04, P07, R08
