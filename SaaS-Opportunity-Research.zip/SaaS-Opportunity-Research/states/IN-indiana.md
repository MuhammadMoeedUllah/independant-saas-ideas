# Indiana (IN): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 591,671 small businesses (99.4% of Indiana businesses). They employ 1.2 million people, or 43.2% of Indiana employees ([SBA Advocacy 2025 Indiana profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Indiana_2025-State-Profile.pdf); counts use 2022 data).
- **New-business momentum:** Slightly positive.
  - From March 2023 to March 2024, small businesses opened 15,661 establishments and closed 15,161, a net gain of about 500.
  - They added a net 23,008 jobs (187,389 gained, 164,381 lost).
  - Women owned 44.1% of businesses, veterans 5.8% and Hispanic owners 5.9%.
  - All figures are from the same SBA profile. Business-application trend data was not pulled.
- **Buyer clusters** (metro detail is an estimate):
  - **Indianapolis and its north suburbs** (Carmel, Fishers, Noblesville, Westfield): med spas and aesthetics (E04 names Indianapolis), home services, logistics (airport and I-465/I-70/I-65), single-family rentals, private and Christian schools.
  - **Fort Wayne:** manufacturing and defense suppliers.
  - **Elkhart and South Bend:** the RV manufacturing belt (verify share) and its supplier and trucking networks.
  - **Northwest Indiana (Lake County):** Chicago spillover in trades, trucking and restaurants.
  - **Evansville, Lafayette, Bloomington:** regional health care and university-town services.
- **Industries overweight vs. US:**
  - **Transportation and warehousing:** 70,480 firms, #2 by count (SBA). Indiana calls itself the "Crossroads of America."
  - **Construction:** 66,189 firms and 119,132 employees (SBA).
  - **Real estate and rental/leasing:** 55,562 firms, which is unusually high in the top five (SBA). These are small landlords.
  - **Other services:** 71,355 firms, #1 (SBA).
  - **Manufacturing:** RVs, auto parts and steel (estimate).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **SB 282 med-spa law:** effective Jul 1 2026. It requires **state registration by Jan 1 2027**, a responsible practitioner, **adverse-event reporting within 15 days** and advertising rules. It covers med spas, IV hydration and GLP-1 clinics ([Decoda Health](https://decodahealth.com/blog/new-med-spa-laws-2026), via E04) | Med spas, IV bars, weight-loss clinics | **Registration by Jan 1 2027 (about 14 weeks away)** | E04 |
| **Indiana Consumer Data Protection Act** in force (IN, KY and RI all started Jan 1 2026) ([MultiState, Feb 2026](https://www.multistate.us/insider/2026/2/4/all-of-the-comprehensive-privacy-laws-that-take-effect-in-2026), via J02). It applies above 100,000 Indiana consumers, or 25,000 consumers plus 50% of revenue from data sales (verify) | E-commerce, data-heavy SMBs, agencies building sites | Jan 1 2026 | J02 |
| **INESA (disability ESA):** up to $20k per student with a disability and up to $8k for siblings. Parents pay providers after service through **ClassWallet** (no debit cards). **Administration moved from the Treasurer to the Indiana Department of Education on Jul 1 2026**; the 2025–26 invoice deadline was May 22 ([IN Treasurer](https://www.in.gov/tos/inesa/)) | Private schools, tutors, therapists (ABA, speech, OT), camps | Transition live for 2026–27 | F06, F07, E06 |
| **Choice Scholarship** becomes universal (income cap removed) starting 2026–27 under the 2025 budget (verify) | Private and parochial schools | 2026–27 school year | F06, I07 |
| **Medicaid EVV:** open model with Sandata as aggregator; deadline 10/28/2022 ([HHAeXchange](https://www.hhaexchange.com/state-evv-status)) | Home-care agencies | In force | E07 |
| **Sales tax:** Indiana is among the states that dropped the 200-transaction test (J01 list) | Remote sellers | In force | J01 |
| **Property-tax and local income-tax overhaul** (SB 1, 2025), phased in 2026–2028 (verify) | Landlords, CPAs | 2026–2028 (verify) | H01, G03 |
| **Minimum wage** stays at the federal $7.25 (verify), so wage-law pressure is low | Employers | n/a | Lowers D04 and G04 fit |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | E04 | Glowchart | This is the only hard statewide deadline in the region that lands in the next 100 days (SB 282 registration by Jan 1 2027). The 15-day adverse-event log and responsible-practitioner records are exactly the workflow incumbents lack. Carmel and Fishers have a dense med-spa and IV-bar cluster (estimate). |
| 2 | B04 | FirstCall | Scoreboard 23. Indiana has 66,189 construction firms and fast suburban home building around Indianapolis. |
| 3 | K03 | HaulDesk | 70,480 small transportation firms (#2 by count) on a national freight crossroads. The IFTA Oct 31 deadline and DAT hikes are immediate hooks. |
| 4 | F06 | ESA Desk | The INESA hand-off to the Department of Education (Jul 1 2026) plus universal Choice (verify) means new rules and new families this year. ClassWallet invoicing pain (F06 evidence) applies directly. |
| 5 | H01 | DoorLedger | Real estate and rental is a top-5 small-business category (55,562 firms). Indianapolis is an investor-heavy single-family rental market (estimate). Buildium's repeated hikes hit small portfolios. |
| 6 | F01 | Chairly | Other services is #1 by count. Fresha and Vagaro switching anger (scoreboard 22). |
| 7 | E06 | SkillTrack | ABA, speech and OT providers are paid through INESA and ClassWallet as well as Medicaid. A cheaper practice system with ESA-ready invoices fits a state where therapies are an approved ESA expense ([IN Treasurer](https://www.in.gov/tos/inesa/)). |

## State-only opportunities
- **SB 282 "registration and adverse-event kit" (E04 wedge):** a $49 one-time registration checklist and a responsible-practitioner roster, which upsells to the Glowchart subscription. It's time-boxed to before Jan 1 2027 and works as the fastest proof-of-demand test in this region. Not written as a separate file because it is E04's launch campaign.
- **INESA provider "get paid" pack (F06/E06 variant):** invoices formatted for the IDOE-run ESA and ClassWallet, for therapists, tutors and small schools. It's strong locally but an extension of F06.
- **Elkhart RV supplier and dealer ecosystem:** there are many small suppliers and dealers, but the buyers are B2B manufacturers with ERP needs, which is a poor fit for card-bought SaaS. Skip.

## Where to sell
- **Associations & events** (months to verify):
  - Trucking and hospitality: Indiana Motor Truck Association, Indiana Restaurant & Lodging Association.
  - Building and real estate: Indiana Builders Association, Indiana REALTORS and MIBOR (Indianapolis).
  - Professionals: Indiana CPA Society (INCPAS), Indiana State Bar Association, Indiana Dental Association.
  - Med spas: the Indiana State Medical Association is the channel to supervising physicians.
  - Schools: Indiana Non-Public Education Association (verify).
  - General business: Indiana Chamber of Commerce and the Indy Chamber.
- **Online communities:** r/indianapolis, r/Indiana, r/fortwayne, r/Bloomington, r/MedSpa and aesthetic-injector groups (verify), r/Truckers, and Indiana landlord and REI groups on Facebook (names to verify).
- **Partners:**
  - Indiana SBDC.
  - Med-spa compliance and health-law attorneys in Indianapolis, for SB 282 webinars.
  - Aesthetic product distributors.
  - Freight factoring firms.
  - Property-management bookkeepers.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials law: HEA 1447 (2023)** | School libraries must publish an online catalog of their materials. Parents get a formal process to challenge material. Schools must adopt policies on material "harmful to minors", and the law removes the "educational purposes" defense for school staff ([Wikipedia summary](https://en.wikipedia.org/wiki/Indiana_HB_1447)). Response timelines and any 2024–26 amendments were not confirmed (verify) | Signed May 2023; in force | R01, R07 |
| **Science of reading and three-cueing ban: HEA 1558 (2023) and follow-ons** | Three-cueing is banned. Schools had to adopt curriculum aligned to the science of reading by 2024–25, and IDOE keeps an approved curriculum list (IC 20-26-12-24.5) ([Chalkbeat, Sep 19 2023](https://www.chalkbeat.org/indiana/2023/9/19/23879309/indiana-science-of-reading-three-cueing-ban-literacy-law/); [Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/indiana/)). Other rules, all from Compass:<br>• **SEA 358 (2025)** writes the Indiana Literacy Cadre into law. Schools under a 70% IREAD pass rate must join targeted reading support, if it is funded.<br>• **Acadience K–6 Reading** has been the preferred K–2 universal screener since 2025–26.<br>• **From Jul 1 2027**, PK–5 teachers who renew a literacy license need **80 hours of approved science-of-reading PD** and must pass a content test (verify details) | Curriculum since 2024–25; licensure rule Jul 1 2027 | P01, R08 |
| **3rd-grade retention: SEA 1 (2024) and IREAD-3** | Third graders who fail IREAD are held back unless they get one of 5 good-cause exemptions (GCEs). All second graders now take IREAD, so a child has up to **5 chances to pass** before 4th grade, including 2 summer retests and summer school with a science-of-reading-trained teacher. Students with a GCE must **retest every spring and summer until they pass or reach 7th grade** ([SBOE reading update, Nov 5 2025](https://www.in.gov/sboe/files/11.5.25-Reading-Update.pdf)).<br>• **2025:** 10,663 did not pass (12.7%), about 3,040 were retained, and about 7,000 got GCEs. Nearly 75% of GCEs were special-education students.<br>• **2026:** 88.7% passed. About **9,100 of 81,100** third graders did not pass. Second-grade proficiency rose from 48% to **62%**. The 2026 retention count is not yet released ([Chalkbeat, Aug 11 2026](https://www.chalkbeat.org/indiana/2026/08/11/iread-pass-rates-surpass-pre-covid-literacy-levels/)).<br>• About 673 students left the state or switched to homeschool after the first retention year (Chalkbeat, via P02/P03) | Retention since 2024–25; retest cycles each spring and summer | P02, P01, R08 |
| **Homeschool: HSLDA "No notice, low regulation"** | No notice to anyone and no testing. HSLDA stresses keeping your own records ([HSLDA Indiana](https://hslda.org/legal/indiana)) | In force | P03 |
| **ESA and scholarship money** | Four programs:<br>• **Choice Scholarship voucher:** eligibility is listed as open to all Indiana students ages 5–21. It had **79,448 students (fall 2025)** and an average award of **$6,536 (2024–25)**. It pays tuition at private schools, not family book purchases (verify) ([EdChoice](https://www.edchoice.org/school-choice/programs/indiana-choice-scholarship-program/)).<br>• **INESA:** up to $20k for students with disabilities, paid through ClassWallet and run by IDOE since Jul 1 2026 (see table above).<br>• **Private school/homeschool expense deduction:** listed by EdChoice; about $1,000 per child (verify) ([EdChoice Indiana](https://www.edchoice.org/school-choice/state/indiana/)).<br>• **Federal tax-credit scholarship:** Indiana opted in Jan 22 2026, and HB 1266 was enacted Mar 12 2026 ([Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program); [IRS list, Jun 8 2026](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)). Credits start Jan 1 2027 | 2026–27 school year; federal credit 2027 | P03, P04, P07, R05, R08, F06, F07 |
| **Other: Imagination Library** | Direct state funding ended for 2025–26 (it had been $2M in 2023–24 and $4M in 2024–25). The program reached all 92 counties on Apr 2 2026 through private fundraising (Chalkbeat, via P06). No Indiana auto-renewal law for subscriptions was found (verify) | 2025–26 onward | P06, R02 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home:** about 9,100 third graders missed IREAD-3 in spring 2026, and thousands with GCEs must retest every spring and summer. Families need a plain-language plan and a retest calendar.
- **R08 Readlings:** second graders are now tested, and 38% were not yet proficient in 2026. At-home decodable practice fits the three-cueing ban. R08 already names Indiana for free pilots.
- **P01 PhonicsPrep:** tutors and interventionists staff summer school and GCE retesting. The Jul 1 2027 rule of 80 PD hours for PK–5 license renewal adds a teacher-side hook (verify).

**Where to sell:**
- **Libraries:** Indiana Library Federation annual conference (fall; verify month) and its school-library division AISLE (verify).
- **Parents:** Indiana PTA.
- **Homeschool:** Indiana Association of Home Educators (IAHE) convention (spring; verify).
- **Reading specialists:** IDA Indiana branch and The Reading League Indiana chapter (both verify), plus IDOE Literacy Cadre coaches.
- **Booksellers:** the Great Lakes Independent Booksellers Association (GLIBA; verify its current name and territory).

## Launch verdict
**Speed:** Medium. The market is smaller, but it has the sharpest deadline in the region.

**First city:** Indianapolis (Carmel and Fishers for med spas).

**Lead offer:** Glowchart with an SB 282 kit. The pitch is "Registered by Jan 1 2027, with a 15-day adverse-event log and practitioner records included; switch from Zenoti or Boulevard free." Follow with HaulDesk and FirstCall statewide.

## Sources
- [SBA Office of Advocacy: 2025 Indiana Small Business Profile (PDF)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Indiana_2025-State-Profile.pdf)
- [Indiana Treasurer of State: Indiana Education Scholarship Account (INESA)](https://www.in.gov/tos/inesa/)
- [HHAeXchange: State-by-State EVV Status](https://www.hhaexchange.com/state-evv-status)
- [Decoda Health: New Med Spa Laws in 2026 (Indiana SB 282)](https://decodahealth.com/blog/new-med-spa-laws-2026) (via E04)
- [MultiState: Comprehensive privacy laws taking effect in 2026 (Feb 2026)](https://www.multistate.us/insider/2026/2/4/all-of-the-comprehensive-privacy-laws-that-take-effect-in-2026) (via J02)
- The Indiana AG data-privacy page URL returned 404, and the IAPP tracker is paywalled. The privacy thresholds are marked (verify).
- Scoreboard and idea files E04, B04, K03, F06, H01, F01, E06, J01, J02 (internal).
- [Chalkbeat: Indiana third-grade literacy rates pass pre-COVID levels (Aug 11 2026)](https://www.chalkbeat.org/indiana/2026/08/11/iread-pass-rates-surpass-pre-covid-literacy-levels/)
- [Indiana SBOE: Reading update (Nov 5 2025, PDF)](https://www.in.gov/sboe/files/11.5.25-Reading-Update.pdf)
- [Chalkbeat: Indiana schools must drop three-cueing programs (Sep 19 2023)](https://www.chalkbeat.org/indiana/2023/9/19/23879309/indiana-science-of-reading-three-cueing-ban-literacy-law/)
- [The Reading League Compass: Indiana](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/indiana/)
- [Wikipedia: Indiana HB 1447](https://en.wikipedia.org/wiki/Indiana_HB_1447)
- [HSLDA: Indiana homeschool law](https://hslda.org/legal/indiana)
- [EdChoice: Indiana Choice Scholarship Program](https://www.edchoice.org/school-choice/programs/indiana-choice-scholarship-program/) and [EdChoice: Indiana programs](https://www.edchoice.org/school-choice/state/indiana/)
- [Ballotpedia: State participation in the federal K-12 tax credit scholarship program](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [IRS: More than half the states signed up for the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- Internal: ../ideas/P02 (Chalkbeat retention data), P06 (Imagination Library funding), R08, P01
