# Pennsylvania (PA): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 1.2 million small businesses (99.6% of PA businesses), employing 2.5 million people (45.2% of private employees). 938,764 are nonemployer firms ([SBA Advocacy 2025 PA profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Pennsylvania_2025-State-Profile.pdf)).
- **New-business momentum:**
  - From Mar 2023 to Mar 2024, small firms opened 32,635 establishments and closed 30,816.
  - Small businesses created a net 46,429 jobs, or 92.9% of PA's net job growth ([SBA Advocacy 2025](https://advocacy.sba.gov/wp-content/uploads/2025/06/Pennsylvania_2025-State-Profile.pdf)).
  - Census BFS trend was not fetched in this pass.
- **Buyer clusters** (estimate, verify):
  - **Philadelphia and its suburbs** (Bucks, Montgomery, Delaware, Chester): restaurants, salons, med spas, home services, law and CPA firms, nonprofits.
  - **Pittsburgh:** health care, trades, nonprofits. The federal court there is an ADA web-suit hotspot.
  - **Lehigh Valley and the I-78/I-81 corridor** (Allentown, Harrisburg, Carlisle, Scranton/Wilkes-Barre): warehousing and trucking.
  - **Lancaster and York:** Amish-country tourism, contractors, farm-adjacent businesses.
  - **Poconos:** short-term rentals, campgrounds, resorts.
- **Largest small-business sectors** (SBA; comparison with the US is an estimate):
  - **Health care:** 436,340 small-business employees, the largest by far.
  - **Accommodation & food services:** 296,370 employees.
  - **Construction:** 213,176 employees and 125,359 firms.
  - **Transportation & warehousing:** 128,280 firms.
  - Plus a large base of **youth-serving nonprofits and volunteer fire companies** (estimate).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Child Protective Services Law clearances.** Employees and unpaid volunteers with child contact need a PA Child Abuse History clearance, a PA State Police criminal clearance, an FBI check (all employees, some volunteers) and out-of-state checks. Clearances renew "at a minimum of every 60 months from the date of the oldest clearance" ([PA DHS](https://www.pa.gov/agencies/dhs/resources/keep-kids-safe/child-abuse-clearances)). | Youth sports clubs, camps, dance and gym studios, churches, schools, child care | Rolling 60-month expiries, re-checked every season | I05, I06, F03, I02 |
| **Medicaid EVV, open model.** Agencies may use their own EVV if it captures the 6 CURES Act items and interfaces with the DHS Aggregator, built with Gainwell/Sandata ([PA DHS EVV](https://www.pa.gov/agencies/dhs/resources/for-providers/evv)). Managed-care plans may use HHAeXchange (verify). | Personal-care and home-health agencies | Ongoing | E07 |
| **ADA website lawsuits.** 137 federal web-accessibility suits were filed in PA in 2025, 5th-most in the US ([Seyfarth](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)). | Any SMB with a website: restaurants, retail, clinics | Ongoing | J02 |
| **Home Improvement Consumer Protection Act.** Contractors must register with the Attorney General ([PA AG](https://www.attorneygeneral.gov/protect-yourself/home-improvement/)). Background knowledge, verify: the usual threshold is about $5,000/yr of home-improvement work, registration is biennial, and contracts must be written with a 3-day right to rescind. | Remodelers, roofers, HVAC and other trades | Ongoing, biennial renewals | C05, C01, A04 |
| **Charitable organization registration** with the Bureau of Corporations and Charitable Organizations. PA is one of the heaviest registration states ([I01 research](../ideas/I01-nonprofit-donor-crm-blackbaud-bloomerang-givebutter-alternative.md); verify renewal cadence). | Nonprofits that solicit | Annual | I01 |
| **Local earned income tax (Act 32) and Local Services Tax.** Withholding is by PSD code for work and home location (background, verify). | Every PA employer | Every payroll | G04 |
| **Sales-tax filing failures.** An Avalara customer reports failed PA filings five months running ([Trustpilot, Jun 2026](https://www.trustpilot.com/review/avalara.com), via J01). | E-commerce sellers | Monthly | J01 |
| **IFTA Q3 return** | Interstate carriers | Oct 31 2026 | K03 |
| **NFIRS retired; all departments report to NERIS** | PA fire companies, many of them volunteer (J07) | Since Jan 31 2026 | J07 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture) | Top-scoring idea (23). PA has 125k small construction firms and 213k construction small-business employees. HICPA-registered contractors are an easy target list (AG registration lookup, verify availability). |
| 2 | A03 | LocalLoop (reviews + texting) | Huge base of health-care small businesses (436k employees) and trades that live on reviews. |
| 3 | F01 | Chairly (salon/barber booking) | Dense in Philadelphia and Pittsburgh. The Fresha/Vagaro switching window is open now. |
| 4 | I05 | ClubHouse (youth sports clubs), with a PA clearance tracker | PA's 60-month clearance rule is a legal must-have that TeamSnap ONE and SportsEngine don't track well. Travel soccer, baseball and hockey clubs are dense in PA suburbs. The pitch: "never let an expired clearance on the field." |
| 5 | C05 | FlatBuild (CoConstruct refugees) | CoConstruct stops new projects Mar 31 2027. PA remodelers also need HICPA-compliant written contracts with rescission notices built in. |
| 6 | I01 | GiftLedger (donor CRM) | PA is a top-5 nonprofit state with heavy charitable registration. Q4 year-end giving and Blackbaud renewals make this the moment. |
| 7 | K03 | HaulDesk (small-fleet back office) | 128,280 small transportation firms along the I-78/I-81 warehouse corridor. IFTA is due Oct 31 and DAT renewals are up 25–45%. |

## State-only opportunities
1. **PA clearance tracker for every youth-serving org** (a module of I05/I06/F03/I02). It tracks the three or four clearances per person, the oldest-clearance date and the 60-month expiry, collects uploaded PDFs, sends reminders, and gives the board a roster report.
   - Sell it standalone at about $10–$20/mo to churches, scout units, PTAs, libraries, dance studios and camps.
   - A strong wedge, but PA-only and low ARPU, so it was not written up as an S2 file.
2. **PA web-accessibility defense bundle** (J02). With 137 federal suits in 2025, plaintiffs' firms are active here, especially in Western PA. Target restaurants and retailers with an "ADA demand letter received?" landing page.
3. **HICPA contract pack** (C05/A04). Written contracts with the AG registration number, a 3-day rescission notice and deposit terms, pre-filled for PA remodelers (verify statute details before selling).

## Where to sell
All association names below are from background knowledge (verify).
- **Associations & events:**
  - Pennsylvania Restaurant & Lodging Association; PA Chamber of Business and Industry.
  - Pennsylvania Institute of CPAs (PICPA); Pennsylvania Bar Association; Pennsylvania Builders Association.
  - Pennsylvania Homecare Association (named in E07); PANO, the PA Association of Nonprofit Organizations (named in I01).
  - Pennsylvania Motor Truck Association; Pennsylvania Campground Owners Association; volunteer fire associations (named in J07).
  - Groom Expo in Hershey (fall; named in F04).
- **Online communities:** r/philadelphia, r/pittsburgh, r/Pennsylvania, r/lehighvalley; PA youth-sports parent and coach Facebook groups (Eastern PA and PA West soccer); "Philly small business" Facebook groups.
- **Partners:** PA SBDC network (Wharton SBDC, University of Pittsburgh SBDC); county chambers; home-improvement supply houses; payroll accountants dealing with Act 32 local EIT; diocesan and youth-sports league administrators (clearances).

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | No statewide school-library statute confirmed in this pass. Collection and reconsideration rules are set by local board policy. PA is on neither category-research list (verify any 2025–26 bills) | — | R01 (policy templates only), R07 |
| Science-of-reading law: **Act 135 of 2024** + **Act 47 of 2025** (structured literacy) | PDE publishes lists of evidence-based core curricula, intervention and supplementary materials, and PD programs; screener resources are "under review for compliance with Act 47 of 2025" ([PDE Act 135](https://www.pa.gov/agencies/education/programs-and-services/instruction/elementary-and-secondary-education/curriculum/english-language-arts/act-135)). **Act 47 dates:** survey due **Mar 31 2026**. Schools adopt "evidence-based reading instruction curriculum and materials no later than the beginning of the **2027-2028** school year," but PDE's list isn't mandatory. **K–3 universal screening** runs three times a year (beginning, middle, end) from **2027–28**. PD must be complete by the start of **2028–29**, and the first report is due **Jul 31 2027**. Three-cueing status to be verified ([PDE Act 47 FAQs](https://www.pa.gov/agencies/education/programs-and-services/schools/school-services/act-47-structured-literacy-faqs)) | Curriculum and screening from 2027–28 | **P01**, R08, P02 |
| 3rd-grade reading plan / parent notice | No retention law. **Act 47** requires parent notification "in writing or electronic" form of screening results, with **progress updates three times per year for grades 1–3** ([PDE Act 47 FAQs](https://www.pa.gov/agencies/education/programs-and-services/schools/school-services/act-47-structured-literacy-faqs)) | 2027–28 | **P02** |
| Homeschool rules (HSLDA tier: **high**, per category research; the HSLDA page label couldn't be confirmed, verify). Home-education statute option | **Affidavit** "filed with the local superintendent before you start … and by **August 1** of each year after that." **Portfolio:** (1) a log "made contemporaneously with the instruction [that designates] by title the reading materials used," (2) work samples, and (3) standardized tests in **grades 3, 5 and 8**. **Evaluator:** a licensed psychologist, a certified teacher with two years' experience, or a nonpublic-school teacher or administrator. "**By June 30** each year" the parent submits the evaluator's certification to the superintendent. **Time:** 180 days, or 900 hours (elementary) / 990 hours (secondary) ([HSLDA how-to-comply PA](https://hslda.org/post/how-to-comply-with-pennsylvanias-homeschool-law)). PA has **four** legal homeschool options, and immunization rules apply. Compulsory ages 6–18 ([HSLDA PA](https://hslda.org/legal/pennsylvania)) | Aug 1 affidavit; year-round log; spring evaluation; Jun 30 certification | **P03**, R02 (reading log) |
| ESA / scholarship money that can buy books, curriculum, classes | **No ESA.** PA has two tax-credit scholarships, the **Educational Improvement Tax Credit** and the **Opportunity Scholarship Tax Credit** ([EdChoice PA](https://www.edchoice.org/school-choice/state/pennsylvania/)), which fund private-school tuition (verify whether homeschoolers or tutoring qualify). PA was **not** on the IRS list of 27 states in the federal tax-credit scholarship as of Jun 8 2026 (verify any later opt-in) ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | — | P07 (weak), F06 |
| Other | Not on the CSG South list of statewide Imagination Library programs ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)). PA is not on the category-research auto-renewal list | — | P06 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll:** PA homeschool law requires a contemporaneous log that names **every reading material by title**, plus work samples, grade 3/5/8 tests, an evaluator interview and a Jun 30 filing. A daily reading and lesson log that exports an evaluator-ready portfolio (with an evaluator-side review and certificate letter as V2) is the sharpest PA hook.
- **P02 ReadingPlan Home:** Act 47 makes every district send written or electronic K–3 screening notices and three progress updates a year from 2027–28. Districts will choose tools during 2026–27.
- **P01 PhonicsPrep:** the Act 47 PD deadline (2028–29) and curriculum switch (2027–28) push demand to tutors and reading specialists.

**Where to sell:**
- **Libraries:** Pennsylvania Library Association (PaLA) annual conference (fall, verify); PA School Librarians Association conference (spring, verify).
- **Families:** PA PTA.
- **Homeschool groups:** Christian Homeschool Association of PA (CHAP) convention (spring, verify); PA homeschool evaluator networks and "PA homeschool evaluators" Facebook groups.
- **Reading groups:** IDA Pennsylvania Branch; The Reading League Pennsylvania (verify).
- **Booksellers:** New Atlantic Independent Booksellers Association (verify).

## Launch verdict
**Speed:** Fast. **First city:** Philadelphia (plus Montgomery, Bucks and Delaware County suburbs). **Lead offer:** B04 FirstCall for contractors. Run a second track of I05 ClubHouse with a free PA clearance tracker, timed for spring-season registrations (Jan–Mar).

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Pennsylvania](https://advocacy.sba.gov/wp-content/uploads/2025/06/Pennsylvania_2025-State-Profile.pdf)
- [PA DHS, Child abuse clearances](https://www.pa.gov/agencies/dhs/resources/keep-kids-safe/child-abuse-clearances)
- [PA DHS, Electronic Visit Verification](https://www.pa.gov/agencies/dhs/resources/for-providers/evv)
- [PA Attorney General, home improvement](https://www.attorneygeneral.gov/protect-yourself/home-improvement/)
- [Seyfarth ADA Title III, federal web accessibility filings 2025 (Mar 2026)](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)
- [Trustpilot, Avalara reviews](https://www.trustpilot.com/review/avalara.com)
- [HSLDA: How to comply with Pennsylvania's homeschool law](https://hslda.org/post/how-to-comply-with-pennsylvanias-homeschool-law)
- [HSLDA: Pennsylvania homeschool law](https://hslda.org/legal/pennsylvania)
- [PDE: Act 47 structured literacy FAQs](https://www.pa.gov/agencies/education/programs-and-services/schools/school-services/act-47-structured-literacy-faqs)
- [PDE: Act 135 structured literacy resources](https://www.pa.gov/agencies/education/programs-and-services/instruction/elementary-and-secondary-education/curriculum/english-language-arts/act-135)
- [EdChoice: Pennsylvania programs](https://www.edchoice.org/school-choice/state/pennsylvania/)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
