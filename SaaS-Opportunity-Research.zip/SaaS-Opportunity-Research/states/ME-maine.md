# Maine (ME): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 160,215 small businesses, 99.2% of ME businesses, employing 290,518 people (54.5% of ME employees). 125,923 are nonemployer firms. ([SBA Advocacy 2025 ME profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Maine_2025-State-Profile.pdf))
- **New-business momentum:** From Mar 2023 to Mar 2024, small businesses opened 6,025 establishments and closed 5,248. They produced **98.5%** of the state's net job gain (7,026 of 7,136). ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Maine_2025-State-Profile.pdf))
- **Buyer clusters:**
  - **Greater Portland:** restaurants, breweries, professional services.
  - **Southern coast (Ogunquit, Kennebunkport, Old Orchard Beach):** motels, campgrounds, short-term rentals.
  - **Midcoast (Camden, Rockland, Boothbay):** inns, windjammers, boat tours.
  - **Downeast and Bar Harbor (Acadia):** tours, lodging, seasonal restaurants.
  - **Western mountains (Sunday River, Sugarloaf, Rangeley):** ski lodging, sporting camps, overnight summer camps.
  - **Bangor and Lewiston-Auburn:** trades and health care.

  These clusters are an estimate.
- **Industries overweight vs. US:**
  - By small-firm count, **construction (24,122)**, professional services (19,350) and **real estate and rental (15,908)** lead ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Maine_2025-State-Profile.pdf)).
  - Also overweight: seasonal accommodation and food, fishing and lobster, forestry (estimate).
  - Heating-oil trades are overweight: the Northeast holds about 82% of the 4.79M US heating-oil households ([EIA](https://www.eia.gov/energyexplained/heating-oil/use-of-heating-oil.php)), and Maine has the highest oil-heat share of any state (verify state figure).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Maine Paid Family & Medical Leave.** Benefits cover leave on or after **May 1 2026**, with up to 12 weeks of partial pay. Filing is quarterly, and private-plan substitutes are certified (12 policies certified Feb 2025) ([Maine PFML](https://www.maine.gov/paidleave/)). The 1% contribution started Jan 1 2025, and employers under 15 employees pay only the employee share (verify) | Every ME employer (quarterly filing, notices, leave tracking) | Live since May 2026; quarterly filings | G04, J03 |
| Minimum wage indexed each Jan 1 ($15.10 in 2026, verify) | All employers | Jan 1 2027 | J03, D04 |
| Sales tax nexus is $100k; ME dropped the 200-transaction test (category research) | Remote sellers | Ongoing | J01 |
| Metrc cannabis tracking state (category research) | Adult-use and medical cannabis retailers | Ongoing | J04 |
| Home construction contracts over a threshold need a written contract (10 MRSA §1487, verify) | Builders and remodelers | Ongoing | A04, C05 |
| Youth camp licensing via ME CDC (verify) | Overnight and day camps | Pre-season (spring) | I06 |
| Efficiency Maine heat-pump rebates and the registered-vendor program (verify) | HVAC and heat-pump installers, fuel dealers adding heat pumps | Ongoing | C01 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall | Construction is Maine's #1 small-business category by count (24,122 firms). Rural contractors pay Angi and Google LSA for thin lead pools. Scoreboard 23. |
| 2 | D06 | SiteLoop | Southern-coast, Acadia and lakes campgrounds are a dense cluster. Oct–Apr is the only switch window, and it's opening now. |
| 3 | C01 | FlatRate | The heaviest heating-oil state (verify), with fuel dealers turning into heat-pump installers. Get off ServiceTitan and Housecall Pro pricing. |
| 4 | D07 | BookTrail | Bar Harbor, Portland and Midcoast tours, whale watches and windjammers pay FareHarbor's 6% guest fee. They switch in winter. |
| 5 | J03 | PostedUp | Maine's first PFML benefit year (May 2026) plus the Jan 2027 wage change, and many micro-employers do their own compliance. |
| 6 | I06 | CampFile | Maine's famous overnight summer camps. The Sep–Dec switch window before registration opens is now. |
| 7 | H03 | StayDesk | Coastal and lake STR density, plus Airbnb's 15.5% host-only fee for PMS-connected hosts (Oct 2025). |

## State-only opportunities
1. **Heating-oil and propane dealer back office (regional: ME, NH, VT, MA, CT, NY).** Dealers need degree-day auto-delivery scheduling, tank monitoring, budget-plan billing, price-protection (cap) contracts, and service contracts for burners and heat pumps. The Northeast has about 3.9M oil-heat households ([EIA](https://www.eia.gov/energyexplained/heating-oil/use-of-heating-oil.php)). **We didn't write a full file.** Pain evidence against incumbent dealer systems wasn't collected this pass, because no search was available. It's a strong candidate for the next wave.
2. **Maine PFML small-employer helper.** A quarterly-filing, leave-request and notice kit for employers under 15. Folded into J03/G04.

## Where to sell
- **Associations & events:**
  - Hospitality: HospitalityMaine (restaurants and lodging), Maine Campground Owners Association (verify), Maine Tourism Association, Maine Windjammer Association.
  - Construction and trades: Maine Energy Marketers Association (heating oil and propane, verify), Home Builders & Remodelers Association of Maine.
  - Professional services: Maine Society of CPAs, Maine State Bar Association.
  - Other: Maine Summer Camps (verify), ACA New England, Maine State Chamber of Commerce.
- **Online communities:** r/Maine, r/portlandme, r/BarHarbor (verify), r/smallbusiness. Facebook groups for Maine campground owners, Maine contractors and Maine STR hosts (search by name).
- **Partners:** Maine SBDC, Maine Center for Entrepreneurs, regional chambers (Portland Regional, Bar Harbor, Kennebunk), Efficiency Maine registered vendors (C01 channel), Maine credit unions.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials or freedom-to-read law** | None found. Maine is not on Book Riot's Aug 2026 list of 13 freedom-to-read states ([Book Riot](https://bookriot.com/massachusetts-passes-freedom-to-read-law/)) (verify) | n/a | (R01 weak) |
| **Science of reading** | Maine has **no science-of-reading statute**. The Maine State Literacy Action Plan, announced Oct 2025, adds evidence-based instruction. The dyslexia statute (20-A §4710-B) requires K–2 screening of students with reading difficulties. Curriculum is locally controlled, with no state list. Free AIM Pathways and Keys to Literacy modules are offered to K–5 staff ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/maine/)) | Plan announced Oct 2025 | P01, R08 |
| **3rd-grade reading plan or retention law** | None found | n/a | (P02 weak) |
| **Homeschool: HSLDA "Moderate regulation"** | Two options. Notice and state subjects are required, and option 1 requires an annual assessment ([HSLDA Maine](https://hslda.org/legal/maine)). Deadlines were not on the page (verify) | In force | P03 |
| **ESA and scholarship money** | No ESA. Maine is not in the federal tax-credit scholarship ([IRS, Jun 8 2026](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)). The town tuitioning program exists but was not checked (verify) | n/a | (P07 weak) |
| **Other: library funding and subscriptions** | After IMLS cuts, the **Maine State Library laid off 8 staff and closed its physical location** (Library Journal, Apr 2026, via R03). Library Journal also reports Maine cuts to LSTA-funded summer reading support (via R02). Maine has an automatic-renewal law for subscriptions (category research; verify) | 2026 | R03, R02, P07 |

**Top 3 reading/education ideas here:**
- **R03 Branchline:** small town libraries lost state-library support in 2026 and need low-cost events, rooms and circulation tools.
- **R02 ReadRally:** summer-reading platform subsidies from the state are at risk, so libraries are shopping for a cheaper Beanstack.
- **P03 HomeRoll:** under moderate regulation, homeschoolers must file notice and complete an annual assessment.

**Where to sell:**
- **Libraries:** Maine Library Association (fall conference; verify) and the Maine Association of School Libraries (MASL; verify).
- **Parents:** Maine PTA (verify it exists).
- **Homeschool:** Homeschoolers of Maine (verify).
- **Reading specialists:** IDA branch covering Maine (verify).
- **Booksellers:** NEIBA (New England Independent Booksellers Association).

## Launch verdict
**Speed:** Medium. It's seasonal: sell to tourism operators Oct–Apr and to trades year-round. **First city:** Portland, then a southern-coast and Acadia campground and tour road trip in Nov–Feb. **Lead offer:** D06 SiteLoop's "switch before May, free migration," bundled with D07 for Acadia and Midcoast tour operators. For trades, B04's "leave Angi" pitch.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Maine](https://advocacy.sba.gov/wp-content/uploads/2025/06/Maine_2025-State-Profile.pdf)
- [Maine Paid Family and Medical Leave](https://www.maine.gov/paidleave/)
- [EIA: Use of heating oil](https://www.eia.gov/energyexplained/heating-oil/use-of-heating-oil.php)
- [The Reading League Compass: Maine](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/maine/)
- [HSLDA: Maine homeschool law](https://hslda.org/legal/maine)
- [Book Riot: Massachusetts passes freedom-to-read law, with list of states (Aug 2026)](https://bookriot.com/massachusetts-passes-freedom-to-read-law/)
- [IRS: Federal scholarship tax credit participating states (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- Internal: ../ideas/R02, R03 (Library Journal reporting on Maine State Library cuts)
