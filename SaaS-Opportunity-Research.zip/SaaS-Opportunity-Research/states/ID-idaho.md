# Idaho (ID): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** **207,670** small businesses employing **386,078** people, or **56.0%** of Idaho employees. **160,914** have no employees ([SBA Advocacy 2026 Idaho profile, Sep 2026](https://advocacy.sba.gov/wp-content/uploads/2026/09/Idaho.pdf); [2025 profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Idaho_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Small businesses had **9,942 openings vs 8,623 closings**. They added **5,816 net jobs**, **61.8%** of Idaho's net job growth (Mar 2024–Mar 2025) ([SBA 2026 profile](https://advocacy.sba.gov/wp-content/uploads/2026/09/Idaho.pdf)).
  - Most common small-business types:
    - **Construction: 27,800**
    - Professional services: 27,231
    - Real estate: 24,737
- **Buyer clusters (estimate):**
  - **Treasure Valley** (Boise, Meridian, Nampa, Eagle, Caldwell): home builders and remodelers, HVAC and trades, real estate, salons, dental and chiro, fast in-migration.
  - **Coeur d'Alene/Post Falls:** lake tourism, STRs, builders.
  - **Idaho Falls/Pocatello:** trades, ag services, Yellowstone gateway traffic.
  - **Central Idaho** (Salmon, Stanley, Riggins, McCall) and **Sun Valley/Ketchum:** outfitters, rafting, hunting, STRs, resort services.
- **Industries overweight vs. US (estimate):**
  - Construction (the #1 small-business category)
  - Real estate
  - Outdoor recreation and outfitting
  - Agriculture and food processing
  - Resort tourism (Sun Valley, McCall, Coeur d'Alene)

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Outfitter and guide licensing (IOGLB).** Outfitter license $400; guide $105 renewal ($20 first-time); designated agent $140; amendments $35–$200; **late penalty $150**. Outfitters file **outfitter use reports** and roster and amendment requests. Unlicensed outfitting or guiding "are a crime (IC § 36-2104)." Online portal at edopl.idaho.gov ([Idaho OGLB](https://dopl.idaho.gov/oglb/)). | Hunting, fishing, rafting and pack outfitters and their guides | Annual renewals and use reports | **S7-01** GuideLedger, **D07** |
| **EXPLORE Act (P.L. 118-234, Jan 4 2025)**: Title III outfitter permit and fee changes. **BLM implementing since Feb 2 2026** ([BLM](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits); [GovInfo](https://www.govinfo.gov/app/details/PLAW-118publ234)). Idaho is about 60%+ federal land (verify). | Outfitters on USFS and BLM land | 2026 rollout | **S7-01** |
| **Parental Choice Tax Credit** (2025): refundable credit of about $5,000 per student ($7,500 with disability) for private tuition, tutoring and curriculum, with a capped fund (verify amounts, cap and administration) | Private and micro-schools, tutors, curriculum vendors (families need itemized receipts) | Tax-year based (verify) | **F07** LessonLedger, **F06** |
| **STR protection statute**: Idaho limits local STR bans (verify) | Sun Valley, McCall and Coeur d'Alene STR hosts | In force | **H03** StayDesk |
| **FinCEN BOI domestic exemption final Aug 11 2026** ([FinCEN](https://www.fincen.gov/boi), via J06). Idaho annual reports still due (verify). | All LLCs | Now | **J06** |
| **CoConstruct stops new projects Mar 31 2027** (national, per C05) | Idaho's 27,800 small construction firms | Mar 31 2027 | **C05** FlatBuild |

Idaho has a light state-mandate environment: minimum wage stays at the federal level, and there is no comprehensive privacy, pay-transparency or paid-leave law (verify). The sale is about price and forced migrations.

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **B04** | FirstCall (owned leads) | Construction is Idaho's #1 small-business category, and Treasure Valley growth drives heavy lead buying. Scoreboard 23. |
| 2 | **C05** | FlatBuild (vs Buildertrend/CoConstruct) | Boise-area custom builders and remodelers face the **CoConstruct forced migration (Mar 31 2027)**, and Buildertrend is the expensive default. |
| 3 | **A03** | LocalLoop | Owner-operated services and clinics in a fast-growth metro. Scoreboard 22. |
| 4 | **S7-01** | GuideLedger (outfitters) | Idaho has the most concrete fetched outfitter paperwork (use reports, rosters, $150 late penalty) plus EXPLORE Act changes. The Dec–Mar off-season is the sales window. |
| 5 | **C01** | FlatRate (FSM) | Boise HVAC and plumbing shops scaling from 3 to 15 techs hit ServiceTitan pricing walls. |
| 6 | **H03** | StayDesk (STR PMS) | Sun Valley, McCall, Coeur d'Alene and Island Park STR managers, plus Airbnb's 15.5% host-only fee (Oct 27 2025, per H03). |
| 7 | **F07** | LessonLedger (tutors/music) | Tax-credit money needs clean receipts. Tutors and music teachers who issue credit-ready invoices win families (verify credit rules). |

Runners-up: **F01** Chairly (Boise salons), **E02** Alignly (chiro), **D06** SiteLoop (RV parks and campgrounds).

## State-only opportunities
1. **Outfitter compliance plus booking. Written up as [S7-01 GuideLedger](../ideas/S7-01-outfitter-guide-booking-permit-reporting.md) (16/25).** Idaho is the launch state because its board publishes clear report and roster requirements and penalties, and central Idaho has a dense cluster of rafting and hunting outfitters.
2. **Tax-credit receipt pack (F07 variant).** If the Parental Choice Tax Credit holds (verify), a free "Idaho credit-ready receipt" generator for tutors and small schools is a lead magnet for F07.

## Where to sell
- **Associations & events (verify names/dates):**
  - Idaho Outfitters & Guides Association (IOGA; winter convention)
  - Building Contractors Association of Southwestern Idaho (Parade of Homes)
  - Idaho Building Contractors Association
  - Idaho REALTORS
  - Idaho Society of CPAs
  - Idaho State Bar
  - Idaho Lodging & Restaurant Association
  - Idaho Technology Council
  - Boise Metro Chamber
- **Online communities:**
  - Reddit: r/Boise, r/Idaho, r/CoeurdAlene, r/IdahoFalls
  - Facebook: Treasure Valley contractor and builder groups, Idaho outfitter and guide groups
- **Partners:**
  - Idaho SBDC (Boise State) and Boise Metro Chamber
  - Idaho Central Credit Union (verify)
  - Builder supply yards (e.g., Franklin Building Supply; verify)
  - Outfitter insurance brokers

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School/public library-materials law: **HB 710 (2024)** | Schools and public libraries may not promote, give, or make available to minors materials defined as harmful to minors. The law creates a cause of action with damages and injunctive relief. Signed Apr 10 2024 (Session Law ch. 327); effective **Jul 1 2024** ([Idaho Legislature H0710](https://legislature.idaho.gov/sessioninfo/2024/legislation/H0710/)). The request-form, review-window and damages-amount details were not on the summary page (verify in the bill text). | In force since Jul 1 2024 | R01, R07, R03 |
| Science of reading / three-cueing law | A 2025 three-cueing bill is unverified (per the lead list). | — | P01, R08 |
| 3rd-grade reading plan / retention law | No retention mandate on the lead lists (verify) | — | P02 (weak) |
| Homeschool rules (HSLDA tier: **no notice, low**) | One option. No notice, no testing, no teacher qualifications; state-mandated subjects apply. Compulsory age 7–16 ([HSLDA ID](https://hslda.org/legal/idaho)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **Parental Choice Tax Credit:** "up to $5,000 per eligible student" or "$7,500" with a qualifying disability, for eligible nonpublic-school expenses, from "nearly $50 million" in state funds. **7,055 applications covering 12,561 students** were filed in 2026. Families at or below 300% of the federal poverty level can take a one-time advance payment. The Idaho State Tax Commission runs the program, and the current window is closed ([myschoolchoice.idaho.gov](https://myschoolchoice.idaho.gov/about-the-program/)). Whether homeschool costs qualify is not stated on that page (verify). | 2026 round closed; next window: verify | P07, P03, P04, R05, R08 |
| Other | No state Imagination Library funding confirmed (verify). | — | P06 |

**Top 3 reading/education ideas here:**
- **P07 LearnLedger:** a tax credit, unlike an ESA wallet, rests on the family's own receipts. With 12,561 students applying for about $50M, families need a qualified-expense vault and claim worksheet.
- **P03 HomeRoll:** a no-notice state, but homeschoolers claiming the credit (if eligible) or proving required subjects still need records.
- **R01 ClearShelf:** it gives schools and public libraries a documented, neutral request and review log under HB 710, which exposes them to lawsuits.

**Where to sell:**
- **Libraries:** Idaho Library Association (conference, fall; verify) and the Idaho Commission for Libraries.
- **Parents:** Idaho PTA, the Idaho Coalition of Home Educators, and Christian Homeschoolers of Idaho State (verify names).
- **Reading:** IDA and The Reading League (ID chapter: verify).
- **Booksellers:** PNBA (Pacific Northwest Booksellers Association; verify ID coverage).

## Launch verdict
**Speed:** Medium. The market is fast-growing but mid-sized, with few law triggers. **First city:** Boise (Meridian/Nampa).

**Lead offer:** **C05 FlatBuild** for Treasure Valley builders. The hook: "CoConstruct stops new projects Mar 31 2027; migrate free now." Pair it with **B04 FirstCall**. In Dec–Feb, run **S7-01** at the IOGA convention.

## Sources
- [SBA Office of Advocacy, 2026 Small Business Profile: Idaho (Sep 2026)](https://advocacy.sba.gov/wp-content/uploads/2026/09/Idaho.pdf)
- [SBA Office of Advocacy, 2025 Idaho profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Idaho_2025-State-Profile.pdf)
- [Idaho Outfitters and Guides Licensing Board (DOPL)](https://dopl.idaho.gov/oglb/)
- [BLM Special Recreation Permits (EXPLORE Act Title III updates, Feb 2 2026)](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits)
- [GovInfo: Public Law 118-234, EXPLORE Act](https://www.govinfo.gov/app/details/PLAW-118publ234)
- [FinCEN BOI page](https://www.fincen.gov/boi) (via idea J06)
- Internal: ideas B04, C01, C05, F07, H03, S7-01; `_scoreboard.csv`
- [Idaho Legislature: H0710 (2024), signed Apr 10 2024, effective Jul 1 2024](https://legislature.idaho.gov/sessioninfo/2024/legislation/H0710/)
- [Idaho Parental Choice Tax Credit: About the Program](https://myschoolchoice.idaho.gov/about-the-program/)
- [HSLDA: Idaho homeschool laws](https://hslda.org/legal/idaho)
