# South Carolina (SC): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 530,402 small businesses (99.4% of SC businesses) employ 863,326 people, or 42.9% of SC employees (2022). From Mar 2023 to Mar 2024, 20,541 establishments opened and 17,427 closed (net +3,114). Small firms produced a net 25,358 jobs, 70.9% of the total ([SBA Advocacy 2025 South Carolina profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/South_Carolina_2025-State-Profile.pdf)).
- **New-business momentum:**
  - **72,111 business applications in Jan–Aug 2026** (not seasonally adjusted), 1.7% of US applications, slightly above population share (verify) ([Census BFS monthly CSV](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)).
  - Small-business employment grew 21.3% from 1998 to 2022.
  - **Accommodation and food services is the #1 small-business employer (151,187)**, ahead of health care (114,671) and construction (80,328). The top firm counts are other services (68,832), professional services (63,369) and construction (57,078) (SBA profile).
- **Buyer clusters:**
  - **Charleston:** tours, destination weddings, restaurants, short-term rentals, and remodelers on older homes.
  - **Myrtle Beach/Grand Strand:** golf courses, family campgrounds, attractions, fishing charters, condo-hotels and vacation rentals.
  - **Hilton Head/Bluffton:** golf, short-term rentals, home services for retirees.
  - **Greenville-Spartanburg:** manufacturing suppliers (BMW cluster; verify) and fast-growing suburbs with home services.
  - **Columbia:** government, health care, insurance.
- **Industries overweight vs. US:**
  - Accommodation and food services (per the SBA data above).
  - Golf and resort tourism.
  - Campgrounds and RV (Grand Strand).
  - Automotive manufacturing suppliers (verify).
  - Retiree-driven home services and health care.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **SC Code Title 41 Ch. 8, E-Verify for ALL private employers** covered by federal I-9 rules, within 3 business days of hire. Every employer holds an "imputed" SC employment license. A first failure-to-verify offense brings 1-year probation with quarterly reports, and later offenses bring a **10–30 day license suspension**. Knowingly hiring unauthorized workers can end in revocation. SC LLR enforces through audits ([SC Code 41-8](https://www.scstatehouse.gov/code/t41c008.php)). | Every employer, including 1–10 person shops | In force | G04, J03, regional E-Verify kit |
| **Education Scholarship Trust Fund (S.62, signed May 7 2025).** **$7,500 per student** in 2025–26, indexed after that. Capped at 10,000 students in 2025–26 and **at least 15,000 from 2026–27**. Income cap rises from 300% to **500% of the federal poverty level in 2026–27**. Funds can pay **tutors, therapists (OT, speech, behavioral, PT), online courses and private schools**. Providers receiving $50k+ must file surety bonds, and all need background checks. A trustee manages the accounts for a fee of up to 5% ([SC Statehouse S.62](https://www.scstatehouse.gov/sess126_2025-2026/bills/62.htm)); ClassWallet rail per [GetESAPaid](https://getesapaid.com/become-an-esa-vendor), verify for the re-enacted program. | Tutors, therapists, microschools, private schools | 2026–27 expansion | F06, F07, E06 |
| **Medicaid EVV via HHAeXchange.** A single EVV system across all HCBS waiver and home-health programs, with a free HHAX portal or third-party EVV under the **new open model** ([HHAeXchange SC](https://www.hhaexchange.com/info-hub/south-carolina-information-center)). | Home care and home health agencies | Rollout guidance "coming soon" (2026) | E07 |
| **Minimum wage:** no state law; federal $7.25 applies ([DOL](https://www.dol.gov/agencies/whd/minimum-wage/state)). | n/a | n/a | n/a |
| **No comprehensive privacy law** ([privacyterms.io](https://privacyterms.io/us-state-privacy-laws-2026)). | n/a | n/a | J02 weak |
| **FTC all-in pricing rule** (hotels and short-term lodging, and live-event tickets, May 2025; per D-series research). | Condo-hotels, campgrounds, attractions | In force | D05, D06, D07, I04 |
| **Hurricane season.** | Coastal roofers, restoration | Jun 1–Nov 30 | C02, C07 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture) | In-migration to Greenville, Charleston suburbs, Bluffton and Fort Mill keeps trades busy. This is the highest-scoring idea nationally, and the pain is the same here. |
| 2 | A03 | LocalLoop (reviews and texting) | Restaurants and hospitality are the largest small-business employers, and reviews drive tourist traffic in Charleston and Myrtle Beach. |
| 3 | D07 | BookTrail (tours and charters) | Charleston walking, ghost and harbor tours, plus Myrtle Beach and Hilton Head fishing and dolphin charters. The off-season (Nov–Feb) is the switch window, and FareHarbor's 6% guest fee is the hook. |
| 4 | B07 | StudioDesk (HoneyBook alternative) | B07's research names Charleston a destination-wedding hub. Photographers and planners are angry about HoneyBook's 51–89% hikes. |
| 5 | F06 | ESA Desk (ESA billing) | ESTF grows to 15,000+ slots at $7,500+ in 2026–27 with a 500% FPL cap. New vendors need itemized, ESA-compliant invoices and a compliance binder (background checks, surety bonds). |
| 6 | D08 | TeeFree (golf tee sheet) | The Grand Strand's dense course cluster (commonly cited as 80+ courses; verify) plus Hilton Head. Barter tee times cost about $94.5k/yr, and the winter off-season is when courses switch. |
| 7 | E07 | Shiftwell (home care with EVV) | SC is moving to an open-model EVV on HHAeXchange, so agencies can bring their own EVV. Retiree-heavy coastal counties add private-pay demand. |

Bench:
- **D06 SiteLoop:** Grand Strand family campgrounds.
- **H03 StayDesk:** Myrtle Beach and Hilton Head short-term rentals.
- **F07 LessonLedger:** tutors paid by ESTF.
- **C07 ClaimKit:** hurricane claims.

## State-only opportunities
1. **Grand Strand golf plus lodging package desk (a D08 extension).** Myrtle Beach golf is sold as multi-course packages that bundle tee times at several courses with lodging. A lightweight package builder would help small package operators and course groups quote, hold tee times and invoice. It would pull course tee sheets from TeeFree and add an all-in price display. The package market is an estimate and needs verification with local operators.
2. **ESTF provider kit (F06/F07).** This is one of the few ESAs that explicitly funds **therapists and tutors** and requires **surety bonds at $50k+** plus background checks. The kit covers provider onboarding, the bond and background-check tracker, ESA-compliant invoices and the 2026–27 surge of families newly eligible under the 500% FPL cap.
3. **"Imputed license" E-Verify guard (regional kit).** SC is one of the strictest states because every employer, however small, must E-Verify within 3 business days, and violations suspend the right to employ anyone. That makes a cheap I-9 + E-Verify log + audit binder an easy add-on for restaurants and hospitality. E-Verify itself is free, so sell it bundled.

## Where to sell
- **Associations & events** (verify names and dates):
  - **Hospitality:** SC Restaurant & Lodging Association.
  - **Building and real estate:** Home Builders Association of SC, SC REALTORS.
  - **Professional:** SC Association of CPAs, SC Bar, SC Dental Association.
  - **Health and trucking:** SC Home Care & Hospice Association, SC Trucking Association.
  - **Tourism and golf:** Myrtle Beach Area Chamber/CVB, Charleston Area CVB, and Myrtle Beach Golf Holiday (course marketing co-op; verify).
- **Online communities:** r/Charleston, r/myrtlebeach, r/greenville, r/columbiasc and r/southcarolina; SC ESA parent and provider groups (names not verified); wedding-vendor networks in Charleston.
- **Partners:**
  - SC SBDC network (verify host).
  - Tourism DMOs.
  - Golf management companies.
  - ESTF trustee and vendor onboarding webinars.
  - Banks: SouthState and First Citizens (verify SC footprint).
  - HVAC supply houses in the Upstate.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials rule: State Board Reg. 43-170** | A state-level mechanism under which the State Board can require a title's removal statewide, aimed at "sensitive" or sex-related content. PEN counts **22 statewide removals** ([PEN America, Dec 2025](https://pen.org/report/the-bills-igniting-book-bans/)). Year adopted: 2024 (verify). | In force | R01, R07 |
| Science-of-reading / three-cueing law | South Carolina is on the three-cueing-ban list and NCTQ's approved-curriculum list (via P01/R08). The statute and bill number weren't fetched in this pass (verify). Read to Succeed is the umbrella law (verify). | In force | P01, R08 |
| 3rd-grade reading plan / retention law | **Mandatory retention**, based on SC READY Reading ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)) | In force | P02 |
| Homeschool: three options (HSLDA tier: moderate, verify) | **Option 1 (§59-65-40):** district approval, a 4.5-hour day and 180 days, a plan book, portfolio and semiannual progress reports, and the annual statewide tests. **Option 2 (§59-65-45):** SCAIHS membership. **Option 3 (§59-65-47):** membership in a homeschool association. The parent keeps a plan book, a portfolio and a **semiannual progress report including attendance records** ([SC Code ch. 65](https://www.scstatehouse.gov/code/t59c065.php)). **81 Option 3 associations** are on SCDE's 2026–27 list, and each files an Annual Standards Assurance form ([SCDE](https://ed.sc.gov/districts-schools/state-accountability/home-schooling/home-school-option-3/)). Fees run about **$35–$75 per family** ([Homeschool Start Guide, Feb 2026](https://homeschoolstartguide.com/blog/south-carolina-option-3-accountability-association)) or **$20–$50 per student** ([SC-TOP](https://sc-top.org/)). South Carolina had the **fastest homeschool growth** in 2024–25 at +21.5% (JHU, via P03). | Mid-year and year-end forms (e.g., ~Jan 5 / ~Jun 5) | P03, **S9-04** |
| **ESA: Education Scholarship Trust Fund (ESTF)** | **Size:** **$7,500** per student and **10,000** students in 2025–26. At least **15,000** scholarships in 2026–27, with the income cap raised to **500% FPL** ($160,750 for a family of four). **Legal history:** a 2025 law restored tuition use after the Oct 2024 court ruling. **Covered:** "textbooks, curriculum, or other instructional materials" and tutoring ([EdChoice](https://www.edchoice.org/school-choice/programs/south-carolina-education-scholarship-trust-fund-program/); [SCDE, Jun 27 2025](https://ed.sc.gov/newsroom/news-releases/sc-estf-program-reaches-10000-student-landmark)). **Platform:** ClassWallet runs a program page for ESTF (verify it's the current rail). Homeschool eligibility: verify. | 2026–27 | P03, P04, P07, R05 (+F07) |
| Other | Statewide Imagination Library funding (verify). | n/a | P06 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll.** South Carolina is the fastest-growing homeschool state, and Option 3 requires a semiannual progress report with attendance.
- **P02 ReadingPlan Home.** Mandatory 3rd-grade retention on SC READY.
- **R01 ClearShelf.** Reg. 43-170's statewide-removal list has to be tracked against every school catalog.

**State-only add-on:** see **ideas/S9-04**. Its buyers are the 81 Option 3 associations. Each collects semiannual assurance forms from hundreds of families by email and web forms, so the association is a B2B2C channel into P03.

**Where to sell** (names from background knowledge; verify months):
- South Carolina Library Association (fall) and SC Association of School Librarians (SCASL, spring).
- SC PTA.
- SCAIHS and the Option 3 association directors (SCDE list).
- IDA South Carolina branch (verify).
- Southern Independent Booksellers Alliance (SIBA).

## Launch verdict
**Speed:** Medium. **First city:** Charleston, then Myrtle Beach for the off-season tourism push and Greenville for trades. **Lead offer:** BookTrail (D07), "no guest booking fee, free migration before spring," for Charleston and Grand Strand tour and charter operators. Run FirstCall (B04) in parallel in Greenville.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: South Carolina](https://advocacy.sba.gov/wp-content/uploads/2025/06/South_Carolina_2025-State-Profile.pdf)
- [US Census Bureau, Business Formation Statistics monthly CSV (Jan–Aug 2026)](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)
- [SC Code Title 41 Chapter 8 (E-Verify / imputed license)](https://www.scstatehouse.gov/code/t41c008.php)
- [SC Statehouse, S.62 Education Scholarship Trust Fund (2025)](https://www.scstatehouse.gov/sess126_2025-2026/bills/62.htm)
- [HHAeXchange South Carolina information center](https://www.hhaexchange.com/info-hub/south-carolina-information-center)
- [GetESAPaid, ESA payment rails by state](https://getesapaid.com/become-an-esa-vendor)
- [US DOL, state minimum wage table](https://www.dol.gov/agencies/whd/minimum-wage/state)
- [privacyterms.io, US state privacy laws 2026](https://privacyterms.io/us-state-privacy-laws-2026)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [SC Code Title 59 Chapter 65 (homeschool options §§59-65-40, -45, -47)](https://www.scstatehouse.gov/code/t59c065.php)
- [SCDE: Home School Option 3 association list 2026–27](https://ed.sc.gov/districts-schools/state-accountability/home-schooling/home-school-option-3/)
- [Homeschool Start Guide: SC Option 3 accountability associations (Feb 4 2026)](https://homeschoolstartguide.com/blog/south-carolina-option-3-accountability-association)
- [SC-TOP (Option 3 association fees and forms)](https://sc-top.org/)
- [EdChoice: SC Education Scholarship Trust Fund](https://www.edchoice.org/school-choice/programs/south-carolina-education-scholarship-trust-fund-program/)
- [SCDE: ESTF reaches 10,000 students (Jun 27 2025)](https://ed.sc.gov/newsroom/news-releases/sc-estf-program-reaches-10000-student-landmark)
- Internal (education): ideas P01, P02, P03, R01, R08, S9-04
