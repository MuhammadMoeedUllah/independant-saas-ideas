# Mississippi (MS): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 294,768 small businesses employ 444,113 people, or **47.0% of MS employees** (2022), above the national small-business share. From Mar 2023 to Mar 2024, small businesses had 6,915 openings and 7,162 closings. The state overall had a **net decrease of 177 establishments**, but small firms still added a net 5,426 jobs ([SBA Advocacy 2025 Mississippi profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Mississippi_2025-State-Profile.pdf)).
- **New-business momentum:**
  - **44,768 business applications in Jan–Aug 2026** (not seasonally adjusted), **1.0% of US applications from about 0.9% of US population**, so per-capita filing is above average (population share from memory, verify) ([Census BFS monthly CSV](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)).
  - Most small-business employees: health care (71,235) and accommodation and food (69,658).
  - Top firm counts: other services (44,194) and construction (35,448) (SBA profile).
- **Buyer clusters:**
  - **Jackson metro** (Madison, Rankin): health care, government contractors, churches, home services.
  - **DeSoto County** (Southaven, Olive Branch, Horn Lake): Memphis suburbs with logistics and new-home services.
  - **Gulf Coast** (Gulfport, Biloxi, Ocean Springs): casinos, hospitality, fishing charters, hurricane rebuild, shipyard suppliers.
  - **Hattiesburg, Tupelo and Oxford/Starkville:** university towns, furniture manufacturing (Tupelo), health care.
- **Industries overweight vs. US** (inference, verify):
  - Health care and home care (Medicaid-heavy).
  - Poultry and agriculture.
  - Timber and trucking.
  - Casino gaming and Gulf tourism.
  - Shipbuilding suppliers.
  - Churches.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Medicaid EVV on HHAeXchange (with FEI Systems).** Rolled out in phases: waivers Aug 1 2023, state-plan services Dec 11 2023, **MCOs (Magnolia, Molina, UnitedHealthcare) May 1 2025**. **All EVV claims have had to go through HHAeXchange since Dec 1 2025.** A **claims edit (712) suspends EVV claims submitted directly in MESA from Jan 1 2026**, and the **new HHAeXchange+ caregiver app became mandatory Aug 31 2026**. Agencies can use the free portal or import from their own EVV over EDI ([HHAeXchange Mississippi](https://www.hhaexchange.com/info-hub/mississippi)). | Personal care, private duty nursing, home health and waiver agencies | Changes through **Aug 31 2026** (just passed) | E07 |
| **E-Verify for all employers, contractors and subcontractors** (Mississippi Employment Protection Act, S 2988, 2008, per [NCSL table (2015)](https://www.ncsl.org/immigration/state-e-verify-action)). Current code section (Miss. Code 71-11-3) and penalties to verify. | Every employer | In force | G04, J03, regional E-Verify kit |
| **Medical Cannabis Act (2022):** MS is listed as a Metrc state (per J04) ([MMCP](https://www.mmcp.ms.gov/)). License and patient counts not retrieved; verify. | Dispensaries, cultivators, processors | Ongoing; federal hemp cap (~Nov 2026) touches hemp shops | J04 |
| **Minimum wage:** no state law; federal $7.25 ([DOL](https://www.dol.gov/agencies/whd/minimum-wage/state)). | n/a | n/a | n/a |
| **No comprehensive privacy law** ([privacyterms.io](https://privacyterms.io/us-state-privacy-laws-2026)). | n/a | n/a | J02 weak |
| **Income-tax phase-down** (HB 1, 2025; from memory, verify schedule). | Owners and CPAs | Multi-year | G03 (minor) |
| **IFTA quarterly** returns. | Trucking (timber, poultry, DeSoto logistics) | **Oct 31 2026** | K03 |
| **Hurricane season** (Gulf Coast). | Roofers, restoration, marinas | Jun 1–Nov 30 | C02, C07 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | E07 | Shiftwell (home care with EVV export) | MS just finished a forced EVV consolidation: the HHAX-only claims path (Dec 2025), the MESA claims edit (Jan 2026) and a new mandatory caregiver app (Aug 31 2026). Health care is the #1 small-business employer. Agencies on the free portal still need scheduling, private-pay billing and payroll, and EDI into HHAX lets them keep their own tool. |
| 2 | B04 | FirstCall (owned lead capture) | Construction is the #2 firm category (35,448). DeSoto and Madison/Rankin suburbs are growing. Highest national score. |
| 3 | A03 | LocalLoop (reviews and texting) | Restaurants, casinos' surrounding businesses, dental and home services. The price-sensitive market favors a flat price. |
| 4 | I02 | TitheBox (church giving) | Among the most church-dense states in the US (verify). The Q4 giving season is the switch window now, and multi-year Pushpay contracts are the pain. |
| 5 | F01 | Chairly (salon/barber booking) | Other services is the #1 small-firm category (44,194). Commission-free, low-cost booking fits a low-margin market. |
| 6 | K03 | HaulDesk (small-fleet back office) | Timber, poultry and DeSoto County logistics create many owner-operators. IFTA is due Oct 31. |
| 7 | K01 | BayBook (auto repair) | Car-dependent rural state with many independent shops (part of the 44,194 other-services firms). Tekmetric and Shopmonkey tier creep is the switching window. |

Bench:
- **J04 TagTrue:** medical cannabis on Metrc.
- **C07 ClaimKit and D07 BookTrail:** Gulf Coast storms, charters and tours.
- **E06 SkillTrack:** Medicaid therapy providers.

## State-only opportunities
1. **Mississippi EVV companion for HHAeXchange-portal agencies (E07 wedge).** Many small MS agencies adopted the free HHAX portal only because the state required it. We would sell the rest of the back office: caregiver scheduling across Medicaid and private-pay clients, payroll export, private-pay invoicing, and an EDI feed that keeps HHAX in sync.
   - The Aug 31 2026 mandatory app change means agencies are re-training caregivers now, a natural moment to evaluate tools.
   - Price below WellSky and AxisCare, at a flat per-agency rate.
2. **Strictest-tier E-Verify kit (regional, with AL and SC).** All employers must E-Verify. Offer an I-9 + E-Verify case log + audit binder add-on to G04 or J03. E-Verify is free, so this is an add-on, not a standalone product.
3. **Medical cannabis compliance reconciliation (J04).** A small, young market reconciling Metrc against POS. It is only worth pursuing after verifying license counts (the MMCP transparency portal was not retrieved).

## Where to sell
- **Associations & events** (verify names and dates):
  - **Hospitality:** Mississippi Hospitality & Restaurant Association.
  - **Building and real estate:** Home Builders Association of Mississippi, Mississippi REALTORS.
  - **Professional:** Mississippi Society of CPAs, The Mississippi Bar, Mississippi Dental Association.
  - **Health and trucking:** Mississippi home care association (verify name), Mississippi Trucking Association.
  - **General business:** Mississippi Economic Council (state chamber), Mississippi Gulf Coast Chamber.
  - **Denominational bodies,** for church outreach.
- **Online communities:** r/mississippi, r/jacksonms and r/Gulfport; home care owner groups on Facebook (names not verified); DeSoto County business networks.
- **Partners:**
  - Mississippi SBDC (verify host).
  - Innovate Mississippi.
  - Banks: Trustmark, BankPlus, Renasant and Hancock Whitney (verify footprints).
  - Medicaid billing consultants, for E07 referrals.
  - HHAeXchange EDI integrator listings, where applicable.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials law** | No library-materials law found. **HB 1193 (2025)** bans "divisive concepts" and diversity programming, including "formal or informal education" on race, sex, gender identity and sexual orientation. A federal district court has enjoined the divisive-concepts and "informal education" provisions ([PEN America, Dec 18 2025](https://pen.org/report/the-bills-igniting-book-bans/)) | Partly enjoined | R07, R01 (weak) |
| **Science of reading: Literacy-Based Promotion Act (LBPA, 2013)** | Universal K–3 screening at least 3 times a year with state-approved screeners (FAST, i-Ready, ISIP, mCLASS, MAP Growth, STAR). Dyslexia screening in spring of kindergarten and fall of grade 1. "Pathways to Proficient Reading" training, and K–5 materials evaluated through three gateways ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/mississippi/)). Not on the category-research list of three-cueing bans (verify) | Since 2013; dyslexia screening since 2017 | P01, R08 |
| **3rd-grade retention: LBPA "third-grade gate"** | Mandatory retention (category research). Mississippi's model pairs **individual reading plans, parent notification and "Read at Home" plans** (The 74, via P02). Good-cause exemption details were not on the fetched page (verify) | In force since 2014–15 (verify) | P02, P01 |
| **Homeschool: HSLDA low regulation** | A certificate of enrollment (notice) is required. No state subjects, testing or immunization rules apply ([HSLDA Mississippi](https://hslda.org/legal/mississippi)). The Sep 15 deadline and records rules were not confirmed (verify) | In force | P03 |
| **ESA and scholarship money** | Three programs: the Equal Opportunity for Students with Special Needs ESA, the Dyslexia Therapy Scholarship and the Nate Rogers Scholarship ([EdChoice Mississippi](https://www.edchoice.org/school-choice/state/mississippi/)); amounts not confirmed (verify). **HB 2 (2026)**, a "Mississippi Educational Freedom Program" with Magnolia Student Accounts and ESAs, would have launched in 2027–28 with a 12,500 cap. It was listed as not enacted ([FutureEd, Jul 13 2026](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). Gov. Reeves opted in to the federal tax-credit scholarship on Jan 19 2026. It covers households up to 300% of area median income, about $150k ([Mississippi Today, Jan 20 2026](https://mississippitoday.org/2026/01/20/mississippi-federal-school-choice-tax-credits-reeves/)) | Federal credit Jan 1 2027 | F06, F07, P07, P04 |
| **Other** | Not checked (Imagination Library, auto-renewal law: verify) | — | — |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home:** the LBPA third-grade gate already requires individual reading plans, parent notification and Read-at-Home plans, the exact workflow P02 digitizes.
- **P01 PhonicsPrep:** dyslexia therapists paid by the Dyslexia Therapy Scholarship, and interventionists working toward the third-grade gate, need structured-literacy tools.
- **R08 Readlings:** K–3 screening 3 times a year and "Read at Home" plans need take-home decodable practice.

**Where to sell:**
- **Libraries:** Mississippi Library Association (fall conference; verify), including its school-library section (verify).
- **Parents:** Mississippi PTA.
- **Homeschool:** Mississippi Home Educators Association (MHEA; verify).
- **Reading specialists:** IDA Mississippi branch and The Reading League Mississippi (both verify), plus MDE literacy coaches.
- **Booksellers:** SIBA.

## Launch verdict
**Speed:** Slow-Medium (small, price-sensitive market; one strong forced-change vertical). **First city:** Jackson metro (Madison/Rankin), with DeSoto County as the second, Memphis-adjacent market. **Lead offer:** Shiftwell (E07), "keep HHAeXchange for EVV, run everything else in one flat-priced app," sold to agencies right after the Aug 31 2026 app change. FirstCall (B04) runs as the horizontal backup.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Mississippi](https://advocacy.sba.gov/wp-content/uploads/2025/06/Mississippi_2025-State-Profile.pdf)
- [US Census Bureau, Business Formation Statistics monthly CSV (Jan–Aug 2026)](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)
- [HHAeXchange Mississippi information center](https://www.hhaexchange.com/info-hub/mississippi)
- [NCSL, State E-Verify action (2015 table; historical)](https://www.ncsl.org/immigration/state-e-verify-action)
- [Mississippi Medical Cannabis Program](https://www.mmcp.ms.gov/)
- [US DOL, state minimum wage table](https://www.dol.gov/agencies/whd/minimum-wage/state)
- [privacyterms.io, US state privacy laws 2026](https://privacyterms.io/us-state-privacy-laws-2026)
- [The Reading League Compass: Mississippi](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/mississippi/)
- [HSLDA: Mississippi homeschool law](https://hslda.org/legal/mississippi)
- [EdChoice: Mississippi school choice programs](https://www.edchoice.org/school-choice/state/mississippi/)
- [FutureEd: 2026 private school choice bill tracker (Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
- [Mississippi Today: Reeves opts in to federal school-choice tax credits (Jan 20 2026)](https://mississippitoday.org/2026/01/20/mississippi-federal-school-choice-tax-credits-reeves/)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- Internal: ../ideas/P02 (The 74 on Mississippi's reading-plan model)
