# Illinois (IL): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 1.4 million small businesses (99.6% of Illinois businesses). They employ 2.4 million people, or 43.7% of Illinois employees ([SBA Advocacy 2025 Illinois profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Illinois_2025-State-Profile.pdf); counts use 2022 data).
- **New-business momentum:** Flat. From March 2023 to March 2024, 35,143 establishments opened and 34,914 closed, a net gain of only 229. Small businesses added a net 14,131 jobs. Banks lent $3.3B to firms with revenue of $1M or less in 2023 (same SBA profile). The fastest-growing sectors were not broken out in this pass.
- **Buyer clusters** (from SBA sector counts plus inference; metro detail is an estimate):
  - **Chicago city:** restaurants, bars, salons and barbers, dental and law practices, nonprofits, condo associations. It also has the densest local labor rules in the Midwest.
  - **Cook County suburbs and the I-55/I-80/I-90 corridors** (Elk Grove Village, Bolingbrook, Joliet, Cicero): trucking and small fleets, warehouses, light manufacturing, staffing agencies.
  - **Collar counties** (DuPage, Lake, Kane, Will): home services, kids' activities, med spas, HOAs.
  - **Rockford, Peoria, the Quad Cities:** manufacturing and ag-equipment suppliers.
  - **Springfield:** state associations and lobbying groups.
  - **Metro East:** St. Louis spillover (trades, restaurants).
- **Industries overweight vs. US:**
  - **Transportation and warehousing** is Illinois's #1 small-business category by count, with 210,396 firms. That is unusual; most states lead with professional services or other services (SBA).
  - **Accommodation and food services:** 318,909 small-business employees (SBA).
  - **Manufacturing:** 239,226 small-business employees and 19,462 small exporters, 88.8% of all Illinois exporters (SBA).
  - **Professional, scientific and technical services:** 172,405 firms (SBA).
  - **Health care:** 343,660 small-business employees (SBA).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **2026 Remote Retailer Tax Amnesty.** Covers periods Jan 1 2021 to Jun 30 2026. Amnesty rates are 9% for general merchandise and 1.75% for qualifying items. Penalties and interest are waived ([IDOR](https://tax.illinois.gov/programs/illinoistaxamnesty.html)). | Out-of-state e-commerce sellers with IL customers | **Window Aug 1 to Oct 31 2026 (open now)** | J01 |
| **200-transaction nexus test removed**, leaving only the $100k sales test ([TaxCloud](https://taxcloud.com/sales-tax-radar/illinois-eliminates-transaction-threshold-2026/), via J01) | Remote sellers | Jan 1 2026 | J01, L03 |
| **State 1% grocery tax repealed.** Cities and counties may adopt their own 1% local grocery tax (verify) | Grocers, convenience stores, delis, POS vendors | Jan 1 2026 | D09, D01 |
| **Pay transparency.** Employers with 15+ employees must post pay and benefits in every job posting, tell staff about promotions within 14 days, and keep records for 5 years. An anonymous-complaint policy took effect Jan 1 2026, and rule revisions took effect Jun 18 2026 ([IDOL](https://labor.illinois.gov/laws-rules/conmed/equalpay.html)) | 15+ employee firms, staffing agencies | In force since Jan 1 2025; new rules 2026 | J03, G07, S5-01 |
| **Equal Pay Registration Certificate** (100+ IL employees), renewed every 2 years ([IDOL](https://labor.illinois.gov/laws-rules/conmed/equalpay.html)) | Mid-size employers | Rolling | J03, G04 |
| **Paid Leave for All Workers Act:** 1 hour per 40 worked, up to 40 hours a year (verify) | Nearly every employer outside Chicago and Cook County | In force since Jan 1 2024 | G04, D04, S5-01 |
| **Chicago Paid Leave and Paid Sick Leave Ordinance:** 40 hours of paid leave plus 40 hours of paid sick leave (verify) | Chicago employers | In force since Jul 1 2024 | D04, G04, S5-01 |
| **Chicago "One Fair Wage" tipped-wage phase-out:** the tip credit shrinks each Jul 1 until the full minimum wage applies (verify schedule) | Chicago restaurants and bars | Next step Jul 1 2027; ends Jul 1 2028 (verify) | D04, D01, S5-01 |
| **BIPA** (740 ILCS 14): written release and a public retention policy before any fingerprint or face scan. The 2024 amendment (SB 2979) counts repeat scans of one person as one violation and allows e-signed consent (verify) | Anyone using biometric time clocks: restaurants, manufacturers, staffing, health care | In force; amendment Aug 2024 (verify) | S5-01, D04 |
| **IL Human Rights Act amendment on AI in employment** (HB 3773): notice required when AI is used in hiring or other decisions (verify) | Employers using AI screening | Jan 1 2026 (verify) | G07, J03 |
| **Electronic Lien and Title expansion** ([IL SOS, Feb 11 2026](https://www.ilsos.gov/news/2026/february-11-2026-giannoulias-expands-electronic-lien-and-titling-to-deliver-faster-more-secure-vehicle-titles.html), via K02) | Independent dealers, lenders | Feb 2026 onward | K02 |
| **Medicaid EVV:** open model with HHAeXchange as state aggregator. Deadline was 2/10/2023; compliance was 75% ([HHAeXchange](https://www.hhaexchange.com/state-evv-status)) | Home-care agencies | In force | E07 |
| **ADA website suits:** 585 federal filings in 2025, #3 in the US ([Seyfarth](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/), via J02) | Any SMB with a website, especially restaurants and retail | Ongoing | J02 |
| **Charitable solicitation registration** with the IL AG is among the heaviest burdens (lead from I01); **SOPPA** student-data agreements (lead from I07) | Nonprofits; private schools | Annual | I01, I07 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | D04 (+S5-01 IL pack) | ShiftTip | Illinois stacks statewide PLAWA leave, Chicago paid leave plus sick leave, the Chicago tip-credit phase-out and BIPA risk on biometric clocks. The food-service sector alone has 318,909 small-business employees. No generic scheduler handles all of it. |
| 2 | K03 | HaulDesk | Transportation and warehousing is the state's largest small-business category (210,396 firms), with dense small fleets around Chicago. IFTA is due Oct 31, and DAT renewals are up 25–45%. |
| 3 | B04 | FirstCall | This idea tops the scoreboard (23). Chicago is a high-cost lead metro. The state has a big construction and home-services base, and Google ended LSA disputes in Nov 2025. |
| 4 | J02 | SiteShield | Illinois had 585 federal ADA web suits in 2025, #3 nationally. A privacy page that "discloses biometrics" is a natural Illinois add-on. Buyers act out of fear, fast and with a card. |
| 5 | F01 | Chairly | Salon and barber density in Chicago (America's Beauty Show is held there). Fresha and Vagaro payout and commission anger (scoreboard 22). |
| 6 | J01 | NexusBook | The amnesty window closes **Oct 31 2026**, and the 200-transaction test is gone. "Do I owe Illinois?" is a live question for every remote seller. |
| 7 | J03 | PostedUp | Illinois and Chicago keep adding rules: 2026 pay-transparency complaint and rule changes, AI-notice rules, and the city and county leave ordinances. Posters plus a law-change feed are a cheap card purchase. |

## State-only opportunities
- **S5-01 ClockRight IL** ([ideas/S5-01-illinois-bipa-safe-time-clock-leave-compliance.md](../ideas/S5-01-illinois-bipa-safe-time-clock-leave-compliance.md)): a BIPA-free time clock with accruals for PLAWA, Chicago and Cook County leave, plus a Chicago tip-credit tracker and pay-transparency posting checks. Only Illinois combines biometric-privacy suits with three layers of paid-leave rules. Scored 17/25.
- **Remote-retailer amnesty sprint (J01 campaign, not a new product):** an "Illinois amnesty calculator" landing page aimed at Shopify and Etsy sellers before Oct 31 2026. After that, the page becomes "IL nexus without the 200-transaction test."
- **Chicago condo associations (H02 variant):** Chicago has a very large high-rise condo stock (estimate). Illinois has no statewide website mandate found in this pass (verify the IL Condominium Property Act's records rules). Treat it as a V2 market, not a launch.

## Where to sell
- **Associations & events** (months to verify):
  - Hospitality and retail: Illinois Restaurant Association, the National Restaurant Association Show (Chicago, May), Illinois Hotel & Lodging Association, Illinois Retail Merchants Association.
  - Trucking: Illinois Trucking Association, Mid-West Truckers Association (Springfield).
  - Professionals: Illinois CPA Society, Illinois State Bar Association and Chicago Bar Association, Chicago Dental Society Midwinter Meeting (Feb).
  - Beauty and staffing: America's Beauty Show (Chicago), Illinois Staffing Association (via G07).
  - Real estate and building: Illinois REALTORS, Home Builders Association of Illinois.
  - Tech: ABA TECHSHOW (Chicago, spring).
- **Online communities:** r/chicago, r/ChicagoSuburbs, r/illinois, r/restaurateur, r/Truckers, and Chicago neighborhood business groups on Facebook (names to verify). Spanish-language outreach helps for Chicago restaurants, trades and trucking (estimate).
- **Partners:**
  - Illinois SBDC network (DCEO) and Chicago neighborhood chambers.
  - Chicago-area payroll bookkeepers and restaurant CPAs, who field the leave and tip questions.
  - Factoring companies and truck-stop networks for fleets.
  - Restaurant supply houses (verify).
  - Employment-law firms running BIPA and PLAWA webinars.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **Freedom-to-read law: HB 2789 (Public Act 103-0100)** | Libraries that want state library grants must adopt the ALA Library Bill of Rights or a written statement against banning materials. Book Riot names Illinois as the first such state, covering both school and public libraries ([Book Riot, Aug 2026](https://bookriot.com/massachusetts-passes-freedom-to-read-law/); [EdWeek, Jan 7 2026](https://www.edweek.org/policy-politics/states-are-banning-book-bans-will-it-work/2026/01)). The Secretary of State's page blocked fetching, so the certification steps and deadlines are unconfirmed (verify) | In force since Jan 1 2024 (verify) | R01, R03 |
| **Science of reading (no three-cueing ban)** | Illinois leaves curriculum to districts and has no statewide curriculum list or three-cueing ban. ISBE adopted the **Illinois Comprehensive Literacy Plan on Jan 24 2024** and published a curriculum evaluation tool (Jul 2024). Two laws add requirements ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/illinois/)):<br>• **Public Act 103-0402:** ISBE measures how educator-preparation programs teach literacy, starting **Jul 1 2026**.<br>• **Public Act 104-0389:** starting **2026–27**, districts serving K–3 must report which early-literacy screeners they use, in which grades and how often.<br>An FY2025 District Literacy Implementation Grant also exists | Screener reporting from 2026–27 | P01, R08 |
| **3rd-grade reading plan or retention law** | None. There is no statewide third-grade retention policy (Compass). Reading plans are set locally | n/a | (P02 weak) |
| **Homeschool: HSLDA "No notice, low regulation"** | No notice and no testing, but state-mandated subjects apply ([HSLDA Illinois](https://hslda.org/legal/illinois)). HSLDA's page covers opposition to **HB 2827** and reports that a "bad bill" died. That bill's content (a proposed homeschool notice or registration requirement) is unconfirmed here (verify) | In force; bill fight 2025 (verify) | P03 |
| **ESA and scholarship money** | Illinois has **no ESA or voucher**, and the Invest in Kids tax-credit scholarship expired at the end of 2023 (verify). Illinois is **not** on the IRS list of states in the federal tax-credit scholarship ([IRS, Jun 8 2026](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)). SB 3966 (2026), which would bar participation in federal voucher or ESA programs, was not enacted ([FutureEd, Jul 13 2026](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). The state K–12 Education Expense Credit is reported as 25% of tuition, book and lab fees above $250, up to $750 per family. The IDOR page returned 404 (verify) | Annual tax filing | P07 (weak), F06 (weak) |
| **Other: subscriptions and student data** | The Illinois Automatic Contract Renewal Act (815 ILCS 601) requires clear auto-renewal disclosures and online cancellation for online sign-ups (verify). **SOPPA** requires a data-privacy agreement with each district before an edtech product touches student data (see I07). Any R01/R08/P01 school sale here needs one | In force | P07, R08, R01 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf:** state library grants depend on written anti-banning and collection policies. Illinois libraries need a policy-plus-catalog record that proves compliance.
- **P03 HomeRoll:** a large no-notice homeschool population that held a record-setting rally against a proposed bill (HSLDA) keeps its own records. Records and transcripts sell without a state form.
- **P01 PhonicsPrep:** with local control, districts pick their own tools. The 2026–27 screener reporting and the literacy plan push districts toward evidence-based interventions, and every sale needs a SOPPA agreement.

**Where to sell:**
- **Libraries:** Illinois Library Association annual conference (October; verify) and the Illinois School Library Media Association (ISLMA; verify).
- **Parents:** Illinois PTA.
- **Homeschool:** Illinois Christian Home Educators (ICHE) convention (verify).
- **Reading specialists:** IDA Illinois branch and The Reading League Illinois chapter (both verify).
- **Booksellers:** GLIBA (verify territory).

## Launch verdict
**Speed:** Fast.

**First city:** Chicago (city plus inner Cook County suburbs).

**Lead offer:** ShiftTip with the ClockRight IL pack. The hook is "BIPA-free clock plus automatic PLAWA and Chicago leave plus tip-credit tracking, flat $39 per location." Follow with a HaulDesk "IFTA by Oct 31" sprint to suburban fleets, and a NexusBook amnesty page (closes Oct 31 2026).

## Sources
- [SBA Office of Advocacy: 2025 Illinois Small Business Profile (PDF)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Illinois_2025-State-Profile.pdf)
- [IL Department of Revenue: 2026 Remote Retailer Tax Amnesty Program](https://tax.illinois.gov/programs/illinoistaxamnesty.html)
- [IL Department of Labor: Equal Pay Act / Pay Transparency / EPRC](https://labor.illinois.gov/laws-rules/conmed/equalpay.html)
- [HHAeXchange: State-by-State EVV Status](https://www.hhaexchange.com/state-evv-status)
- [Seyfarth ADA Title III: 2025 federal website-accessibility filings (Mar 2026)](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/) (via J02)
- [TaxCloud: Illinois eliminates 200-transaction threshold (Jan 1 2026)](https://taxcloud.com/sales-tax-radar/illinois-eliminates-transaction-threshold-2026/) (via J01; not re-opened)
- [IL Secretary of State: Electronic Lien and Titling expansion (Feb 11 2026)](https://www.ilsos.gov/news/2026/february-11-2026-giannoulias-expands-electronic-lien-and-titling-to-deliver-faster-more-secure-vehicle-titles.html) (via K02)
- [Biometric Information Privacy Act, 740 ILCS 14 (ILGA)](https://www.ilga.gov/legislation/ilcs/ilcs3.asp?ActID=3004&ChapterID=57) (the fetch was blocked by robots.txt; statute details marked verify)
- Chicago minimum-wage page (chicago.gov) showed only 2023 figures, and the One Fair Wage page returned 403. The Chicago tip-credit and paid-leave details above are marked (verify).
- [The Reading League Compass: Illinois](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/illinois/)
- [ISBE: Illinois Comprehensive Literacy Plan](https://www.isbe.net/literacyplan) (search listing; not opened)
- [Book Riot: Massachusetts passes freedom-to-read law, with list of other states (Aug 2026)](https://bookriot.com/massachusetts-passes-freedom-to-read-law/)
- [EdWeek: States are banning book bans (Jan 7 2026)](https://www.edweek.org/policy-politics/states-are-banning-book-bans-will-it-work/2026/01)
- [HSLDA: Illinois homeschool law](https://hslda.org/legal/illinois)
- [IRS: Federal scholarship tax credit participating states (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [FutureEd: 2026 state private school choice bill tracker (updated Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
- The IL Secretary of State freedom-to-read page (robots.txt) and the IDOR education-expense-credit page (404) could not be fetched. Those details are marked (verify).
