# Arkansas (AR): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:**
  - 292,728 small businesses, 99.3% of Arkansas businesses.
  - 501,512 small-business employees, 46.1% of Arkansas employees ([SBA Advocacy 2025 Arkansas profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Arkansas_2025-State-Profile.pdf)).
- **New-business momentum:**
  - Mar 2023–Mar 2024: small businesses opened 9,630 establishments and closed 8,949.
  - Small firms produced a net 14,245 jobs, **87.0% of all net new jobs**. That share is high for a small state.
  - Banks lent $1.1B to firms with revenue under $1M in 2023 (same SBA profile).
  - Growth is concentrated in Northwest Arkansas (inference; verify with Census BFS).
- **Buyer clusters:**
  - **Northwest Arkansas (Bentonville, Rogers, Springdale, Fayetteville):** fast-growing suburbs, the Walmart supplier and CPG ecosystem, Tyson and poultry, J.B. Hunt and trucking. Home services for new-build neighborhoods (inference).
  - **Little Rock–Conway:** state government, health care, private schools, professional services.
  - **Fort Smith:** trucking and logistics (ArcBest), manufacturing.
  - **Jonesboro and the Delta:** ag services.
  - **Hot Springs and the Ozarks:** tourism, cabins, short-term rentals, campgrounds (inference).
- **Industries overweight vs. US:** estimate, from SBA rankings.
  - **Construction** is the #1 small-business sector by count: 38,786 firms.
  - **Retail trade** ranks #5 by count (26,999 firms) and employs 52,262 people.
  - **Health care** employs 88,401 people; **accommodation & food**, 74,300.
  - **Trucking**, with HQs for J.B. Hunt and ArcBest and many small carriers (verify counts).
  - **Hail:** Arkansas was #10 in the US for major hail events in 2025, with 154 events ([III hail facts](https://www.iii.org/fact-statistic/facts-statistics-hail)).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Education Freedom Accounts (EFA), created by the LEARNS Act.**<br>• **Universal since 2025–26**, with **46,578 students** that year.<br>• Average account $6,694, capped at $6,864 (or $7,627 for students coming from the earlier voucher program).<br>• Allowable spending covers tuition, tutoring, therapies, testing, curriculum and technology. Transportation and extracurriculars are each capped at 25%.<br>• 166 providers or schools participate ([EdChoice, updated Dec 16 2025](https://www.edchoice.org/school-choice/programs/arkansas-childrens-educational-freedom-account-program/)). | Private schools, microschools, tutors, therapists, homeschool vendors | 2026–27 school year now | F06, F07, E06 |
| **The Education Department's review of the EFA platform vendor (ClassWallet).**<br>• It found ClassWallet "fragmented, inefficient and increasingly misaligned", citing manual workarounds, limited reporting, weak compliance monitoring and slow responses.<br>• Arizona is also seeking vendor alternatives: a Request for Information (RFI) went out in Mar 2026, with responses due Jul 29 ([Grand Canyon Times, Jul 24 2026](https://grandcanyontimes.com/report-finds-esa-vendor-classwallet-fragmented-inefficient-and-increasingly-misaligned)). | Every EFA provider that has to invoice through the platform | 2026 (a possible platform change is unconfirmed; verify) | F06, F07 |
| **Act 952 (HB 1717), Arkansas Children and Teens' Online Privacy Protection Act.** Signed Apr 21 2025 ([LegiScan](https://legiscan.com/AR/bill/HB1717/2025)). The effective date is likely Jul 1 2026 (J02 notes Arkansas privacy changes on that date; verify). | Sites and apps aimed at children or teens: tutoring, lessons, youth sports, camps | Jul 1 2026 (verify) | J02, F07, I05, I06 |
| **IFTA Q3** | Arkansas carriers | Oct 31 2026 | K03 |
| **Hemp and delta-8.** Act 629 of 2023 restricted intoxicating hemp, and it has been in litigation (background, verify current status). | Smoke and CBD shops | Uncertain | J04 (skip) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | F06 | ESA Desk | Arkansas is **where the ClassWallet pain is documented by the state itself**. 46,578 EFA students (2025–26) are spread across a young provider base (166 providers or schools). We sell provider-side reconciliation and ESA-compliant invoices, whichever platform the state keeps. |
| 2 | F07 | LessonLedger (ESA-ready tutoring and lessons) | Universal EFA money lets families spend on tutoring, therapies and curriculum. A tutor who can't invoice the platform cleanly loses the family. Pair it with Act 952 teen-privacy defaults (verify date). |
| 3 | B04 | FirstCall | Construction is the #1 small-business sector. New-build growth in Northwest Arkansas feeds demand for owned leads. Highest national score (23). |
| 4 | K03 | HaulDesk | Arkansas is a trucking state: J.B. Hunt (Lowell) and ArcBest (Fort Smith) anchor a large small-carrier and owner-operator base (verify counts). IFTA is due Oct 31. |
| 5 | C01 | FlatRate | HVAC and plumbing shops in the NWA and Little Rock suburbs. Oct–Feb switch window. |
| 6 | A03 | LocalLoop | Horizontal review and texting tool. Retail and home services depend on Google reviews in fast-growing NWA. |
| 7 | C02 | StormDesk | #10 hail state (154 events in 2025). Sell it as a secondary storm market together with Oklahoma and Texas. |

## State-only opportunities
1. **ClassWallet-independent provider desk (F06 Arkansas pack).**
   - The state's own review is public evidence of platform pain.
   - We offer providers a "system of record" that keeps their own ledger, student records, invoices and claim status, whatever the platform does.
   - If Arkansas re-procures, the provider data is portable.
   - This isn't a new idea file; it's the F06 go-to-market for Arkansas.
2. **Walmart-supplier SMB tooling (watch, not specced).**
   - Northwest Arkansas hosts a large cluster of small CPG suppliers and vendor-services firms serving Walmart.
   - A flat-priced Retail Link and Walmart Marketplace reporting tool could fit the "cheaper SaaS" thesis.
   - Not verified in this pass: incumbent names, pricing and supplier counts all need research before any build.

## Where to sell
- **Associations & events** (background knowledge; verify names and vendor programs):
  - **Hospitality and retail:** Arkansas Hospitality Association (restaurants and lodging), Arkansas State Chamber / Associated Industries of Arkansas.
  - **Construction and real estate:** Home Builders Association of Arkansas, Arkansas REALTORS Association.
  - **Professional services:** Arkansas Society of CPAs, Arkansas Bar Association.
  - **Trucking:** Arkansas Trucking Association.
  - **Schools and ESA advocacy:** Arkansas nonpublic school accrediting associations, EFA advocacy groups, homeschool co-op networks.
- **Online communities:** r/Arkansas, r/LittleRock, r/fayetteville and Northwest Arkansas subreddits and Facebook groups; Arkansas EFA parent and provider Facebook groups (verify names).
- **Partners:**
  - **Business support:** Arkansas Small Business and Technology Development Center (ASBTDC, verify host), Northwest Arkansas Council, Startup Junkie (NWA) and the Venture Center (Little Rock) (verify).
  - **Banks:** community banks such as Arvest.
  - **Referrals:** EFA-participating private schools, which can refer our tutor and therapist customers.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School/public library-materials law | Act 372 (2023) changed library-material challenge procedures and criminal provisions. It was struck down in Dec 2024 (per the lead list; verify appeal status). | Struck Dec 2024 | R01 (weak), R07 |
| Science of reading / three-cueing law | Right to Read Act, a three-cueing ban, and an approved-curriculum mandate (per the lead list; verify bill numbers) | In force | P01, R08 |
| 3rd-grade reading plan / retention law | Mandatory-retention state under the LEARNS Act (per the lead list; verify thresholds) | In force | P02 |
| Homeschool rules (HSLDA tier: **low**) | One option. Notice is required. No testing, no state-mandated subjects, no teacher qualifications ([HSLDA AR](https://hslda.org/legal/arkansas)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **Education Freedom Accounts:** universal since 2025–26, with 46,578 students that year (see the laws table above). **$70M in reserves was approved on Sep 18 2026, raising the FY27 total to $379.4M** ([Arkansas Democrat-Gazette headline, Sep 18 2026](https://www.nwaonline.com/news/2026/sep/18/70-million-in-reserves-approved-for-arkansas/); article body not fetched). A tutoring-vendor guide gives the 2026–27 award as **$6,000**, with a hard **June 1** application deadline and quarterly ClassWallet deposits ([upistudy, Aug 23 2026](https://www.upistudy.com/blog/efa/arkansas-efa-2026-2027-new-funding-amount-and-the-june-1-deadline-you-cant-miss)). That conflicts with EdChoice's $6,694 average for 2025–26 (verify). Homeschool families are eligible (verify the separate rules). | FY27 now; next deadline Jun 1 2027 (verify) | P03, P04, P07, R05, R08 |
| Other | Arkansas's auto-renewal law took effect Aug 3 2025 (via R08). The Imagination Library is funded regionally, not statewide (for example, a $60,000 grant for NW Arkansas counties, per [KATV](https://katv.com/newsletter-daily/arkansas-imagination-library-gets-60000-grant-to-fund-dolly-parton-books-in-nwa-counties)). | — | R08, P06 |

**Top 3 reading/education ideas here:**
- **P07 LearnLedger:** a $379.4M FY27 EFA pool paid through a ClassWallet setup the state's own review called "fragmented", so families need their own receipt and balance ledger.
- **P03 HomeRoll:** it keeps homeschool EFA families' notices and records alongside their EFA spend.
- **P02 ReadingPlan Home:** it covers mandatory retention plus the three-cueing ban. Bench: P01 for tutors aligned to the approved-curriculum list.

**Where to sell:**
- **Libraries:** Arkansas Library Association (ArLA; conference, fall; verify) and the Arkansas Association of School Librarians (verify).
- **Parents:** Arkansas PTA and The Education Alliance, Arkansas's homeschool association (verify).
- **ESA:** EFA parent and provider Facebook groups.
- **Reading:** The Reading League Arkansas (verify).
- **Booksellers:** SIBA.

## Launch verdict
**Speed:** Medium.
- Arkansas is a small market overall.
- The EFA vendor pain is sharp, documented and state-specific right now.

**First city:** Little Rock, where the state agencies and the largest private-school base are. Northwest Arkansas (Bentonville–Rogers–Fayetteville) is second, for trades and growth.

**Lead offer:** F06 ESA Desk. The pitch: "Stop fighting ClassWallet: your EFA invoices, claims and family balances in one ledger, with free setup for the 2026–27 year." Upsell F07 to tutors and therapists.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Arkansas](https://advocacy.sba.gov/wp-content/uploads/2025/06/Arkansas_2025-State-Profile.pdf)
- [EdChoice: Arkansas Children's Educational Freedom Account Program (updated Dec 16 2025)](https://www.edchoice.org/school-choice/programs/arkansas-childrens-educational-freedom-account-program/)
- [EdChoice: Arkansas school choice overview](https://www.edchoice.org/school-choice/state/arkansas/)
- [Grand Canyon Times: Report finds ESA vendor ClassWallet "fragmented, inefficient and increasingly misaligned" (Jul 24 2026)](https://grandcanyontimes.com/report-finds-esa-vendor-classwallet-fragmented-inefficient-and-increasingly-misaligned)
- [LegiScan: AR HB 1717 (Act 952), Children and Teens' Online Privacy Protection Act](https://legiscan.com/AR/bill/HB1717/2025)
- [Insurance Information Institute: Facts + Statistics: Hail](https://www.iii.org/fact-statistic/facts-statistics-hail)
- Internal: ideas/A03, B04, C01, C02, F06, F07, J02, K03
- [HSLDA: Arkansas homeschool laws](https://hslda.org/legal/arkansas)
- [Arkansas Democrat-Gazette/NWA: $70 million in reserves approved for EFAs, FY27 total $379.4M (Sep 18 2026)](https://www.nwaonline.com/news/2026/sep/18/70-million-in-reserves-approved-for-arkansas/)
- [upistudy: Arkansas EFA 2026–2027 funding and June 1 deadline (Aug 23 2026)](https://www.upistudy.com/blog/efa/arkansas-efa-2026-2027-new-funding-amount-and-the-june-1-deadline-you-cant-miss)
- [KATV: Arkansas Imagination Library gets $60,000 grant for NWA counties](https://katv.com/newsletter-daily/arkansas-imagination-library-gets-60000-grant-to-fund-dolly-parton-books-in-nwa-counties)
