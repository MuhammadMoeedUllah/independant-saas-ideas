# California (CA): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 4.3 million small businesses, which is 99.8% of California businesses. They employ 7.6 million people, or 47.4% of the private workforce. About 3.50 million (3,502,950) have no employees, which leaves roughly 0.8 million small employers (our subtraction, an estimate). Small firms created 86,885 of the state's 87,185 net new jobs (99.7%) from March 2023 to March 2024 ([SBA Advocacy 2025 California profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/California_2025-State-Profile.pdf)).
- **New-business momentum:** From March 2023 to March 2024, small firms opened 132,020 establishments and closed 104,071, a net gain of about 28,000 (SBA profile above). Census Business Formation Statistics were not pulled in this pass. Two 2026 demand spikes are clear:
  - **Construction and restoration:** the January 2025 LA fires destroyed **16,264 structures** (Eaton 9,419, Palisades 6,845) and damaged 2,051 more ([CAL FIRE Eaton](https://www.fire.ca.gov/incidents/2025/1/7/eaton-fire), [CAL FIRE Palisades](https://www.fire.ca.gov/incidents/2025/1/7/palisades-fire)).
  - **Beauty:** the ABC-test exemption for manicurists came back on Jan 1 2026 and runs through Dec 31 2028, so booth-rental nail salons can re-form ([CA Labor Agency FAQ](https://www.labor.ca.gov/employmentstatus/faq/)).
- **Largest small-business employers:** Accommodation & food services is #1 with 1,110,793 employees, then health care & social assistance (1,013,023), professional/scientific/technical services (805,645), construction (703,903) and retail (599,194) (SBA profile).
- **Buyer clusters:**
  - **Los Angeles County:** restaurants and ghost kitchens; beauty, lash, nail and med-spa studios; independent used-car lots; small landlords under city rent control; entertainment services. Wildfire-rebuild contractors work in Altadena/Pasadena and Pacific Palisades/Malibu.
  - **Orange County:** med spas, dental and chiro practices, franchise home services, insurance agencies.
  - **Inland Empire (Riverside/San Bernardino):** trucking and warehousing, new-home trades, HVAC/solar, used-car lots.
  - **San Diego:** tours and attractions, craft breweries, home services, military-adjacent contractors, therapy practices.
  - **Bay Area (SF/Oakland/San Jose):** independent restaurants (SF delivery-fee cap), professional services, rent-controlled landlords, law and CPA firms.
  - **Sacramento:** state-association headquarters, lobbying and consulting firms, home services.
  - **Central Valley (Fresno/Bakersfield/Stockton):** agriculture services, farm labor contractors, pest-control and ag applicators, trucking.
  - **Wine Country (Napa/Sonoma/Paso Robles):** wineries (DTC shipping), boutique lodging, tours.
  - **Emerald Triangle (Humboldt/Mendocino/Trinity):** craft cannabis cultivators under Metrc.
- **Industries overweight vs. US** (qualitative estimate; not benchmarked against national shares in this pass):
  - Restaurants and food service.
  - Beauty and personal care (salons, booth renters, med spas).
  - Residential construction, remodeling and fire rebuild.
  - Used-car retail.
  - Entertainment and creative services.
  - Agriculture, wine and cannabis.
  - Logistics and trucking (Inland Empire, Central Valley).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **SB 766 "CARS Act."** A 3-day return right on used cars priced at $50k or less, all-in "total price" in ads and first contact, add-on bans, cash and lease precontract disclosures, 2-year record retention (per [CA Dealer Academy](https://www.californiadealeracademy.com/articles/cars-act-sb-766-major-changes-coming-october-1-2026), cited in K02) | Every licensed CA retail dealer of light-duty vehicles, including independents and buy-here-pay-here lots | **Oct 1 2026**, one week away. The first enforcement and audit wave follows in Q4 2026 | K02 DealJacket |
| **Home-improvement contract rules applied to disaster rebuilds.** A fixed-price contract is required. The down payment may be no more than $1,000 or 10% of the contract price, whichever is less. Progress payments may never exceed the value of work completed. LA County treats a post-disaster rebuild as a "home improvement project" ([LA County Recovery](https://recovery.lacounty.gov/rebuilding/licensed-contractors-and-industry-professionals-list/)) | Every residential remodeler and rebuild contractor. It matters most for the 16,264 structures destroyed in the Jan 2025 Eaton and Palisades fires (CAL FIRE; structures, not lots) | In force now. Rebuild peak is 2026–2028 | **S8-01 RebuildLedger**, C05 FlatBuild, A04 SignFlat, C01 FlatRate |
| **CoConstruct sunset.** No new projects after Mar 31 2027 ([CoConstruct](https://www.coconstruct.com/migration)) | CA remodelers and custom builders on CoConstruct | **Mar 31 2027** | C05, S8-01 |
| **20-day preliminary notice** for mechanics' lien rights (Civil Code §8200 et seq., verify) | Subcontractors, suppliers, equipment rental firms | On every job | C06 LienClock |
| **SB 478 Honest Pricing Law.** Advertised prices must include all mandatory fees. Under **SB 1524**, restaurant fees are allowed only if "clearly and conspicuously displayed" ([CA AG](https://oag.ca.gov/hiddenfees)) | Hotels, short-term rentals, tours, ticketing, restaurants, delivery | In force since Jul 1 2024. AG enforcement is ongoing | D07 BookTrail, H03 StayDesk, I04 DoorList, D02 DirectPlate, D03 TableKeep, D05 InnDesk, D06 SiteLoop |
| **CCPA regulation update (ADMT, risk assessments, cybersecurity audits).** Approved by OAL Sep 22 2025, effective Jan 1 2026 ([CPPA](https://cppa.ca.gov/regulations/ccpa_updates.html)). Phased dates: ADMT compliance Jan 1 2027, then risk-assessment and audit filings from 2028 (verify) | Only CCPA-covered businesses (revenue above roughly $26.6M, or large data volumes; verify). Most SMBs are exempt, but their vendors get questionnaires | Jan 1 2026 / Jan 1 2027 (verify) | J02 SiteShield |
| **CIPA wiretap/pixel demand letters and Unruh Act ADA website suits** (state court, statutory damages; background knowledge, verify) | Any SMB website with chat widgets, session replay, tracking pixels, or accessibility gaps | Ongoing | J02 SiteShield |
| **Automatic Renewal Law amendments (AB 2863).** Online click-to-cancel, annual reminders, consent to price changes, limits on "save" offers (verify; leginfo blocked our fetch). Consumer contracts only; B2B SaaS is not covered | Gyms, studios, car-wash clubs, dental membership plans, subscription boxes | In force since Jul 1 2025 (verify) | F02 OpenStudio, K06 WashClub, E03 Bitewing, B01 ListFair |
| **SB 553 workplace violence prevention (Labor Code §6401.9).** A written plan, a violent-incident log kept 5 years, and training records kept 1 year. **Cal/OSHA's Standards Board must adopt the general-industry standard by Dec 31 2026** ([Cal/OSHA](https://www.dir.ca.gov/dosh/Workplace-Violence/General-Industry.html)) | Nearly all employers. Small-site exemptions exist (verify: fewer than 10 employees and not open to the public) | In force since Jul 1 2024. New standard by **Dec 31 2026** | J03 PostedUp |
| **SB 294 "Workplace Know Your Rights" notice**, plus emergency-contact designation (verify) | All employers | First notice Feb 1 2026, then annually (verify) | J03 PostedUp, G04 StatePay |
| **Pay transparency amendment (SB 642).** "Pay scale" now means a good-faith estimate of the expected hiring range (J03, citing Hunton) | Employers with 15+ employees that post jobs | **Jan 1 2026** | J03 PostedUp, G07 BenchBoard |
| **SB 351.** Bars PE and management companies from controlling clinical decisions and requires physician-directed orders (per E04/Decoda; verify statute) | Med spas, IV lounges, dental/derm practices backed by MSOs | Jan 1 2026 | E04 Glowchart |
| **CTAPP.** The State Bar requires trust-account registration (Dec 31 balances) and a self-assessment ([State Bar CTAPP](https://www.calbar.ca.gov/Attorneys/Conduct-Discipline/Client-Trust-Accounting-IOLTA/Client-Trust-Account-Protection-Program)) | Every licensed CA lawyer | Annually by **Feb 1** (initial deadline was Feb 1 2024). Next due Feb 1 2027 (verify date) | G01 LawLedger |
| **AB 12 security-deposit cap.** Most landlords may charge "up to one month's rent" ([CA AG](https://oag.ca.gov/consumers/general/landlord-tenant-issues)). AB 1482 caps rent increases at 5% + CPI, maximum 10%. AB 2801 requires move-in/move-out photos (verify) | Small landlords. A small-landlord deposit exception exists (verify) | Deposit cap since Jul 1 2024. Photos 2025 (verify) | H01 DoorLedger |
| **Labor Code §2778 booth-renter carve-out from the ABC test.** Covers licensed barbers, cosmetologists, estheticians and electrologists. **Manicurists are covered Jan 1 2026–Dec 31 2028** ([CA Labor Agency FAQ](https://www.labor.ca.gov/employmentstatus/faq/)). The renter must set their own rates, process their own payments and keep their own book (verify) | Salon and suite owners, nail salons, booth renters | Now through Dec 31 2028 | F01 Chairly |
| **Healthy Schools Act school-site pesticide use reporting** to DPR (verify) | Licensed pest-control operators serving schools and childcare centers | Ongoing, annual (verify) | C03 SprayLog |
| **$800 minimum franchise tax**, due the 15th day of the 4th month (verify) | Every LLC, LP and corporation | Apr 15 each year | J06 LicenseLedger |
| **Cannabis excise tax.** Now "15 percent of gross receipts" ([CDTFA](https://www.cdtfa.ca.gov/industry/cannabis.htm)). It rose to 19% Jul 1 2025, then AB 564 rolled it back to 15% from Oct 1 2025 (verify). Price collapse and distress continue (background) | Dispensaries, distributors, cultivators on Metrc | Ongoing | J04 TagTrue |
| **Child-care subsidy freeze and proof-of-spend.** Axios reported California among 5 frozen states in Jan 2026 (per F05) | Subsidy-funded centers and family child-care homes | Jan 2026 onward | F05 RollCall |
| **Wildfire claim timelines.** 36 months to collect replacement cost after a state-of-emergency loss (Ins. Code §2051.5, verify). ALE extensions (verify) | Rebuild homeowners, their contractors, restoration firms, public adjusters | 2025–2028 | S8-01, C07 ClaimKit, G05 AgencyLite |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture for trades) | California has the most construction and home-service employers of any state. Google LSA disputes and the Guarantee are gone (Nov 2025), and Angi has exit fees. Fire rebuild adds a flood of inbound leads that contractors are losing to missed calls. CA is an all-party call-recording-consent state (Penal Code §632, verify), so a built-in consent script is a selling point over generic call tools. |
| 2 | C05 | FlatBuild (Buildertrend/CoConstruct replacement) | A hard sunset (Mar 31 2027) collides with LA's rebuild boom. Pitch a "California edition": contracts with the $1,000-or-10% down-payment cap and a guard that keeps progress payments at or below work completed. Rebuild contractors must prove both. |
| 3 | F01 | Chairly (salon/barber booking) | California has the most licensed beauty pros and the most booth-rental salons (estimate). The manicurist ABC-test exemption returned Jan 1 2026, but it only protects renters who process their own payments and keep their own book. Chairly's per-renter calendars with each renter's own processor fit that exactly, and Fresha/Vagaro commissions make the switch easy to sell. |
| 4 | K02 | DealJacket (CARS Act deal jacket) | A California-only law in force **Oct 1 2026**. Independents in LA, the Inland Empire and the Central Valley are improvising on paper right now. Sell a "first-90-days audit" (3-day return log, total-price ad check, signage and disclosure capture) through Q4. |
| 5 | A03 | LocalLoop (Podium/Birdeye alternative) | Huge local-service base in LA, OC and San Diego. Podium sells heavily into CA. Text-to-pay plus reviews at $79/mo against 12-month auto-renewing contracts. Note: the CA ARL protects consumers, not B2B buyers, so sell on price and our renewal-date tracker, not on a legal exit. |
| 6 | J02 | SiteShield (privacy + accessibility compliance) | California is where SMB websites get sued in state court: CIPA pixel/chat "wiretap" letters and Unruh Act accessibility claims (verify volumes). The ADMT regulations drive vendor questionnaires. A flat per-site product that removes risky trackers and fixes code (not an overlay) sells on fear. |
| 7 | J03 | PostedUp (posters + employment-law feed) | California is the densest employment-law state. The SB 294 notice (annual, Feb 1), a new Cal/OSHA workplace-violence standard (**adopted by Dec 31 2026**), the SB 642 pay-scale redefinition (Jan 1 2026) and local minimum wages across dozens of cities make a $9/location CA feed plus a workplace-violence plan builder an easy yes. |

*Just outside the Top 7:* **G01 LawLedger** (CTAPP by Feb 1, the country's second-largest bar), **H01 DoorLedger** (AB 12, AB 1482, LA/SF/Oakland rent control), **E04 Glowchart** (SB 351; LA/OC med-spa density), **D07 BookTrail** (SB 478 all-in pricing kills guest booking fees).

## State-only opportunities
1. **RebuildLedger: fire-rebuild contracts, draws and permits for LA contractors** (full file: `ideas/S8-01-rebuildledger-ca-fire-rebuild-contract-draw-compliance.md`, 19/25). 16,264 structures were destroyed. LA County tells rebuild homeowners to demand fixed-price contracts, a down payment of $1,000 or 10% at most, and progress payments that never exceed work done. Lenders and insurers release rebuild funds in draws that need documentation. Contractors who can prove compliance win jobs. It expands into a statewide "CA-compliant home-improvement contract" product and a Maui/Lahaina edition.
2. **Cal/OSHA workplace-violence plan kit** (fold into J03 as a CA module, not a separate file). It covers the written plan, the violent-incident log (kept 5 years), training records (kept 1 year) and annual SB 294 notice delivery. The Standards Board's general-industry standard (due by Dec 31 2026) will force plans to be rewritten in 2027. It is cheap to build, and every CA employer with 10+ staff is a prospect.
3. **Booth-renter compliance pack for salons** (fold into F01). For each renter it keeps records showing they set their own rates, run their own processor account and keep their own client book, plus a lease and rent ledger. This is the paper trail salon owners need to keep renters outside the ABC test while the manicurist carve-out runs through 2028.

## Where to sell
- **Associations & events:**
  - **Construction:** CSLB-licensed contractor lists by county. The LA County "Licensed Contractors and Industry Professionals List" is a ready outreach list for rebuild. Also BIA of Southern California (LA/Ventura chapter), NARI chapters (San Diego, Los Angeles, Silicon Valley; verify), and CBIA.
  - **Hospitality and dealers:** California Restaurant Association, California Hotel & Lodging Association, Independent Automobile Dealers Association of California (verify name) for K02.
  - **Property and professional:** California Apartment Association (H01), California Association of REALTORS, CalCPA (G03), California Lawyers Association and county bars such as the LA County Bar (G01), California Dental Association's CDA Presents (spring Anaheim, late-summer SF; verify dates).
  - **Trades and beauty:** Pest Control Operators of California (C03), California Landscape Contractors Association, ISSE Long Beach salon show (Jan; verify) for F01.
  - **Other:** Wine Institute (J05), California Cannabis Industry Association (J04), CalChamber (HR compliance buyers; also a competitor for J03).
- **Online communities:** r/LosAngeles, r/Pasadena, r/Altadena and r/Palisades (rebuild threads; verify subreddit names), r/bayarea, r/sanfrancisco, r/sandiego, r/InlandEmpire, r/Sacramento, r/smallbusiness. Fire-survivor Facebook groups for Eaton/Altadena and Palisades (verify names). Nextdoor in rebuild zones. Also Facebook groups for CA salon-suite owners, CA independent auto dealers and CA landlords.
- **Partners:**
  - California SBDC network, especially the LA Regional SBDC for fire-recovery clients.
  - LA County Department of Economic Opportunity recovery programs, and the Pasadena, Altadena and Palisades chambers.
  - CDFIs such as Pacific Community Ventures (verify).
  - Credit unions (Golden 1, SchoolsFirst; verify for SMB programs).
  - Supply houses serving rebuilds (Ferguson, lumberyards), restoration firms and public adjusters (C07 tie-in).
  - Bookkeepers who serve contractors, salon suites and dealerships.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| Freedom-to-read law: **AB 1078 (2023) and AB 1825 (2024)** | Written collection-development policies. Removals on partisan or doctrinal grounds are barred, and librarians get stronger protections. Applies to school and public libraries ([American Libraries, Jun 2 2025](https://americanlibrariesmagazine.org/2025/06/02/banning-the-book-bans/)). | In force | R01 (policy and reconsideration log), R07 |
| Science-of-reading law: **AB 1454** (signed Oct 9 2025) | Elementary teachers must be trained in evidence-based reading instruction. The State Board of Education must adopt evidence-based literacy materials **by January 2027**, and districts that deviate must certify their materials are aligned. K–2 reading-difficulty (including dyslexia) screening began in 2025–26. The 2025–26 budget carried **$480M** for literacy, including $200M one-time for teacher training ([EdSource](https://edsource.org/2025/governor-newsom-signs-literacy-bill/742396)). | Materials adoption Jan 2027 | P01, R08, P06 |
| 3rd-grade reading plan / retention law | No retention mandate on the lead lists (verify). K–2 screening (above) drives parent notices instead. | — | P02 (weak) |
| Homeschool rules (HSLDA tier: **low**) | Three options (private-school affidavit, credentialed private tutor, and one more; verify details). Notice is required and subjects are mandated. No testing; teacher qualifications apply only under option 3 ([HSLDA CA](https://hslda.org/legal/california)). | Affidavit filed each fall (verify window) | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **No state ESA.** AB 19 is pending and could only take effect after 2027–28 with voter approval (verify). **Independent-study (homeschool) charter schools** give families educational funds of about **$2,200–$2,800 (elementary), $2,600–$3,200 (middle) and $2,800–$3,800 (high school)** a year. The money is spent through approved-vendor portals on curriculum, books, online subscriptions, tutoring and classes; religious materials are excluded ([Numa CA funding guide, Jul 30 2026](https://numaschool.com/states/california/homeschool-funding); secondary source, verify ranges). | Each school year | P04, P07, R05, R08 |
| Other | **529:** CA does not conform to federal K–12 529 treatment and adds a **2.5% penalty** on non-qualified withdrawals (via P03/P07, Savingforcollege Jan 5 2026). **Auto-renewal:** AB 2863, in force Jul 1 2025 (via R08). **Imagination Library:** the 2022 budget set aside $70M for reading, part of it for the Imagination Library. The program has served more than 160,000 CA children and nearly 3M books. At an Apr 7 2026 Senate hearing, lawmakers questioned the State Library after its Strong Reader Partnership spent over $1M without distributing books; 90% of funds now go straight to the Dollywood Foundation ([Times of San Diego, Apr 14 2026](https://timesofsandiego.com/education/2026/04/14/california-funding-dolly-parton-library/)). | 2025–2026 | P07, R08, P06 |

**Top 3 reading/education ideas here:**
- **P01 PhonicsPrep:** AB 1454 teacher training, a $480M budget, the Jan 2027 materials adoption and K–2 screening create demand for structured-literacy tutor tools. LA tutor rates run $185/hr (per P01).
- **P04 ClassHouse:** thousands of independent teachers want to become approved vendors across many homeschool charters, which fund $2.2k–$3.8k per student a year.
- **P07 LearnLedger:** CA's 529 non-conformity plus the 2.5% penalty, and splitting spend across charter funds and 529 money, is the costliest mistake a family can make.
- **Bench:** R08 (AB 2863 honest billing) and R01 (AB 1078/1825 policy documentation).

**Where to sell:**
- **Libraries:** California Library Association (annual conference, fall; verify) and the California School Library Association (CSLA; conference, winter; verify).
- **Parents:** California State PTA (convention, spring; verify), plus the California Homeschool Network and CHEA of California (verify convention dates).
- **Charters:** homeschool charter vendor departments.
- **Reading:** IDA Northern and Southern California branches, and The Reading League California (verify).
- **Booksellers:** CALIBA, the California Independent Booksellers Alliance (successor to NCIBA/SCIBA; verify).

## Launch verdict
**Speed:** Fast. It is the largest SMB pool in the US, with the most law-driven deadlines, three of them landing in the next six months: CARS Act Oct 1 2026, Cal/OSHA workplace-violence standard by Dec 31 2026, CTAPP/SB 294 by Feb 1 2027. **First city:** Los Angeles (rebuild zones in Altadena/Pasadena and the Palisades, plus the densest salon and used-car-lot base). **Lead offer:** FlatBuild "California Rebuild Edition" (S8-01 RebuildLedger as the wedge). Free CoConstruct/Buildertrend import, CA-compliant fixed-price contracts with automatic down-payment and progress-payment guards, and a free homeowner portal, sold alongside FirstCall's missed-call text-back. In parallel, run a quick-cash sprint on K02 DealJacket for the Oct 1 CARS Act deadline.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, California (Jun 2025)](https://advocacy.sba.gov/wp-content/uploads/2025/06/California_2025-State-Profile.pdf)
- [CAL FIRE: Eaton Fire incident page](https://www.fire.ca.gov/incidents/2025/1/7/eaton-fire)
- [CAL FIRE: Palisades Fire incident page](https://www.fire.ca.gov/incidents/2025/1/7/palisades-fire)
- [LA County Recovery: Licensed contractors list and "Important Contract and Payment Rules" for 2025 rebuilds](https://recovery.lacounty.gov/rebuilding/licensed-contractors-and-industry-professionals-list/)
- [LA County Recovery: Permitting progress dashboard](https://recovery.lacounty.gov/rebuilding/permitting-progress-dashboard/)
- [CA Attorney General: Honest Pricing Law (SB 478) and SB 1524](https://oag.ca.gov/hiddenfees)
- [CA Attorney General: Landlord-tenant issues (deposit cap, rent cap)](https://oag.ca.gov/consumers/general/landlord-tenant-issues)
- [CPPA: CCPA updates, cybersecurity audits, risk assessments, ADMT regulations (approved Sep 22 2025, effective Jan 1 2026)](https://cppa.ca.gov/regulations/ccpa_updates.html)
- [Cal/OSHA: Workplace violence prevention in general industry (SB 553)](https://www.dir.ca.gov/dosh/Workplace-Violence/General-Industry.html)
- [State Bar of California: Client Trust Account Protection Program](https://www.calbar.ca.gov/Attorneys/Conduct-Discipline/Client-Trust-Accounting-IOLTA/Client-Trust-Account-Protection-Program)
- [CA Labor & Workforce Development Agency: Employment status FAQ (ABC test exemptions; manicurists 2026–2028)](https://www.labor.ca.gov/employmentstatus/faq/)
- [CDTFA: Cannabis tax guide](https://www.cdtfa.ca.gov/industry/cannabis.htm)
- [California Dealer Academy: CARS Act SB 766 changes Oct 1 2026 (via K02)](https://www.californiadealeracademy.com/articles/cars-act-sb-766-major-changes-coming-october-1-2026)
- [CoConstruct: migration page (new projects through Mar 31 2027) (via C05)](https://www.coconstruct.com/migration)
- Internal: `_scoreboard.csv`, `_state_leads_from_category_research.md`, ideas B04, C05, F01, K02, A03, J02, J03, E04, F05, G01, H01.
- [EdSource: Newsom signs literacy bill AB 1454 (Oct 2025)](https://edsource.org/2025/governor-newsom-signs-literacy-bill/742396)
- [American Libraries: Banning the book bans (Jun 2 2025)](https://americanlibrariesmagazine.org/2025/06/02/banning-the-book-bans/)
- [HSLDA: California homeschool laws](https://hslda.org/legal/california)
- [Numa: California homeschool funding options (Jul 30 2026)](https://numaschool.com/states/california/homeschool-funding)
- [Times of San Diego: How California bungled $1 million in a collaboration with Dolly Parton's Imagination Library (Apr 14 2026)](https://timesofsandiego.com/education/2026/04/14/california-funding-dolly-parton-library/)

## Verification (Sep 24 2026)
- ✅ SB 766 CARS Act takes effect Oct 1 2026 (the quick-cash hook). It gives a 3-day cancel right on used vehicles priced at $50,000 or less (lost after 400 miles; restocking fee 1.5% of price, min $200, max $600), total-price advertising, named add-on bans and 2-year record retention. Source is a dealer-training site, not an official page ([CA Dealer Academy](https://www.californiadealeracademy.com/articles/cars-act-sb-766-major-changes-coming-october-1-2026))
- ✅ Rebuild rules: LA County says a disaster rebuild is a "home improvement project" and requires a fixed-price contract, a down payment of no more than $1,000 or 10%, "whichever amount is smaller", and progress payments no larger than work completed. ADUs and solar are covered too ([LA County Recovery](https://recovery.lacounty.gov/rebuilding/licensed-contractors-and-industry-professionals-list/))
- ✅ Fire scale: 9,419 structures destroyed in Eaton and 6,845 in Palisades, 16,264 in total. The "16k lots" wording was changed to "structures" ([CAL FIRE Eaton](https://www.fire.ca.gov/incidents/2025/1/7/eaton-fire); [CAL FIRE Palisades](https://www.fire.ca.gov/incidents/2025/1/7/palisades-fire))
- ✅ CoConstruct: "Projects can still be added through March 31, 2027." No final read-only date is given ([CoConstruct](https://www.coconstruct.com/migration))
- ✅ SB 553: a written plan, a violent-incident log kept 5 years, training records kept 1 year, enforceable since Jul 1 2024. "OSHSB is required to adopt the standard no later than December 31, 2026." The page does not mention the small-site exemption, so it stays (verify) ([Cal/OSHA](https://www.dir.ca.gov/dosh/Workplace-Violence/General-Industry.html))
- ⚠️ CCPA/ADMT regulations: OAL approval Sep 22 2025 and the Jan 1 2026 effective date are confirmed. The phased ADMT (2027) and audit/risk-assessment (2028+) dates are not on the CPPA landing page and still need checking ([CPPA](https://cppa.ca.gov/regulations/ccpa_updates.html))
