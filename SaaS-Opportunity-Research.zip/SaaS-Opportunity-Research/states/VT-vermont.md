# Vermont (VT): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 81,949 small businesses, 99.0% of VT businesses, employing 157,959 people. That's **62.1% of VT employees**, among the highest small-business shares in the US. ([SBA Advocacy 2025 VT profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Vermont_2025-State-Profile.pdf))
- **New-business momentum:** From Mar 2023 to Mar 2024, 3,552 establishments opened and 3,020 closed (net +532). Small businesses had 3,388 openings and 2,905 closings and produced **96.1%** of net new jobs. ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Vermont_2025-State-Profile.pdf))
- **Buyer clusters:**
  - **Burlington and Chittenden County:** restaurants, professional services, small tech.
  - **Ski towns (Stowe, Killington, Mad River, Okemo, Stratton):** lodging, short-term rentals, ski-season restaurants.
  - **Southern VT (Manchester, Brattleboro, Woodstock):** second homes, inns, weddings.
  - **Rutland and the Northeast Kingdom:** rural trades, forestry, heating fuel.

  These clusters are an estimate.
- **Industries overweight vs. US:**
  - By small-business count, professional services (11,897), **construction (11,642)** and real estate and rental (7,337) lead. By employment, health care (25,218), accommodation and food (20,690) and retail (20,519) lead ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Vermont_2025-State-Profile.pdf)).
  - Also overweight (estimate): craft beverage, dairy and maple, ski tourism.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **VT AG settlement with Angi,** Oct 13 2025, over misleading marketing on its contractor platform. Angi paid **$100,000** ([VT AG press releases](https://ago.vermont.gov/blog/category/press-releases?page=6); release: [Oct 13 2025](https://ago.vermont.gov/blog/2025/10/13/attorney-general-clark-settles-dispute-angi-over-misleading-marketing-practice)). Per category research, Angi also agreed to stop using "Angi Certified Pro" and to point users to VT's contractor registry | Contractors buying Angi leads, and homeowners | Settled; PR hook | B04 |
| **Residential contractor registration:** register with the Office of Professional Regulation, use written contracts and carry insurance for jobs of **$10,000+**. The AG took enforcement action against unregistered contractors on May 15 2026, and one had been fined $500 in 2025 ([VT AG](https://ago.vermont.gov/blog/2026/05/15/attorney-general-clark-takes-enforcement-action-against-unregistered-residential-contractors)) | Remodelers, roofers, HVAC, builders | In force; active enforcement | A04, C05, B04 |
| **VT Data Privacy and Online Surveillance Act** (S.71, Act 145 of 2026), effective **Jan 1 2028**. It applies at 35,000 consumers, **sensitive data of 3,000 consumers**, or the sale of data of 3,000 consumers. There's no private right of action. The AG must give a 60-day cure notice from Jan 2028 to Jun 2029 ([VT Legislature bill status](https://legislature.vermont.gov/bill/status/2026/S.71), [Act 145 text](https://legislature.vermont.gov/Documents/2026/Docs/ACTS/ACT145/ACT145%20As%20Enacted.pdf)) | Clinics, wellness, e-commerce, anyone with health or sensitive data. The 3,000 threshold is low | Jan 1 2028 (sell readiness in 2027) | J02 |
| Pay transparency: pay ranges in postings from Jul 1 2025, for employers with 5+ employees, including remote roles that report to a VT office (J03 category research) | Employers hiring | In force | J03, G07 |
| Child Care Contribution (Act 76) payroll tax, 0.44% since Jul 1 2024 (verify) | All employers | Ongoing | G04 |
| Meals and rooms tax plus a short-term-rental surcharge (verify rate and date) | STR hosts and inns | Ongoing | H03, D05 |
| Sales tax nexus: $100k or 200 transactions (verify) | Remote sellers | Ongoing | J01 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall | The VT AG settled with Angi (Oct 2025), and it's actively enforcing contractor registration (May 2026). Pitch: "own your leads, show your OPR registration, stop paying Angi." |
| 2 | A04 | SignFlat | Jobs of $10k+ legally require a written contract, which makes a VT-compliant residential contract template with e-sign and deposit capture an easy entry product. |
| 3 | H03 | StayDesk | Ski-town and second-home STR density, plus Airbnb's 15.5% host-only fee for PMS-connected hosts (Oct 2025). |
| 4 | C05 | FlatBuild | Small custom builders and remodelers on CoConstruct, which stops new projects Mar 31 2027 and forces a migration. |
| 5 | J03 | PostedUp | Pay transparency reaches down to **5 employees**, much lower than most states. |
| 6 | D07 | BookTrail | Foliage, ski-school, farm and brewery tours, with FareHarbor's 6% guest fee. |
| 7 | C01 | FlatRate | Heating-fuel dealers and heat-pump installers across rural VT (see the ME file for the heating-oil thesis). |

## State-only opportunities
1. **"Registered-contractor trust page."** A B04 feature that shows OPR registration, insurance and a compliant written contract, marketed with the Angi settlement and the 2026 enforcement. This is the best PR test bed for B04 in the US: small, press-friendly, and a pro-consumer AG. No separate file, since it's a B04/A04 feature bundle.
2. **Early sensitive-data readiness (Act 145, 3,000-consumer threshold).** Vermont's 3,000-consumer sensitive-data trigger is unusually low, so wellness practices will be pulled in on Jan 1 2028. Sell J02 readiness in 2027.

## Where to sell
- **Associations & events:**
  - Hospitality: Vermont Chamber of Commerce (includes hospitality and tourism), Vermont Ski Areas Association.
  - Construction and trades: Home Builders & Remodelers Association of Northern VT, Vermont Fuel Dealers Association (verify).
  - Professional services: VT Society of CPAs, Vermont Bar Association.
  - Other: Vermont Realtors, Vermont Businesses for Social Responsibility, Vermont Brewers Association (verify), Vermont Specialty Food Association.
- **Online communities:** r/vermont, r/burlington, r/smallbusiness, and Front Porch Forum (VT's hyper-local neighborhood lists, where contractors are heavily discussed). Also Facebook groups for VT STR hosts and contractors (search by name).
- **Partners:** VT SBDC, Lake Champlain Regional Chamber, local credit unions (VSECU/Vermont Federal, verify), CPA firms, building-supply yards.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| Freedom-to-read law | R01 lists **S.220 (2024)** and R07 lists VT among the 2025 freedom-to-read states. Neither the bill number nor its requirements were confirmed (verify). | 2024 (verify) | R01 |
| Science-of-reading / three-cueing law | Act 28 (2023) on evidence-based literacy comes from background knowledge (verify). A three-cueing ban was not confirmed. | n/a | P01 |
| 3rd-grade reading plan / retention law | **None** ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)) | n/a | P02 (none) |
| Homeschool (FreedomRankings/P03: **high**) | Notice, testing and subjects are all required, with "comprehensive documentation requirements" ([FreedomRankings, Sep 2026](https://freedomrankings.com/learn/homeschool-laws-by-state)). The annual enrollment notice and end-of-year assessment (16 V.S.A. §166b) come from background knowledge (verify). Vermont had the **second-fastest homeschool growth** in 2024–25 at **+17%** (JHU, via P03). | Yearly | P03 |
| ESA / scholarship money | No ESA. Vermont's town-tuitioning system is from background knowledge (verify). **Vermont doesn't conform** to the federal K–12 529 expansion ([Savingforcollege, Jan 2026, via P03/P07](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)). | 2027 tax season | P07 |
| Other | Statewide Imagination Library funding (verify) | n/a | P06 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll.** High regulation plus +17% growth makes this the best filing-pain market in New England after MA.
- **P07 LearnLedger.** Vermont's 529 non-conformity means a withdrawal that's tax-free federally can still hit the state return, so families need a warning before they withdraw.
- **R01 ClearShelf.** A freedom-to-read policy pack (once the statute is verified).

**Where to sell** (names from background knowledge; verify months):
- Vermont Library Association and Vermont School Library Association.
- Vermont PTA.
- Vermont homeschool networks (verify names).
- IDA New England branch (verify).
- New England Independent Booksellers Association (NEIBA).

## Launch verdict
**Speed:** Slow as a revenue market, because it's tiny. It's fast as a PR and proof market for B04. **First city:** Burlington. **Lead offer:** B04 FirstCall "Leave Angi" pack: an owned lead page with the OPR registration badge and a $10k+ written-contract template (A04), marketed off the AG's Angi settlement and 2026 contractor enforcement.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Vermont](https://advocacy.sba.gov/wp-content/uploads/2025/06/Vermont_2025-State-Profile.pdf)
- [VT AG: Settles dispute with Angi over misleading marketing (Oct 13 2025)](https://ago.vermont.gov/blog/2025/10/13/attorney-general-clark-settles-dispute-angi-over-misleading-marketing-practice)
- [VT AG press releases, Aug–Oct 2025 listing](https://ago.vermont.gov/blog/category/press-releases?page=6)
- [VT AG: Enforcement against unregistered residential contractors (May 15 2026)](https://ago.vermont.gov/blog/2026/05/15/attorney-general-clark-takes-enforcement-action-against-unregistered-residential-contractors)
- [VT Legislature: S.71 status (Act 145)](https://legislature.vermont.gov/bill/status/2026/S.71)
- [VT Act 145 as enacted](https://legislature.vermont.gov/Documents/2026/Docs/ACTS/ACT145/ACT145%20As%20Enacted.pdf)
- [FreedomRankings: homeschool laws by state (Sep 13 2026)](https://freedomrankings.com/learn/homeschool-laws-by-state)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [Savingforcollege: states that do not conform to federal 529 law (Jan 5 2026), via P03/P07](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)
- Internal (education): ideas R01, R07, P03, P07
