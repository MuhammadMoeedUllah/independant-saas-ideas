# Michigan (MI): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 983,079 small businesses (99.6% of Michigan businesses). They employ 1.9 million people, or 47.7% of Michigan employees ([SBA Advocacy 2025 Michigan profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Michigan_2025-State-Profile.pdf); counts use 2022 data).
- **New-business momentum:** Modestly positive.
  - From March 2023 to March 2024, 25,756 establishments opened and 24,412 closed, a net gain of 1,344. Small businesses accounted for 24,975 of the openings.
  - Small businesses added a net 27,947 jobs (265,544 gained, 237,597 lost).
  - All figures are from the same SBA profile. Business-application trend data was not pulled.
- **Buyer clusters** (metro detail is an estimate):
  - **Metro Detroit:**
    - Auto suppliers and tool-and-die shops.
    - Independent auto repair, dental practices and home-care agencies.
    - Arab-American and Chaldean-owned restaurants, markets and party stores (Dearborn, Sterling Heights).
  - **Grand Rapids:** construction, health care, furniture and office manufacturing, breweries.
  - **Ann Arbor and Lansing:** restaurants, associations, insurance, state government.
  - **Traverse City and northern Lower Michigan:** tourism, wineries, golf, campgrounds and marinas.
  - **Upper Peninsula:** seasonal lodging and snowmobile tourism.
- **Industries overweight vs. US:**
  - **Other services** (auto repair, personal care, repair shops) is Michigan's #1 small-business category, with 122,577 firms (SBA).
  - **Manufacturing:** 256,182 small-business employees (SBA).
  - **Health care:** 270,839 small-business employees (SBA).
  - **Accommodation and food:** 241,634 small-business employees (SBA).
  - **Construction:** 105,786 firms (SBA).
  - **Adult-use cannabis:** one of the largest independent markets, on Metrc (J04). Outdoor recreation: golf, campgrounds and marinas (D06, D08).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Minimum wage (SB 8):** the wage rises in steps to $15. It is **$13.73 from Jan 1 2026** and **$15.00 from Jan 1 2027** ([MI LEO](https://www.michigan.gov/leo/bureaus-agencies/ber/wage-and-hour/min-wage)). The tipped wage keeps a tip credit that shrinks each year, reaching 50% of minimum wage by 2031 (verify schedule) | Every hourly employer; restaurants hardest | **Next jump Jan 1 2027** | D04, G04, J03 |
| **Earned Sick Time Act (ESTA)**, effective Feb 21 2025. Small employers can cap sick time at 40 hours, larger ones at 72 hours ([MI LEO](https://www.michigan.gov/leo/bureaus-agencies/ber/wage-and-hour/paid-medical-leave-act)). Accrual is 1 hour per 30 worked, and employers with 10 or fewer employees had to comply by Oct 1 2025 (verify) | All employers | In force; first full year of small-employer accruals in 2026 | G04, D04, J03 |
| **Medicaid EVV:** open model with HHAeXchange as state aggregator; deadline 10/28/2022; compliance 85% ([HHAeXchange](https://www.hhaexchange.com/state-evv-status)) | Home-care and Home Help agencies | In force | E07 |
| **Adult-use cannabis on Metrc** (J04). A new 24% wholesale marijuana excise tax was reported for Jan 1 2026 (verify) | Growers, processors, dispensaries | Jan 1 2026 (verify) | J04 |
| **Motor Vehicle Service and Repair Act:** written estimates, customer authorization and certified mechanics (verify) | Independent auto repair shops | In force | K01 |
| **Construction Lien Act:** notice of furnishing within 20 days of first work (verify) | Subs and suppliers | Ongoing | C06 |
| **Camp licensing** (MI listed among licensing states in the I06 leads) | Day and resident camps | Annual | I06 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | D04 | ShiftTip | Every restaurant must re-do labor budgets before the **Jan 1 2027 $15.00** jump. The tip credit keeps shrinking, and ESTA accruals now apply to small employers too. A "Michigan wage and ESTA pack" is an easy card purchase for the small food-service businesses that employ 241,634 people. |
| 2 | B04 | FirstCall | This idea tops the scoreboard (23). Michigan has 105,786 construction firms, and fall furnace, roofing and snow-contract selling season is here. |
| 3 | K01 | BayBook | Michigan's #1 small-business category is other services, which includes auto repair, and metro Detroit is the country's car capital. Written-estimate and authorization rules (verify) make repair-order compliance a selling point. Tekmetric and Shopmonkey bill creep adds pressure. |
| 4 | F01 | Chairly | Other services density again (salons and barbers). Fresha and Vagaro anger is at scoreboard 22. |
| 5 | E07 | Shiftwell | Michigan is an open EVV state with HHAeXchange as aggregator, and has a large metro-Detroit home-care agency base. A cheaper agency system that exports visits to HHAeXchange is legal here. |
| 6 | D06 | SiteLoop | Michigan is a top campground state (D06). The off-season switch window (Oct–Mar) opens now, and the same "Up North" owners often run marinas and cabins too. |
| 7 | J04 | TagTrue | A large, price-compressed independent cannabis market on Metrc, plus a new wholesale tax (verify). Margin pressure makes owners cut software spend (scoreboard 14, but local fit is very high). |

## State-only opportunities
- **Great Lakes marina and boat-storage software (unscored lead):** Michigan has one of the largest boating markets in the US (verify registrations). Marinas juggle seasonal slip leases, winter storage (haul-out, shrink-wrap, launch queues), fuel docks and transient bookings. Incumbents (Dockwa, DockMaster, Molo; verify) could not be fetched this pass, so no pricing or pain evidence exists yet. Worth a dedicated research pass, since the buying window is Oct–Mar and it spans MI, WI, OH, NY and MN.
- **Michigan wage-step planner (D04/G04 module):** a free "what does $15.00 on Jan 1 2027 do to my labor cost" calculator as the lead magnet for ShiftTip in Michigan.
- **Snow and ice contracts for landscapers (C-series gap):** per-push and seasonal billing, salt logs, and time-stamped service proof for slip-and-fall defense. Michigan, Wisconsin, Ohio, Illinois and Indiana all have this seasonal flip (landscape to snow). No evidence was gathered this pass; this is a candidate idea for a later wave.

## Where to sell
- **Associations & events** (months to verify):
  - Hospitality and recreation: Michigan Restaurant & Lodging Association (MRLA), Michigan Association of Private Campground Owners (verify name), Michigan Boating Industries Association (Detroit Boat Show, Feb; verify).
  - Auto and cannabis: AASP-MI (via K01), Michigan Cannabis Industry Association (via J04).
  - Building and home care: Home Builders Association of Michigan, Michigan Home Care & Hospice Association (verify).
  - Professionals: Michigan Association of CPAs, State Bar of Michigan, Michigan Dental Association.
  - General business: Small Business Association of Michigan (SBAM), Detroit Regional Chamber (Mackinac Policy Conference, May).
- **Online communities:** r/Detroit, r/Michigan, r/grandrapids, r/AnnArbor, r/lansing, r/MichiganCannabis (verify), r/restaurateur, and Michigan contractor and campground-owner groups on Facebook (names to verify).
- **Partners:**
  - Michigan SBDC.
  - TechTown Detroit and ProsperUs Detroit (verify) for Detroit microbusinesses.
  - Chaldean and Arab-American chambers (verify names).
  - Restaurant CPAs handling ESTA and tip questions.
  - Auto parts distributors for repair shops.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials or freedom-to-read law** | None found. Michigan is not on Book Riot's Aug 2026 list of freedom-to-read states, and PEN's Dec 2025 report names no Michigan restriction law ([Book Riot](https://bookriot.com/massachusetts-passes-freedom-to-read-law/); [PEN](https://pen.org/report/the-bills-igniting-book-bans/)) (verify) | n/a | (R01 weak) |
| **Science of reading: K-12 Literacy and Dyslexia Law (2024 Public Acts, cited as PA 146 and 147/247; verify numbering; MCL 380.1280f)** | By **Jan 1 2026** the state must approve 3 or more K–3 and 4–12 screening and progress-monitoring tools. Districts must run Tier 1 elementary reading curricula aligned with the science of reading, and materials may not rely on strategies that downplay letter-sound decoding (a functional three-cueing limit). The FY2025 School Aid Act §35m put **$87M** into PD, materials and coaching, and LETRS training is free ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/michigan/)). Full implementation dates beyond Jan 1 2026 were not confirmed (verify) | Tool approvals Jan 1 2026; district rollout 2026–27 onward (verify) | P01, R08 |
| **3rd-grade reading plan or retention law** | Retention under Read by Grade Three was **repealed** (2023). Individual reading plans remain (verify). The 74 notes Michigan dropped retention (via P02) | Repealed 2023 | (P02 weak) |
| **Homeschool: HSLDA "Low regulation"** | Option 1 requires no notice; option 2 requires notice. State subjects apply, with no testing ([HSLDA Michigan](https://hslda.org/legal/michigan)) | In force | P03 |
| **ESA and scholarship money** | None; the state constitution bars aid to private schools (background, verify). Michigan is not in the federal tax-credit scholarship ([IRS, Jun 8 2026](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | n/a | (P07 weak) |
| **Other** | Nothing confirmed this pass (Imagination Library and auto-renewal law: verify) | — | — |

**Top 3 reading/education ideas here:**
- **P01 PhonicsPrep:** districts must move to science-of-reading-aligned Tier 1 curricula, with $87M in §35m money for materials and coaching.
- **R08 Readlings:** newly approved K–12 screeners flag readers, and letter-sound-first home practice matches the law's limit on cueing strategies.
- **P03 HomeRoll:** a large low-regulation homeschool market with no notice under option 1.

**Where to sell:**
- **Libraries:** Michigan Library Association (fall conference; verify) and the Michigan Association for Media in Education (MAME; verify).
- **Parents:** Michigan PTA.
- **Homeschool:** Information Network for Christian Homes (INCH; verify).
- **Reading specialists:** IDA Michigan branch and The Reading League Michigan (both verify), plus the intermediate school district (ISD) literacy coaches funded by §35m.
- **Booksellers:** GLIBA (verify).

## Launch verdict
**Speed:** Fast.

**First city:** Metro Detroit (Detroit, Dearborn, Macomb and Oakland suburbs). Grand Rapids comes second.

**Lead offer:** ShiftTip with a Michigan wage and ESTA pack. The pitch is "Be ready for $15.00 on Jan 1 2027: tip-credit math, ESTA accruals and schedules for a flat $39 per location." Pair it with FirstCall and BayBook for trades and auto shops.

## Sources
- [SBA Office of Advocacy: 2025 Michigan Small Business Profile (PDF)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Michigan_2025-State-Profile.pdf)
- [Michigan LEO: Minimum Wage](https://www.michigan.gov/leo/bureaus-agencies/ber/wage-and-hour/min-wage)
- [Michigan LEO: Earned Sick Time Act](https://www.michigan.gov/leo/bureaus-agencies/ber/wage-and-hour/paid-medical-leave-act)
- [Michigan LEO: Wage & Hour Division](https://www.michigan.gov/leo/bureaus-agencies/ber/wage-and-hour)
- [HHAeXchange: State-by-State EVV Status](https://www.hhaexchange.com/state-evv-status)
- The Michigan MDHHS EVV page URL returned 404, so the EVV row relies on HHAeXchange. The tipped-wage schedule, cannabis wholesale tax, MVSRA and lien details are marked (verify).
- Scoreboard and idea files D04, B04, K01, F01, E07, D06, J04, D08, I06 (internal).
- [The Reading League Compass: Michigan](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/michigan/)
- [HSLDA: Michigan homeschool law](https://hslda.org/legal/michigan)
- [Book Riot: Massachusetts passes freedom-to-read law, with list of states (Aug 2026)](https://bookriot.com/massachusetts-passes-freedom-to-read-law/)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [IRS: Federal scholarship tax credit participating states (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
