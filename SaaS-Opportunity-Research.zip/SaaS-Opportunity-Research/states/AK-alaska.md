# Alaska (AK): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 77,814 small businesses, which is 99.1% of Alaska businesses. They employ 139,534 people, or **54.2% of the private workforce**. 60,471 have no employees, which leaves roughly 17k small employers (our subtraction, an estimate) ([SBA Advocacy 2025 Alaska profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Alaska_2025-State-Profile.pdf)).
- **New-business momentum:** Flat. From March 2023 to March 2024, small firms opened 2,065 establishments and closed 2,096. Even so, small firms added 4,814 of the state's 5,985 net new jobs (80.4%) (SBA profile). Census Business Formation Statistics were not pulled.
- **Largest small-business employers:** Health care & social assistance (27,334), accommodation & food services (21,388), retail (13,834), construction (13,734) (SBA profile).
- **Buyer clusters:**
  - **Anchorage:** about 40% of the population (verify). Health care, oil-field and aviation services, restaurants, trades, landlords.
  - **Mat-Su (Wasilla/Palmer):** home builders and trades in the fastest-growing borough (verify).
  - **Fairbanks:** military-adjacent services, winter aurora tourism, construction.
  - **Kenai Peninsula (Seward, Homer, Soldotna):** fishing charters, lodges, RV parks, glacier and wildlife tours.
  - **Southeast (Juneau, Ketchikan, Skagway, Sitka):** cruise shore excursions, flightseeing, retail.
  - **Kodiak/Bristol Bay:** commercial fishing and processing.
- **Industries overweight vs. US** (qualitative estimate):
  - Tourism (cruise shore excursions, lodges, flightseeing, charters).
  - Commercial fishing and seafood.
  - Oil & gas services.
  - Aviation and air taxis.
  - Military and federal contracting.
  - Seasonal hospitality.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Minimum-wage steps and paid sick leave (Ballot Measure 1, 2024).** Minimum wage has been "$13.00 per hour effective Jul. 1, 2025" ([AK Dept. of Labor](https://labor.alaska.gov/lss/whact.htm)). It rises to $14 on Jul 1 2026 and $15 on Jul 1 2027, and paid sick leave took effect Jul 1 2025 (verify both). No tip credit (state leads) | Every employer, especially seasonal tourism and restaurants | Jul 1 2026 / Jul 1 2027 | G04 StatePay, D04 ShiftTip, J03 PostedUp |
| **Remote-seller local sales tax (ARSSTC).** Threshold is **$100,000** in statewide gross sales, with no transaction count, under the "Uniform Code as amended July 2024, effective January 1, 2025" ([ARSSTC Code](https://arsstc.org/code/)). Alaska has no state sales tax, but many boroughs and cities levy their own (verify count) | E-commerce sellers into AK, Alaska retailers selling statewide | In force since Jan 1 2025 | J01 NexusBook, L03 StackSaver |
| **Local bed and sales taxes on lodging, tours and STRs** (borough and city level; verify rates) | Lodges, B&Bs, STR hosts, tour operators | Monthly or quarterly local filings (verify) | H03 StayDesk, D05 InnDesk, D07 BookTrail |
| **Juneau cruise passenger daily limits.** Agreed limits start with the 2026 season (verify figures). This shifts demand and dates for shore-excursion operators; the CBJ Tourism Best Management Practices program also applies ([CBJ Tourism](https://juneau.org/tourism)) | Juneau tour operators, retailers | 2026 season onward (verify) | D07 BookTrail |
| **Metrc track-and-trace** (per state leads) | Cannabis licensees | Ongoing | J04 TagTrue |
| **Not an IFTA jurisdiction** (verify). This weakens K03 in Alaska | Truckers | n/a | (K03 deprioritized) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | D07 | BookTrail (tours/charters booking) | Alaska's economy runs on May–Sep excursions: flightseeing, glacier cruises, fishing charters, dog-sled camps, whale watching. **The season just ended, so Oct–Mar is the switching window.** No guest booking fee plus all-in prices suit cruise-passenger buyers. Cruise-line caps (Juneau 2026) make direct booking more valuable. |
| 2 | D05 | InnDesk (independent lodge/hotel PMS) | Hundreds of small lodges, B&Bs and roadhouses (estimate) use Cloudbeds or paper. Fly-in fishing lodges sell multi-day packages (lodging, guide, flight), which generic PMS handles badly. Alaska fit is much better than the national 14/25 score suggests. |
| 3 | H03 | StayDesk (STR PMS + tax ledger) | Anchorage, Seward, Homer and Girdwood cabins and STRs deal with borough bed taxes and platform-collection gaps. The Airbnb host-only fee pushes direct booking. |
| 4 | B04 | FirstCall (owned lead capture for trades) | Anchorage and Mat-Su trades have a short, intense building season, so missed calls cost the most in April–October. Lead marketplaces are thin in Alaska, so owned lead capture is the main channel. |
| 5 | G04 | StatePay (compliance copilot beside payroll) | New paid sick leave and two more wage steps (2026, 2027) hit seasonal employers who rehire every spring. Onboarding, accrual tracking and carry-over across seasons is the pain. |
| 6 | D04 | ShiftTip (scheduling + tip pooling) | Seasonal restaurants and bars in tourism towns have no tip credit and rising wage floors. Crews scale up fast in May and back down in September. |
| 7 | J01 | NexusBook (sales tax) | Alaska's local-only sales tax runs through ARSSTC with a $100k threshold and no transaction count. It confuses both Lower-48 e-commerce sellers and Alaska sellers shipping statewide. Flat-fee filing beats Avalara quotes. |

*Just outside the Top 7:* **D06 SiteLoop** (summer RV parks on the Kenai and Parks Highway), **J06 LicenseLedger** (Alaska business license renewals and professional licensing; verify cycle), **J04 TagTrue**.

## State-only opportunities
1. **Fly-in lodge / guided-package booking** (a D05 + D07 hybrid). A multi-day package combining lodging, guide, air-taxi seat and fish processing, with deposits and balance schedules, guide logbook export and weather rebooking. The niche is real but small (a few hundred operators, estimate). It is better as a BookTrail "packages" module, or as an Alaska extension of **S7-01 GuideLedger** (outfitter booking plus federal permit reporting; Alaska guides work heavily on Tongass/Chugach and NPS lands), than as a standalone file. ADF&G's guide logbook page errored during this pass, so reporting duties are unverified.
2. **Seasonal-worker compliance pack** (G04 module). Rehire onboarding, paid-sick-leave carry-over across seasons, and wage-step reminders for Jul 1 2026 and 2027.
3. **ARSSTC filing helper** (J01 module) for Alaska-based e-commerce and Lower-48 sellers crossing $100k into Alaska.

## Where to sell
- **Associations & events:** Alaska Travel Industry Association (ATIA; annual convention in the fall, verify), Alaska CHARR (Cabaret, Hotel, Restaurant & Retailers Association; verify), Alaska Hotel & Lodging Association (verify), Anchorage Home Builders Association and Alaska State Home Building Association, Alaska Chamber and Anchorage Chamber, Alaska Society of CPAs, Alaska Bar Association, Alaska State Dental Society, and the Alaska Wilderness Recreation & Tourism Association (verify).
- **Online communities:** r/alaska, r/anchorage, r/juneau, r/fairbanks. Alaska tour-operator and lodge-owner Facebook groups, and Alaska small-business groups (verify names). Alaska Business Magazine.
- **Partners:** Alaska SBDC (hosted by the University of Alaska Anchorage; verify), visitor bureaus (Visit Anchorage, Travel Juneau, Ketchikan Visitors Bureau, Seward Chamber), Northrim Bank and Denali State Bank (verify SMB programs), credit unions (Global Credit Union, Credit Union 1, Denali FCU; verify), and bookkeepers serving seasonal businesses.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law | None on our lead lists (verify). Library funding is the bigger issue: Alaska's books-by-mail service had not restarted a year after the federal IMLS cuts ([Library Journal, Apr 2026](https://www.libraryjournal.com/story/one-year-after-the-executive-order), via R03), and LJ reported cuts to the state's LSTA-funded services (via R02). | 2025–2026 | R03, R02 |
| Science of reading / three-cueing law | Alaska Reads Act (2022; verify provisions) | Phasing in | P01, R08 |
| 3rd-grade reading plan / retention law | Conditional-retention state (per the lead list; verify the Reads Act's rules) | In force | P02 |
| Homeschool rules (HSLDA tier: **no notice, low**) | Four options. Notice and testing apply only under option 4, and teacher qualifications only under option 2. No state-mandated subjects. Compulsory age 7–16 ([HSLDA AK](https://hslda.org/legal/alaska)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **Correspondence-school allotments.** Nearly **23,000** homeschool students in district correspondence programs get state money for approved purchases. On Jun 28 2024 the Alaska Supreme Court reversed a ruling that had struck the program, saying there are "many constitutionally permissible uses of allotment funds", and sent the question of specific spending back to the Superior Court ([Alaska Beacon, Jun 28 2024](https://alaskabeacon.com/briefs/alaska-supreme-court-reverses-homeschool-allotment-ruling/)). Plaintiffs revived the suit in Feb 2025, naming four school districts ([KTOO, Feb 10 2025](https://www.ktoo.org/2025/02/10/plaintiffs-revive-homeschool-suit-naming-four-alaska-school-districts-as-defendants/)). Allotment amounts and the current case status are unconfirmed (verify). | Litigation ongoing (verify) | P03, P04, P07, R05, R08 |
| Other | No statewide Imagination Library facts confirmed in this pass (verify). | — | P06 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll:** it covers Alaska's four legal options and keeps the per-purchase allotment records that correspondence programs require, which matter more while spending is under court review.
- **P04 ClassHouse:** it helps local teachers become approved allotment vendors and sell classes to about 23k correspondence students.
- **R03 Branchline:** tiny rural libraries lost their federal-funded services, including books-by-mail, and need cheap events, holds and mail-lending tools.

**Where to sell:**
- **Libraries:** Alaska Library Association (AkLA; conference, late winter; verify) and the Alaska Association of School Librarians (verify).
- **Parents:** Alaska PTA, the Alaska Private & Home Educators Association (APHEA; verify), and district correspondence programs' vendor offices.
- **Reading:** IDA and The Reading League (no AK chapter confirmed; verify).
- **Booksellers:** PNBA (Pacific Northwest Booksellers Association; verify AK coverage).

## Launch verdict
**Speed:** Slow to medium. The market is small (about 17k employers) and seasonal. But the timing is ideal right now: the off-season switching window runs Oct–Mar, and operators are reachable at fall and winter industry events. **First city:** Anchorage for sales and partners, with Juneau/Seward/Ketchikan operators as the first BookTrail customers. **Lead offer:** BookTrail "no guest fee, all-in pricing" for tours and charters, with free migration and setup before the May 2027 season. Add a lodge-package module for fly-in lodges.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Alaska (Jun 2025)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Alaska_2025-State-Profile.pdf)
- [Alaska Department of Labor: Wage and Hour Act (minimum wage $13.00 from Jul 1 2025)](https://labor.alaska.gov/lss/whact.htm)
- [Alaska Remote Seller Sales Tax Commission: Uniform Code (amended Jul 2024, effective Jan 1 2025)](https://arsstc.org/code/)
- [City and Borough of Juneau: Tourism (TBMP program)](https://juneau.org/tourism)
- Internal: `_scoreboard.csv`, `_state_leads_from_category_research.md` (no tip credit, Metrc, AK local sales tax), ideas D07, D05, H03, G04, J01.
- [HSLDA: Alaska homeschool laws](https://hslda.org/legal/alaska)
- [Alaska Beacon: Alaska Supreme Court reverses homeschool allotment ruling (Jun 28 2024)](https://alaskabeacon.com/briefs/alaska-supreme-court-reverses-homeschool-allotment-ruling/)
- [KTOO: Plaintiffs revive homeschool suit, naming four Alaska school districts (Feb 10 2025)](https://www.ktoo.org/2025/02/10/plaintiffs-revive-homeschool-suit-naming-four-alaska-school-districts-as-defendants/)
- [Library Journal: One year after the executive order (Apr 2026)](https://www.libraryjournal.com/story/one-year-after-the-executive-order) (via R03)
