# New York (NY): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 2.4 million small businesses, 99.8% of NY businesses, employing 3.9 million people (46.6% of NY employees). 1,923,517 are nonemployer firms. ([SBA Advocacy 2025 NY profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_York_2025-State-Profile.pdf))
- **New-business momentum:** From Mar 2023 to Mar 2024, small businesses opened 62,612 establishments and closed 59,915. They added a net 54,510 jobs, 42.4% of the state's net job gain. Churn is high, so there's a steady stream of new owners buying their first software stack. ([SBA Advocacy 2025](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_York_2025-State-Profile.pdf))
- **Buyer clusters:**
  - **NYC's five boroughs:** restaurants, delivery-heavy food, salons and barbers, independent retail, professional services, dental.
  - **Long Island (Nassau/Suffolk):** HVAC, plumbing, landscaping, pools, insurance agencies, dental and med spas.
  - **Westchester/Hudson Valley:** home services, med spas, farms, wineries, weddings.
  - **Capital Region (Albany):** professional services and government contractors.
  - **Buffalo, Rochester, Syracuse:** trades, snow removal, manufacturing.
  - **Finger Lakes and the North Fork:** wineries and craft beverage.
  - **Adirondacks and Catskills:** summer camps, lodging, tours.

  These clusters are an estimate.
- **Industries overweight vs. US:**
  - By small-business employment, health care and social assistance (617,801) and accommodation and food services (537,380) lead, followed by professional services (344,414) ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_York_2025-State-Profile.pdf)).
  - Also overweight (estimate): insurance and finance, real estate, arts and entertainment.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| Federal ADA Title III website suits. NY led the country with **1,021** federal filings in 2025 ([Seyfarth](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)) | Any SMB with a website, especially NYC restaurants and retailers | Ongoing, peaks every quarter | J02 |
| **GBL §527-a auto-renewal**: easy cancellation "through all mediums" used for sign-up, and a renewal reminder 15–45 days before the cancellation deadline for initial terms of 1 year or more that renew for 6 months or more ([NY Senate, revision dated 2025-11-07](https://www.nysenate.gov/legislation/laws/GBS/527-A)) | Gyms, studios, car-wash clubs, subscription boxes, memberships | Current revision Nov 7 2025 (effective date to verify) | F02, K06, L03, J02 |
| GOL §5-903 notice rule for auto-renewing service contracts (verify) | SMBs trying to exit Podium, Yext, RingCentral or Birdeye contracts | Ongoing | A03, B05, B06 (a "we'll help you exit" hook) |
| **NY DFS 23 NYCRR 500 cybersecurity**: annual certification or acknowledgment by **April 15**, 72-hour incident notice, 24-hour extortion-payment notice. Small entities with a limited exemption (<20 staff, <$7.5M revenue or <$15M assets) still need MFA, an asset inventory, a risk assessment, policies and training ([DFS small business](https://www.dfs.ny.gov/cybersecurity/small-business-resources), [DFS submissions](https://www.dfs.ny.gov/cybersecurity/submissions)) | Insurance agencies, individual agents and brokers, mortgage brokers, DFS licensees | Apr 15 2027 filing | **S1-01**, G05, L06 |
| NY Pesticide Reporting Law annual report due **Feb 1** (verify; the DEC page doesn't state the date). The Birds and Bees Act ban on neonics for outdoor ornamentals and turf expands to imidacloprid, thiamethoxam and acetamiprid on **Dec 31 2026** ([NY DEC](https://dec.ny.gov/environmental-protection/pesticides)) | Commercial applicators: lawn, tree, pest, turf | Dec 31 2026, then Feb 1 2027 | C03 |
| NYC delivery-app pressure: DoorDash's **$131.5M** settlement for delivery-worker violations (Sep 22 2026). Delivery-worker minimum pay is **$22.13/hr** before tips ([NYC DCWP](https://www.nyc.gov/site/dca/news/065-26/mayor-mamdani-wins-record-131-5-million-doordash-delivery-workers)). The NYC fee cap ended Jun 2025 (category research) | NYC restaurants paying app commissions | Now | D02, D03 |
| NYC Fair Workweek for fast food and retail: advance schedules, premium pay for changes (details to verify on NYC DCWP) | Fast-food franchisees, retail chains | Ongoing | D04 |
| NY pay transparency, Labor Law §194-b (Sep 2023, 4+ employees) (verify) | Employers posting jobs | In force | J03, G07 |
| NY Retail Worker Safety Act: violence-prevention policy and training, panic buttons for large retailers from Jan 1 2027 (verify) | Retail stores with 10+ employees | 2025 to Jan 1 2027 | J03 |
| NY LLC Transparency Act, in effect Jan 1 2026. Scope changed after the federal BOI domestic exemption (verify) | LLCs formed or registered in NY | 2026 | J06 |
| Minimum wage 2026: $17 in NYC, Long Island and Westchester, $16 elsewhere ([US DOL](https://www.dol.gov/agencies/whd/minimum-wage/state)), indexed from 2027 (verify indexing) | All employers (poster, payroll and tip-credit changes) | Jan 1 2027 | J03, D04, G04 |
| Economic nexus: $500k in sales **and** 100 transactions (verify) | Remote sellers | Ongoing | J01 |
| Children's camp permits under DOH Subpart 7-2 (verify). Student data privacy under Ed Law 2-d (category research) | Catskills and Adirondacks camps, private and charter schools | Pre-season permits; ongoing | I06, I07 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | J02 | SiteShield | NY is the top ADA web-suit state (1,021 in 2025), and the amended auto-renewal law (Nov 2025) adds a second exposure. Sell a fear-driven, card-swipe "ADA + privacy + auto-renew checkup" to any NYC SMB with a website. |
| 2 | D02 | DirectPlate | About 20k+ NYC restaurants (estimate). The fee cap is gone, and DoorDash's $131.5M settlement (Sep 22 2026) keeps apps in the news. Pitch "own your orders." |
| 3 | A03 | LocalLoop | Dense multi-location SMBs locked into Podium or Birdeye. New York's own auto-renewal rules support a contract-exit service. Scoreboard 22. |
| 4 | S1-01 | Part500 Kit | New York only. DFS-licensed agencies, individual agents and brokers must certify by Apr 15 and prove MFA and an asset inventory. The compliance platforms we checked (Vanta, Drata) are quote-only and don't feature Part 500. |
| 5 | B04 | FirstCall | Long Island, Westchester and upstate trades hurting from Angi fees and Google LSA changes. Scoreboard 23. |
| 6 | D04 | ShiftTip | NYC Fair Workweek premium-pay exposure. The 2027 wage change for fast-food and retail schedulers. |
| 7 | C03 | SprayLog | Hard dates: the neonic expansion Dec 31 2026 and the pesticide report Feb 1 2027. Q4 2026 is the switch window. |

Honorable mention: F01 Chairly (NYC salon and barber density; Vagaro payout freezes Sep 2026).

## State-only opportunities
1. **NY DFS Part 500 compliance kit for small licensees (S1-01).** DFS supervises **over 1,900 insurance companies** and **1,300+ banks** ([DFS](https://www.dfs.ny.gov/about_us)). Individual agents and brokers must also file each year unless fully exempt ([DFS FAQ](https://www.dfs.ny.gov/cybersecurity/faqs)). That base is far larger, likely tens of thousands of agencies and individuals (estimate; DFS doesn't publish the count). Vanta and Drata are quote-only and don't list 23 NYCRR 500 as a featured framework. Full file: `ideas/S1-01-ny-dfs-part-500-cyber-compliance-kit.md`.
2. **NYC Fair Workweek plus delivery-era scheduling for fast food.** Fold predictive-scheduling premium math into D04. This is a feature pack, not a standalone product.
3. **Neonic-ban and pesticide-report bundle for Long Island and Westchester lawn and tree companies.** C03 with a NY "what can I still spray on Jan 1 2027" product checker.

## Where to sell
- **Associations & events:**
  - Restaurants and hospitality: NYS Restaurant Association, NYC Hospitality Alliance, Hotel Association of NYC, NYS Hospitality & Tourism Association.
  - Construction and home services: Long Island Builders Institute, NYS Builders Association, NYS Turfgrass Association, NYS Pest Management Association (verify name).
  - Professional services: NYSSCPA, NYS Bar Association, NYS Dental Association.
  - Insurance: IIABNY (Big I NY) and PIANY, the core S1-01 channel.
  - Events: Greater New York Dental Meeting (late Nov–early Dec, Javits, verify), International Restaurant & Foodservice Show of NY (March, Javits, verify).
- **Online communities:** r/nyc, r/AskNYC, r/longisland, r/Westchester, r/HudsonValley, r/Albany, r/Buffalo, r/Rochester, r/Syracuse, r/smallbusiness. Facebook groups for NYC restaurant owners, Long Island contractors and NY insurance agents (search by name).
- **Partners:**
  - Public programs: NYS SBDC network, NYC Small Business Services Business Solutions Centers, NYC Business Improvement Districts.
  - Chambers: borough chambers (Brooklyn, Queens, Bronx, Staten Island) and the Long Island Association.
  - Channel partners: CPA firms, POS resellers, MSPs serving insurance agencies, and agency clusters and aggregators.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | **No statewide law.** The **Freedom to Read Act (S1099)** would have required policies letting school libraries and staff "curate and develop collections that provide students with access to the widest array of developmentally appropriate materials available." Gov. Hochul **vetoed it on Dec 20 2025** without a statement ([Words & Money](https://www.wordsandmoney.com/new-york-governor-kathy-hochul-vetoes-states-freedom-to-read-bill/)). Collection and reconsideration policy stays with local boards, and sponsors may reintroduce it (verify 2026 status) | Vetoed Dec 20 2025 | R01 (policy-template upsell only), R07 |
| Science-of-reading law: **"Back to Basics"** (FY2025 budget) | By **Sep 2025**, "all school districts will need to certify with the State Education Department (SED) that their curriculum, instructional strategies, and teacher professional development align with all elements of the evidenced-based reading instruction." The budget put **$10M toward training 20,000 teachers** ([NY Governor](https://www.governor.ny.gov/programs/back-basics-reading-plan)). On mandatory surveys, **more than 130 of 713 districts** still reported "balanced literacy" curricula (Fountas & Pinnell, Units of Study). Compliance is self-reported with no enforcement, and about **400,000 students** lack evidence-based instruction ([NYS Focus, May 7 2026](https://nysfocus.com/2026/05/07/science-of-reading-back-to-basics-school-curriculum-new-york)). Not a statutory three-cueing ban (verify) | Certification Sep 2025; gaps reported May 2026 | **P01**, **R08** |
| 3rd-grade reading plan / retention law | No retention law. NY is not on the category-research retention lists | — | P02 (low fit) |
| Homeschool rules (HSLDA tier: **high**, per category research; the HSLDA page label couldn't be confirmed, verify) under 8 NYCRR 100.10 | **Notice of intent** "by July 1 … annually, or within 14 days of establishing your homeschool program." NYC families email LetterofIntent@schools.nyc.gov. **IHIP** "by August 15 or within four weeks of the receipt of the IHIP form … (whichever is later)." It lists the child's grade, syllabi, curriculum materials or textbooks, quarterly-report dates and the instructor. **Four quarterly reports** give hours, material covered per subject, and a grade or narrative. **Annual assessment:** grades 1–3 by narrative or test; grades 4–8 by a standardized test every other year (narrative in between); grades 9–12 by a test yearly. The composite must be "above the 33rd percentile" or show one year of growth. **Hours:** 900 a year (grades 1–6), 990 (grades 7–12) ([HSLDA how-to-comply NY](https://hslda.org/post/how-to-comply-with-new-yorks-homeschool-law)). The district rules on an IHIP within 10 business days, and a deficient IHIP must be revised within 15 days ([NYSED Q&A via P03](https://www.nysed.gov/nonpublic-schools/home-instruction-questions-and-answers)) | Every year: Jul 1, Aug 15, 4 quarterlies, year-end assessment | **P03** |
| ESA / scholarship money that can buy books, curriculum, classes | **None.** NY has no ESA or voucher, and it was **not** on the IRS list of 27 states in the federal tax-credit scholarship as of Jun 8 2026 ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)). NY 529 treatment of K–12 withdrawals is not confirmed; category research lists 13 non-conforming states (verify NY) | — | P07 (weak) |
| Other | **Imagination Library:** the NYS Library awarded **$499,149 on Oct 14 2025** to 25 local programs, covering "up to 50% of program partner costs" ([NYSED](https://www.nysed.gov/news/2025/new-york-state-library-awards-nearly-500k-expand-dolly-partons-imagination-library)). **Auto-renewal:** GBL §527-a (Nov 2025 revision; see the laws table) applies to family reading and learning subscriptions sold to NY consumers | Oct 2025 grants; §527-a in force | P06, R08, P07 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll:** NY has the most paperwork-heavy homeschool regime we found. A daily log that auto-writes the IHIP, four quarterly reports (hours plus material by subject) and the assessment plan is a direct time-saver. The Jul 1 / Aug 15 cycle just passed, so the next hook is the first quarterly report (Oct–Nov).
- **R08 Readlings:** about 400k students sit in districts still using balanced-literacy programs. Sell parents an at-home decodable app with §527-a-compliant one-click cancel.
- **P01 PhonicsPrep:** tutors and reading specialists serving families who see that gap. NY and Long Island tutoring rates are among the highest (per P01).

**Where to sell:**
- **Libraries:** New York Library Association annual conference (fall, verify) and its Section of School Librarians; NYS Library Imagination Library grantees (library systems, United Ways).
- **Families:** NYS PTA.
- **Homeschool groups:** LEAH (Loving Education At Home), NYSHEN, and "NY homeschool IHIP help" Facebook groups (verify).
- **Reading groups:** **The Reading League**, headquartered in Syracuse (verify); IDA New York Branch (verify).
- **Booksellers:** New Atlantic Independent Booksellers Association (verify).

## Launch verdict
**Speed:** Fast. **First city:** New York City (start in Brooklyn and Queens independents), with Long Island second. **Lead offer:** J02 SiteShield "NY Website Risk Check." The pitch: ADA scan, a privacy notice and a GBL §527-a auto-renew audit in 10 minutes, then a flat monthly fix plan, marketed on NY's #1 rank in ADA web suits. Then cross-sell D02 to the same restaurants, and run S1-01 through the Jan–Apr 15 season.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: New York](https://advocacy.sba.gov/wp-content/uploads/2025/06/New_York_2025-State-Profile.pdf)
- [NY DFS Cybersecurity Resource Center](https://www.dfs.ny.gov/industry_guidance/cybersecurity)
- [NY DFS Small Business Compliance Resources](https://www.dfs.ny.gov/cybersecurity/small-business-resources)
- [NY DFS Cybersecurity Submissions](https://www.dfs.ny.gov/cybersecurity/submissions)
- [NY DFS About Us](https://www.dfs.ny.gov/about_us)
- [NY DFS Cybersecurity FAQs](https://www.dfs.ny.gov/cybersecurity/faqs)
- [NY DEC Pesticides (PRL and Birds and Bees Act)](https://dec.ny.gov/environmental-protection/pesticides)
- [NYC DCWP: $131.5M DoorDash settlement (Sep 22 2026)](https://www.nyc.gov/site/dca/news/065-26/mayor-mamdani-wins-record-131-5-million-doordash-delivery-workers)
- [NY General Business Law §527-a (NY Senate)](https://www.nysenate.gov/legislation/laws/GBS/527-A)
- [Seyfarth: federal website accessibility suits 2025](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)
- [HSLDA: How to comply with New York's homeschool law](https://hslda.org/post/how-to-comply-with-new-yorks-homeschool-law)
- [HSLDA: New York homeschool law](https://hslda.org/legal/new-york)
- [NYSED: Home instruction Q&A (cited in P03)](https://www.nysed.gov/nonpublic-schools/home-instruction-questions-and-answers)
- [NY Governor: Back to Basics reading plan](https://www.governor.ny.gov/programs/back-basics-reading-plan)
- [NYS Focus: districts still using discredited reading curricula (May 7 2026)](https://nysfocus.com/2026/05/07/science-of-reading-back-to-basics-school-curriculum-new-york)
- [Words & Money: Hochul vetoes the Freedom to Read bill S1099 (Dec 2025)](https://www.wordsandmoney.com/new-york-governor-kathy-hochul-vetoes-states-freedom-to-read-bill/)
- [NYSED: $499K for Imagination Library programs (Oct 14 2025)](https://www.nysed.gov/news/2025/new-york-state-library-awards-nearly-500k-expand-dolly-partons-imagination-library)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)

## Verification (Sep 24 2026)
- ✅ GBL §527-a (the lead-offer audit): cancellation must be "through all mediums" used for consent, with a reminder "at least fifteen days before, but not more than forty-five days before" the cancellation deadline. That applies to initial terms of 1 year or more that renew for 6+ months (wording tightened). The latest revision is dated 2025-11-07; its effective date is still to be confirmed ([NY Senate](https://www.nysenate.gov/legislation/laws/GBS/527-A))
- ✅ DFS Part 500 annual notice is due April 15 and signed by the highest-ranking executive plus the CISO or senior officer. Incident notice is due within 72 hours and an extortion-payment notice within 24 hours. The 500.19(a) thresholds (<20 staff, <$7.5M revenue or <$15M assets) and the duties that still apply (MFA, asset inventory, risk assessment, training) also match ([DFS submissions](https://www.dfs.ny.gov/cybersecurity/submissions); [DFS small business](https://www.dfs.ny.gov/cybersecurity/small-business-resources))
- ✅ Birds and Bees Act: clothianidin and dinotefuran were barred on outdoor ornamentals and turf from Dec 31 2024, and imidacloprid, thiamethoxam and acetamiprid are added from Dec 31 2026 ([NY DEC](https://dec.ny.gov/environmental-protection/pesticides))
- ⚠️ The Feb 1 Pesticide Reporting Law due date is not stated on the DEC page, so (verify) was added ([NY DEC](https://dec.ny.gov/environmental-protection/pesticides))
- ✅ DoorDash settlement: $131.5M, announced Sep 22 2026 (more than $115M to workers and more than $16M in penalties). The delivery-worker minimum pay is "currently $22.13 per hour, excluding tips" ([NYC DCWP](https://www.nyc.gov/site/dca/news/065-26/mayor-mamdani-wins-record-131-5-million-doordash-delivery-workers))
- ✅ The 2026 minimum wage is $17.00 in NYC, Nassau, Suffolk and Westchester and $16.00 elsewhere. Indexing from 2027 is not shown on the page ([US DOL](https://www.dol.gov/agencies/whd/minimum-wage/state))
