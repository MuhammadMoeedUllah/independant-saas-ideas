# Minnesota (MN): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 560,428 small businesses employing 1.3 million people, or 45.8% of Minnesota employees. 118,083 small employer firms. Data year 2022. ([SBA Advocacy 2025 Minnesota profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Minnesota_2025-State-Profile.pdf))
- **New-business momentum:** Weak job momentum. Small businesses gained 171,390 jobs and lost 170,773 between March 2023 and March 2024, a net gain of only 617 ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Minnesota_2025-State-Profile.pdf)). Small-business employment grew 7.0% from 1998 to 2022. The largest small-business employers are health care and social assistance (225,087 employees), construction (106,925) and other services (103,001), which covers salons, repair and personal services. Census BFS business-application data was not fetched in this pass.
- **Buyer clusters:**
  - **Minneapolis–St. Paul:** health care and home care, construction and remodeling, restaurants, salons, professional services, child care centers.
  - **Rochester:** clinics and allied health around Mayo.
  - **Brainerd Lakes, the North Shore/Duluth and Detroit Lakes:** family resorts, campgrounds, fishing guides, bait-and-tackle shops.
  - **St. Cloud and Mankato:** ag retail and co-ops, trucking, trades.
  - **Southern and western MN farm towns:** co-ops, grain elevators, ag-equipment dealers, custom pesticide applicators.
  - **Metro-wide:** hail-belt roofing and exterior contractors.
- **Industries overweight vs. US:** health care and social assistance (the largest small-business employer by far, with a large PCA/CFSS home-care agency base), child care (the CCAP program is under national scrutiny), resorts and lake tourism, ag retail and co-ops, roofing and exteriors (hail), and nonprofits (a strong Minnesota Council of Nonprofits network) (overweights are estimates from the cluster analysis, verify).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **MN Paid Leave** (Minn. Stat. ch. 268B, §268B.14). Premiums began Jan 1 2026. Employers pay at least 50% and deduct the rest from wages. Employers with fewer than 30 employees get a wage-base reduction. Premiums are due the last day of the month after each quarter. The 2026 rate is widely cited as 0.88%, but the statute text fetched reads 0.7% plus adjustment provisions (verify on DEED). | Every employer with MN employees | Started Jan 1 2026. Q3 premium due **Oct 31 2026** | G04, J03 |
| **Pay transparency** (§181.173). Job postings must show the starting salary range and a general description of benefits. | Employers with **30+ employees** in MN | In force since Jan 1 2025 (verify date) | J03, G07 |
| **Junk-fee / all-in pricing** (§325D.44 subd. 1a, enacted 2024 c. 111, amended 2025 c. 20). Advertised prices must include all mandatory fees and surcharges. Restaurants must disclose the percentage of any automatic or mandatory gratuity. Delivery platforms must itemize fees. | Resorts, campgrounds, restaurants, event organizers, any SMB quoting prices | In force since Jan 1 2025 (verify date) | D06, D05, D07, D01–D03, I04 |
| **Minnesota Consumer Data Privacy Act** (ch. 325M) | Controllers over the consumer thresholds. SBA-defined small businesses are largely exempt (verify) | Jul 31 2025 (per J02) | J02 |
| **ADA website lawsuits:** 162 federal filings in MN in 2025, the 4th-highest state | Restaurants, retail, hotels and clinics with websites | Ongoing | J02 |
| **Child-care subsidy (CCAP/CCDF) scrutiny.** ACF froze MN CCDF funding with letters on Jan 5–6 2026 and rescinded them on Jul 8 2026 (DCYF tracker). The 2026 CCDF final rule (effective Jul 13 2026) lets states pay on attendance again (per F05). | CCAP-enrolled centers and licensed family child care | 2026 onward | F05 |
| **Medicaid EVV.** HHAeXchange is the state aggregator and MN is an open model, so agencies may use their own EVV system at their own cost. DHS has enforced EVV since Sep 1 2024, and PCA services moved to CFSS codes on Oct 1 2024. | PCA/CFSS agencies, home health | In force | E07 |
| **Pesticide application records** (§18B.37, amended 2024). Each record must include EPA reg. no., rate, temperature, wind speed and direction, site and customer, and must be completed within **5 days**. Records are kept **5 years**. Commercial applicators must **give the customer a copy**. | Lawn care, pest control, ag retailers, custom and aerial applicators | In force | C03 |
| **Earned Sick & Safe Time (ESST)**; no tip credit in MN | All employers; restaurants | ESST since Jan 1 2024 (verify) | D04, G04 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture vs Angi/Thumbtack/LSA) | Highest-scoring idea (23). The Twin Cities have a large construction small-business base (106,925 employees) and hail-season lead-buying. Oct–Feb is when trades review their lead spend. |
| 2 | F05 | RollCall (subsidy-proof attendance) | Minnesota is ground zero for the CCAP fraud story. Legitimate providers want proof: the Jan 2026 funding freeze and the return of attendance-based pay make an audit-ready attendance record essential to cash flow. This is the state-only hook. |
| 3 | A03 | LocalLoop (Podium/Birdeye alternative) | Score 22. Dense metro base of salons, clinics, auto shops and home services that are locked into 12-month Podium contracts. |
| 4 | G04 | StatePay (payroll with state paid-leave built in) | Every MN employer now remits Paid Leave premiums quarterly, alongside ESST accruals and the <30-employee wage reduction. A Jan 1 2027 payroll switch window follows Gusto's +22% hike. |
| 5 | J02 | SiteShield (privacy + accessibility) | 162 federal ADA web suits in 2025 plus a new state privacy law. Sell to Twin Cities restaurants and retailers as "suit-proof your site." |
| 6 | C02 | StormDesk (roofing CRM) | Hail belt. The Oct–Feb off-season is when roofers re-evaluate AccuLynx/JobNimbus. Add MN licensing and storm-contract rules as a differentiator. |
| 7 | E07 | Shiftwell (home care + EVV) | MN is an HHAeXchange open-model state with a very large PCA/CFSS agency base. Agencies can bring their own EVV, and small agencies want scheduling and payroll beyond the free portal. |

Close alternates: F01 Chairly (22) for metro salons, J03 PostedUp (Paid Leave, pay-transparency and ESST notices), D06 SiteLoop for lake resorts (junk-fee law).

## State-only opportunities
1. **CCAP audit-proof attendance (F05 variant).** Build a Minnesota edition of RollCall: parent sign-in/out with timestamp, GPS or photo, daily attendance reconciled against authorizations, and a one-click "evidence packet" for DCYF audits. Pitch it as "prove every hour you bill." Buyers are licensed family child care homes (card buyers) and independent centers.
2. **All-in pricing for lake resorts and campgrounds (D06/D05 variant).** §325D.44 subd. 1a requires advertised prices to include mandatory fees such as resort fees, cleaning fees and dock or boat-slip fees. A booking engine that shows the all-in price by default and audits existing rate cards sells to Brainerd, North Shore and Detroit Lakes resorts in the Oct–Apr off-season, when they rebuild next summer's rates.
3. **Pesticide records for lawn/pest and ag applicators (C03 regional edition).** §18B.37 requires weather fields, a 5-day completion deadline, 5-year retention and a customer copy for every commercial application. A phone-first record that pulls weather automatically and emails the customer copy fits metro lawn/pest companies and rural custom applicators, including drone spray operators. FAA 14 CFR 137.71 records overlap. This is a candidate for a separate idea file once complaint evidence on ag-retail tools is gathered.

## Where to sell
- **Associations & events** (names from knowledge, verify dates):
  - Hospitality Minnesota (restaurants, lodging, resorts, campgrounds)
  - Congress of Minnesota Resorts
  - Housing First Minnesota
  - Minnesota Realtors
  - MNCPA, the Minnesota Society of CPAs
  - Minnesota State Bar Association
  - Minnesota Dental Association (Star of the North, spring)
  - Minnesota Veterinary Medical Association
  - Minnesota Home Care Association
  - Minnesota Licensed Family Child Care Association and the Minnesota Child Care Association
  - Minnesota Nursery & Landscape Association (Northern Green expo, January)
  - Minnesota Crop Production Retailers (winter ag expo)
  - Minnesota Council of Nonprofits
- **Online communities:** r/TwinCities, r/Minneapolis, r/saintpaul, r/minnesota, r/duluth, r/rochestermn. Minnesota family child care provider Facebook groups (verify). Local BNI chapters.
- **Partners:**
  - The Minnesota SBDC network
  - Launch Minnesota (DEED)
  - CCR&R agencies and Think Small, which serves child-care providers (verify)
  - Payroll-savvy CPAs, now fielding Paid Leave questions
  - Roofing supply houses (ABC Supply, SRS branches)
  - Regional banks and credit unions

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **Freedom-to-read law (2024)** | Covers school and public libraries ([Book Riot, Aug 2026](https://bookriot.com/massachusetts-passes-freedom-to-read-law/); [EdWeek, Jan 7 2026](https://www.edweek.org/policy-politics/states-are-banning-book-bans-will-it-work/2026/01)). Bill number and policy requirements not confirmed this pass (verify) | 2024 (verify) | R01, R03 |
| **Science of reading: READ Act (2023; amended 2024)** | The Act ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/minnesota/)):<br>• **bans three-cueing**;<br>• keeps an approved curriculum list with 4 alignment ratings;<br>• requires universal K–3 screening, plus screening for students in grade 4 and up who read below grade level, including dyslexia signs;<br>• requires intervention until each student reads at grade level.<br>**Deadlines:**<br>• **2026–27:** districts may use only evidence-based interventions and must have district literacy leads.<br>• **Jul 1 2027:** license renewal requires approved structured-literacy training.<br>• Training for K–3 teachers, special-education teachers, interventionists and administrators runs 2023–26. | 2026–27 and Jul 1 2027 | P01, R08 |
| **3rd-grade reading plan or retention law** | No retention. The READ Act requires ongoing intervention and parent communication, and personal learning plans are reported (verify) | n/a | P02 (moderate) |
| **Homeschool: HSLDA "Moderate regulation"** | Notice, teacher-qualification, subject, assessment and immunization rules all apply ([HSLDA Minnesota](https://hslda.org/legal/minnesota)). Annual report due Oct 1 and yearly standardized testing (verify). HSLDA tracks recent bills SF 4458 and HF 3239/SF 3439 (content not confirmed) | In force | P03 |
| **K–12 Education Credit and subtraction (tax, no ESA)** | **Credit** (Form M1ED; income limits by federal adjusted gross income, AGI): **$81,820** for 1–2 children, **$84,820** for 3, and **$87,820 plus $3,000 per extra child** for 4 or more. **Subtraction** (no income limit): up to **$1,625 per K–6 child** and **$2,500 per grade 7–12 child**. **Itemized receipts and invoices are required**, and one expense cannot be claimed twice ([MN Revenue](https://www.revenue.state.mn.us/k-12-education-subtraction-and-credit)). The credit rate and per-child cap are reported as 75% and $1,000 (verify). Minnesota is not in the federal tax-credit scholarship (IRS, Jun 8 2026) | Every tax season (2027 filing for 2026 spending) | **P07**, P04, P03, R05 |
| **Other: subscriptions** | A Minnesota automatic-renewal law is reported (verify) | — | P07, R08 |

**Top 3 reading/education ideas here:**
- **P07 LearnLedger:** Minnesota is the clearest receipt-tracking state here. Tutoring, books and learning-spend receipts feed a credit (income-limited) and a subtraction (open to all) every tax season.
- **P01 PhonicsPrep:** READ Act deadlines put evidence-based-only interventions in 2026–27 and structured-literacy license renewal on Jul 1 2027.
- **R08 Readlings:** universal K–3 screening and the three-cueing ban create demand for decodable home practice.

**Where to sell:**
- **Libraries:** Minnesota Library Association (fall conference; verify) and the Minnesota Educational Media Organization (MEMO; verify).
- **Parents:** Minnesota PTA.
- **Homeschool:** Minnesota Association of Christian Home Educators (MÂCHÉ; verify).
- **Reading specialists:** IDA Upper Midwest branch and The Reading League Minnesota (both verify).
- **Booksellers:** MIBA (verify).

## Launch verdict
**Speed:** Fast. **First city:** Minneapolis–St. Paul. **Lead offer:** F05 RollCall as the state-only wedge ("CCAP-proof attendance, audit packet in one click"), with B04 FirstCall as the volume play for Twin Cities trades going into the Oct–Feb off-season. J03/G04 are a strong follow-on: pitch a "MN Paid Leave + ESST + pay-transparency compliance kit" before the Jan 1 2027 payroll switch window.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Minnesota](https://advocacy.sba.gov/wp-content/uploads/2025/06/Minnesota_2025-State-Profile.pdf)
- [Minn. Stat. §268B.14, Paid Leave premiums (Revisor)](https://www.revisor.mn.gov/statutes/cite/268B.14)
- [Minn. Stat. §181.173, pay transparency (Revisor)](https://www.revisor.mn.gov/statutes/cite/181.173)
- [Minn. Stat. §325D.44, including subd. 1a all-in pricing (Revisor)](https://www.revisor.mn.gov/statutes/cite/325D.44)
- [Minn. Stat. §18B.37, pesticide recordkeeping (Revisor)](https://www.revisor.mn.gov/statutes/cite/18B.37)
- [MN DCYF Federal Funding Action Tracker (CCDF freeze rescinded Jul 8)](https://dcyf.mn.gov/federal-funding-action-tracker)
- [HHAeXchange Minnesota EVV info hub](https://www.hhaexchange.com/info-hub/minnesota)
- [ACF 2026 CCDF Final Rule (via F05)](https://acf.gov/occ/law-regulation/2026-ccdf-final-rule)
- [Seyfarth: federal website accessibility filings 2025 (via J02)](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)
- [14 CFR 137.71, agricultural aircraft operator records (eCFR)](https://www.ecfr.gov/current/title-14/chapter-I/subchapter-G/part-137/subpart-D/section-137.71)
- Internal: ../ideas/F05, G04, J02, J03, E07, C02, C03, B04 idea files; ../_state_leads_from_category_research.md
- [MN Department of Revenue: K-12 Education Subtraction and Credit](https://www.revenue.state.mn.us/k-12-education-subtraction-and-credit)
- [The Reading League Compass: Minnesota](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/minnesota/)
- [HSLDA: Minnesota homeschool law](https://hslda.org/legal/minnesota)
- [Book Riot: Massachusetts passes freedom-to-read law, with list of states (Aug 2026)](https://bookriot.com/massachusetts-passes-freedom-to-read-law/)
- [EdWeek: States are banning book bans (Jan 7 2026)](https://www.edweek.org/policy-politics/states-are-banning-book-bans-will-it-work/2026/01)
- [IRS: Federal scholarship tax credit participating states (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
