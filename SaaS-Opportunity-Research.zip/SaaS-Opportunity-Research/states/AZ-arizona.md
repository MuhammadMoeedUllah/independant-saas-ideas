# Arizona (AZ): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** **706,640** small businesses, 99.5% of all Arizona firms. They employ **1.2 million** people, or **42.6%** of Arizona employees. **585,251** of them have no employees ([SBA Advocacy 2026 Arizona profile, Sep 2026](https://advocacy.sba.gov/wp-content/uploads/2026/09/Arizona.pdf)). The 2025 profile is [here](https://advocacy.sba.gov/wp-content/uploads/2025/06/Arizona_2025-State-Profile.pdf).
- **New-business momentum:**
  - Small businesses opened **26,411** establishments between Mar 2024 and Mar 2025. That is the most of any state in this batch, more than CO (15,114) and UT (15,459).
  - Small businesses added **11,425** net jobs, **60.0%** of Arizona's net job growth ([SBA 2026 profile](https://advocacy.sba.gov/wp-content/uploads/2026/09/Arizona.pdf)).
  - Largest small-business employers:
    - Health care and social assistance: 193,567 employees
    - Accommodation and food services: 174,464
    - Construction: 150,178
- **Buyer clusters (estimate):**
  - **Phoenix metro** (Phoenix, Mesa, Chandler, Gilbert, Scottsdale, Glendale, Peoria): year-round HVAC, pool service, roofing, pest, solar, new-home construction, HOAs, salon suites, med-spas, golf, and ESA microschools.
  - **Tucson:** home services, health care, snowbird rentals.
  - **Yuma, Mesa/Apache Junction and Quartzsite:** snowbird RV parks and 55+ resorts, busy Oct–Apr.
  - **Sedona and Flagstaff:** tours, jeep and hiking operators, STRs, inns.
- **Industries overweight vs. US (estimate, from SBA mix plus climate):**
  - Construction and trades (heat-driven HVAC, pools)
  - Accommodation and food, plus seasonal tourism
  - Residential real estate and HOA management
  - Health care
  - K-12 school choice: the largest universal ESA in the US

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Universal ESA (Empowerment Scholarship Account)**: **106,253 students enrolled for 2026–27** as of 9/21/2026. Funds flow through ClassWallet. A new **Resident Verification Program** was announced (Nov 2025), and about 7,000 students missed renewal paperwork ([AZ Dept of Ed ESA page](https://www.azed.gov/esa)). | Microschools, private schools, tutors, therapists and curriculum vendors paid through ClassWallet | Ongoing; quarterly funding. 2026–27 year now running | **F06** ESA Desk, **F07** LessonLedger |
| **State Treasurer procurement for an ESA fraud and misspending tracking vendor.** Responses were due **Jul 29 2026** ([AZ Capitol Times, Jun 5 2026](https://azcapitoltimes.com/news/2026/06/05/state-treasurer-seeks-esa-vendor-to-track-misspending-fraud/), via F06). More audit scrutiny means vendors need clean, itemized invoices. | ESA vendors and schools | Award/rollout FY2027 (verify) | **F06**, **F07** |
| **HB 2397 (2026), HOAs: property covenants and disclosures.** The introduced text requires resale documents within **10 calendar days**, adds disclosure of **any outstanding unresolved violation**, and caps fees at **$400** (disclosure), **$100** (72-hour rush) and **$50** (update after 30 days), collected once at closing. It also caps regular assessment increases at 20% without a member vote, and late charges at $15 or 10% ([azleg.gov introduced text](https://www.azleg.gov/legtext/57leg/2R/bills/HB2397P.htm)). The H02 tracker lists it as effective **Sep 12 2026**. The [House-engrossed text](https://www.azleg.gov/legtext/57leg/2R/bills/HB2397H.htm) keeps the 10-day delivery and the $400/$100/$50 fee caps, but the $15/10% late-charge cap does not appear in it. Whether it was enacted, and the Sep 12 date, remain unverified (verify), because the azleg bill-status page blocks automated fetches. | Self-managed HOAs and condos, small CAM firms, title/escrow | Sep 12 2026 (verify) | **H02** BoardBinder (resale-packet generator) |
| **20-day preliminary notice** for mechanics' liens (A.R.S. 33-992.01). Lien 120 days; enforce within 6 months (per [C06 table](../ideas/C06-lien-deadlines-notices-waivers.md)). | Subs and suppliers in AZ's construction boom (150k small-biz construction employees) | Every job | **C06** LienClock |
| **FTC Rule on Unfair or Deceptive Fees** (short-term lodging, live-event tickets) ([FTC](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)) | RV parks, resorts, STRs, event organizers | Since May 12 2025 | **D06** SiteLoop, **H03**, **I04** |
| **STR permits and TPT licensing.** Cities may require an STR permit plus a state TPT license (A.R.S. 9-500.39) (verify). | Scottsdale, Sedona and Phoenix STR hosts and co-hosts | Ongoing | **H03** StayDesk |
| **Minimum wage and earned paid sick time** (Prop 206). State minimum $15.15 in 2026 (US DOL); Flagstaff is higher. A $3 tip credit is allowed (verify). | Restaurants, salons, home-care agencies | Jan 1 each year | **D04** ShiftTip, **G04** StatePay |
| **FinCEN BOI domestic exemption, final Aug 11 2026** (federal; [FinCEN](https://www.fincen.gov/boi), via J06). ACC annual reports still apply to corporations (verify). | All LLCs and corporations paying "compliance" upsells | Now | **J06** LicenseLedger |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **B04** | FirstCall (owned lead capture vs Angi/Thumbtack/LSA) | Phoenix HVAC, pool, roofing and plumbing shops run year-round and buy leads heavily. The B04 file puts Phoenix among the high-cost lead metros. Oct–Mar is the shoulder season when owners have time to fix lead flow before 115°F summer. Scoreboard 23. |
| 2 | **F06** | ESA Desk (microschool/ESA billing) | 106,253 ESA students is the largest universal ESA pool in the US. ClassWallet reimbursement delays, the new resident-verification program and the Treasurer's fraud-tracking procurement all push vendors toward audit-ready invoicing. Microschool founders buy with a card. |
| 3 | **A03** | LocalLoop (reviews and texting vs Podium/Birdeye) | Many dense home-service and med-spa owners who were sold Podium/Birdeye annual contracts. There are 26k small-business openings a year. Scoreboard 22. |
| 4 | **C01** | FlatRate (FSM vs ServiceTitan/Housecall Pro) | HVAC is the definitive Phoenix trade: emergency no-cool calls, membership plans and huge summer peaks. Winter is the switch window. |
| 5 | **F01** | Chairly (salon/barber booking vs Vagaro/Fresha) | The F01 file lists Phoenix as a salon-suite-heavy Sun Belt metro. Scoreboard 22. Suite renters are solo owners who switch in a day. |
| 6 | **H02** | BoardBinder (HOA portal plus resale packets) | HB 2397 fee caps and 10-day delivery (verify enacted text) turn resale disclosures into a timed workflow. Phoenix's master-planned communities are full of self-managed HOAs and small CAM firms. |
| 7 | **C06** | LienClock (lien deadlines) | The 20-day preliminary notice lands on every job, and small-business construction employment in AZ is 150k. Subs and suppliers lose lien rights on missed notices. |

Runners-up: **C04** RouteBook (Phoenix pool routes), **D06** SiteLoop (snowbird RV parks), **F07** LessonLedger (ESA tutors), **D08** TeeFree (Scottsdale golf).

## State-only opportunities
1. **ESA vendor "get paid" desk (F06 or F07 variant for ClassWallet).** Arizona is the only state with 100k+ universal-ESA students on ClassWallet. A lightweight ClassWallet invoice and receipt pack sells to tutors, therapists and microschools: itemized invoices, a pre-submit rejection checker and an audit binder, at $19–39/mo. This is the first market for F06 and F07, not a separate idea file.
2. **Snowbird RV park season kit (D06 variant).** Yuma, Mesa and Quartzsite parks book monthly and seasonal stays Oct–Apr. They need all-in pricing (FTC short-term lodging rule), metered electric billing per site and waitlists for returning snowbirds. **Sell Aug–Oct.** We are at the end of that window now, so target the 2027 renewals.
3. **Phoenix pool route plus water-chemistry log (C04 variant).** Phoenix and Las Vegas are the densest year-round pool routes in the US (estimate). Chemical logs, green-to-clean upsells and monsoon cleanups make a sharper pitch than generic route software. Bundle with B04.

## Where to sell
- **Associations & events (verify names/dates):**
  - Arizona Restaurant Association
  - Arizona Lodging & Tourism Association (AzLTA)
  - Arizona Association of REALTORS
  - Home Builders Association of Central Arizona
  - Arizona Society of CPAs
  - State Bar of Arizona
  - Arizona Dental Association
  - Arizona Pest Professional Organization
  - Arizona Roofing Contractors Association
  - CAI Central Arizona Chapter and the Arizona Association of Community Managers (HOA/CAM)
  - Arizona Travel Parks Association (RV parks)
  - Independent Pool & Spa Service Association (IPSSA) Arizona chapters
  - Arizona Charter Schools Association and ESA parent/vendor fairs
- **Online communities:**
  - Reddit: r/phoenix, r/arizona, r/tucson, r/scottsdale, r/HVAC, r/pools
  - Facebook: "Arizona ESA Families" (per F06) and Phoenix contractor and salon-suite groups
  - Nextdoor business pages in Gilbert, Chandler and Queen Creek
- **Partners:**
  - Arizona SBDC Network (Maricopa Community Colleges) and Local First Arizona, a large independent-business network (verify)
  - Supply houses: Johnstone, Ferguson, POOLCORP/SCP and Leslie's (Phoenix is Leslie's HQ; verify)
  - Desert Financial Credit Union
  - Bookkeepers who serve ESA microschools

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law | No statewide school library-materials law is in our lead lists (verify). Policy is set district by district: for example, Queen Creek USD adopted a library policy in 2026 that gives the superintendent oversight authority ([Book Riot, Apr 17 2026](https://bookriot.com/dollys-imagination-library-state-funding/)). | District-level, 2026 | R01 (district policy packs), R07 |
| Science of reading / three-cueing law | AZ is not on the lead list's three-cueing-ban or approved-curriculum lists (verify against the [EdWeek tracker](https://www.edweek.org/teaching-learning/which-states-have-passed-science-of-reading-laws-whats-in-them/2022/07), which counts 43 states plus DC as of Aug 2026). | — | P01, R08 |
| 3rd-grade reading plan / retention law | Mandatory-retention state ("Move On When Reading"; verify statute and good-cause exemptions). Charter-dense Phoenix is a P02 launch metro (per P02). | In force | P02 |
| Homeschool rules (HSLDA tier: **low**) | One option. Notice is required (an affidavit of intent; filed with the county school superintendent, verify deadline). State-mandated subjects: yes. No testing and no teacher qualifications ([HSLDA AZ](https://hslda.org/legal/arizona)). ESA students sign an ESA contract instead and may not be enrolled in a public or charter school, even part-time ([Outschool AZ guide](https://outschool.com/esa-guides/arizona-empowerment-scholarship)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **Empowerment Scholarship Account: 106,253 students as of 9/21/2026** ([ADE ESA](https://www.azed.gov/esa)). The general-education award is "often described around $7,000 a year", with more for IEP/504 students. Quarterly deposits go into **ClassWallet**, and unused funds roll over. Allowed uses include "private tuition, curriculum, online classes, tutoring, educational therapies, testing, educational technology, microschools". Outschool is an approved ClassWallet vendor paid directly from the ESA ([Outschool AZ guide, Sep 16 2026](https://outschool.com/esa-guides/arizona-empowerment-scholarship); vendor-written, verify amounts). Oversight is tightening: a resident-verification program, about 7,000 students who did not renew, and the Treasurer's fraud and misspending tracking procurement (see the laws table above). | 2026–27 year running; quarterly funding | P03, P04, P07, R05, R08 |
| Other | No 529 conformity issue (AZ is not on the 13-state list). No state Imagination Library funding found in this pass. | — | P06 (weak) |

**Top 3 reading/education ideas here:**
- **P04 ClassHouse:** 106k ESA students with about $7k each is the largest universal ESA pool. Independent teachers need a ClassWallet-payable class storefront so they don't have to hand Outschool its cut.
- **P07 LearnLedger:** families need a receipt vault and an audit trail as the Treasurer and ADE tighten fraud checks and resident verification.
- **P03 HomeRoll:** it tracks the affidavit-vs-ESA-contract choice, required subjects and ESA quarterly spend records.
- **Bench:** P02 (Move On When Reading, Phoenix charter networks).

**Where to sell:**
- **Libraries:** Arizona Library Association (AzLA; annual conference, fall/winter; verify) and its school-library/teacher-librarian division (verify name).
- **Parents:** Arizona PTA and Arizona Families for Home Education (AFHE convention, summer; verify).
- **ESA:** ESA parent Facebook groups ("Arizona ESA Families", per F06).
- **Reading:** IDA Arizona branch and The Reading League Arizona (verify).
- **Booksellers:** MPIBA (Mountains & Plains Independent Booksellers Association).

## Launch verdict
**Speed:** Fast. **First city:** Phoenix (East Valley: Mesa, Gilbert, Chandler).

**Lead offer:** **B04 FirstCall** for HVAC, pool and roofing shops. The hook: "Stop renting leads before summer 2027: own your missed-call text-back and quote page, with a free Angi/Thumbtack contract exit review." Run a parallel wedge of **F06 ESA Desk** for microschools with a "ClassWallet-ready invoices + audit binder" offer, timed to Q2/Q3 funding.

## Sources
- [SBA Office of Advocacy, 2026 Small Business Profile: Arizona (Sep 2026)](https://advocacy.sba.gov/wp-content/uploads/2026/09/Arizona.pdf)
- [SBA Office of Advocacy, 2026 profiles landing page (Sep 17 2026)](https://advocacy.sba.gov/2026/09/17/2026-small-business-profiles-for-the-states-territories-nation/)
- [SBA Office of Advocacy, 2025 Arizona profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Arizona_2025-State-Profile.pdf)
- [Arizona Dept of Education, ESA program page (enrollment as of 9/21/2026)](https://www.azed.gov/esa)
- [Arizona Legislature, HB 2397 (57th Leg., 2nd Reg. Session) introduced text](https://www.azleg.gov/legtext/57leg/2R/bills/HB2397P.htm)
- [AZ Capitol Times: State treasurer seeks ESA vendor to track misspending, fraud (Jun 5 2026)](https://azcapitoltimes.com/news/2026/06/05/state-treasurer-seeks-esa-vendor-to-track-misspending-fraud/) (via idea F06)
- [FTC: Rule on Unfair or Deceptive Fees takes effect May 12 2025](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)
- [FinCEN BOI page (domestic exemption final Aug 11 2026)](https://www.fincen.gov/boi) (via idea J06)
- Internal: ideas B04, C01, C04, C06, D06, F01, F06, F07, H02 and `_scoreboard.csv`
- [HSLDA: Arizona homeschool laws](https://hslda.org/legal/arizona)
- [Outschool: Arizona ESA 2026–27 eligibility and funding (Sep 16 2026)](https://outschool.com/esa-guides/arizona-empowerment-scholarship)
- [Book Riot: Book Censorship News, Apr 17 2026 (Queen Creek USD policy)](https://bookriot.com/dollys-imagination-library-state-funding/)
- [Education Week: science-of-reading law tracker (updated Aug 27 2026)](https://www.edweek.org/teaching-learning/which-states-have-passed-science-of-reading-laws-whats-in-them/2022/07)

## Verification (Sep 24 2026)
- ✅ ESA enrollment is "106,253" students "as of 09/21/2026". "7,000 students who were eligible to renew contracts did not submit required information", and a Resident Verification Program announcement from Nov 2025 is linked, along with ClassWallet info ([AZ Dept of Ed ESA](https://www.azed.gov/esa))
- ⚠️ HB 2397: the House-engrossed text confirms 10-day delivery and the $400 / $100 (72-hour rush) / $50 (update after 30+ days) caps, plus a 20%-per-year increase limit. The $15/10% late-charge cap is not in it. Final passage and the Sep 12 2026 effective date could not be confirmed because the bill-status page is robots-blocked ([HB2397 House engrossed](https://www.azleg.gov/legtext/57leg/2R/bills/HB2397H.htm))
- ✅ A.R.S. 33-992.01: the preliminary 20-day notice is due "not later than twenty days after the claimant has first furnished". A late notice covers only work from 20 days before it was served ([A.R.S. 33-992.01](https://www.azleg.gov/ars/33/00992-01.htm))
- ✅ The 2026 state minimum wage is $15.15. The $3 tip credit was not checked ([US DOL](https://www.dol.gov/agencies/whd/minimum-wage/state))
