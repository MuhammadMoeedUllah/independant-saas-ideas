# Virginia (VA): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 880,366 small businesses (99.6% of VA businesses), employing 1.6 million people (45.9% of private employees). 722,562 are nonemployer firms ([SBA Advocacy 2025 VA profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Virginia_2025-State-Profile.pdf)).
- **New-business momentum:**
  - From Mar 2023 to Mar 2024, small firms opened 31,514 establishments and closed 28,134.
  - Small businesses created a net 34,814 jobs (79.2% of the total).
  - Small-business employment grew 21.2% from 1998 to 2022, faster than the national rate ([SBA Advocacy 2025](https://advocacy.sba.gov/wp-content/uploads/2025/06/Virginia_2025-State-Profile.pdf)).
  - Census BFS trend was not fetched in this pass.
- **Buyer clusters** (estimate, verify):
  - **Northern Virginia** (Fairfax, Arlington, Loudoun, Prince William): federal contractors and IT consultancies, associations (Alexandria), affluent home-services demand, med spas, restaurants.
  - **Richmond:** professional services, health care, restaurants, trades.
  - **Hampton Roads** (Virginia Beach, Norfolk, Newport News): military families, beach STRs, tours, marine trades.
  - **Charlottesville, Shenandoah and Loudoun wine country:** wineries, breweries, agritourism.
  - **Southwest VA and Roanoke:** trades, trucking.
- **Industries overweight vs. US** (SBA; comparison is an estimate):
  - **Professional, scientific & technical services:** 136,539 small firms and 258,843 small-business employees, the #1 small-business employer. The govcon effect.
  - **Health care:** 218,609 small-business employees.
  - **Accommodation & food services:** 208,748 small-business employees.
  - **Wineries and agritourism:** the Virginia Wineries Association is named in J05.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Junk-fee / total-cost disclosure.** VCPA § 59.1-200(A)(79) bans "failing to disclose the total cost of a good or continuous service… including any mandatory fees or charges, prior to entering into an agreement" ([Code of Virginia](https://law.lis.virginia.gov/vacode/title59.1/chapter17/section59.1-200/)). | Hotels, short-term rentals, campgrounds, tours, ticket sellers, gyms, restaurants with mandatory service fees | In force Jul 1 2025 (date per lead list; verify) | D05, D06, D07, I04, H03, F02 |
| **Minimum wage:** $12.77/hr through Dec 31 2026, rising to **$13.75/hr on Jan 1 2027** ([VA DOLI](https://www.doli.virginia.gov/)) | All VA employers, especially restaurants, retail and child care | Jan 1 2027 | J03, G04, D04 |
| **Seizure first-aid poster.** One of five mandatory poster changes in Sep 2026 ([Poster Guard](https://www.posterguard.com/), via J03) | All VA employers | Sep 2026 | J03 |
| **Paid family & medical leave:** contributions Apr 1 2028, benefits Dec 1 2028; employers with 10 or fewer employees exempt from the employer premium ([OnPay, Jul 2026](https://onpay.com/insights/paid-family-leave-by-state/)) | All VA employers | 2028 (prep during 2027) | G04 |
| **Automatic-renewal / continuous-service rules** (VCPA § 59.1-200 items 58 and 89, Chapter 17.8) ([Code of Virginia](https://law.lis.virginia.gov/vacode/title59.1/chapter17/section59.1-200/)) | Gyms, car-wash clubs, subscription boxes, SaaS sold to consumers | In force | F02, K06 |
| **Certified-payroll work group** (HB 569 / SB 518), convened by DOLI in 2026 ([VA DOLI](https://doli.virginia.gov/2026/08/30/certified-payroll-work-group-hb569-sb-518/)) | Public-works contractors (prevailing-wage reporting) | 2026–27 (watch) | C01, G04 |
| **Consumer Data Protection Act** (J02) | Businesses over the thresholds | In force Jan 1 2023 | J02 |
| **CMMC.** Paused in Phase 1; Phase II suspended Jul 13 2026 ([DoD CIO](https://dodcio.defense.gov/CMMC/About/)) | NoVA defense subcontractors | Paused | (watch); L05 for Jira DC holdouts |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture) | Top score (23). NoVA has some of the highest home-services spend per household in the US (estimate), and Google LSA's dispute removal hurts VA contractors. |
| 2 | A03 | LocalLoop (reviews + texting) | Large base of health-care small businesses (218k employees) and trades. Universal fit. |
| 3 | F01 | Chairly (salon/barber booking) | NoVA and Richmond salons, many immigrant-owned. Commission and payout pain. |
| 4 | D07 | BookTrail (FareHarbor/Peek alternative) | VA's total-cost law plus the FTC fees rule make all-in pricing a compliance selling point. Virginia Beach tours, Shenandoah outfitters and winery tours. FareHarbor's 6% guest fee and the 2026 platform change. Off-season (Oct–Mar) is the switch window. |
| 5 | L02 | Studioboard (flat-price project management) | 136,539 small professional-services firms (govcon subs, consultancies) hit by monday/Asana/ClickUp seat blocks and AI credits. |
| 6 | J03 | PostedUp (posters + pay rules) | Sep 2026 seizure-poster change, the Jan 1 2027 minimum-wage step and 2028 paid leave. Every VA employer must update, and poster vendors upsell. |
| 7 | I03 | DuesDesk (membership associations) | Alexandria/Arlington is part of the DC association cluster, and Virginia has many chambers. WildApricot price hikes. |

## State-only opportunities
1. **"Virginia all-in pricing" checker for hospitality and tours** (D07/D05/D06 feature). It scans a booking page for mandatory fees shown late (resort fees, booking fees, service charges) and rewrites them to total-price displays. It works as a free lead magnet for BookTrail and InnDesk.
2. **Jan 1 2027 wage-change kit** for VA restaurants and child care (D04/J03). It updates schedules, cost forecasts and posters for $13.75. Timely, but a feature, not a company.
3. **Govcon small-business back office** (NoVA). Contractor-grade timekeeping, SAM renewals, CMMC Level 1 affirmation and SPRS reminders. The market is dense, but CMMC Phase II's suspension (Jul 13 2026) removed the 2026 forcing deadline. Not written up as S2.

## Where to sell
All names below are from background knowledge (verify).
- **Associations & events:**
  - Virginia Chamber of Commerce; Virginia Restaurant, Lodging & Travel Association (VRLTA).
  - Virginia Society of CPAs (VSCPA); Virginia State Bar and the Virginia Bar Association.
  - Home Builders Association of Virginia; Virginia Wineries Association (J05).
  - Northern Virginia Technology Council (NVTC); Fairfax County and Hampton Roads chambers.
  - Virginia Society of Association Executives.
- **Online communities:** r/nova, r/rva, r/virginiabeach, r/Virginia; NoVA home-services and "Northern Virginia small business" Facebook groups; Nextdoor (heavily used in NoVA suburbs).
- **Partners:** Virginia SBDC network (Mason SBDC at George Mason University and regional centers); Community Business Partnership (Springfield); VA community banks and credit unions (Navy Federal members in Hampton Roads); CPAs serving govcon subs.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials / freedom-to-read law | **SB 656 (2022)** requires parent notification and an opt-out before a teacher assigns classroom materials with "sexually explicit content." It doesn't mandate library removals ([PEN America, Dec 2025](https://pen.org/report/the-bills-igniting-book-bans/)). R07 lists Virginia among the 2025 freedom-to-read states (bill not identified; verify). | 2022 | R01, R07 |
| **Science-of-reading law: Virginia Literacy Act (2022)** | **Instruction:** evidence-based literacy instruction for the whole literacy block, with K–5 core programs taken from the state-approved list. **Screening:** literacy screeners in K–8. **Divisions:** each writes a literacy plan and staffs reading specialists ([VDOE](https://www.doe.virginia.gov/teaching-learning-assessment/k-12-standards-instruction/english-reading-literacy/literacy/virginia-literacy-act)). **Three-cueing:** APM Reports counts VA among the earlier bans (via R08). The VDOE page doesn't state it (verify statute). | In force since 2024–25 (verify) | P01, R08 |
| 3rd-grade reading plan / retention law | **No retention** ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)). The VLA requires **student reading plans**: "every family will... be able to participate in the development of their child's student reading plan." VDOE supplies family invitation and explanation letters in **English and Spanish** for K–3 and grades 4–8 ([VDOE](https://www.doe.virginia.gov/teaching-learning-assessment/k-12-standards-instruction/english-reading-literacy/literacy/virginia-literacy-act)). | Every screening window | P02 |
| Homeschool (HSLDA tier: verify; FreedomRankings: low-moderate) | Four options, notice required, assessment required under some options ([HSLDA](https://hslda.org/legal/virginia)). The dates (annual notice by Aug 15, evidence of progress by Aug 1) and the religious-exemption option are from background knowledge (verify). | Aug 1 / Aug 15 yearly (verify) | P03 |
| ESA / scholarship money | No ESA. There is a tax-credit scholarship program (Education Improvement Scholarships; verify). | n/a | (P07 via federal 529) |
| Other | No state Imagination Library funding was confirmed in this pass (verify). | n/a | P06 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home.** The VLA makes family participation in the reading plan a statewide expectation, and the letters are templated. There's no retention, so the pitch is engagement, not appeals.
- **P01 PhonicsPrep.** Evidence-based core plus intervention creates tutor and interventionist demand outside the approved-vendor contracts.
- **P03 HomeRoll.** The Aug 1 evidence-of-progress and Aug 15 notice deadlines are annual, fixed dates to build reminders around.

**Where to sell** (names from background knowledge; verify months):
- Virginia Library Association (fall) and Virginia Association of School Librarians (VAASL, fall).
- Virginia PTA.
- Home Educators Association of Virginia (HEAV) and its convention (June).
- IDA and The Reading League Virginia (verify).
- The regional bookseller association (verify: SIBA or NAIBA).

## Launch verdict
**Speed:** Medium (a big, wealthy market, but VA's forcing laws land later: wage Jan 2027, paid leave 2028). **First city:** Fairfax County / Northern Virginia. **Lead offer:** B04 FirstCall for NoVA contractors. Run D07 BookTrail's "Virginia all-in pricing" audit for Virginia Beach and Shenandoah operators during the Oct–Mar off-season.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Virginia](https://advocacy.sba.gov/wp-content/uploads/2025/06/Virginia_2025-State-Profile.pdf)
- [Code of Virginia § 59.1-200, prohibited practices](https://law.lis.virginia.gov/vacode/title59.1/chapter17/section59.1-200/)
- [Virginia DOLI homepage (minimum wage)](https://www.doli.virginia.gov/)
- [Virginia DOLI, certified payroll work group (Aug 30 2026)](https://doli.virginia.gov/2026/08/30/certified-payroll-work-group-hb569-sb-518/)
- [OnPay, paid family leave by state (Jul 2026)](https://onpay.com/insights/paid-family-leave-by-state/)
- [Poster Guard homepage (Sep 2026 poster changes)](https://www.posterguard.com/)
- [DoD CIO, About CMMC](https://dodcio.defense.gov/CMMC/About/)
- [VDOE: Virginia Literacy Act (reading plans, approved core programs, family letters)](https://www.doe.virginia.gov/teaching-learning-assessment/k-12-standards-instruction/english-reading-literacy/literacy/virginia-literacy-act)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [HSLDA: Virginia homeschool law](https://hslda.org/legal/virginia)
- Internal (education): ideas P01, P02, P03, R07, R08
