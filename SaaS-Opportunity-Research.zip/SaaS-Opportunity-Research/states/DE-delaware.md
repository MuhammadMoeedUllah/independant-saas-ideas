# Delaware (DE): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 111,346 small businesses (98.7% of DE businesses), employing 214,539 people (50.6% of private employees). 88,530 are nonemployer firms ([SBA Advocacy 2025 DE profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Delaware_2025-State-Profile.pdf)).
- **New-business momentum:**
  - From Mar 2023 to Mar 2024, 4,580 establishments opened and 3,753 closed (net +827).
  - Small businesses created a net 5,323 jobs (76.1% of the total).
  - Small-business employment grew 30.4% from 1998 to 2022, faster than the national rate ([SBA Advocacy 2025](https://advocacy.sba.gov/wp-content/uploads/2025/06/Delaware_2025-State-Profile.pdf)).
  - **The bigger story is legal entities, not local shops.** Delaware has more than 2.28 million entities, and 334,461 were formed in 2025 (235,393 LLCs, 74,716 corporations) ([DE Division of Corporations](https://corp.delaware.gov/stats/)).
- **Buyer clusters** (estimate, verify):
  - **Wilmington / New Castle County:** banks and credit-card operations, corporate law firms, registered-agent companies, professional services.
  - **Dover / Kent County:** government, logistics (Dover AFB), agriculture.
  - **Sussex County beaches** (Rehoboth, Lewes, Bethany): fast retiree-driven growth, home services, short-term rentals, restaurants, seasonal tours.
- **Industries overweight vs. US** (estimate):
  - Professional services: 17,099 small firms.
  - Real estate & rental/leasing: 13,316 small firms.
  - Transportation & warehousing: 12,249 small firms.
  - Corporate-services and legal industry: registered agents and incorporation services.
  - Beach hospitality and short-term rentals.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Delaware Paid Leave** ([DE Dept. of Labor](https://labor.delaware.gov/delaware-paid-leave/)):<br>• 9 or fewer employees are exempt.<br>• 10–24 employees must provide parental leave only; 25+ must provide all leave types.<br>• Funded by less than 1% of wages, and employers may charge employees up to half.<br>• Deductions started Jan 1 2025; claims opened Jan 1 2026.<br>• Benefits: up to 80% of wages, capped at $900/wk. | Employers with 10+ employees and their payroll providers | Live; quarterly hours & wage reports | G04, J03 |
| **Corporation annual report and franchise tax.** Due Mar 1. Late: $200 penalty plus 1.5%/mo interest. Minimum tax is $175 (Authorized Shares method) or $400 (Assumed Par Value Capital method). Taxpayers should use the method that gives the lesser tax ([DE Corporations](https://corp.delaware.gov/frtax/), [calc methods](https://corp.delaware.gov/frtaxcalc/)). | Every DE corporation, owned from anywhere | Mar 1 2027 | **S2-01**, J06 |
| **LLC/LP/GP annual tax: now $400** (earlier research listed $300; date of the increase: verify). Due Jun 1; late: $200 penalty plus 1.5%/mo ([DE Corporations](https://corp.delaware.gov/frtax/)). | 1M+ DE LLCs (estimate) | Jun 1 2027 | **S2-01**, J06 |
| **Foreign corporation annual report.** $250 filing fee, due Jun 30 ([DE Corporations](https://corp.delaware.gov/paytaxes/)). | Out-of-state corporations registered in DE | Jun 30 | J06 |
| **Deceptive-solicitation alert.** "Corporate Records Service" mailers ask DE corporations for $125 ([DE Corporations](https://corp.delaware.gov/frtax/)). | DE corporations | Ongoing | S2-01 |
| **Pay transparency:** a good-faith min–max range in postings ([J03 research](../ideas/J03-smb-employment-law-posters-pay-transparency-poster-guard-mineral-alternative.md); employer threshold: verify) | DE employers | Sep 26 2027 | J03 |
| **Delaware Personal Data Privacy Act** (J02) | Businesses over the thresholds | In force Jan 1 2025 | J02 |
| **Medicaid EVV:** Sandata, a closed model per the E07 table (verify) | Home-care agencies | Ongoing | E07 (weak fit) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | **S2-01** | ParCheck (DE franchise-tax and annual-report autopilot) | Exists only because of Delaware law. Buyers are 2.28M entities nationwide, with hard deadlines on Mar 1 and Jun 1. The LLC tax is now $400, and Authorized-Shares tax figures shock founders. |
| 2 | J06 | LicenseLedger (entity + license compliance) | The same entity-deadline pain, broadened to foreign qualifications and professional licenses. It sells to Wilmington law and accounting firms that manage many entities. |
| 3 | G04 | StatePay (payroll state-compliance copilot) | Paid Leave has been live since Jan 1 2026, with different rules at 10–24 vs 25+ employees and quarterly reports. Many small employers are confused about the tiering. |
| 4 | B04 | FirstCall (owned lead capture) | Sussex County's retiree growth drives demand for roofing, HVAC and remodeling. Highest scoreboard score (23). |
| 5 | A03 | LocalLoop (reviews + texting) | A universal SMB fit. Beach-town hospitality and clinics rely on reviews. |
| 6 | F01 | Chairly (salon booking) | High score (22), easy card sale. The market is small but reachable in a single sales push. |
| 7 | H03 | StayDesk (STR PMS) | The Rehoboth, Bethany and Lewes rental market. Airbnb's 15.5% host-only fee for PMS-connected hosts makes a cheaper PMS attractive (H03). |

## State-only opportunities
1. **Delaware franchise-tax and annual-report autopilot (written up as [S2-01](../ideas/S2-01-delaware-franchise-tax-annual-report-autopilot.md)).**
   - Every DE corporation gets a franchise tax figure that can be dramatically higher under the Authorized Shares method than under the Assumed Par Value Capital method. From the official rate table, 10M authorized shares works out to about $85k versus a $400 minimum (our calculation).
   - Every LLC now owes $400 by Jun 1, and scam mailers target both groups.
   - Registered agents renew at up to $159/yr (Harbor Compliance) and don't compute the tax for you.
2. **Paid Leave tier helper for 10–24-employee firms.** It explains parental-only coverage, the employee cost share and quarterly filing. This is a G04 feature, not a standalone product.
3. **Beach-season STR and tour bundle** (H03 + D07) for Sussex County operators. The market is small, so bundle it rather than lead with it.

## Where to sell
All association names below are from background knowledge (verify).
- **Associations & events:**
  - Delaware State Chamber of Commerce; Delaware Restaurant Association.
  - Delaware Society of CPAs; Delaware State Bar Association (Corporation Law Section, for the S2-01 partner channel).
  - Home Builders Association of Delaware; Sussex County Association of REALTORS; Delaware Alliance for Nonprofit Advancement.
- **Online communities:** r/Delaware, r/rehoboth; national founder communities for S2-01: r/startups, r/Entrepreneur, r/smallbusiness, Indie Hackers, Hacker News.
- **Partners:** Delaware SBDC; Wilmington coworking and startup hubs; startup law firms and fractional CFOs nationwide (S2-01); licensed Delaware commercial registered agents, needed as S2-01's fulfillment partner; payroll accountants (G04).

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| Freedom-to-read law: **HB 119** (signed Sep 18 2025) | A transparent challenge process for materials in **school and public libraries** ([PEN America](https://pen.org/chance-conversation-with-pen-america-director-spurs-delaware-freedom-to-read-act/), via R01). The policy-adoption deadline is unconfirmed (verify). | Sep 2025 | R01, R07 |
| Science of reading / three-cueing law | Delaware is counted in EdWeek's 43 states plus DC with evidence-based reading laws or policies ([EdWeek tracker, Aug 2026](https://www.edweek.org/teaching-learning/which-states-have-passed-science-of-reading-laws-whats-in-them/2022/07)). Bill and provisions not confirmed (verify). | — | P01, R08 |
| 3rd-grade reading plan / retention law | Conditional-retention state (per the lead list; verify) | In force | P02 |
| Homeschool rules (HSLDA tier: **low**) | Three options. Notice is required. No testing, no state-mandated subjects, no teacher qualifications ([HSLDA DE](https://hslda.org/legal/delaware)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **None.** No ESA or voucher program was found. | — | — |
| Other | Statewide Imagination Library program (Delaware Libraries; verify funding and launch year). | — | P06 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf:** HB 119 covers both school and public libraries, so a single challenge-log and policy product fits about 19 districts plus the county and municipal library systems (count: verify).
- **P02 ReadingPlan Home:** it handles parent notices in a conditional-retention state (thin; verify rules).
- **P03 HomeRoll:** it covers the three notice-based options.
- DE is a small market for all of these. Use it as a test for the freedom-to-read pack, not a launch state.

**Where to sell:**
- **Libraries:** Delaware Library Association (conference, spring; verify), the Delaware Division of Libraries, and the Delaware Association of School Librarians (verify).
- **Parents:** Delaware PTA and the Delaware Home Education Association (verify).
- **Reading:** IDA and The Reading League (DE chapter: verify).
- **Booksellers:** NAIBA (New Atlantic Independent Booksellers Association; verify DE coverage).

## Launch verdict
**Speed:** Medium. The local market is small, but the entity-tax product sells nationally and fast. **First city:** Wilmington, the legal/finance hub and the partner base for S2-01. **Lead offer:** S2-01 ParCheck, a free "check your Delaware franchise tax before you pay" calculator from Dec 2026 to Mar 1 2027, upselling a $49/yr autopilot.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Delaware](https://advocacy.sba.gov/wp-content/uploads/2025/06/Delaware_2025-State-Profile.pdf)
- [DE Division of Corporations, statistics (2025 annual report)](https://corp.delaware.gov/stats/)
- [DE Division of Corporations, annual report and tax information](https://corp.delaware.gov/frtax/)
- [DE Division of Corporations, how to calculate franchise tax](https://corp.delaware.gov/frtaxcalc/)
- [DE Division of Corporations, pay taxes / file annual report](https://corp.delaware.gov/paytaxes/)
- [Delaware Department of Labor, Delaware Paid Leave](https://labor.delaware.gov/delaware-paid-leave/)
- [OnPay, paid family leave by state (Jul 2026)](https://onpay.com/insights/paid-family-leave-by-state/)
- [HSLDA: Delaware homeschool laws](https://hslda.org/legal/delaware)
- [PEN America: Delaware Freedom to Read Act (Sep 2025)](https://pen.org/chance-conversation-with-pen-america-director-spurs-delaware-freedom-to-read-act/) (via R01)
- [Education Week: science-of-reading law tracker (updated Aug 27 2026)](https://www.edweek.org/teaching-learning/which-states-have-passed-science-of-reading-laws-whats-in-them/2022/07)
