# Texas (TX): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:**
  - 3.5 million small businesses, which are 99.8% of Texas businesses.
  - 5.1 million small-business employees, which is 44.4% of Texas private-sector employees ([SBA Advocacy 2025 Texas profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Texas_2025-State-Profile.pdf)).
  - Ownership: women own 44.9% of businesses, **Hispanic owners 33.0%** and veterans 5.6% (same source). A Spanish-language interface and SMS templates count as a real selling point here.
- **New-business momentum:**
  - Mar 2023–Mar 2024: small businesses opened 80,833 establishments and closed 72,611.
  - Small firms added a net 148,641 jobs, which is 84.0% of the state's 176,889 net new jobs.
  - Banks lent $8.6B to businesses with revenue under $1M in 2023 (same SBA profile).
  - Census BFS state-level application counts could not be pulled in this pass. Texas being the #1 or #2 state by business applications is background knowledge (verify).
- **Buyer clusters:**
  - **Dallas–Fort Worth:**
    - Hail and storm roofing; storm-chasing companies base themselves here (C02).
    - HVAC, trucking and logistics (the GATS truck show is held in Dallas in August), franchise HQs, salon suites, and suburban private schools and microschools.
  - **Houston:** HVAC and plumbing, energy and petrochemical contractors, hurricane and flood restoration, med spas, independent restaurants, and a large Hispanic-owned business base.
  - **Austin:** creators, agencies and SaaS, med spas, microschools and private schools, and Hill Country wineries and short-term rentals (STRs).
  - **San Antonio:** hail roofing, HVAC, military-adjacent services and tourism restaurants.
  - **Permian Basin (Midland–Odessa):** oilfield services and hot-shot trucking (verify local counts).
  - **Laredo and the Rio Grande Valley:** cross-border trucking. Winter-Texan RV parks (D06).
- **Industries overweight vs. US:** These shares are estimates from SBA small-business counts; the national comparison was not computed.
  - **Construction:** 428,901 small firms, #2 in the state.
  - **Transportation & warehousing:** 415,445 small firms, #3 in the state. That is an unusually high rank for this sector.
  - **Oil & gas field services** (verify).
  - **Storm and hail roofing:** Texas was #1 in the US for major hail events in 2025, with 902 events ([III hail facts, NOAA data](https://www.iii.org/fact-statistic/facts-statistics-hail)).
  - **HVAC:** long cooling season (inference).
  - **Private schools and microschools**, now funded by TEFA.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Texas Education Freedom Accounts (TEFA)**, year 1. $1B appropriated. 274,000+ applications and 100,000+ students awarded. Awards: $10,474 for private school, up to $30,000 for students with an IEP or disability, up to $2,000 for homeschool. Run by the Comptroller with **Odyssey** as the administrator (CEAO) ([TEFA](https://educationfreedom.texas.gov/)). Vendors include tutors, therapists, course providers and curriculum/tech sellers. They register on Odyssey's vendor portal and appear in a marketplace ([TEFA providers & vendors](https://educationfreedom.texas.gov/providers-vendors/)). | Accredited private schools with 2+ years of operation, microschools that qualify, tutors, speech/OT/ABA therapists, lesson providers | Private-school installments: 25% on Jul 1 2026, **25% on Oct 1 2026** and **50% on Feb 1 2027**. A 2027–28 interest list is open. | F06, F07, E06, I07 |
| **Lien law.** HB 2237 overhaul (Jan 1 2022). **SB 929** (signed May 21 2025, effective immediately) moves weekend and holiday deadlines to the next business day. SB 841 (trust-fund assignment), HB 2960 (Texas venue) and HB 3005 (public-pay audits) took effect Sep 1 2025. Notice deadlines are the 15th of the 2nd month for residential work and the 15th of the 3rd month for commercial work ([Texas Easy Lien, 2026](https://www.texaseasylien.com/blog/texas-lien-law-2026-what-every-contractor-needs-to-know-now/)). | Subcontractors, suppliers, GCs, remodelers | In force. Deadlines recur monthly. | C06, C05 |
| **HB 3749 "Jenifer's Law"** (elective IV therapy). Signed Jun 20 2025, effective Sep 1 2025 ([LegiScan](https://legiscan.com/TX/bill/HB3749/2025)). Records must show who ordered and who administered each treatment (details in E04). | Med spas, IV hydration bars | In force | E04 |
| **SB 1188** (EHR requirements, civil penalty). Signed Jun 20 2025, effective Sep 1 2025 ([LegiScan](https://legiscan.com/TX/bill/SB1188/2025)). The enrolled text requires EHRs to be physically maintained in the US or a US territory from **Jan 1 2026** (Health & Safety Code 183.002), and practitioners who use AI for diagnostic purposes must disclose it to patients (183.005). Civil penalties run $5,000 (negligent), $25,000 (knowing) and $250,000 (PHI used for financial gain) per violation ([enrolled SB 1188](https://capitol.texas.gov/tlodocs/89R/billtext/pdf/SB01188F.pdf)). | Every Texas practice that uses an EHR | Storage rule since Jan 1 2026 | E01, E02, E04, E08 |
| **HB 300** (Texas Medical Records Privacy Act). Covers more "covered entities" than HIPAA and requires staff training (verify details). | Clinics, med spas, wellness, and any business handling health information | In force | A01, E08 |
| **Consumable hemp.** DSHS emergency age-21 rules took effect Oct 2 2025. Fees: **$10,000 a year per location** for a manufacturer license and **$5,000 a year per location** for a retail registration. New rules took effect Mar 31 2026. The delta-8 scheduling change took effect **Jul 31 2026** ([DSHS](https://www.dshs.texas.gov/consumable-hemp-program)). The federal 0.4 mg cap arrives around Nov 2026 (J04). | Smoke, vape and CBD shops | Now. **The market is contracting.** | J04 (caution) |
| **TDLR non-consent towing caps.** Light-duty tow $272 and drop $135. Storage $21.03/day for vehicles 25 ft or shorter, $36.80 for longer ones. Impound fee $21.03. VSF-12/13 release forms have been required since Jul 4 2022 ([TDLR](https://www.tdlr.texas.gov/towing/towing.htm)). | Tow operators, vehicle storage facilities (VSFs) | In force. No fee change found for 2024–26. | K04 |
| **Property Code 207.006.** An owners' association with **60+ lots**, or any association that uses a management company, must post its dedicatory instruments on a website ([Tex. Prop. Code 207.006](https://texas.public.law/statutes/tex._prop._code_section_207.006)). | Self-managed HOAs/POAs, small HOA managers | In force (amended Sep 1 2021) | H02 |
| **TREC-promulgated contract forms** and the **TREC inspection report form** (REI 7-6; verify the current version, since the TREC site could not be fetched). | Agents, home inspectors | In force | H04, H05, A04 |
| **Texas Data Privacy & Security Act** (in force Jul 1 2024). SBA-defined small businesses are largely exempt, but they still need consent before selling sensitive data (verify). | Websites that collect or sell data | In force | J02 (weak here) |
| **Insurance Code limits on roofers.** Roofers may not waive or rebate deductibles (ch. 707), and contractors may not act as public adjusters (verify). | Storm roofers, restoration firms | In force | C02, C07 |
| **IFTA Q3 return** | Interstate carriers | Oct 31 2026 | K03 |
| **No state income tax and no state paid-leave program** | Payroll buyers | n/a. This makes G04 and J03 *weaker* in Texas. | (G04, J03) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture vs Angi, Thumbtack and Google LSA) | Highest national score (23). Texas has the most construction small businesses (428,901) and pays big-metro lead prices in DFW and Houston. Google ended LSA disputes in Nov 2025. We'd ship a bilingual EN/ES version. |
| 2 | F06 | ESA Desk (+ F07 LessonLedger as the tutor/therapist tier) | **TEFA year 1** means $1B and 100k+ students flowing through a brand-new Odyssey portal. Schools must reconcile the Oct 1 2026 and Feb 1 2027 installments against their own tuition ledgers. There's no incumbent default yet. |
| 3 | C01 | FlatRate (vs ServiceTitan, Housecall Pro, Jobber) | Long cooling season with dense HVAC and plumbing shops in DFW, Houston and San Antonio. **Oct–Feb is the off-season switch window, and it opens now.** ServiceTitan exit-fee stories resonate. TDLR publishes lists of licensed HVAC contractors for outreach (verify file). |
| 4 | C02 (+C07) | StormDesk + ClaimKit | Texas was #1 for major hail in 2025 (902 events). Storm-chasing companies cluster in DFW. Per-seat pricing hurts when a team adds canvassers after a storm. Sell in winter, before the spring 2027 hail season. |
| 5 | A03 | LocalLoop (vs Podium, Birdeye) | Dense Sun Belt home-service and clinic base. Podium and Birdeye 12-month auto-renewals. Bilingual review and text flows fit a market where 33% of owners are Hispanic. |
| 6 | K03 | HaulDesk (small-fleet back office) | Transportation is the #3 small-business sector (415,445 firms). Hot-shot and owner-operator density in DFW, Houston, Laredo and the Permian. IFTA is due Oct 31. GATS in Dallas is the annual meeting point. |
| 7 | C06 | LienClock (vs Levelset) | Texas monthly notice deadlines (15th of the 2nd or 3rd month) are uniquely unforgiving. SB 929 changed the calendar math in 2025. Our lead is a Texas-first deadline engine for subs and suppliers. |

Just outside the Top 7, each with a Texas-specific law hook: **E04** (HB 3749 chart audit), **H05** (TREC report form), **H02** (207.006 websites), **F01** (DFW and Houston salon suites), **K04** (TDLR caps).

## State-only opportunities
1. **TEFA "get-paid" pack.** Extends F06/F07; it isn't a new idea file, because both are already specced.
   - **Buyers:** private schools, microschools and TEFA vendors (tutors, speech/OT/ABA therapists).
   - **What it does:**
     - Maps each family's award tier ($10,474, up to $30,000 for students with disabilities, $2,000 for homeschool) to tuition.
     - Tracks the Jul 1, Oct 1 and Feb 1 installments.
     - Produces Odyssey-ready itemized invoices.
     - Chases the parent-owed remainder.
   - **Selling window:** fall 2026 (just after the Oct 1 installment) through Feb 1 2027, then the 2027–28 enrollment season.
   - **Reuse:** the same Odyssey logic serves Louisiana GATOR (see LA file).
2. **Texas storm-roofer compliance pack** (C02/C07 module):
   - Hail-date and ZIP canvassing.
   - Deductible-waiver warnings under Insurance Code ch. 707 (verify).
   - "No public-adjusting" guardrails in the supplement writer.
   - TDI windstorm WPI-8 certification documents for the 14 coastal counties (background knowledge, verify).
   - Texas has no statewide FORTIFIED grant that we could confirm. Oklahoma and Louisiana do (see ideas/S4-01).
3. **Texas clinic and med-spa compliance bundle** (E04 + E08). An HB 3749 "ordered by / administered by" chart audit, an SB 1188 US-hosting attestation (storage rule in force since Jan 1 2026), and HB 300 training logs. It sells best in the Houston, Dallas and Austin med-spa clusters.

Watch but don't lead with: hemp/THC retail (J04). The new DSHS rules and fees and the Jul 31 2026 delta-8 scheduling are shrinking the market rather than creating software buyers.

## Where to sell
- **Associations & events** (names are background knowledge; verify months and vendor programs):
  - **Construction and home services:** Texas Air Conditioning Contractors Association (TACCA), Roofing Contractors Association of Texas (RCAT), Texas Association of Builders.
  - **Restaurants and lodging:** Texas Restaurant Association (TRA Marketplace show), Texas Hotel & Lodging Association.
  - **Real estate:** Texas REALTORS, TPREIA (inspectors).
  - **Professional services:** TXCPA, State Bar of Texas solo/small-firm section, Independent Insurance Agents of Texas.
  - **Health and personal care:** Texas Dental Association, TVMA (vets), Texas Association for Home Care & Hospice, AmSpa Texas med-spa action center.
  - **Education and childcare:** Texas Private Schools Association, Texas Home School Coalition, Texas Licensed Child Care Association.
  - **Transport:** Texas Trucking Association, GATS (Dallas, August), Texas Towing & Storage Association.
- **Online communities:**
  - **Reddit:** r/Dallas, r/FortWorth, r/houston, r/Austin, r/sanantonio, r/texas, r/HVAC and r/Roofing (Texas-heavy threads).
  - **Facebook groups:** TEFA parent and provider groups (e.g. "Texas Education Freedom Accounts parents and providers", named in F06), and Texas microschool founder groups.
  - **Local networks:** Nextdoor business pages and BNI chapters in DFW and Houston.
- **Partners:**
  - **Texas SBDC networks:** four regional networks (North Texas/Dallas, Houston, South-West Texas Border/UTSA, Northwest Texas/Lubbock) (verify).
  - **Chambers:** Hispanic chambers in Houston, Dallas and San Antonio, plus Greater Houston Partnership and Dallas Regional Chamber.
  - **Supply houses:** HVAC (Johnstone, Carrier Enterprise/Watsco, Ferguson) and roofing (ABC Supply, SRS, QXO/Beacon) branch counter days.
  - **Others:** TXCPA members who serve contractors, FORTIFIED and TDI windstorm engineers for coastal roofers, and Odyssey-listed TEFA vendors (cross-referral).

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials law: SB 13 (2025)**, layered on **HB 900 (2023)** | **Purchasing:** the list of materials proposed for purchase or donation must be open for public review for **30 days**, and the school board then approves them in an open meeting. **Advisory council:** a School Library Advisory Council becomes mandatory once the lesser of **10% or 50** of the district's parents petition. The council needs at least 5 members, and a majority must be parents. **Challenges:** filed on a TEA form. The board must decide within **90 days**, students may not access a title while it's being challenged, and a retained title can't be challenged again for 2 years. **State standards:** TSLAC had until **Apr 1 2026** to update its collection-development standards. **Tools:** TxLA's sample tools are Google Forms and spreadsheets ([TxLA](https://txla.org/advocacy/sb-13-school-library-acquisition-reconsideration-collection-development/sb-13-implementation/)). **Parents:** they also get catalog access and can set per-child do-not-lend lists ([TEA, via R01](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials)). HB 900's vendor rating system was partly struck down in court ([PEN America, Dec 2025](https://pen.org/report/the-bills-igniting-book-bans/)). | Effective Sep 1 2025. 2026–27 is the second year of posting and board-approval cycles in 1,200+ districts. | R01, R07, R05 (school B2B) |
| **Science of reading / three-cueing: HB 1605 (2023)** | Districts and charters "may not include any instruction that incorporates three-cueing in K–3 English language arts/reading." **New allotments:** **$40 per student** a year for SBOE-approved (IMRA) materials, and **up to $20 per student** for state-developed OER (Bluebonnet Learning). **Parent portal:** publishers of IMRA-approved materials must give parents access through a portal at least **30 days** before school starts ([TEA HB 1605 FAQ](https://tea.texas.gov/academics/instructional-materials/house-bill-1605/house-bill-1605-faqs)). K–3 teacher reading academies date from HB 3 (2019) (verify). | In force. IMRA review cycles run yearly. | P01, R08, P06 |
| 3rd-grade reading plan / retention | **No retention.** A low STAAR score triggers intervention, "not repeating the year" ([Reading Pacer, Jun 2026](https://readingpacer.com/reading-laws/)). The accelerated-instruction rules come from HB 4545 (2021) and HB 1416 (2023) (verify). | In force | P02 (weak here) |
| Homeschool (HSLDA: **no notice, low regulation**) | **Rules:** no notice, no testing, no teacher qualifications, and state-mandated subjects ([HSLDA](https://hslda.org/legal/texas)). The subject list (reading, spelling, grammar, math, good citizenship) is from background knowledge (verify). **Size:** THSC estimates that **8–10% of Texas students (500k–620k)** are homeschooled, and that **50,000+** students withdrew to homeschool in 2022–23 ([THSC](https://thsc.org/homeschooling-facts/)). Census data put Texas at 6% of US homeschool enrollment in 2024, up from 3.7% in 2023 ([Newsweek, Jun 2024](https://www.newsweek.com/texas-sees-surge-kids-being-homeschooled-1910617)). Against NHERI's ~3.4M US total (via P03), THSC's range would make Texas the largest homeschool state. That ranking is our inference (verify). | n/a | P03 |
| **ESA: Texas Education Freedom Accounts (TEFA)** | **Awards:** **$2,000/yr** per homeschooler, $10,474 for private school, and up to $30,000 for students with an IEP or disability. **Platform:** Odyssey is the CEAO, and money goes to approved vendors. **Year one (2026–27):** 274,000+ applications and 100,000+ awards. The site doesn't break out homeschool awards. A 2027–28 interest list is open ([TEFA](https://educationfreedom.texas.gov/)). | Year 1 now; 2027–28 cycle next | P03, P04, P07, R05, R08 (+F07) |
| Other | The **Texas App Store Accountability Act** has been enforceable since Jun 10 2026 (via P07). Texas opened the most new indie bookstores: 21 in 2024 (via R05). State funding for Imagination Library was not confirmed in this pass (verify). | See ideas | R05, R04, P07 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf.** 1,200+ districts are in year two of SB 13's workflow: the 30-day posting, board-approval packets, advisory-council petitions and 90-day challenge clocks. TxLA's model tools are still Google Forms and spreadsheets, and Bookmarked already sells here at $2–3 per student (via R01). R01's MVP #6, the acquisition notice board, covers this, so there's no separate state file.
- **P03 HomeRoll.** This is probably the biggest homeschool population in the US, but there's no filing duty. So the pitch is a receipt vault for the $2,000 TEFA money plus transcripts, not compliance.
- **P04 ClassHouse.** TEFA homeschool dollars can only go to approved Odyssey vendors. Independent class teachers and co-op tutors need to get listed and invoice cleanly (pair with F07).

**Where to sell** (names from background knowledge; verify months):
- Texas Library Association: TLA Annual Conference (spring) and its school-library members.
- TASB and the 20 Education Service Centers (ESCs).
- Texas PTA.
- Texas Home School Coalition (THSC) and its convention.
- IDA branches in Dallas, Houston and Austin, and The Reading League Texas.
- TCEA (ed tech).
- The regional independent-bookseller association that covers Texas (verify which).

## Launch verdict
**Speed:** Fast.

**First city:** Dallas–Fort Worth.
- It has the densest overlap of hail roofing, HVAC, trucking and suburban private schools.
- Houston comes second.

**Lead offer:**
- **Main offer: B04 FirstCall + C01 FlatRate** for DFW HVAC and roofing shops. The pitch: "Own your leads after Google's LSA changes. One flat price, English/Spanish, free migration before spring storm season."
- **Parallel wedge: F06 ESA Desk.** Offer "TEFA installment reconciliation free through the Feb 1 2027 payment" to Texas private schools and microschools.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Texas](https://advocacy.sba.gov/wp-content/uploads/2025/06/Texas_2025-State-Profile.pdf)
- [Texas Education Freedom Accounts: program home (funding, applications, awards, installment dates)](https://educationfreedom.texas.gov/)
- [TEFA: Providers and Vendors](https://educationfreedom.texas.gov/providers-vendors/)
- [Texas Comptroller: TEFA final rules and key dates (Nov 25 2025), via F06](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312)
- [Texas Easy Lien: Texas Lien Law 2026](https://www.texaseasylien.com/blog/texas-lien-law-2026-what-every-contractor-needs-to-know-now/)
- [LegiScan: TX HB 3749 (2025), elective IV therapy](https://legiscan.com/TX/bill/HB3749/2025)
- [LegiScan: TX SB 1188 (2025), electronic health records](https://legiscan.com/TX/bill/SB1188/2025)
- [Texas DSHS: Consumable Hemp Program (age-21 rules, fees, Mar 31 2026 rules, Jul 31 2026 delta-8 scheduling)](https://www.dshs.texas.gov/consumable-hemp-program)
- [TDLR: Towing, Booting and Vehicle Storage (fee caps, VSF-12/13)](https://www.tdlr.texas.gov/towing/towing.htm)
- [Texas Property Code 207.006 (public.law)](https://texas.public.law/statutes/tex._prop._code_section_207.006)
- [Insurance Information Institute: Facts + Statistics: Hail (2025 NOAA major hail events by state)](https://www.iii.org/fact-statistic/facts-statistics-hail)
- Internal: ideas/B04, C01, C02, C06, C07, E04, F06, F07, H02, H05, K03, K04 (see their own sources)
- [Texas Library Association: SB 13 implementation (30-day posting, advisory council, 90-day challenges, TSLAC Apr 1 2026)](https://txla.org/advocacy/sb-13-school-library-acquisition-reconsideration-collection-development/sb-13-implementation/)
- [TEA: SB 13 requirements related to school library materials (Aug 28 2025), via R01](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [TEA: House Bill 1605 FAQs (three-cueing ban K–3, $40/$20 allotments, parent portal)](https://tea.texas.gov/academics/instructional-materials/house-bill-1605/house-bill-1605-faqs)
- [Reading Pacer: Third-grade reading laws by state (Jun 11 2026)](https://readingpacer.com/reading-laws/)
- [HSLDA: Texas homeschool law](https://hslda.org/legal/texas)
- [THSC: Homeschooling facts (500k–620k estimate; 50,000+ withdrawals 2022–23)](https://thsc.org/homeschooling-facts/)
- [Newsweek: Texas sees surge in kids being homeschooled (Jun 10 2024)](https://www.newsweek.com/texas-sees-surge-kids-being-homeschooled-1910617)
- Internal (education): ideas R01, R05, R07, P03, P04, P07 (see their own sources)

## Verification (Sep 24 2026)
- ✅ TEFA: $1B, 274,000+ applications, 100,000+ awards, $10,474 private school / up to $30,000 IEP / up to $2,000 homeschool, Odyssey as CEAO — the program home page matches all of these ([TEFA](https://educationfreedom.texas.gov/))
- ✅ TEFA private-school installments 25% Jul 1 2026, 25% Oct 1 2026, 50% Feb 1 2027, plus a 2027–28 interest list (the launch-verdict hook): stated on the same page ([TEFA](https://educationfreedom.texas.gov/))
- ✅ SB 929 signed May 21 2025, effective immediately. It amends Prop. Code 53.003(e) so a deadline that falls on a Saturday, Sunday or legal holiday moves to the next day that is none of those ([LegiScan](https://legiscan.com/TX/bill/SB929/2025); [enrolled text](https://capitol.texas.gov/tlodocs/89R/billtext/pdf/SB00929F.pdf))
- ✅ HB 3749 (elective IV therapy): signed Jun 20 2025, effective Sep 1 2025 ([LegiScan](https://legiscan.com/TX/bill/HB3749/2025))
- ✅ SB 1188: signed Jun 20 2025, effective Sep 1 2025. The US-storage rule applies from Jan 1 2026, AI used for diagnosis must be disclosed, and penalties are $5k/$25k/$250k. The earlier "(verify)" tags were removed ([enrolled SB 1188](https://capitol.texas.gov/tlodocs/89R/billtext/pdf/SB01188F.pdf))
- ✅ DSHS hemp: age-21 emergency rules Oct 2 2025, $10,000/yr per location for a **manufacturer** license (the file said "product license" and is now fixed), $5,000/yr per location for a retail registration, new rules effective Mar 31 2026, delta-8 scheduling effective Jul 31 2026 ([DSHS](https://www.dshs.texas.gov/consumable-hemp-program))
- ✅ Prop. Code 207.006 covers an association of "at least 60 lots" or one that "has contracted with a management company". Last amended by SB 1588, effective Sep 1 2021 ([public.law](https://texas.public.law/statutes/tex._prop._code_section_207.006))
