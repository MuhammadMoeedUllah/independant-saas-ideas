# Alabama (AL): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 465,610 small businesses (99.4% of AL businesses) employ 816,850 people, or **46.0% of AL employees** (2022). From Mar 2023 to Mar 2024, 16,141 establishments opened and 13,115 closed (net +3,026). Small firms produced a net 4,814 jobs, 80.4% of the total ([SBA Advocacy 2025 Alabama profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Alabama_2025-State-Profile.pdf)).
- **New-business momentum:**
  - **53,139 business applications in Jan–Aug 2026** (not seasonally adjusted), 1.2% of US applications, below population share of about 1.5% (verify) ([Census BFS monthly CSV](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)).
  - Most small-business employees: health care (116,931), accommodation and food (105,560) and construction (77,609).
  - Top firm counts: other services (65,570), **admin/support/waste (57,900)** and construction (53,712) (SBA profile).
- **Buyer clusters:**
  - **Huntsville/Madison:** defense and aerospace contractors, and fast-growing high-income suburbs where new-home services thrive.
  - **Birmingham:** health care (UAB ecosystem), banking, home services, churches, restaurants.
  - **Mobile and Baldwin County** (Gulf Shores, Orange Beach): beach rentals, fishing charters, hurricane rebuild.
  - **Montgomery and Tuscaloosa:** government, university, auto suppliers.
- **Industries overweight vs. US** (inference, verify):
  - Aerospace and defense (Huntsville).
  - Auto manufacturing suppliers.
  - Health care.
  - Admin/support/waste services (cleaning, landscaping, staffing).
  - Churches.
  - Gulf Coast tourism.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Alabama Medicaid ended its free state EVV tools on Apr 1 2025.** Providers must "obtain their own EVV system through an approved state EVV provider," and enrollment in the state-sponsored solution is closed. This covers the Community Transition and Elderly & Disabled waivers and Rehab Services ([HHAeXchange Alabama](https://www.hhaexchange.com/info-hub/alabama)). | Home care and waiver agencies | **Already forced (Apr 1 2025)**; agencies on stop-gap vendors are reachable now | E07 |
| **Ala. Code 31-13-15, every employer must enroll in E-Verify.** A first violation brings up to 10 business days' license suspension at that location plus 3 years' probation with quarterly reports. A second violation **permanently revokes** that location's licenses, and further violations suspend licenses statewide ([Justia, 2025 code](https://law.justia.com/codes/alabama/title-31/chapter-13/section-31-13-15/)). | All employers, including 1–10 person shops | In force | G04, J03, regional E-Verify kit |
| **CHOOSE Act ESA.** **$7,000** per student at participating schools and **$2,000** per homeschool student (max $4,000/family). The first 500 awards go to students with special needs, then families up to 300% FPL. Applications passed **20,000** by mid-Feb 2025. The Department of Revenue administers the program on a **ClassWallet** portal ([AL DOR CHOOSE Act](https://www.revenue.alabama.gov/choose-act/)). Universal eligibility in later years is from memory (verify). | Private schools, microschools, homeschool vendors and tutors | 2026–27 cycle | F06, F07 |
| **Comprehensive privacy law passed in 2026**, not yet in effect as of July 2026 ([privacyterms.io](https://privacyterms.io/us-state-privacy-laws-2026)). Bill number, thresholds and effective date to verify. | Businesses above the (unverified) thresholds | Likely 2027 (verify) | J02 |
| **CMMC Phase II requirements (Level 2 certification) were suspended on Jul 13 2026**; they had been due Nov 10 2026. Phase I began Nov 10 2025 ([DoD CIO CMMC](https://dodcio.defense.gov/CMMC/About/)). | Huntsville defense subcontractors | Suspended, so urgency drops | L05 (weaker) |
| **Atlassian Data Center:** no new DC licenses from Mar 30 2026, read-only Mar 2029 (per L05). | Defense and aerospace firms on self-hosted Jira/Confluence | Rolling to 2029 | L05 |
| **Minimum wage:** no state law; federal $7.25 ([DOL](https://www.dol.gov/agencies/whd/minimum-wage/state)). | n/a | n/a | n/a |
| **Medical cannabis:** Metrc is listed for AL (J04); licensing has been tied up in litigation (verify). | Future dispensaries | Uncertain | J04 (hold) |
| **Hurricane season** (Mobile and Baldwin). | Roofers, restoration | Jun 1–Nov 30 | C02, C07 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture) | Huntsville's new-home boom and Birmingham suburbs have a large admin/support/waste and construction firm base. Highest national score. |
| 2 | E07 | Shiftwell (home care plus EVV) | **The state withdrew its free EVV tool**, so every waiver agency must buy an approved EVV system. That is a rare forced purchase for small agencies. Catch: we must first be added to Alabama Medicaid's approved EVV vendor list (timeline unknown), or partner with an approved vendor. |
| 3 | A03 | LocalLoop (reviews and texting) | Restaurants, dental and home services in Birmingham and Huntsville. Sell on price and no auto-renew. |
| 4 | F01 | Chairly (salon/barber booking) | Other services is the #1 small-firm category (65,570). Salons and barbershops in Birmingham, Huntsville, Mobile and Montgomery are price-sensitive and hate commissions. |
| 5 | C01 | FlatRate (field service) | Long cooling season, and Huntsville HVAC and plumbing shops are scaling with new builds. ServiceTitan and Housecall Pro costs are the pain. |
| 6 | F06 | ESA Desk (ESA billing) | The CHOOSE Act pays $7,000 per student at participating schools over ClassWallet, and AR's review called ClassWallet "fragmented." New private and faith schools need split billing (ESA plus parent) and itemized ESA invoices. |
| 7 | I02 | TitheBox (church giving) | Very high church density. The Q4 giving season is now, and small churches want out of Pushpay contracts. |

Bench:
- **L05 Harbor:** Huntsville Jira/Confluence DC exits; CMMC suspension weakens the urgency.
- **H03 StayDesk and D07 BookTrail:** Gulf Shores and Orange Beach.
- **K01 BayBook:** auto repair.
- **C07 ClaimKit:** Gulf Coast storm claims.

## State-only opportunities
1. **Alabama EVV "bring-your-own" for small waiver agencies (E07 wedge).** Since Apr 1 2025 the state no longer provides free EVV, and agencies must use an approved vendor. A low-cost, AL-approved EVV plus scheduling app for 5–50-caregiver agencies could win on price against enterprise vendors.
   - **Blocker:** we have to get on the approved vendor list first, which is a certification and integration step (build ease 2/5).
   - **Next step:** verify the approval process with Alabama Medicaid before investing.
2. **Huntsville self-hosted wiki/tracker exit (L05).** Defense and aerospace SMBs that can't use Atlassian Cloud need a self-hosted replacement before the Mar 2029 read-only date. The Jul 13 2026 CMMC Phase II suspension removes the near-term compliance forcing function, so position on the DC sunset, not CMMC.
3. **Strictest-tier E-Verify kit (regional).** Along with MS and SC, AL requires E-Verify from every employer, and repeat violations permanently revoke licenses. Offer an I-9 + E-Verify log + audit binder add-on for restaurants, landscapers and construction subs. E-Verify is free, so sell it bundled with G04 or J03.

## Where to sell
- **Associations & events** (verify names and dates):
  - **Hospitality:** Alabama Restaurant & Hospitality Association.
  - **Building and real estate:** Home Builders Association of Alabama, Alabama REALTORS.
  - **Professional:** Alabama Society of CPAs, Alabama State Bar, Alabama Dental Association.
  - **Health and trucking:** Alabama home care association (verify name), Alabama Trucking Association.
  - **General business:** Business Council of Alabama, Huntsville/Madison County Chamber.
  - **Coast:** Alabama Gulf Coast CVB.
- **Online communities:** r/HuntsvilleAlabama, r/Birmingham, r/Mobile and r/Alabama; church-admin and homeschool-co-op Facebook groups (names not verified); CHOOSE Act parent groups.
- **Partners:**
  - Alabama SBDC Network (verify host).
  - Innovate Alabama.
  - Banks: Regions (Birmingham HQ) and ServisFirst (verify).
  - Waiver case-management agencies, for E07 referrals.
  - Homeschool co-ops and private-school associations, for F06.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School/public library-materials rules | The Alabama Public Library Service handles minors' access to materials through administrative code, not statute (per R07's lead list; verify the rule and date). A bill to create a statewide Imagination Library program stalled in the 2026 session and was not placed on the Senate calendar ([Book Riot, Apr 17 2026](https://bookriot.com/dollys-imagination-library-state-funding/)). | Admin code (verify); 2026 session | R01, R07, R03 |
| Science of reading / three-cueing law | Alabama Literacy Act (2019; verify). A 2025 three-cueing bill is unverified. | In force | P01, R08 |
| 3rd-grade reading plan / retention law | Mandatory-retention state under the Literacy Act (per the lead list; verify thresholds) | In force | P02 |
| Homeschool rules (HSLDA tier: **low**) | Three options. Notice is required. No testing and no state-mandated subjects; teacher qualifications apply only under option 3 ([HSLDA AL](https://hslda.org/legal/alabama)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **CHOOSE Act 2026–27: over 34,000 students approved, over $174M funded.** Awards are **$7,000** (private school) and **$2,000 per homeschool student (capped at $4,000 per family)**, paid through **ClassWallet**. Nearly 49,000 students applied, and the next application deadline is **January 2027** for 2027–28 ([Governor Ivey, Jul 1 2026](https://governor.alabama.gov/newsroom/2026/07/governor-ivey-announces-funding-for-choose-act-education-savings-accounts-for-2026-2027-school-year/)). | Funded Jul 1 2026; next window Jan 2027 | P03, P04, P07, R05, R08 |
| Other | No statewide Imagination Library funding (see the stalled bill above). | — | P06 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll:** CHOOSE homeschool families get $2,000 each through ClassWallet and have to keep receipts, notices and records across three legal options.
- **P04 ClassHouse:** it gives $7k/$2k CHOOSE families somewhere to buy local classes and tutoring, and about 15,000 applicants who were not funded are a warm list for the Jan 2027 window.
- **P02 ReadingPlan Home:** it covers parent-facing reading plans under the Literacy Act's mandatory retention.

**Where to sell:**
- **Libraries:** Alabama Library Association (ALLA; convention, spring; verify) and the Alabama School Library Association (verify).
- **Parents:** Alabama PTA and CHEF of Alabama (Christian Home Education Fellowship; verify).
- **Reading:** IDA Alabama branch and The Reading League Alabama (verify).
- **Booksellers:** SIBA.

## Launch verdict
**Speed:** Medium. **First city:** Huntsville for trades and growth, then Birmingham. **Lead offer:** FirstCall (B04) for Huntsville-area home services. Open a parallel track to get Shiftwell (E07) on Alabama Medicaid's approved EVV vendor list. If approval is feasible, EVV becomes AL's best-fit forced-purchase product.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Alabama](https://advocacy.sba.gov/wp-content/uploads/2025/06/Alabama_2025-State-Profile.pdf)
- [US Census Bureau, Business Formation Statistics monthly CSV (Jan–Aug 2026)](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)
- [HHAeXchange Alabama provider page (free EVV tools ended Apr 1 2025)](https://www.hhaexchange.com/info-hub/alabama)
- [Ala. Code 31-13-15 (Justia, 2025)](https://law.justia.com/codes/alabama/title-31/chapter-13/section-31-13-15/)
- [Alabama Department of Revenue, CHOOSE Act](https://www.revenue.alabama.gov/choose-act/)
- [Governor Ivey: CHOOSE Act ESA funding for 2026–27 (Jul 1 2026)](https://governor.alabama.gov/newsroom/2026/07/governor-ivey-announces-funding-for-choose-act-education-savings-accounts-for-2026-2027-school-year/)
- [HSLDA: Alabama homeschool laws](https://hslda.org/legal/alabama)
- [Book Riot: Book Censorship News, Apr 17 2026](https://bookriot.com/dollys-imagination-library-state-funding/)
- [privacyterms.io, US state privacy laws 2026](https://privacyterms.io/us-state-privacy-laws-2026)
- [DoD CIO, About CMMC (Phase II suspended Jul 13 2026)](https://dodcio.defense.gov/CMMC/About/)
- [US DOL, state minimum wage table](https://www.dol.gov/agencies/whd/minimum-wage/state)
