# District of Columbia (DC): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 82,666 small businesses (98.2% of DC businesses), employing 259,181 people (49.1% of private employees). 65,130 are nonemployer firms ([SBA Advocacy 2025 DC profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/District_of_Columbia_2025-State-Profile.pdf)).
- **New-business momentum:**
  - From Mar 2023 to Mar 2024, small firms opened 5,817 establishments and closed 4,724. Total DC establishments rose by a net 1,171.
  - Small businesses gained 43,168 jobs and lost 40,490, a net of +2,678 ([SBA Advocacy 2025](https://advocacy.sba.gov/wp-content/uploads/2025/06/District_of_Columbia_2025-State-Profile.pdf)).
  - Census BFS trend was not fetched in this pass.
- **Buyer clusters** (estimate, verify):
  - **Downtown, K Street and Dupont:** trade associations, advocacy nonprofits, law and lobbying firms, consultancies.
  - **Shaw, U Street, 14th St, Navy Yard and H St:** chef-driven restaurants and bars, salons and barbers, boutique fitness.
  - **Wards 7–8:** DC-certified local businesses (CBEs) and nonprofits.
- **Industries overweight vs. US** (SBA; comparison is an estimate):
  - **Professional, scientific & technical services:** 22,477 small firms and 53,687 small-business employees.
  - **"Other services":** 9,251 small firms, the #2 sector, and 63,960 small-business employees. This category includes membership associations, advocacy groups, religious orgs, salons and repair. DC's association density drives it.
  - **Transportation:** 8,145 small firms, mostly rideshare and delivery sole proprietors.
  - **Restaurants and bars:** dense and wage-law-exposed.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Initiative 82 tipped-wage phase-out**, amended by the Council in 2025 to slow the phase-in. Current tipped cash wage and schedule: verify (DOES pages returned 404 this pass). | Restaurants, bars, salons with tipped staff | Ongoing annual steps (typically Jul 1) | D04, D01 |
| **Tipped Wage Workers Fairness Act.** Businesses that employ at least one tipped worker must have everyone on staff complete anti-sexual-harassment training from an OHR-certified trainer every two years ([RAMW](https://www.ramw.org/training-workforce-development/tipped-wage-workers-fairness-act-training)). | Every tipped-wage employer | Biennial | D04 (training tracker), F01 |
| **DC Paid Family Leave changes:** maximum weekly benefit becomes $1,100, and maximum leave durations change for medical and family leave ([DC PFL](https://dcpaidfamilyleave.dc.gov/)). A new required poster is listed for Sep 2026 ([Poster Guard](https://www.posterguard.com/)). | All private DC employers (employer-paid tax) | **Oct 1 2026** | G04, J03 |
| **Wage transparency in job postings** (background, verify) | DC employers | In force since mid-2024 (verify) | J03 |
| **Cannabis.** DC is listed as a Metrc market ([Metrc](https://www.metrc.com/partners/)). | Licensed dispensaries and cultivators | Ongoing | J04 |
| **CMMC.** In Phase 1 (self-assessments only); Phase II suspended Jul 13 2026 ([DoD CIO](https://dodcio.defense.gov/CMMC/About/)). | Small federal and defense contractors headquartered in DC | Paused | (watch) |
| **FTC fees rule** (all-in pricing for live-event tickets and short-term lodging) | Event organizers, venues, hotels | In force May 12 2025 | I04, D05 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | I03 | DuesDesk (WildApricot/MemberClicks alternative) | DC is the association capital; "Other services" is its #2 small-business sector. WildApricot hikes, a 20% outside-processor surcharge and Personify's sale (Jan 2026) create switching windows. |
| 2 | D04 | ShiftTip (7shifts/Homebase alternative) | I-82 wage steps, the biennial TWWF harassment-training mandate and the Oct 1 2026 PFL changes make DC restaurant labor the most rule-heavy in the region. Sell scheduling plus tip pooling plus a training-due tracker. |
| 3 | D03 | TableKeep (OpenTable/Resy alternative) | Dense chef-driven dining. OpenTable's 2% deposit fee (Jan 2026) and the Resy–Tock merger give a reason to switch. |
| 4 | I04 | DoorList (Eventbrite alternative) | Associations, nonprofits and venues run constant events. Bending Spoons' takeover of Eventbrite plus the FTC all-in pricing rule. |
| 5 | I01 | GiftLedger (donor CRM) | Very high nonprofit density. Blackbaud renewal escalators and Q4 giving season. |
| 6 | F01 | Chairly (salon/barber booking) | Salons and barbers fall in DC's big "Other services" sector. The Fresha/Vagaro fee pain is universal. |
| 7 | L02 | Studioboard (flat-price project management) | 22,477 small professional-services firms (consultancies, lobbying, PR). Seat-block pricing and AI credits annoy 5–30-person firms. |

## State-only opportunities
1. **DC restaurant labor-compliance pack** (a D04 "DC pack"). It tracks I-82 tipped-wage steps, service-charge disclosures, TWWF biennial training certificates per employee, PFL notices and the Oct 1 2026 benefit change in one screen. Pitch it through RAMW's compliance webinars (RAMW runs regular webinars; see its site). Strong, but D04 covers it, so there is no separate S2 file.
2. **Association-in-a-box for the DC long tail** (I03). Small associations (under 2,000 members) spend on AMS suites built for large ones. A flat-price dues, events and directory product can undercut WildApricot and GrowthZone.
3. **Govcon subcontractor compliance** (CMMC Level 1 affirmations, SAM renewal, SPRS). The need is real in the DC/MD/VA region, but CMMC Phase II was **suspended Jul 13 2026**, so buyers are in wait-and-see mode. Keep it on watch.

## Where to sell
All names below are from background knowledge (verify), except RAMW events, which were fetched.
- **Associations & events:**
  - Restaurant Association Metropolitan Washington (RAMW). The RAMMYS were held Jun 29 2026, and RAMW runs regular compliance webinars (FROG program Sep 29 2026; I-9 enforcement Sep 22 2026) ([RAMW](https://ramw.org/)).
  - ASAE, the American Society of Association Executives, headquartered in DC. Its annual meeting (Aug) and Great Ideas conference are where association buyers gather.
  - DC Chamber of Commerce; DC Bar; Center for Nonprofit Advancement; DC Main Streets programs.
- **Online communities:** r/washingtondc, r/dcfood; ASAE Collaborate forums; DC restaurant-owner Facebook groups; LinkedIn association-executive groups.
- **Partners:** DC SBDC (Howard University); Department of Small and Local Business Development (CBE program); association management companies (AMCs), which resell software to the many associations they each manage; restaurant accountants and payroll bureaus.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law | None found on our lead lists (verify). | — | — |
| Science of reading / three-cueing law | DC is counted in EdWeek's "43 states and the District of Columbia" with evidence-based reading laws or policies as of Aug 2026 ([EdWeek tracker](https://www.edweek.org/teaching-learning/which-states-have-passed-science-of-reading-laws-whats-in-them/2022/07)). Provisions not confirmed (verify). | — | P01, R08 |
| 3rd-grade reading plan / retention law | No retention mandate on the lead lists (verify) | — | P02 (weak) |
| Homeschool rules (HSLDA tier: **moderate**) | One option. Notice is required, subjects are mandated, and teacher qualifications apply. No formal assessment ([HSLDA DC](https://hslda.org/legal/district-of-columbia)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | No ESA. The federal DC Opportunity Scholarship Program pays private-school tuition only (verify current amounts and rules). | — | — |
| Other | **Books from Birth:** every child under 5 living in DC gets a free book by mail each month. It is run by DC Public Library with Dolly Parton's Imagination Library and funded by the DC government through the Sing, Talk and Read (STAR) initiative. Families have been able to choose 100% bilingual English/Spanish books since Jun 2024 ([DCPL Books from Birth](https://www.dclibrary.org/booksfrombirth)). Private reading tutors charge about **$156.67/hr** in DC (per P01). | Ongoing | P06, P01 |

**Top 3 reading/education ideas here:**
- **P01 PhonicsPrep:** DC has one of the highest private reading-tutor rates in the US (per P01), so dyslexia and structured-literacy tutors can afford a flat-price toolkit.
- **P06 StoryNest:** Books from Birth already puts a book in every young child's home. A parent-engagement and read-along layer for DCPL, Head Start and pre-K programs builds on it rather than competing with it.
- **P04 ClassHouse:** it lets independent teachers sell enrichment classes to a dense, high-income parent base.

**Where to sell:**
- **Libraries:** DC Library Association (verify event calendar) and DC Public Library Youth & Family Services.
- **Parents:** DC PTA (verify) and DC homeschool co-ops (names: verify).
- **Reading:** IDA DC Capital Area branch (verify) and The Reading League DC (verify).
- **Booksellers:** NAIBA (verify DC coverage).

## Launch verdict
**Speed:** Medium. The market is dense but small, and association buyers move on budget cycles (Q4 is budget season). **First city:** Washington, DC (downtown associations plus the 14th St/Shaw restaurant corridor). **Lead offer:** I03 DuesDesk ("leave WildApricot at renewal, free migration") through AMCs. Run D04 ShiftTip's "DC tip and training compliance" pack as a second track through RAMW.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: District of Columbia](https://advocacy.sba.gov/wp-content/uploads/2025/06/District_of_Columbia_2025-State-Profile.pdf)
- [DC Paid Family Leave (Oct 1 2026 changes)](https://dcpaidfamilyleave.dc.gov/)
- [RAMW, Tipped Wage Workers Fairness Act training](https://www.ramw.org/training-workforce-development/tipped-wage-workers-fairness-act-training)
- [RAMW homepage and events](https://ramw.org/)
- [Poster Guard homepage (Sep 2026 poster changes)](https://www.posterguard.com/)
- [DoD CIO, About CMMC](https://dodcio.defense.gov/CMMC/About/)
- [Metrc partners/markets](https://www.metrc.com/partners/)
- [DC Public Library: Books from Birth](https://www.dclibrary.org/booksfrombirth)
- [HSLDA: District of Columbia homeschool laws](https://hslda.org/legal/district-of-columbia)
- [Education Week: science-of-reading law tracker (updated Aug 27 2026)](https://www.edweek.org/teaching-learning/which-states-have-passed-science-of-reading-laws-whats-in-them/2022/07)
- Internal: idea P01 (DC tutor rates)
