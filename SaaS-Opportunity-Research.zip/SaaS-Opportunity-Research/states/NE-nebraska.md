# Nebraska (NE): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 193,495 small businesses employing 422,756 people, or 47.5% of Nebraska employees, above the national share. 43,375 small employer firms. Data year 2022. ([SBA Advocacy 2025 Nebraska profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Nebraska_2025-State-Profile.pdf))
- **New-business momentum:** From March 2023 to March 2024, small businesses gained 64,882 jobs and lost 52,143, a net gain of 12,739 ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Nebraska_2025-State-Profile.pdf)). Small-business employment by industry: health care and social assistance 73,932, accommodation and food services 53,637, construction 45,585. Census BFS was not fetched in this pass.
- **Buyer clusters:**
  - **Omaha:** insurance and finance back offices, construction and roofing (major hail exposure), restaurants, health care, trucking.
  - **Lincoln:** government, university, restaurants, services.
  - **Grand Island, Kearney and Hastings:** ag retail, trucking, meatpacking suppliers.
  - **North Platte and Scottsbluff:** rail, ag, hunting and outdoor tourism.
  - **Rural:** co-ops, irrigation dealers, custom applicators.
- **Industries overweight vs. US:** accommodation and food services (the #2 small-business employer), agriculture and ag retail, insurance and finance, trucking and rail, roofing and exteriors (hail). Overweights are estimates.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Paid sick time** (Healthy Families and Workplaces Act): employers with **11+ employees** (10 or fewer are exempt). Accrual is 1 hour per 30 hours worked, with a minimum of **40 hrs/yr at 11–19 employees** and **56 hrs/yr at 20+**. Written notice was due by Sep 15 2025 (or at hire), a poster is required, and each pay period must record time available, taken and paid. | Restaurants, retail, clinics, trades with 11+ staff | **Oct 1 2025** | D04, G04, J03 |
| **Minimum wage $15.00** (2022 ballot initiative; verify rate and 2027 CPI indexing) | Restaurants, retail | Jan 1 2026 (verify) | D04 |
| **Nebraska Data Privacy Act:** applies to non-small businesses. SBA-defined small businesses are exempt except that they may not sell sensitive data without consent (verify). | Mid-size SMBs, e-commerce | Jan 1 2025 (per J02) | J02 |
| **Contractor registration** with the Nebraska Dept. of Labor (portal at dol.nebraska.gov/conreg) | All contractors and subs, including storm roofers | Ongoing (renewal cycle: verify) | C02, C01 |
| **IFTA quarterly return** | Interstate carriers | **Oct 31 2026** | K03 |
| **Medicaid EVV:** sources conflict (Netsmart vs Sandata closed model) | Home care | In force | E07 (weak) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall | Top score (23). Omaha and Lincoln trades buy leads heavily after every hail event. |
| 2 | C02 | StormDesk | Omaha and Lincoln see repeated major hail. Flat unlimited-user pricing for storm hiring surges, with NDOL contractor registration tracking for crews. |
| 3 | A03 | LocalLoop | Score 22. Restaurants, the #2 small-business employer, plus clinics and auto shops need reviews and texting. |
| 4 | D04 | ShiftTip | New sick-time accrual (Oct 2025) and a $15 wage (2026; verify) hit restaurants hardest. Scheduling with accrual tracking and per-pay-period sick-time records is a direct compliance buy. |
| 5 | J03 | PostedUp | The sick-time notice, poster and records obligations are new, and employers with 11–19 vs 20+ staff face different caps. A cheap compliance kit sells by card. |
| 6 | F01 | Chairly | Score 22. Omaha and Lincoln salons and barbers. |
| 7 | C07 | ClaimKit | Hail claim documentation and supplements for Omaha roofers and restorers. |

Close alternates: K03 HaulDesk (Grand Island and I-80 carriers), G04 StatePay (sick-time accruals in payroll).

## State-only opportunities
1. **Nebraska sick-time tracker for 11–50 employee businesses (D04/J03 variant).** Tracks accruals by employer-size band (40 vs 56 hours), prints the pay-period statement of available, taken and paid time the law requires, and produces the notice and poster. A $19–29/mo add-on that restaurants and retailers can buy today. Omaha restaurant groups are the first targets.
2. **Hail-season contractor compliance (C02 variant).** Registration checks for subcontracted and out-of-state storm crews, bundled with the roofing CRM.

## Where to sell
- **Associations & events** (from knowledge, verify):
  - Nebraska Restaurant Association
  - Nebraska Hotel & Motel Association
  - Metro Omaha Builders Association and Home Builders Association of Lincoln
  - Nebraska REALTORS Association
  - Nebraska Society of CPAs
  - Nebraska State Bar Association
  - Nebraska Trucking Association
  - Nebraska Agri-Business Association
  - Nebraska Dental Association
- **Online communities:** r/Omaha, r/Lincoln, r/Nebraska. Omaha small-business and contractor Facebook groups (verify).
- **Partners:**
  - Nebraska Business Development Center (the state SBDC)
  - Greater Omaha Chamber and Lincoln Chamber
  - Payroll-focused CPAs (sick-time questions)
  - Roofing supply branches
  - Community banks and credit unions

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law: **LB 390** (Neb. Rev. Stat. 79-533.04) | Each district must keep "a catalog of all books in the school district's library, organized by school building" that parents can access; paper is allowed. Parents must get the "opportunity" to be notified when their child checks out a book, with title, author and due date. This is opt-in. Every district adopts a board policy "before school starts in fall 2026." It's unclear whether eBooks and periodicals are covered ([KSB School Law, Nov 24 2025](https://www.ksbschoollaw.com/blog/2025/11/24/turning-the-page-nebraskas-new-library-catalog-law-for-schools)) | Policies due fall 2026, now in force for 2026–27 | **R01**, R07 |
| Science-of-reading / three-cueing law | Nebraska Reading Improvement Act, with K–3 screening and Individual Reading Improvement Plans (IRIPs). Not on the category-research three-cueing-ban list (verify) | In force | P01, R08 |
| 3rd-grade reading plan / retention law | No mandatory retention. An **IRIP** is due within **30 days** of identification, with written parent notice within **15 working days**. Each plan includes a **home support plan** (parent-guided home reading) and dated records of every parent contact. Districts "develop templates locally" ([NDE IRIP guidance, updated Aug 1 2025](https://www.education.ne.gov/wp-content/uploads/2025/08/Individual-Reading-Improvement-Plans-Guidance-Document2023.pdf)) | Every school year | **P02**, R08 |
| Homeschool rules (HSLDA tier: **low**) | Notice required (exempt-school filing, verify form and date). No assessment and no teacher qualifications. Subjects are state-mandated and immunization rules apply. Compulsory ages 6–18. HSLDA flags recent bills LB 1224 and LB 1112 ([HSLDA NE](https://hslda.org/legal/nebraska)) | In force | P03 |
| ESA / scholarship money that can buy books, curriculum, classes | **No state program:** "Nebraska has no school choice programs" ([EdChoice NE](https://www.edchoice.org/school-choice/state/nebraska/)). Nebraska **opted in to the federal tax-credit scholarship** (Ballotpedia: Sep 29 2025; IRS list, Jun 8 2026). SGO scholarships can pay for tutors, textbooks and supplies, including for homeschoolers, from **Jan 1 2027** ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill); [Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)) | Jan 1 2027 | P07, P03, P04 |
| Other | Not on the CSG South list of statewide Imagination Library programs ([CSG South, Jan 2024](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)) | — | P06 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf:** LB 390 policies, per-building catalogs and opt-in checkout alerts are live for 2026–27. About 244 districts (estimate) need tooling, not binders.
- **P02 ReadingPlan Home:** IRIPs require a home support plan and dated parent-contact logs, and each district builds its own template.
- **P07 LearnLedger:** federal scholarships to families start Jan 2027 in a state with no ESA of its own.

**Where to sell:**
- **Libraries:** the joint Nebraska Library Association / Nebraska School Librarians Association fall conference (October, verify); NASB policy services.
- **Families:** Nebraska PTA; Nebraska Christian Home Educators Association (verify).
- **Reading groups:** Decoding Dyslexia NE or IDA contacts (verify).
- **Booksellers:** Mountains & Plains Independent Booksellers Association (verify region).

## Launch verdict
**Speed:** Medium. **First city:** Omaha. **Lead offer:** C02 StormDesk plus B04 FirstCall for Omaha roofers, sold in the Oct–Feb off-season. D04/J03 "Nebraska sick-time accrual + poster kit" is the state-only card-swipe add-on for restaurants.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Nebraska](https://advocacy.sba.gov/wp-content/uploads/2025/06/Nebraska_2025-State-Profile.pdf)
- [Nebraska Dept. of Labor, Paid Sick Time FAQs](https://dol.nebraska.gov/LaborStandards/PaidSickTime/PSTFAQs)
- [Nebraska Dept. of Labor home (contractor registration portal link)](https://dol.nebraska.gov/)
- Internal: ../ideas/C02, C07, D04, J02, J03, E07 idea files; ../_state_leads_from_category_research.md
- [KSB School Law: Nebraska LB 390 library catalog law (Nov 24 2025)](https://www.ksbschoollaw.com/blog/2025/11/24/turning-the-page-nebraskas-new-library-catalog-law-for-schools)
- [Nebraska DOE: Individual Reading Improvement Plans guidance (updated Aug 1 2025)](https://www.education.ne.gov/wp-content/uploads/2025/08/Individual-Reading-Improvement-Plans-Guidance-Document2023.pdf)
- [HSLDA: Nebraska homeschool law](https://hslda.org/legal/nebraska)
- [EdChoice: Nebraska](https://www.edchoice.org/school-choice/state/nebraska/)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [Ballotpedia: state participation in the federal K-12 tax credit scholarship program](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [CSG South: statewide Imagination Library expansions (Jan 2024)](https://csgsouth.org/wp-content/uploads/QofM-January-1.pdf)
