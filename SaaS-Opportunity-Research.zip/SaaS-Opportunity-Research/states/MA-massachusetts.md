# Massachusetts (MA): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 756,096 small businesses, 99.5% of MA businesses, employing 1.5 million people (44.7% of MA employees). 612,132 are nonemployer firms (2022). ([SBA Advocacy 2025 MA profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Massachusetts_2025-State-Profile.pdf))
- **New-business momentum:** From Mar 2023 to Mar 2024, small firms opened 21,452 establishments and closed 27,112, so closings ran ahead of openings. Surviving small firms still produced 91.2% of the net job gain (+4,824). This is a mature, cost-squeezed market, and owners respond to "cut your software bill" messaging. ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Massachusetts_2025-State-Profile.pdf))
- **Buyer clusters:**
  - **Greater Boston, Cambridge and Somerville:** restaurants, boutique fitness, salons, professional services, dental, vendors to life sciences.
  - **North Shore and Salem:** October tourism, with ghost and history tours.
  - **Cape Cod and the Islands:** seasonal lodging, short-term rentals, whale watches, restaurants.
  - **South Shore and MetroWest:** home services, HVAC and heat-pump installers.
  - **Worcester and Central MA:** trades and manufacturing.
  - **Springfield and the Pioneer Valley:** health care and education-adjacent services.

  These clusters are an estimate.
- **Industries overweight vs. US:**
  - By small-business employment, health care and social assistance (224,073), accommodation and food (198,748) and professional, scientific and technical services (182,888) lead ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Massachusetts_2025-State-Profile.pdf)).
  - Also overweight (estimate): higher education and life sciences.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **PFML contribution change.** The total rate is 0.88% for 2025–2026. Chapter 101 of the Acts of 2026 moves the 60% employer share from medical leave to family leave, effective **Jan 1 2027**. The 2027 rate is announced **by Oct 1 2026**. Employers with fewer than 25 covered individuals still owe no employer share ([Mass.gov PFML rates](https://www.mass.gov/info-details/paid-family-and-medical-leave-employer-contribution-rates-and-calculator)) | Every MA employer (withholding, payroll setup, notices) | Oct 1 2026 announcement, Jan 1 2027 switch | G04, J03 |
| **940 CMR 38.00 unfair and deceptive fees (AG).** Requires clear, conspicuous total-price disclosure including all fees, plus disclosure and cancellation rules for recurring charges and trial offers ([Mass.gov 940 CMR 38](https://www.mass.gov/regulations/940-CMR-3800-unfair-and-deceptive-fees)). Issued Mar 2025, in force Sep 2025 (per category research) | Tours, lodging, campgrounds, ticketed events, gyms, car-wash clubs, restaurants with service fees | In force | D07, D05, D06, I04, F02, K06 |
| **Pay transparency:** pay ranges in job postings for employers with 25+ employees from Oct 29 2025. Employers with 100+ file EEO data reports (annual Feb 1 due date to verify) (category research) | Employers with 25+ | In force; Feb 2027 report | J03, G07 |
| **201 CMR 17.00:** anyone who owns or licenses personal information about a MA resident must meet minimum safeguards, including a written information security program ([Mass.gov 201 CMR 17](https://www.mass.gov/regulations/201-CMR-1700-standards-for-the-protection-of-personal-information-of-residents-of-the-commonwealth)) | Virtually every employer and seller (employee SSNs and card data) | Ongoing | J02, L06, S1-01 (V2 adaptation) |
| Federal ADA web suits: 57 in MA federal courts in 2025 ([Seyfarth](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)) | SMB websites | Ongoing | J02 |
| Sales tax economic nexus: $100k, with no transaction-count test (category research) | Remote sellers | Ongoing | J01 |
| Recreational camps for children (105 CMR 430): annual license from the local board of health (verify) | Day and overnight camps | Pre-season (spring) | I06, F03 |
| Home improvement contractor registration under c.142A and written-contract rules (verify) | Remodelers, roofers, HVAC | Ongoing | B04, A04, C05 |
| Mass Save heat-pump incentives and the oil-to-heat-pump conversion push (verify) | HVAC and fuel dealers adding heat pumps | Ongoing | C01 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | J03 | PostedUp | Three MA-specific changes: pay-range postings (Oct 2025), the PFML split change with new notices (Jan 1 2027), and EEO reports for 100+ employers. Sell a Q4 2026 "MA 2027 compliance pack." |
| 2 | D07 | BookTrail | Under 940 CMR 38, FareHarbor-style add-on guest booking fees risk being treated as junk fees. Salem in October and Cape whale watches are dense operator clusters. |
| 3 | F02 | OpenStudio | 940 CMR 38 recurring-charge and cancellation disclosure rules, dense Boston boutique studios, and Glofox price hikes of 70–300%. |
| 4 | G04 | StatePay | The Jan 1 2027 PFML change is a natural payroll switch date, and Gusto raised prices 22% (Mar 2026). |
| 5 | B04 | FirstCall | Home-improvement contractors paying Angi and Google LSA. Scoreboard 23. |
| 6 | C01 | FlatRate | Heat-pump conversions and oil-heat dealers adding HVAC (verify). ServiceTitan exit fees. |
| 7 | A03 | LocalLoop | Boston multi-location service businesses on Podium or Birdeye auto-renewals. Scoreboard 22. |

## State-only opportunities
1. **"MA 2027 employer pack."** One product that bundles PFML 2027 withholding recalculation, updated notices, pay-range posting checks and a 201 CMR 17 WISP generator. Build it as a J03 state module. No separate file needed.
2. **All-in-price checkout for tourism operators.** D07 and D05 with a "940 CMR 38 compliant" badge and total-price checkout. It's a strong sales line, but it's a feature rather than a separate product.
3. **Oil-heat dealer to heat-pump contractor transition kit.** Covered under C01. See the Maine file for the regional heating-oil thesis.

## Where to sell
- **Associations & events:**
  - Restaurants and lodging: Massachusetts Restaurant Association, Massachusetts Lodging Association.
  - Construction and home services: Home Builders & Remodelers Association of MA, Mass Oil Heat Council (verify).
  - Professional services: Massachusetts Society of CPAs, Massachusetts Bar Association.
  - Dental: Massachusetts Dental Society's Yankee Dental Congress (late Jan–early Feb, Boston).
  - Other: Massachusetts Association of Realtors, Massachusetts Association of Insurance Agents, Associated Industries of Massachusetts, ACA New England (camps).
- **Online communities:** r/boston, r/massachusetts, r/CapeCod, r/Worcester, r/salem, r/smallbusiness. Facebook groups for Cape Cod STR hosts, Boston restaurant owners and MA contractors (search by name).
- **Partners:** Massachusetts SBDC Network, Greater Boston Chamber and regional chambers (Salem, Cape Cod, Worcester), payroll-focused CPA firms, Mass Save-participating HVAC distributors (verify), community banks and credit unions.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **Freedom-to-read law: S.3241, "An Act Regarding Free Expression"** | Libraries must have **collection policies** that explain selection decisions and a challenge process. Materials cannot be removed for "partisan, personal, or doctrinal" views, and librarians are protected from losing their job or license. **Schools must send the state an annual list of challenged titles** ([Book Riot, Aug 2026](https://bookriot.com/massachusetts-passes-freedom-to-read-law/)). The effective date and first report due date were not given (verify) | Signed week of Aug 18 2026 | R01, R03 |
| **Science of reading** | Massachusetts has **no literacy statute** and no three-cueing ban. **603 CMR 28.03** has required universal early-literacy screening through grade 3 since **Jul 1 2023**, and a 2018 dyslexia act exists. DESE teacher panels rate curricula instead of keeping an approved list. The Mass Literacy guide, the Literacy Launch institutes and the PRISM and GLEAM grants support this work ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/massachusetts/)) | Screening since Jul 1 2023 | P01, R08 |
| **3rd-grade reading plan or retention law** | None | n/a | (P02 weak) |
| **Homeschool** | High regulation per category research. HSLDA's overview lists notice and assessment as required ([HSLDA Massachusetts](https://hslda.org/legal/massachusetts)). The page's scale was read as "low", so check the tier. The district prior-approval process was not detailed (verify) | In force | P03 |
| **ESA and scholarship money** | None. Massachusetts is not in the federal tax-credit scholarship ([IRS, Jun 8 2026](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | n/a | (P07 weak) |
| **Other: PTA software and fee rules** | The **Massachusetts PTA says units "must" use Givebacks (formerly MemberHub)** for members, officers and good standing (MA PTA FAQ, Feb 2026, via P05). The 940 CMR 38 fee-disclosure rule (see above) applies to family subscription pricing | Feb 2026 | P05, P07 |

**Top 3 reading/education ideas here:**
- **R01 ClearShelf:** the new S.3241 law requires collection policies and annual challenged-title lists from every school. That is a new reporting job for school librarians.
- **P05 PTOHub:** the MA PTA's Givebacks mandate makes non-PTA parent groups (PTOs) the buyers who can switch.
- **P03 HomeRoll:** under district prior approval and assessments, families need organized plans and evaluations.

**Where to sell:**
- **Libraries:** Massachusetts Library Association (spring conference; verify) and the Massachusetts School Library Association (MSLA; verify).
- **Parents:** Massachusetts PTA (note its Givebacks mandate) and independent PTOs.
- **Homeschool:** the Massachusetts Homeschool Organization of Parent Educators (MassHOPE) and AHEM (both verify).
- **Reading specialists:** IDA Massachusetts branch and The Reading League Massachusetts (both verify).
- **Booksellers:** NEIBA.

## Launch verdict
**Speed:** Fast. **First city:** Boston, then Salem and the North Shore in October for D07. **Lead offer:** J03 PostedUp "MA 2027 Compliance Pack," launched right after the Oct 1 2026 PFML rate announcement: pay-transparency checks, PFML notices and a WISP for $X/mo. Pair it with D07 BookTrail's "all-in pricing, no guest fees" message for tour operators.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Massachusetts](https://advocacy.sba.gov/wp-content/uploads/2025/06/Massachusetts_2025-State-Profile.pdf)
- [Mass.gov: PFML employer contribution rates and calculator](https://www.mass.gov/info-details/paid-family-and-medical-leave-employer-contribution-rates-and-calculator)
- [Mass.gov: Department of Family and Medical Leave](https://www.mass.gov/orgs/department-of-family-and-medical-leave)
- [Mass.gov: 940 CMR 38.00 Unfair and deceptive fees](https://www.mass.gov/regulations/940-CMR-3800-unfair-and-deceptive-fees)
- [Mass.gov: 201 CMR 17.00](https://www.mass.gov/regulations/201-CMR-1700-standards-for-the-protection-of-personal-information-of-residents-of-the-commonwealth)
- [Seyfarth: federal website accessibility suits 2025](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)
- [Book Riot: Massachusetts passes freedom-to-read law (S.3241, Aug 2026)](https://bookriot.com/massachusetts-passes-freedom-to-read-law/)
- [The Reading League Compass: Massachusetts](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/massachusetts/)
- [HSLDA: Massachusetts homeschool law](https://hslda.org/legal/massachusetts)
- [IRS: Federal scholarship tax credit participating states (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- Internal: ../ideas/P05 (MA PTA Givebacks FAQ, Feb 2026)
