# Kansas (KS): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 273,419 small businesses employing 599,134 people, or 48.9% of Kansas employees. 56,401 small employer firms. Data year 2022. ([SBA Advocacy 2025 Kansas profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Kansas_2025-State-Profile.pdf))
- **New-business momentum:** From March 2023 to March 2024, small businesses gained 90,943 jobs and lost 80,342, a net gain of 10,601 ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Kansas_2025-State-Profile.pdf)). The largest small-business employers are health care and social assistance (99,333), construction (54,791) and retail (53,802). Census BFS was not fetched in this pass.
- **Buyer clusters:**
  - **Johnson County / Overland Park and KCK** (KC metro, bi-state with MO): professional services, health care, home services, restaurants.
  - **Wichita:** aviation-supplier machine shops, and roofing and exteriors (one of the most hail-hit metros; verify ranking).
  - **Topeka and Lawrence:** government and university services.
  - **Manhattan:** Fort Riley and K-State.
  - **Western Kansas (Garden City, Dodge City, Hays, Liberal):** feedlots, meatpacking suppliers, wheat co-ops, custom harvesters and applicators, oil-field services.
- **Industries overweight vs. US:** agriculture and ag retail, construction and roofing (hail), aviation manufacturing suppliers, oil and gas services, trucking (I-70/I-35). Overweights are estimates.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Kansas Roofing Contractor Registration Act** (K.S.A. 50-6,121 et seq.). Roofers register with the Attorney General, carry insurance, and may not offer to pay or rebate an insurance deductible (from knowledge; the AG page returned 403, verify details and renewal cycle). | Residential and commercial roofers, including out-of-state storm chasers | In force; annual renewal (verify) | C02, C07 |
| **Bi-state KC payroll:** KS and MO withholding for staff crossing State Line, plus KCMO 1% earnings tax for KS firms with KCMO workers (verify) | KC-metro employers | Ongoing, and each Jan 1 | G04 |
| **IFTA quarterly return** | Interstate carriers, ag and oil haulers | **Oct 31 2026** | K03 |
| **Food sales tax:** state rate on groceries cut to 0% on Jan 1 2025 (verify) | Grocery stores, c-stores, farm stores (POS rate tables) | Jan 2025 (passed) | D09 (weak) |
| **Medicaid EVV:** sources conflict (First Data vs HHAeXchange open model) | Home care | In force | E07 (weak until confirmed) |
| **No comprehensive state privacy law** found for KS (verify) | n/a | n/a | J02 (weak) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall | Top score (23). Construction is the #2 small-business employer, and hail brings a lead-buying frenzy every spring. |
| 2 | C02 | StormDesk | Wichita is a hail capital. A roofing CRM with the KS AG registration and deductible rules built into contracts, plus flat unlimited-user pricing for storm hiring surges. |
| 3 | A03 | LocalLoop | Score 22. Reviews and texting for KC-suburb clinics, salons and auto shops. |
| 4 | C07 | ClaimKit | Hail claims drive supplement and photo-documentation work for roofers and restorers. Carriers reject O&P about 85% of the time. |
| 5 | K03 | HaulDesk | I-70/I-35 trucking plus ag and oil hauling. IFTA is due Oct 31 2026. |
| 6 | F01 | Chairly | Score 22. Salons and barbers across Johnson County and Wichita. |
| 7 | G04 | StatePay | KC bi-state payroll pain for small Johnson County employers (verify earnings-tax details). |

Close alternates: C03 SprayLog (ag applicators, western KS), C01 FlatRate (Wichita and KC HVAC).

## State-only opportunities
1. **"Kansas-compliant storm roofing" (C02 variant).** Contract templates carrying the AG registration number, a check that blocks any deductible-waiver language, and a crew-registration checklist for out-of-state storm workers. Pitch it as "don't lose your registration after the next hail storm." Buyers are Wichita and KC roofers during the Oct–Feb off-season.
2. **Custom harvester and applicator back office (regional).** Western Kansas custom harvesters and applicators bill per acre across many farms and states. They need job tickets, application records and simple invoicing. Candidate for the regional ag-applicator idea (see MN/IA notes); needs complaint research.

## Where to sell
- **Associations & events** (from knowledge, verify):
  - Kansas Restaurant & Hospitality Association
  - Kansas Building Industry Association and Wichita Area Builders Association
  - Home Builders Association of Greater Kansas City
  - Kansas Association of REALTORS
  - Kansas Society of CPAs
  - Kansas Bar Association
  - Kansas Motor Carriers Association
  - Kansas Agribusiness Retailers Association
  - Kansas Dental Association
- **Online communities:** r/wichita, r/kansas, r/kansascity, r/lawrence, r/topeka. Wichita roofing and contractor Facebook groups (verify).
- **Partners:**
  - Kansas SBDC
  - NetWork Kansas (rural entrepreneurship network and E-Community lenders)
  - KCSourceLink (bi-state)
  - Wichita Regional Chamber
  - Roofing supply houses in Wichita
  - Public adjusters and restoration networks
  - Local banks (Emprise, INTRUST; verify programs)

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials or freedom-to-read law** | None found. PEN America's Dec 2025 report names no Kansas library-materials law, and Kansas is not on the freedom-to-read lists (verify) | n/a | (R01 weak) |
| **Science of reading: Blueprint for Literacy (SB 438, Apr 2024)** | The law creates an Office of Literacy, a Director of Literacy and a Literacy Advisory Committee. The State Board makes **structured literacy the required model**. Other requirements ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/kansas/)):<br>• New teachers complete 6 hours of PD (being revised).<br>• Elementary, ELA, special-education and reading staff must show science-of-reading training (a "Seal of Literacy" micro-credential) to **renew licenses**.<br>• K–8 students are screened 3 times a year, from an approved screener list.<br>No three-cueing ban was found (verify) | In force since 2024 | P01, R08 |
| **3rd-grade reading plan or retention law** | None found (verify) | n/a | (P02 weak) |
| **Homeschool: HSLDA low regulation** | Families register once, in the first year, as a non-accredited private school. HSLDA lists "periodic" assessment and no required subjects ([HSLDA Kansas](https://hslda.org/legal/kansas)) | In force | P03 |
| **ESA and scholarship money** | Kansas has no ESA. There is a tax-credit scholarship for low-income students (amounts not checked; verify). **SB 361 (2026)** opted Kansas into the federal tax-credit scholarship by overriding a veto ([FutureEd](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). Kansas was **not** on the IRS list as of Jun 8 2026 (verify the submission) | Federal credit from Jan 1 2027 (verify) | P07 (weak), F06 (weak) |
| **Other** | A statewide Imagination Library partnership through the Kansas Children's Cabinet is reported but not checked (verify) | — | P06 |

**Top 3 reading/education ideas here:**
- **P01 PhonicsPrep:** license renewal now requires science-of-reading training, and structured literacy is mandatory, so teachers and interventionists need structured-literacy materials.
- **R08 Readlings:** screening 3 times a year in grades K–8 flags readers who need home decodable practice.
- **P03 HomeRoll:** homeschools register once as a non-accredited private school and keep their own records.

**Where to sell:**
- **Libraries:** Kansas Library Association and the Kansas Association of School Librarians (KASL) (both verify).
- **Parents:** Kansas PTA.
- **Homeschool:** Christian Home Educators Confederation of Kansas (CHECK; verify).
- **Reading specialists:** the IDA branch covering Kansas (verify), plus KSDE literacy contacts.
- **Booksellers:** MIBA (verify).

## Launch verdict
**Speed:** Medium. **First city:** Wichita (with Johnson County covered from the KC launch in MO). **Lead offer:** C02 StormDesk bundled with B04 FirstCall: "flat-price storm CRM with Kansas roofing-registration compliance built in." Sell during the Oct–Feb off-season before spring hail.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Kansas](https://advocacy.sba.gov/wp-content/uploads/2025/06/Kansas_2025-State-Profile.pdf)
- Kansas Attorney General, Consumer Protection (ag.ks.gov). The roofing-registration page could not be fetched (403) in this pass, so all Roofing Act details above are marked verify.
- Internal: ../ideas/C02, C07, B04, K03, G04, E07 idea files; ../_state_leads_from_category_research.md
- [The Reading League Compass: Kansas](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/kansas/)
- [HSLDA: Kansas homeschool law](https://hslda.org/legal/kansas)
- [FutureEd: 2026 private school choice bill tracker (Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
- [IRS: Federal scholarship tax credit participating states (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
