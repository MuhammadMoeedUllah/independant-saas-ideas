# Missouri (MO): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 590,131 small businesses employing 1.1 million people, or 44.4% of Missouri employees. 114,694 small employer firms. Data year 2022. ([SBA Advocacy 2025 Missouri profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Missouri_2025-State-Profile.pdf))
- **New-business momentum:** From March 2023 to March 2024, small businesses gained 186,348 jobs and lost 167,211, a net gain of 19,137. They accounted for 26,682 openings and 24,831 closings ([SBA](https://advocacy.sba.gov/wp-content/uploads/2025/06/Missouri_2025-State-Profile.pdf)). The largest small-business employers are health care and social assistance (175,990), construction (114,653) and retail (107,042). Census BFS was not fetched in this pass.
- **Buyer clusters:**
  - **Kansas City (bi-state with KS):** trucking and logistics, construction and roofing, restaurants and BBQ, home services, auto repair. The VISION Hi-Tech auto training expo is held here.
  - **St. Louis:** health care, restaurants, professional services, trades, nonprofits.
  - **Springfield:** trucking (large carrier hub), health care, trades.
  - **Branson and Table Rock Lake:** shows, attractions, motels, campgrounds.
  - **Lake of the Ozarks:** marinas, boat rentals, short-term rentals, bars.
  - **Columbia:** university-town services.
- **Industries overweight vs. US:** construction, retail, trucking and logistics (KC and Springfield), tourism and attractions (Branson, Lake of the Ozarks), and licensed cannabis (a Metrc state). Overweights are estimates.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Minimum wage rose to $15.00/hr for 2026**, up from $13.75 in 2025 (Prop A) | Restaurants, retail, child care, salons | Jan 1 2026 | D04, G04 |
| **Prop A paid sick leave (§290.600) repealed** by HB 567, effective Aug 28 2025. The prior version was in effect Nov 5 2024–Aug 28 2025. | All employers need to update handbooks, posters and accrual settings, and many payroll systems still carry the old accruals | Aug 28 2025 | J03, G04 |
| **ADA website lawsuits:** 86 federal filings in MO in 2025 | Restaurants, retail, clinics | Ongoing | J02 |
| **KC and St. Louis 1% city earnings taxes** plus bi-state KS/MO withholding in the KC metro (verify) | Employers with staff living or working across the state line or in KCMO/STL | Ongoing, and each Jan 1 | G04 |
| **IFTA quarterly return** | Interstate carriers (KC, Springfield) | **Oct 31 2026** | K03 |
| **MOScholars** tax-credit scholarships through Educational Assistance Organizations (IEP and low-income students). Odyssey involvement is per category research (verify). | Private schools | Ongoing | F06 (weak) |
| **Cannabis seed-to-sale (Metrc state)** | Dispensaries, microbusinesses | Ongoing | J04 |
| **Medicaid EVV:** Sandata, closed model (both sources agree) | Home care | In force | E07 (weak: closed model) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall | Two large metros plus Springfield. Construction is the #2 small-business employer (114,653). Angi, Thumbtack and LSA anger is national, and KC and STL are both big LSA markets. |
| 2 | A03 | LocalLoop | Score 22. A big retail (#3 employer), restaurant and auto base spread across two metros. |
| 3 | F01 | Chairly | Score 22. Salons and barbers in KC, STL and Springfield. The $15 wage pushes owners to cut software fees. |
| 4 | K03 | HaulDesk | KC and Springfield trucking hubs. IFTA is due Oct 31 2026 and DAT renewals are up 25–45%. |
| 5 | D04 | ShiftTip | The $15 minimum wage (Jan 2026) squeezes restaurant labor. Scheduling to budget and clean tip reporting sell here. |
| 6 | D07 | BookTrail | Branson attractions and Lake of the Ozarks boat and tour operators pay FareHarbor's 6% guest fee. The Nov–Mar off-season is the switch window. |
| 7 | G04 | StatePay | The bi-state KC metro (KS/MO withholding plus KCMO earnings tax) and the Prop A sick-leave repeal clean-up are pain Gusto and ADP handle poorly for tiny firms (verify). |

Close alternates: J02 SiteShield (86 ADA suits), D06 SiteLoop (Ozarks RV parks), K01 BayBook (the VISION expo in KC is a channel).

## State-only opportunities
1. **Bi-state KC payroll and compliance (G04/J03 variant).** A "KC metro" payroll and HR pack: KS and MO withholding in one run, KCMO earnings-tax withholding (verify), posters for both states, and clean-up of the repealed MO sick-leave accruals. Sold to Kansas City SMBs whose staff cross State Line Road daily.
2. **Branson and Ozarks attractions bundle (D07 + D05 + D06).** Show theaters, attractions, motels and RV parks cluster in one market with one tourism season. An all-in-price booking engine with no guest booking fee, plus off-season migration, can win a whole cluster through the Branson/Lakes Area Chamber.

## Where to sell
- **Associations & events** (from knowledge, verify):
  - Missouri Restaurant Association
  - Missouri Hotel & Lodging Association
  - Home Builders Association of Greater Kansas City (bi-state) and HBA of St. Louis & Eastern Missouri
  - Missouri REALTORS
  - Missouri Society of CPAs
  - The Missouri Bar
  - Missouri Dental Association
  - Missouri Trucking Association
  - Branson/Lakes Area Chamber & CVB
  - Lake of the Ozarks chambers
  - MoCannTrade (cannabis)
  - VISION Hi-Tech Training & Expo (KC, spring; auto repair)
- **Online communities:** r/kansascity, r/StLouis, r/springfieldMO, r/columbiamo, r/missouri. KC and STL small-business Facebook groups (verify).
- **Partners:**
  - Missouri SBDC (University of Missouri Extension)
  - KCSourceLink (bi-state KC small-business network)
  - St. Louis Regional Chamber
  - Bi-state CPAs and payroll bureaus
  - Commerce Bank / UMB small-business banking (verify programs)
  - Trucking insurance agents

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| **School library-materials law: SB 775 (2022), struck down** | Made it a misdemeanor for school employees to provide students with visual depictions of sexual conduct. Nearly 300 books were removed after it passed. A court **struck it down in Nov 2025** as unconstitutionally vague and overbroad ([PEN America, Dec 18 2025](https://pen.org/report/the-bills-igniting-book-bans/)) | Struck Nov 2025 | R01 (weak), R07 |
| **Science of reading and three-cueing ban (2025)** | A law signed by Gov. Kehoe in Jul 2025 (Jul 9 per Missouri Independent, via P01) allows three-cueing only as a supplement, with phonics as the main method. **Districts must confirm each year, by checklist, that three-cueing is not their primary model** ([KCUR, Jul 12 2025](https://www.kcur.org/education/2025-07-12/missouri-three-cueing-ban-education)); bill number not confirmed (verify). Related statutes ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/missouri/)):<br>• **RSMo 170.014:** evidence-based K–5 programs and training for new K–3 teachers.<br>• **RSMo 167.950:** dyslexia screening and 2 hours of dyslexia PD a year.<br>• **RSMo 161.097:** reading coursework in teacher preparation.<br>LETRS reached **429 districts and 8,600+ educators by spring 2025** (KCUR) | Annual district checklist | P01, R08 |
| **3rd-grade reading plan or retention: Reading Success Plans (RSMo 167.645)** | K–3 reading tests at the start and end of the year (and for newly enrolled students in grades 1–5), and **Reading Success Plans** for students with substantial reading deficiencies or dyslexia risk (Compass). Conditional retention per category research (verify) | In force | P02 |
| **Homeschool: HSLDA "No notice, low regulation"** | No notice (HSLDA reports the declaration of enrollment was abolished), and a bill opened sports and activities to homeschoolers (HB 2426, per HSLDA; verify). State subjects and record keeping apply ([HSLDA Missouri](https://hslda.org/legal/missouri)). The 1,000-hour (600 core) rule and the required plan book, portfolio and evaluations were not detailed on the page (verify) | In force | P03 |
| **ESA and scholarship money: MOScholars** | Open to students with an IEP or ISP (a service plan, within 36 months), or households at or below 300% of the free/reduced-lunch income level that also meet an attendance or sibling rule. Covers tuition, required textbooks, therapies, **tutoring, curriculum**, Missouri virtual school, test fees, technology devices, summer programs and mileage. Consumable supplies are excluded. EAO (the scholarship groups) applications are due Nov 7 ([MO Treasurer FAQ](https://treasurer.mo.gov/MOScholars/FAQs.aspx)). Award amounts were not listed (verify). **SB 998 (2026)**, which would drop the prior-public-school rule, was not enacted ([FutureEd](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). Missouri is in the federal tax-credit scholarship ([IRS, Jun 8 2026](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | EAO deadline Nov 7; federal credit 2027 | P04, P07, P01, F06, F07 |
| **Other: Imagination Library** | State funding was cut from **$6M to $2M** while **170,000+ children** are enrolled. The Dollywood Foundation says the state "has not fulfilled its commitment" (Fulton Sun, May 20 2026, via P06) | 2026–27 budget | P06, R02 |

**Top 3 reading/education ideas here:**
- **P06 StoryNest:** with Imagination Library funding cut by two-thirds for 170k enrolled children, local affiliates, libraries and preschools need cheaper family-reading tools and book lending.
- **P01 PhonicsPrep:** the annual no-three-cueing checklist, dyslexia PD and Reading Success Plans, plus MOScholars money for tutoring and curriculum.
- **P03 HomeRoll:** a no-notice state where good records (hours and portfolio; verify) are the family's only proof.

**Where to sell:**
- **Libraries:** Missouri Library Association (fall conference; verify) and the Missouri Association of School Librarians (MASL; verify).
- **Parents:** Missouri PTA.
- **Homeschool:** Families for Home Education (FHE; verify).
- **Reading specialists:** IDA branch covering Missouri (verify), plus DESE "Read, Lead, Exceed" LETRS cohorts.
- **Booksellers:** MIBA (verify).

## Launch verdict
**Speed:** Fast. **First city:** Kansas City (one metro reaches MO and KS buyers). **Lead offer:** B04 FirstCall ("own your leads, drop Angi/LSA") for KC trades. Bolt on G04/J03 as a "KC bi-state payroll + poster" hook for Jan 1 2027. K03 HaulDesk before the Oct 31 IFTA deadline is a quick second wedge.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Missouri](https://advocacy.sba.gov/wp-content/uploads/2025/06/Missouri_2025-State-Profile.pdf)
- [Missouri Dept. of Labor, Minimum Wage](https://labor.mo.gov/DLS/MinimumWage)
- [RSMo §290.600, paid sick leave, repealed by HB 567 (2025), Missouri Revisor](https://revisor.mo.gov/main/OneSection.aspx?section=290.600)
- [Missouri State Treasurer, MOScholars](https://treasurer.mo.gov/MOScholars)
- [Seyfarth: federal website accessibility filings 2025 (via J02)](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)
- Internal: ../ideas/B04, K03, D04, D07, G04, J02, J04, E07 idea files; ../_state_leads_from_category_research.md
- [KCUR: Missouri bans three-cueing (Jul 12 2025)](https://www.kcur.org/education/2025-07-12/missouri-three-cueing-ban-education)
- [The Reading League Compass: Missouri](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/missouri/)
- [Missouri State Treasurer: MOScholars FAQs](https://treasurer.mo.gov/MOScholars/FAQs.aspx)
- [HSLDA: Missouri homeschool law](https://hslda.org/legal/missouri)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [FutureEd: 2026 private school choice bill tracker (Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
- [IRS: Federal scholarship tax credit participating states (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- Internal: ../ideas/P06 (Fulton Sun on Imagination Library cut), P01 (Missouri Independent on the three-cueing law)
