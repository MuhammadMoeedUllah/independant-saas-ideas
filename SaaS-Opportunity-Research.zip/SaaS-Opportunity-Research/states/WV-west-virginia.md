# West Virginia (WV): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 118,045 small businesses (98.8% of WV businesses), employing 256,281 people (47.4% of private employees). 93,669 are nonemployer firms ([SBA Advocacy 2025 WV profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/West_Virginia_2025-State-Profile.pdf)).
- **New-business momentum:**
  - From Mar 2023 to Mar 2024, small firms opened 6,099 establishments and closed 4,162, a healthy ratio for a small state.
  - Small businesses created a net 5,885 jobs (61.0% of the total) ([SBA Advocacy 2025](https://advocacy.sba.gov/wp-content/uploads/2025/06/West_Virginia_2025-State-Profile.pdf)).
  - Census BFS trend was not fetched in this pass.
- **Buyer clusters** (estimate, verify):
  - **Charleston and the Kanawha Valley:** government, health care, legal, trades.
  - **Morgantown and the I-79 corridor:** WVU-driven services, health care, energy services.
  - **Huntington:** health care, trades.
  - **Eastern Panhandle** (Martinsburg, Charles Town): fast-growing DC exurb; commuters, contractors, home services.
  - **New River Gorge and Fayetteville; Snowshoe; Hatfield-McCoy trails:** outfitters, cabins, ATV rentals.
- **Industries overweight vs. US** (SBA; comparison is an estimate):
  - **"Other services":** 15,971 small firms, WV's largest small-business sector. Includes auto repair, personal care, religious orgs.
  - **Health care:** 52,985 small-business employees, the largest employer.
  - **Construction:** 12,454 firms and 22,740 employees.
  - **Retail:** 12,282 firms and 27,831 employees.
  - Also energy services and trucking, and a newly booming **education-provider** market (Hope Scholarship).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **Hope Scholarship goes universal** ([Hope FAQ](https://hopescholarshipwv.gov/Home/About/FAQ); [Hope Scholarship](https://hopescholarshipwv.gov/)):<br>• "Effective July 1, 2026, all West Virginia students will be eligible," including private-school and homeschool students.<br>• Award: $5,435.62 per student for 2026–27.<br>• Education Service Providers (ESPs) generate invoices in the Hope portal and are paid by ACH.<br>• Funding windows: 100% (Mar 2–Jun 15 2026), 75% (Jun 16–Sep 15), **50% (Sep 16–Nov 30 2026)**, 25% (Dec 1 2026–Feb 28 2027). | Private schools, microschools, tutors, therapists, online programs; new ESPs | Jul 1 2026; the 50% window is open now | F06, F07 |
| **Hope payment platform.** The official site describes its own Hope portal plus "TheoPay" (fulfillment and one-time virtual cards up to $75) and does not mention ClassWallet ([TheoPay page](https://hopescholarshipwv.gov/Home/Parents-Students/TheoPay)). **Correction to the lead list,** which placed WV on ClassWallet. | ESPs and families | Current (Sep 2026) | F06, F07 |
| **Medicaid EVV.** HHAeXchange is listed as WV's state aggregator, but sources conflict ([HHAeXchange](https://www.hhaexchange.com/state-evv-status), via E07; verify) | Personal-care and home-health agencies | Ongoing | E07 |
| **Medical cannabis track-and-trace.** WV is a Metrc state ([Metrc](https://www.metrc.com/partners/)). | Licensed growers, processors, dispensaries | Ongoing | J04 |
| **NFIRS retired; departments report to NERIS** | WV fire departments, mostly volunteer (estimate) | Since Jan 31 2026 | J07 |
| **IFTA Q3 return** | Coal, gas and timber haulers; small fleets | Oct 31 2026 | K03 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | F06 | ESA Desk (enrollment + ESA billing for private and microschools) | Hope went universal on Jul 1 2026, so thousands of newly eligible private-school and homeschool families can now spend $5,435.62 each. Schools and microschools need enrollment, tuition splitting between Hope and parent, and Hope-portal invoicing. Rolling funding windows through Feb 2027 keep new families arriving. |
| 2 | F07 | LessonLedger (tutors, music, therapy) | Tutoring and therapies are eligible Hope expenses. Solo tutors and therapists becoming ESPs need itemized, Hope-ready invoices and attendance logs. |
| 3 | B04 | FirstCall (owned lead capture) | Top score (23). The Eastern Panhandle's DC-exurb growth and statewide roofing and remodeling demand. |
| 4 | F01 | Chairly (salon/barber booking) | Personal care sits in WV's largest small-business sector ("Other services"). Fresha/Vagaro fee pain. |
| 5 | A03 | LocalLoop (reviews + texting) | A universal fit for clinics, auto shops and trades in small-town markets where reviews decide. |
| 6 | K01 | BayBook (auto repair shop software) | Auto repair is also in "Other services." Rural shops are price-sensitive and annoyed by Tekmetric/Shopmonkey tier creep. |
| 7 | D07 | BookTrail (FareHarbor/Peek alternative) | New River Gorge rafting, climbing and zipline outfitters, plus ATV-trail rentals. FareHarbor's 6% guest fee. The winter off-season is the switch window. |

## State-only opportunities
1. **Hope Scholarship provider toolkit** (F06/F07 "WV pack"). The pieces:
   - ESP onboarding checklist (New Provider Request Form, ESP Handbook).
   - Hope-portal invoice generator with a pre-submit rejection check.
   - Split billing for the 50% and 25% late-window awards.
   - Parent-facing "what Hope covers" pages.
   This is WV-specific and timely because universality started Jul 1 2026 and first-time providers are onboarding now. F06/F07 cover the product, so there is no separate S2 file. Note: WV's platform is its own Hope portal plus TheoPay, not ClassWallet, so the F06 integration list needs updating.
2. **Outdoor-outfitter bundle** (D07 + H03) for Fayetteville and the New River Gorge (cabins plus trips in one checkout). A small but concentrated cluster.
3. **Home-care EVV exporter** (E07) for small WV agencies feeding the state aggregator. The fit is strong given health care's weight in WV, but the aggregator details must be verified first.

## Where to sell
All names below are from background knowledge (verify), except the Hope program links.
- **Associations & events:**
  - West Virginia Chamber of Commerce; WV Hospitality & Travel Association.
  - WV Society of CPAs; West Virginia State Bar; WV Home Builders Association; WV Trucking Association.
  - West Virginia Professional River Outfitters; the West Virginia Microschool/homeschool networks that grew after Hope.
- **Online communities:** r/WestVirginia, r/Morgantown, r/Charleston_WV; "Hope Scholarship" parent and provider Facebook groups (large, active; verify names); WV homeschool co-op groups.
- **Partners:** WV SBDC; Hope Scholarship ESP network ([ESP Handbook](https://hopescholarshipwv.gov/LinkClick.aspx?fileticket=lNsb92NgARs%3d&tabid=356&portalid=7)); private-school associations and church schools; rural credit unions; tourism CVBs (New River Gorge CVB).

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law | PEN's Dec 2025 roundup found no statewide school library-materials law for WV (verify 2026 session). | n/a | R01 (weak) |
| **Science of reading / three-cueing: Third Grade Success Act (HB 3035, 2023)**, W. Va. Code §18-2E-10 | Instructional materials "shall not include practices that are aligned with the Three-Cueing Systems Model of teaching reading" (§18-2E-10(g)) ([WV Code](https://code.wvlegislature.gov/18-2E-10/)). The Act also adds screeners, dyslexia and dyscalculia assessments, and extra K–3 support staff ([WVDE](https://wvde.us/academics/early-elementary-education/third-grade-success-act)). | In force | P01, R08 |
| **3rd-grade retention (reading and math)** | **Retention:** starting **2026–27**, 3rd graders who show minimal understanding of grade-level **ELA or math** are retained, with exceptions (§18-2E-10(o)). **Parent notice:** within **15 days** of identifying a deficiency, in writing, covering the interventions, home strategies and the risk of retention. **Plan:** an individual reading improvement plan within **30 days** ([WV Code](https://code.wvlegislature.gov/18-2E-10/)). WVDE also uses individual math plans and published retention guidance v2.0 in Nov 2025 ([WVDE](https://wvde.us/academics/early-elementary-education/third-grade-success-act)). | **First retention year is 2026–27 (now)** | P02 |
| Homeschool (HSLDA page: **low**; FreedomRankings: moderate-high; verify tier) | Three options. Notice required, teacher qualifications required, state-mandated subjects, and assessment required under options 2 and 3 ([HSLDA](https://hslda.org/legal/west-virginia)). | Annual | P03 |
| **ESA: Hope Scholarship** | **$5,435.62** per student for 2026–27. Universal from Jul 1 2026, so homeschool families qualify. It runs on the Hope portal plus TheoPay (see table above). A family that isn't paying tuition can spend the full award on tutoring, curriculum and technology ([Learner, Mar 2026](https://www.learner.com/blog/west-virginia-hope-scholarship-complete-guide); that guide quotes ~$5,267, the older figure). | Funding window Sep 16–Nov 30 2026 | P03, P04, P07, R08 (+F07) |
| Other | Statewide Imagination Library funding (verify). | n/a | P06 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home.** 2026–27 is the first retention year, and it covers **math as well as reading**. The 15-day notice and 30-day plan clocks give a parent portal a legal schedule to track.
- **P03 HomeRoll (+P07 receipts).** Universal Hope money ($5,435.62) now reaches homeschool families, who need both records and receipts.
- **R08 Readlings.** WV has a statutory three-cueing ban, R08 already plans free pilots here, and families can pay for it with Hope.

**Where to sell** (names from background knowledge; verify months):
- West Virginia Library Association (fall conference).
- WV PTA.
- Christian Home Educators of West Virginia (CHEWV) and WV Home Educators Association.
- Hope Scholarship parent and ESP groups.
- IDA or Reading League contacts (verify).
- The regional bookseller association (verify: SIBA or NAIBA).

## Launch verdict
**Speed:** Slow overall (small, lower-income market), but the Hope-provider niche is **fast** now. **First city:** Charleston (with Morgantown for tutors and microschools). **Lead offer:** F06 ESA Desk / F07 LessonLedger, "Get paid by Hope without the paperwork," a free Hope-ready invoice template during the Sep 16–Nov 30 2026 funding window.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: West Virginia](https://advocacy.sba.gov/wp-content/uploads/2025/06/West_Virginia_2025-State-Profile.pdf)
- [Hope Scholarship, WV homepage (funding windows, 2026–27 eligibility)](https://hopescholarshipwv.gov/)
- [Hope Scholarship FAQ ($5,435.62 award; universal from Jul 1 2026; ESP ACH payments)](https://hopescholarshipwv.gov/Home/About/FAQ)
- [Hope Scholarship, TheoPay](https://hopescholarshipwv.gov/Home/Parents-Students/TheoPay)
- [HHAeXchange state EVV status](https://www.hhaexchange.com/state-evv-status)
- [Metrc partners/markets](https://www.metrc.com/partners/)
- [W. Va. Code §18-2E-10 (Third Grade Success Act: three-cueing ban, retention 2026–27, 15-/30-day parent notice and plan)](https://code.wvlegislature.gov/18-2E-10/)
- [WVDE: Third Grade Success Act](https://wvde.us/academics/early-elementary-education/third-grade-success-act)
- [HSLDA: West Virginia homeschool law](https://hslda.org/legal/west-virginia)
- [Learner: West Virginia Hope Scholarship guide (Mar 13 2026)](https://www.learner.com/blog/west-virginia-hope-scholarship-complete-guide)
- [PEN America: The bills igniting book bans (Dec 18 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- Internal (education): ideas P02, P03, P07, R08
