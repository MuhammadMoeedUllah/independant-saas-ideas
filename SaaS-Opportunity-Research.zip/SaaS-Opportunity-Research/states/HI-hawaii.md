# Hawaii (HI): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 144,375 small businesses, which is 99.3% of Hawaii businesses. They employ 251,556 people, or 49.6% of the private workforce. 119,647 have no employees, which leaves roughly 25k small employers (our subtraction, an estimate) ([SBA Advocacy 2025 Hawaii profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Hawaii_2025-State-Profile.pdf)).
- **New-business momentum:** Weak. From March 2023 to March 2024, small firms opened 4,265 establishments and closed 4,454. Small firms added only 129 of the state's 1,808 net new jobs (7.1%) (SBA profile). The post-Lahaina (Aug 2023) Maui economy and high costs weigh on formation. Census Business Formation Statistics were not pulled.
- **Largest small-business employers:** **Accommodation & food services is #1 (46,743)**, ahead of health care & social assistance (35,446) and construction (25,835) (SBA profile). Hawaii and Alaska are the only states in this group where hospitality leads.
- **Buyer clusters:**
  - **Honolulu/Oahu:** Waikiki hotels, restaurants and tour operators; condo associations (AOAOs); trades; military-adjacent contractors. FareHarbor was founded in Honolulu (background, verify), so the local tour market is dense with its users.
  - **Maui:** Lahaina rebuild contractors, vacation-rental owners and managers facing a TVR phase-out, snorkel/boat/zipline tours, restaurants.
  - **Hawaii Island (Kona/Hilo):** tours (manta, volcano, coffee farms), coffee and macadamia farms, STRs.
  - **Kauai:** tours (boat, helicopter), STRs, restaurants.
- **Industries overweight vs. US:**
  - Accommodation and food service (the SBA ranking confirms this).
  - Tours and activities.
  - Vacation rentals and condo-hotel management.
  - Construction and rebuilding.
  - Specialty agriculture (coffee, macadamia).
  - Military contracting.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **General Excise Tax (GET)**, charged on gross receipts instead of a sales tax. The rate is 4% (0.5% for wholesale), plus a 0.5% county surcharge on Oahu, Kauai and Hawaii County through 2030, and on Maui from Jan 1 2024 to 2030. Periodic returns are due "the 20th day of the month following the close of the tax period," and the annual return by Apr 20 ([HI DoTax GET](https://tax.hawaii.gov/geninfo/get/)) | Every business, including services, tours, STRs and contractors | Monthly/quarterly/semiannual on the 20th, annual Apr 20 | G02 PlainLedger, G03 SeasonDesk, D07 BookTrail, H03 StayDesk, J01 NexusBook |
| **Transient Accommodations Tax "green fee."** TAT rises to 11% from Jan 1 2026 and extends to cruise ships (Act 96, SLH 2025; **verify**; the DoTax TAT page and the Legislature both refused our fetch). The county TAT is added on top (verify rate) | Hotels, condo-hotels, STR hosts, and property managers who remit TAT and GET | Jan 1 2026 (verify) | H03 StayDesk, D05 InnDesk |
| **Maui Bill 9 TVR phase-out** in apartment districts. It passed in late 2025 with phase-out dates in West Maui and then the rest of Maui, affecting several thousand units (**verify**; mauicounty.gov rate-limited our fetch) | Maui vacation-rental owners and managers | Phase-out 2028–2030 (verify) | H03 StayDesk, H01 DoorLedger (conversion to long-term), H02 BoardBinder |
| **Oahu 90-day minimum stay** for non-permitted rentals (Ord. 22-7; verify) | Oahu hosts | In force (verify) | H03, H01 |
| **Minimum wage.** "$16.00 per hour beginning January 1, 2026" and "$18.00 per hour beginning January 1, 2028." **A tip credit is allowed** "under certain conditions" ([HI DLIR](https://labor.hawaii.gov/wsd/minimum-wage/); verify amount) | Restaurants, hotels, retail, tours | Jan 1 2026 (done) / Jan 1 2028 | D04 ShiftTip, G04 StatePay |
| **Prepaid Health Care Act and Temporary Disability Insurance.** Employers must provide health coverage to employees working 20+ hours a week, and TDI coverage is required (background; verify thresholds) | Every employer, a unique HI burden | Ongoing | G04 StatePay |
| **Lahaina rebuild** under Maui County permitting (verify permit counts) | Maui contractors and homeowners | 2025–2028 | C05 FlatBuild, S8-01 RebuildLedger (Maui edition), C07 ClaimKit |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | D07 | BookTrail (tours/activities booking) | Hawaii is likely the most tour-dense state per capita: snorkel boats, helicopters, luaus, manta dives, surf schools. FareHarbor's home market means a big pool of operators reacting to the 6% guest fee and the 2026 "Desk" migration. GET/TAT-aware all-in pricing is a local differentiator. |
| 2 | H03 | StayDesk (STR PMS + permit/tax ledger) | Hosts must file GET and TAT themselves (plus county TAT), unlike most states where platforms do it all. Maui's Bill 9 and Oahu's 90-day rule force a switch to 30+/90-day stays, which most STR tools handle badly. A flat per-property price beats Guesty and Hostaway. |
| 3 | D04 | ShiftTip (scheduling + tip pooling) | Hospitality is the #1 small-business employer (46,743). The $16 minimum wage (2026), $18 in 2028, and tip-credit conditions make tip-pool and tip-credit math critical, which a flat per-location product gets right. |
| 4 | H01 | DoorLedger (small-landlord PM) | TVR phase-outs push Maui and Oahu owners into long-term renting. Many are first-time landlords who need leases, deposits, GET on rent, and owner statements. |
| 5 | C05 | FlatBuild (remodeler/builder PM) | Lahaina rebuild plus Oahu remodel demand; construction is the #3 small-business employer. The CoConstruct Mar 31 2027 cutoff applies. Port S8-01's rebuild draw and documentation tools to Maui. |
| 6 | B04 | FirstCall (owned lead capture for trades) | High trade prices and island logistics make every missed call expensive. There are fewer marketplace alternatives, so owned lead capture matters. It carries the highest national score. |
| 7 | G04 | StatePay (compliance copilot beside payroll) | Hawaii's unique Prepaid Health Care Act and TDI mandates, plus GET withholding on contractors (verify), confuse mainland payroll tools and small owners. An "is this person covered?" checker and calendar is simple to build. |

*Just outside the Top 7:* **H02 BoardBinder** (condo associations facing insurance spikes and TVR conversion votes; verify), **D05 InnDesk** (small inns and condo-hotels; TAT), **D03 TableKeep** (Waikiki and Maui restaurants).

## State-only opportunities
1. **GET/TAT filing helper for hosts and tour operators** (H03 + D07 module). It tracks gross receipts by county, with the 4% + 0.5% county surcharge split, TAT (verify 2026 rate) and county TAT. It shows which platform collected what and produces a ready-to-file summary on the 20th. It is high-need and cheap to build, but the Act 96 rates need verifying before any full idea file.
2. **Maui TVR transition planner** (H03 → H01 path). It models 30+/90-day stay rules, converts listings to mid-term leases, and handles owner communications for condo-hotel managers. The phase-out dates must be confirmed first.
3. **Lahaina edition of RebuildLedger (S8-01).** Draw documentation, change orders and permit tracking for Maui rebuild contractors.

## Where to sell
- **Associations & events:**
  - **Hospitality and tourism:** Hawaii Lodging & Tourism Association (HLTA), Hawaii Restaurant Association, Activities & Attractions Association of Hawaii (verify), Hawaii Tourism Conference (verify).
  - **Building and property:** Building Industry Association of Hawaii (BIA-Hawaii; Home Building & Remodeling Show, verify month), Hawaii Association of REALTORS, Hawaii Council of Associations of Apartment Owners (verify).
  - **Business and professional:** Chamber of Commerce Hawaii, Maui Chamber of Commerce, Kona-Kohala Chamber, Hawaii Society of CPAs (verify), Hawaii State Bar Association, Hawaii Dental Association.
- **Online communities:** r/Hawaii, r/maui, r/BigIsland, r/KauaiHawaii (verify), r/Honolulu (verify). Facebook groups for Maui vacation-rental owners and managers, Hawaii tour operators and Hawaii small businesses (verify names).
- **Partners:**
  - Hawaii SBDC (hosted by UH Hilo; verify) and Maui Economic Development Board.
  - Banks (First Hawaiian, Bank of Hawaii, Central Pacific).
  - Credit unions (HawaiiUSA FCU, Hawaii State FCU; verify).
  - Condo-hotel management companies.
  - CPAs who file GET and TAT for hosts.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law | None found on our lead lists (verify). Hawaii runs one statewide public school district and one statewide public library system (verify), so each is a single buyer, not dozens. | — | R01 (weak), R03 |
| Science of reading / three-cueing law | Not confirmed on a fetched page (verify against the [EdWeek tracker](https://www.edweek.org/teaching-learning/which-states-have-passed-science-of-reading-laws-whats-in-them/2022/07)). | — | P01, R08 |
| 3rd-grade reading plan / retention law | No retention mandate on the lead lists (verify) | — | P02 (weak) |
| Homeschool rules (HSLDA tier: **low**) | One option. Notice and assessment are required; the assessment grades need checking (verify). No state-mandated subjects, but "other curriculum requirements" apply. No teacher qualifications ([HSLDA HI](https://hslda.org/legal/hawaii)). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **None.** Hawaii is one of the 13 states that do not conform to federal K–12 529 treatment (via P03/P07, Savingforcollege Jan 5 2026). | — | P07 |
| Other | No state Imagination Library funding confirmed (verify). | — | P06 |

**Top 3 reading/education ideas here:**
- **P03 HomeRoll:** a low-regulation state that still requires notice and testing, so keeping records is the job to be done.
- **P07 LearnLedger:** 529 non-conformity means a K–12 withdrawal can carry a state-tax cost.
- **R02 ReadRally:** a single statewide library system (verify) and a single DOE mean one reading-challenge contract could cover the whole state. The sales cycle is slow, but a win covers everything.

**Where to sell:**
- **Libraries:** Hawaii Library Association (conference: verify), the Hawaii Association of School Librarians (verify), and the Hawaii State Public Library System.
- **Parents:** Hawaii State PTSA (verify) and Hawaii homeschool associations (names: verify).
- **Reading:** IDA Hawaii branch (verify).
- **Booksellers:** no regional bookseller association is confirmed for Hawaii (verify).

## Launch verdict
**Speed:** Medium. The base is small (about 25k employers) with weak formation. But tourism-heavy buyers are concentrated and reachable, and there are two local pain spikes: GET/TAT filing and the TVR phase-out. **First city:** Honolulu (then Maui). **Lead offer:** BookTrail for tour operators, with "no guest booking fee, GET-inclusive all-in pricing, free FareHarbor migration." Follow with StayDesk's GET/TAT ledger for Maui and Oahu hosts once the 2026 TAT and Bill 9 details are verified.

## Sources
- [SBA Office of Advocacy: 2025 Small Business Profile, Hawaii (Jun 2025)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Hawaii_2025-State-Profile.pdf)
- [Hawaii Department of Taxation: General Excise Tax (rates, county surcharges, filing dates)](https://tax.hawaii.gov/geninfo/get/)
- [Hawaii DLIR: Minimum wage ($16 from Jan 1 2026, $18 from Jan 1 2028; tip credit)](https://labor.hawaii.gov/wsd/minimum-wage/)
- Internal: `_scoreboard.csv`, `_state_leads_from_category_research.md`, ideas D07 (FareHarbor Desk, 6% guest fee), H03, D04, H01, C05, B04, G04.
- [HSLDA: Hawaii homeschool laws](https://hslda.org/legal/hawaii)
- Internal: ideas P03, P07 (529 non-conformity list, Savingforcollege Jan 5 2026)
