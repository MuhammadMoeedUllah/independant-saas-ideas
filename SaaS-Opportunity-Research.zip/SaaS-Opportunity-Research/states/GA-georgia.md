# Georgia (GA): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 1.4 million small businesses (99.7% of GA businesses) employ 1.8 million people, or 42.5% of GA employees (2022). From Mar 2023 to Mar 2024, small businesses accounted for 38,952 establishment openings and 34,762 closings and added a net 45,950 jobs ([SBA Advocacy 2025 Georgia profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Georgia_2025-State-Profile.pdf)).
- **New-business momentum:**
  - **198,985 business applications in Jan–Aug 2026** (not seasonally adjusted), **4.6% of US applications**, from about 3.3% of US population (population share from memory, verify). Only FL, CA, TX and NY were higher among the states checked ([Census BFS monthly CSV](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)).
  - Small-business employment grew 26.0% from 1998 to 2022, above the national rate.
  - Most small-business employees: accommodation and food services (277,660), health care and social assistance (246,539) and construction (161,509).
  - Most small firms: other services (182,664), professional/scientific/technical (165,839) and administrative/support/waste management (158,020), which covers cleaning, landscaping, staffing and pest control (SBA profile).
- **Buyer clusters:**
  - **Metro Atlanta** (Gwinnett, Cobb, Fulton, DeKalb, Cherokee, Forsyth): home services, salons and barbershops, staffing, logistics, churches, film/TV crews and creatives, dental and medical practices, and franchise HQs.
  - **Savannah:** port logistics and trucking, tourism (tours, weddings), and short-term rentals.
  - **Augusta, Columbus and Macon:** military families and health care.
  - **North GA mountains** (Blue Ridge, Helen): cabin rentals and tours.
- **Industries overweight vs. US** (inference, verify):
  - Admin/support/waste services, a firm-count leader (staffing, janitorial, landscaping).
  - Logistics and trucking (Atlanta hub, Port of Savannah).
  - Film/TV production services.
  - Beauty and barbering, with Atlanta a national Black-owned beauty market (verify).
  - Churches and faith organizations.

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **O.C.G.A. 36-60-6, E-Verify for private employers with more than 10 employees** (phased in by Jul 1 2013). To **obtain or renew any business license** the employer files an affidavit with its E-Verify user number and date of authority, or swears it has fewer than 11 employees ([Justia, 2022 code](https://law.justia.com/codes/georgia/title-36/chapter-60/section-36-60-6/)). | Every employer with 11+ staff, at each annual city or county license renewal | Annual renewal (many jurisdictions renew in Q1; verify) | G04, J03, regional E-Verify kit |
| **O.C.G.A. 44-14-366, statutory lien-waiver forms** (interim and final, 12-point font, mandated notice text). A signed waiver becomes binding unless the claimant files an **affidavit of nonpayment within 90 days** (reading per [Justia 2025 code](https://law.justia.com/codes/georgia/title-44/chapter-14/article-8/part-3/section-44-14-366/); verify against current O.C.G.A. because a 2020 reform may have changed the window). Subs routinely sign waivers before they are paid. | Subcontractors and suppliers, remodelers | Ongoing | C06, C05 |
| **Georgia Promise Scholarship ESA** (SB 233, 2024). Odyssey runs the payments ([GetESAPaid rail list](https://getesapaid.com/become-an-esa-vendor)). About $6,500 per student, with year 2 in 2026–27 (amount and year from memory, verify). | Private schools, microschools, tutors and therapists | School year 2026–27 | F06, F07 |
| **No comprehensive privacy law** (not in the 20-state list, [privacyterms.io](https://privacyterms.io/us-state-privacy-laws-2026)). | n/a | n/a | J02 is weak here |
| **Minimum wage:** the state rate is $5.15, but FLSA-covered employers pay the federal $7.25 ([DOL](https://www.dol.gov/agencies/whd/minimum-wage/state)). | n/a | No change | Low payroll-law churn (G04 weaker) |
| **IFTA quarterly returns** (Oct 31, Jan 31, Apr 30, Jul 31). | Small carriers around Atlanta and Savannah | **Oct 31 2026** | K03 |
| **Consumable hemp licensing and 21+ sales** (SB 494, 2024; verify), plus the federal hemp cap (~Nov 2026). | Smoke and hemp shops | 2026 | J04 (weak) |
| **Medicaid EVV:** sources conflict on GA's aggregator (Netsmart/Tellus vs. Conduent), and HHAeXchange's state info hub does not list GA. | Home care | Verify before selling | E07 (hold) |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall (owned lead capture) | B04's research names Atlanta among the costliest lead metros. A dense base of trades buys Angi, Thumbtack and LSA leads every month: 158,020 admin/support/waste firms and 161,509 small-business construction employees. |
| 2 | F01 | Chairly (salon/barber booking) | Atlanta's salon-suite and barbershop density, with Fresha's paid switch and 20% new-client commissions as the hook. Work the Bronner Bros. beauty show in Atlanta (verify dates). |
| 3 | A03 | LocalLoop (reviews and texting) | Sun Belt home-services and dental hub. There is no state mini-TCPA, so the pitch is price plus ending Podium's 12-month auto-renew. |
| 4 | C01 | FlatRate (field service vs ServiceTitan/HCP) | Long cooling season and many 2–15-truck HVAC and plumbing shops in the suburbs. ServiceTitan exit fees and the jump in Housecall Pro bills drive switching. |
| 5 | K03 | HaulDesk (small-fleet back office) | Atlanta's interstate hub and the Savannah port create many owner-operators and small fleets. IFTA is due Oct 31 and DAT renewals are up 25–45%. |
| 6 | B07 | StudioDesk (HoneyBook alternative) | Atlanta film/TV freelancers, photographers and planners, plus Savannah destination weddings. HoneyBook raised prices 51–89% and ended its loyalty discount. |
| 7 | I02 | TitheBox (church giving) | Dense suburban and megachurch base. Q4 is the giving season (the switch window is now), and Pushpay's multi-year contracts anger small churches. |

Bench:
- **F06 ESA Desk:** Georgia Promise on Odyssey.
- **G07 BenchBoard:** Atlanta is a staffing hub.
- **C06 LienClock:** a GA waiver-form and affidavit-of-nonpayment clock.
- **G03 SeasonDesk:** Atlanta tax-prep density in the Oct–Dec pre-season window.
- **K01 BayBook:** auto repair.

## State-only opportunities
1. **Business-license E-Verify affidavit autopilot.** GA ties E-Verify to every business-license renewal: an affidavit with the E-Verify user number, in each city or county where the firm is licensed.
   - A small tool could store the E-Verify MOU details and generate each jurisdiction's affidavit.
   - It would calendar renewals across the metro Atlanta cities and counties and log I-9s and E-Verify cases.
   - It fits as a module of G04 or J03 and is part of the regional E-Verify kit (see FL file). E-Verify itself is free, so the price gap is thin.
2. **Georgia lien-waiver guard (C06 module).** Generate the statutory interim and final waiver forms, then start a countdown for filing an affidavit of nonpayment whenever a waiver was signed but payment hasn't cleared. This targets a GA-specific trap where subs lose rights by signing ahead of payment. Verify whether the window is 60 or 90 days before building.
3. **Film/TV crew and vendor back office** (a B07 variant): call sheets, W-9 and COI collection, and invoicing for small production-service vendors. Estimate only; not researched.

## Where to sell
- **Associations & events** (verify names and dates):
  - **Hospitality:** Georgia Restaurant Association, Georgia Hotel & Lodging Association.
  - **Building and real estate:** Home Builders Association of Georgia, Georgia REALTORS.
  - **Professional:** Georgia Society of CPAs, State Bar of Georgia (Law Practice Management program), Georgia Dental Association, Georgia Veterinary Medical Association.
  - **Trucking and beauty:** Georgia Motor Trucking Association, Bronner Bros. International Beauty Show (Atlanta).
  - **General business:** Metro Atlanta Chamber, Georgia Chamber.
- **Online communities:** r/Atlanta, r/savannah and r/Georgia; Atlanta Tech Village and startup meetups; Nextdoor for home services; church-admin Facebook groups (names not verified).
- **Partners:**
  - UGA Small Business Development Center (Georgia SBDC network; verify).
  - SiteOne Landscape Supply (HQ in Roswell, GA) and HVAC supply houses, for contractor reach.
  - Community banks: Synovus, Ameris, Truist.
  - Bookkeepers and CPA firms.
  - Business-license offices of Atlanta-area cities, for distributing the affidavit checklist.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law: **SB 226 (2023)** | A complaint process for school library materials alleged to be harmful to minors (per the lead list; verify the steps, the appeal route and the timelines). Follett dropped its planned FL/GA parent-notification modules in Apr 2022 (via R01). | 2023 | R01, R07 |
| Science of reading / three-cueing law | Georgia Early Literacy Act (2023; verify bill). GA is on the lead list's approved-curriculum states. A 2025 three-cueing bill is unverified. | In force | P01, R08 |
| 3rd-grade reading plan / retention law | Conditional-retention state (per the lead list; verify) | In force | P02 |
| Homeschool rules (HSLDA tier: **moderate**) | One option. Notice (declaration of intent), assessment, state-mandated subjects and teacher qualifications are all required ([HSLDA GA](https://hslda.org/legal/georgia)). Testing grades and deadlines are not confirmed (verify). | In force | P03 |
| ESA / scholarship money that can buy books, curriculum and classes | **Georgia Promise Scholarship:** a maximum of **$6,500** per student, of which up to 5% may be withheld for administration. Paid through **Odyssey** ([Odyssey help center, Feb 12 2026](https://support.withodyssey.com/hc/en-us/articles/31787686004251-What-is-the-scholarship-amount)); this confirms the amount in the laws table above. Eligible uses and homeschool access are limited (verify). | 2026–27 (year 2) | P04, P07, R05, R08 |
| Other | Booster (fun runs) is headquartered in Georgia, and Sun Belt suburbs run fun runs as a standard fundraiser (per P05). A statewide Imagination Library partnership is unconfirmed (verify). | — | P05, P06 |

**Top 3 reading/education ideas here:**
- **P05 PTOHub:** Atlanta-suburb PTOs in Gwinnett, Cobb and Fulton sit in Booster's home market, where fun runs are the standard fundraiser. A DIY fun-run and read-a-thon option keeps the fee share with the school.
- **P04 ClassHouse:** it lets tutors and class teachers sell to $6,500 Promise families through Odyssey.
- **R01 ClearShelf:** it gives districts an auditable log for SB 226 complaints and their resolution.

**Where to sell:**
- **Libraries:** Georgia Library Association (Georgia Libraries Conference, fall; verify) and the Georgia Library Media Association (verify).
- **Parents:** Georgia PTA and the Georgia Home Education Association (verify).
- **Reading:** IDA Georgia branch and The Reading League Georgia (verify).
- **Booksellers:** SIBA.

## Launch verdict
**Speed:** Fast. **First city:** Atlanta (start in the Gwinnett/Cobb suburbs). **Lead offer:** FirstCall (B04) for HVAC, plumbing, cleaning and landscaping firms: "stop renting leads." Bundle the GA E-Verify affidavit checklist as a free lead magnet at business-license renewal time. Second front: Chairly (F01) for Atlanta salon suites.

## Sources
- [SBA Office of Advocacy, 2025 Small Business Profile: Georgia](https://advocacy.sba.gov/wp-content/uploads/2025/06/Georgia_2025-State-Profile.pdf)
- [US Census Bureau, Business Formation Statistics monthly CSV (Jan–Aug 2026)](https://www.census.gov/econ/bfs/csv/bfs_monthly.csv)
- [O.C.G.A. 36-60-6 (Justia)](https://law.justia.com/codes/georgia/title-36/chapter-60/section-36-60-6/)
- [O.C.G.A. 44-14-366 (Justia, 2025 code)](https://law.justia.com/codes/georgia/title-44/chapter-14/article-8/part-3/section-44-14-366/)
- [US DOL, state minimum wage table](https://www.dol.gov/agencies/whd/minimum-wage/state)
- [privacyterms.io, US state privacy laws 2026](https://privacyterms.io/us-state-privacy-laws-2026)
- [GetESAPaid, ESA payment rails by state](https://getesapaid.com/become-an-esa-vendor)
- [HHAeXchange information hub (GA not listed)](https://www.hhaexchange.com/info-hub)
- [NCSL, State E-Verify action (2015 table; historical)](https://www.ncsl.org/immigration/state-e-verify-action)
- [Odyssey: Georgia Promise Scholarship amount (Feb 12 2026)](https://support.withodyssey.com/hc/en-us/articles/31787686004251-What-is-the-scholarship-amount)
- [HSLDA: Georgia homeschool laws](https://hslda.org/legal/georgia)
- Internal: ideas R01 (Follett FL/GA module history), P05 (Booster HQ)
