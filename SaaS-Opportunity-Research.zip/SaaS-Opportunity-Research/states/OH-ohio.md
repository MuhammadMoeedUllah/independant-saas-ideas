# Ohio (OH): where to sell cheaper, better SaaS

## Snapshot
- **Small businesses:** 1.1 million small businesses (99.6% of Ohio businesses). They employ 2.2 million people, or 43.8% of Ohio employees ([SBA Advocacy 2025 Ohio profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Ohio_2025-State-Profile.pdf); counts use 2022 data).
- **New-business momentum:** Mixed.
  - From March 2023 to March 2024, small businesses opened 24,725 establishments and closed 25,604.
  - Even so, they created 31,354 net jobs, which is 97.6% of Ohio's net job growth.
  - Banks lent $2.2B to firms with revenue of $1M or less.
  - All figures are from the same SBA profile. Business-application trend data was not pulled in this pass.
- **Buyer clusters** (metro detail is an estimate):
  - **Columbus:** Ohio's fastest-growing metro (verify). Logistics and warehousing, insurance, state associations, and suburban home services and kids' activities.
  - **Cleveland/Akron:** health-care ecosystem (dental, therapy, home care), manufacturing and polymers.
  - **Cincinnati/Dayton:** consumer goods and logistics (CVG and the I-75 corridor). Dayton adds a defense and aerospace cluster (Wright-Patterson; noted in L05).
  - **Toledo, Sandusky and the Lake Erie islands:** seasonal tourism (Cedar Point, Put-in-Bay), marinas, inns, tours.
  - **Holmes County (Amish Country):** tourism retail and lodging.
- **Industries overweight vs. US:**
  - **Manufacturing:** 280,431 small-business employees (SBA).
  - **Transportation and warehousing:** 129,272 small firms, #2 by count (SBA). Ohio is an I-70/I-71/I-75 freight crossroads.
  - **Health care:** 342,936 small-business employees, #1 (SBA).
  - **Construction:** 117,839 firms and 174,178 employees (SBA).
  - **Accommodation and food:** 288,958 small-business employees (SBA).

## Laws & deadlines that force software purchases (2025–2027)
| Law / rule | Who it hits | Date | Matching idea(s) |
|---|---|---|---|
| **EdChoice scholarships:** 2025–26 amounts are $6,166 (K–8) and $8,408 (grades 9–12). The 2025–26 application window ran through Jun 30 2026 ([Ohio DEW](https://education.ohio.gov/Topics/Other-Resources/Scholarships/EdChoice-Scholarship-Program)). The income-based "EdChoice Expansion" has made nearly all families eligible since 2023–24 (HB 33, verify) | Private and parochial schools (tuition split between scholarship and parent) | Each school year; 2026–27 cycle live | F06, I07 |
| **ACE (Afterschool Child Enrichment) ESA:** about $1,000 per child for tutoring, lessons and camps, paid through ClassWallet (verify amount, platform and current status) | Tutors, music and dance studios, camps | Rolling (verify) | F07, F03, I06 |
| **Medicaid EVV:** open model with Sandata as aggregator; deadline 1/1/2021 ([HHAeXchange](https://www.hhaexchange.com/state-evv-status)) | Home-care agencies (alternate EVV may export to Sandata) | In force | E07 |
| **Adult-use cannabis** (sales since Aug 2024) on Metrc (J04 list). The 2025 SB 56 rewrite also tightened hemp and THC products (verify) | Dispensaries, hemp and THC retailers | 2025–2026 (verify) | J04 |
| **State minimum wage 2026:** $11.00 standard and $5.50 tipped, for employers above the gross-receipts threshold (verify). The rate is CPI-indexed, and the new rate posts each fall for Jan 1 | Restaurants, retail | Jan 1 2027 update | D04, J03 |
| **Construction lien law:** notice of commencement on commercial jobs, and notice of furnishing within 21 days (verify) | Subs and suppliers | Ongoing | C06 |
| **Ohio Data Protection Act** (2018): an affirmative defense to data-breach claims for firms that run a written cybersecurity program (verify). Ohio has no comprehensive consumer privacy law yet (verify) | Any SMB holding customer data | In force | L06, J02 |
| **Electronic titles:** titles are issued by county clerks of courts, and an e-title and ELT expansion is flagged in K02 (not confirmed; the BMV homepage showed nothing, verify) | Independent dealers | Verify | K02 |
| **Commercial Activity Tax exclusion** raised to $6M in 2025, dropping most small firms from CAT filing (verify) | CPAs, bookkeepers | In force | G03, G02 |

## Top 7 ideas to launch here
| Rank | Idea ID | Product | Why it sells fast here |
|---|---|---|---|
| 1 | B04 | FirstCall | This idea tops the scoreboard (23). Ohio has 117,839 small construction firms, and furnace and roofing demand is high each fall. Contractors facing the end of Google LSA disputes and Angi exit fees want owned leads now. |
| 2 | C01 | FlatRate | Heating season (Oct–Mar) is peak work for HVAC and plumbing. ServiceTitan exit fees and Housecall Pro bill jumps (scoreboard 19) hit the many 2–15 truck shops in Columbus, Cleveland and Cincinnati. |
| 3 | K03 | HaulDesk | 129,272 small transportation firms (#2 by count), and Ohio sits at a freight crossroads. The IFTA Oct 31 deadline and DAT renewal hikes give an immediate hook. |
| 4 | F01 | Chairly | Health care and personal services are large (SBA). Fresha commissions and Vagaro frozen payouts (Sep 2026) are fresh anger. Suburban Columbus is growing. |
| 5 | F06 | ESA Desk | With near-universal EdChoice, Catholic and Christian schools split every family's bill between scholarship and parent. The 2026–27 billing cycle is active, and ACE adds small providers (verify). |
| 6 | A03 | LocalLoop | Scoreboard 22. Dense dental, auto and home-service practices in three large metros sit on Podium and Birdeye auto-renewals. |
| 7 | I01 | GiftLedger | Large foundation and nonprofit sectors in Cleveland, Columbus and Cincinnati (estimate). The year-end giving switch window is Oct–Dec, and Blackbaud renewal escalators give a reason to move (scoreboard 20). |

## State-only opportunities
- **EdChoice and ACE provider billing (F06/F07 variant):** a "scholarship plus parent" split-billing and ACE invoice pack for Ohio parochial schools and enrichment providers. It's a strong Ohio module, but it's an extension of F06, so no separate idea file was written.
- **Lake Erie and Amish Country seasonal hospitality:** inns, tour operators, marinas and campgrounds around Sandusky, Put-in-Bay and Holmes County. They buy in the off-season (Nov–Mar), and D05, D06 and D07 apply. A marina-specific product (seasonal slips, winter storage, haul-out scheduling) was not researched in this pass and needs evidence before scoring.
- **Ohio cannabis and hemp compliance (J04 variant):** a young adult-use market plus 2025 hemp and THC changes (verify) creates first-time compliance buyers. It's a weak overall score (14), so treat it as opportunistic.

## Where to sell
- **Associations & events** (months to verify):
  - Hospitality: Ohio Restaurant Association, Ohio Hotel & Lodging Association.
  - Trades and trucking: Ohio Trucking Association, Ohio Home Builders Association, Ohio REALTORS.
  - Professionals: Ohio Society of CPAs (OSCPA), Ohio State Bar Association, Ohio Dental Association, Ohio Veterinary Medical Association.
  - Home care: Ohio Council for Home Care & Hospice.
  - General business: Ohio Chamber of Commerce, NFIB Ohio, COSE (Council of Smaller Enterprises, Cleveland).
  - Schools: Catholic diocesan school offices (Columbus, Cleveland, Cincinnati).
- **Online communities:** r/Columbus, r/Cleveland, r/cincinnati, r/Dayton, r/toledo, r/ohio, r/HVAC, r/Truckers, and Ohio home-services and contractor groups on Facebook (names to verify).
- **Partners:**
  - Ohio SBDC network and regional chambers (Columbus Partnership, Greater Cleveland Partnership; verify).
  - HVAC and plumbing supply houses.
  - Freight factoring firms.
  - CPAs who handle municipal income tax filings, a unique Ohio pain.

## Books, reading & family education
| Rule / program | What it requires | Date | Matching idea(s) |
|---|---|---|---|
| School library-materials law (or freedom-to-read law) | No statewide school-library catalog or reconsideration-process law was confirmed in this pass. A 2025 "Parents' Bill of Rights" (HB 8) requires parent notice and review of instructional materials with sexuality content (verify bill number, effective date and whether library books are covered) | Verify | R07, R01 (low fit) |
| Science-of-reading law: **HB 33 (2023 budget)** | Schools must use **state-approved core reading curricula (K–5)** and **intervention programs (K–12)** aligned with the science of reading by the end of **2024–25**, and **three-cueing is banned**. Funding: **$64M** for materials, **$86M** for PD stipends ($1,200 for K–5 and reading specialists, $400 for other 6–12 teachers), and **$18M** for coaches. More than 115,000 educators finished the intro course by end of 2025, and **91 coaches** were placed in **151** low-performing schools as of Mar 2026. CKLA is the most-used K–5 core ([Fordham, Aug 18 2026](https://fordhaminstitute.org/ohio/research/next-chapter-ohios-implementation-science-reading-and-where-next)) | In force since 2024–25 | P01, R08 |
| 3rd-grade reading plan / retention law: **Third Grade Reading Guarantee** | Off-track K–3 readers get a **Reading Improvement and Monitoring Plan (RIMP)**, and parents are notified and take part in building it. The DEW released **new RIMP templates for K–3 and 4–9 in Jul 2026**. From **2026–27** the kindergarten reading diagnostic is due **Sep 30** ([Ohio DEW TGRG](https://education.ohio.gov/Topics/Learning-in-Ohio/Literacy/Third-Grade-Reading-Guarantee)). Retention was weakened in 2023: **98%** of third graders were promoted in 2024–25 while **61%** were proficient. Fordham recommends "at least one follow-up parent conference after a RIMP is created" ([Fordham](https://fordhaminstitute.org/ohio/research/next-chapter-ohios-implementation-science-reading-and-where-next)). Category research lists Ohio as **conditional** retention (the parent-request rules are to be verified) | New templates Jul 2026; K diagnostic Sep 30 2026 | **P02**, R08 |
| Homeschool rules (HSLDA tier: **low**) | Notification required. **No assessment requirement.** No teacher qualifications and no immunization rule. Subjects are state-mandated. Compulsory ages 6–18, with two legal options ([HSLDA OH](https://hslda.org/legal/ohio)). The 2023 notification-only change is to be verified against HB 33 | In force | P03 |
| ESA / scholarship money that can buy books, curriculum, classes | **EdChoice:** $6,166 (K–8) and $8,408 (grades 9–12) in 2025–26 ([Ohio DEW](https://education.ohio.gov/Topics/Other-Resources/Scholarships/EdChoice-Scholarship)). **K–12 Home Education Tax Credit:** up to **$250**, nonrefundable, for "books, supplementary materials, supplies, computer software, applications, or subscriptions." It had **6,166 claimants in 2024** under ORC 5747.72 ([EdChoice](https://www.edchoice.org/school-choice/programs/k-12-home-education-tax-credit/)). **ACE ESA** is about $1,000 (see the laws table; verify). Ohio **opted in to the federal tax-credit scholarship** (IRS list, Jun 8 2026), which starts **Jan 1 2027** ([IRS](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)) | Credit claimed each tax season; federal credit Jan 1 2027 | **P07**, R08, P03, P04 |
| Other | **Ohio Governor's Imagination Library** has been "available in all zip codes since November 2020," with **20M+ books** mailed since Aug 2019 ([Ohio Imagination Library](https://ohioimaginationlibrary.org/)). No state auto-renewal law is on the category-research list | 2019– | P06 |

**Top 3 reading/education ideas here:**
- **P02 ReadingPlan Home:** every off-track K–3 student gets a RIMP. The templates were just reissued (Jul 2026), and with 98% promoted but only 61% proficient, parents carry more of the catch-up. A RIMP-aligned parent portal with a home practice plan and conference log fits.
- **P07 LearnLedger:** the $250 home-education credit names "software, applications, or subscriptions." Add ACE and the 2027 federal scholarships, and receipts become the product. R08 subscriptions are credit-eligible spend.
- **R08 Readlings:** Ohio schools switched to state-approved science-of-reading cores (CKLA leads), so a home decodable app that matches school phonics sequences sells to parents.

**Where to sell:**
- **Public libraries:** Ohio Library Council convention (fall, verify).
- **School libraries:** Ohio Educational Library Media Association (verify conference month).
- **Families:** Ohio PTA; Ohio's Statewide Family Engagement Center at OSU, which already publishes RIMP-letter guidance (P02 source).
- **Homeschool groups:** Christian Home Educators of Ohio (CHEO) convention (verify month).
- **Reading groups:** IDA Ohio branches; The Reading League Ohio (verify).
- **Booksellers:** Great Lakes / Midwest independent booksellers association, Heartland Fall Forum (verify).

## Launch verdict
**Speed:** Medium–Fast.

**First city:** Columbus.

**Lead offer:** FirstCall plus FlatRate for HVAC and plumbing heading into heating season. The pitch is "Own your leads, drop Angi and ServiceTitan fees before the furnace rush." Follow with HaulDesk for the Oct 31 IFTA filing.

## Sources
- [SBA Office of Advocacy: 2025 Ohio Small Business Profile (PDF)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Ohio_2025-State-Profile.pdf)
- [Ohio Department of Education & Workforce: EdChoice Scholarship Program](https://education.ohio.gov/Topics/Other-Resources/Scholarships/EdChoice-Scholarship-Program)
- [HHAeXchange: State-by-State EVV Status](https://www.hhaexchange.com/state-evv-status)
- Ohio BMV homepage (bmv.ohio.gov) and the Ohio Department of Commerce Wage & Hour page were fetched but returned no relevant content. The e-title and minimum-wage items are marked (verify).
- Scoreboard and idea files B04, C01, K03, F01, F06, A03, I01, J04, K02 (internal).
- [Fordham Institute: The Next Chapter, Ohio's science-of-reading implementation (Aug 18 2026)](https://fordhaminstitute.org/ohio/research/next-chapter-ohios-implementation-science-reading-and-where-next)
- [Ohio DEW: Third Grade Reading Guarantee](https://education.ohio.gov/Topics/Learning-in-Ohio/Literacy/Third-Grade-Reading-Guarantee)
- [Ohio DEW: EdChoice Scholarship (2025-26 amounts)](https://education.ohio.gov/Topics/Other-Resources/Scholarships/EdChoice-Scholarship)
- [EdChoice: Ohio K-12 Home Education Tax Credit](https://www.edchoice.org/school-choice/programs/k-12-home-education-tax-credit/)
- [EdChoice: Ohio programs](https://www.edchoice.org/school-choice/state/ohio/)
- [HSLDA: Ohio homeschool law](https://hslda.org/legal/ohio)
- [IRS IR-2026-76: states in the federal scholarship tax credit (Jun 8 2026)](https://www.irs.gov/newsroom/more-than-half-the-us-states-signed-up-to-participate-in-the-federal-scholarship-tax-credit-program-enacted-under-the-one-big-beautiful-bill)
- [Ohio Governor's Imagination Library](https://ohioimaginationlibrary.org/)
