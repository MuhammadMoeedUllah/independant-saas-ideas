# State-specific leads surfaced during category research (to verify in the per-state pass)

## Wave 1 (A–F)
- Health-data consent: WA My Health My Data Act, NV SB 370, TX HB 300 → HIPAA-style intake forms (A01, E08).
- Mini-TCPA texting laws: FL, OK, MD (stricter consent/quiet hours) → compliance-first SMS (A03, B01, B04, B06).
- Auto-renewal laws: NY GOL §5-903, WI §134.49, CA ARL → help SMBs exit Podium/Birdeye/Hootsuite/RingCentral/Yext contracts.
- CA home-improvement down-payment cap (10% or $1,000) → quote-sign-deposit flows (A04, C01). TX agents must use TREC forms.
- UT: Podium/Birdeye HQ state, dense pool of unhappy customers.
- VT AG settled with Angi (Oct 2025, "Angi Certified Pro"). CO: Angi HQ, contractor class action Airquip v. HomeAdvisor.
- Two-party call-recording-consent states matter for call tracking (B06).
- TX lien law: HB 2237 (2022) overhaul, 2025 SB 929 and others. Preliminary notices: CA/AZ 20 days, FL 45 days, WA 60 days (C06).
- NY pesticide annual report due Feb 1 (commercial applicators). CA school-site pesticide reporting (C03).
- Storm belts: hail TX/CO/OK/KS/NE/MN; hurricanes FL/LA/Carolinas (C02, C07). Year-round trades: TX/FL/AZ/GA/NV.
- Junk-fee / all-in pricing: CA SB 478 (Jul 2024), MN (Jan 2025), VA (Jul 2025), MA AG rules (Sep 2025), CO HB25-1090 (2026), FTC hotel/ticket rule (May 2025) → lodging, campgrounds, tours, restaurants (D-series).
- Delivery fee caps: NYC cap lifted Jun 2025; SF 15% cap; others (D02).
- Tip laws: DC I-82 revised 2025; Chicago tip-credit phase-out; MI 2025 slowed phase-out; no tip credit in CA/WA/OR/NV/MN/AK/MT; federal no-tax-on-tips reporting (D04).
- Tourism clusters: Smokies (TN/NC), FL Keys/Gulf, Myrtle Beach, AZ & S. TX snowbird RV parks, HI, Orlando; AAHOA motel owners (D05–D08).
- Medicaid EVV: HHAeXchange aggregator in FL, IL, MI, MN, MS, NJ, PA, SC, WV (per vendor); full table in E07.
- Med-spa laws: TX HB 3749 (Sep 2025), IN SB 282 (registration by 1/1/2027), CA SB 351 (1/1/2026), NJ S2996 (3/30/2026), FL SB 1728 failed 3/2026 (E04).
- PSYPACT / Counseling Compact state membership; telehealth parity (E01).
- ESA / school choice: TX TEFA year 1 2026–27 (Odyssey; $10k+, $30k SPED, $2k homeschool); ClassWallet runs AZ, AR, TN, WV, NC, IN, NH, AL, SC; Odyssey runs TX, IA, UT, GA, LA, WY, MO; FL via Step Up For Students. AZ Treasurer RFP for ESA fraud tracking (Jul 2026); AR review called ClassWallet "fragmented" (F06, F07).
- Childcare subsidy: MN funds frozen; reported 5-state freeze incl. NY, CA (Jan 2026); attendance vs enrollment pay by state (F05).

## Wave 2 (G–L)
- Lawyer trust accounts (verify): CA CTAPP annual registration/self-assessment due Feb 1; NJ random trust audits; FL monthly reconciliation (G01).
- Paid family/medical leave: MN started Jan 1 2026 (0.88%); DE benefits Jan 2026 (<10 employees exempt); ME benefits May 1 2026; MD contributions Jan 1 2027 (0.90%); VA 2028 (G04).
- Pay transparency: CO, CA (amended Jan 1 2026), WA (5-day cure 2025), NY, IL, MN, NJ (Jun 1 2025), VT (Jul 1 2025), MA (Oct 29 2025, 25+ employees), DE (Sep 26 2027); IL temp-worker equal pay (G07, J03).
- Insurance agencies: hard property markets FL, CA, TX, LA, CO → heavy re-quoting (G05).
- Landlords: CO HB25-1090 all-in rent / junk-fee ban (Jan 2026); CA AB 12 deposit cap; (verify) CA AB 2801 move-in photos, WA HB 1217 rent cap (H01).
- HOA/condo: FL HB 913 SIRS deadline Dec 31 2025, condo DBPR online account by Oct 1 yearly, HOA 100+ parcel websites Jan 1 2025, condo 25+ unit websites Jan 1 2026; (verify) TX Prop Code 207.006 (60+ lots), NV NRS 116.31069 (150+ units), WI (100+ units), WA ESSB 5129 (Jan 1 2026), AZ HB 2397 resale disclosures (Sep 12 2026) (H02).
- STR: LA marketplaces collect lodging tax 2025; MD county lodging tax via marketplaces Jul 1 2027 (H03).
- Self-storage lien law modernization pushed state by state by SSA (H06). UAD 3.6 appraisal format mandatory Nov 2 2026; TX TREC inspection report form; FL wind-mitigation/4-point forms (H05).
- Charitable solicitation registration in ~40 states (NY, CA, PA, FL, IL heaviest) (I01). Camp licensing: NY, NJ, PA, MA, CT, MI, NC (I06). PA youth volunteer clearances (I05). Student data privacy: CA SOPIPA, NY Ed Law 2-d, IL SOPPA (I07).
- Sales tax states that dropped 200-transaction test: AK(local), CA, CO, IL (Jan 2026), IN, IA, KY (Aug 2026), LA, ME, MA, NC, ND, SD, UT, WA, WI, WY; NJ likely next (J01).
- Privacy laws in force: 20 states; IN, KY, RI started Jan 1 2026 (RI 35k consumer threshold) (J02).
- ADA web suits 2025 (federal): NY 1,021; FL 961; IL 585; MN 162; PA 137; MO 86; MA 57; CA mostly state court (J02).
- Metrc states: AL, AK, CA, CO, DC, LA, ME, MD, MA, MI, MS, MO, MT, NV, NJ, OH, OK, OR, RI, SD, WV (+ portals IL, KY, MN, NY) (J04). Federal hemp 0.4mg cap (H.R. 5371, Nov 12 2025).
- NERIS: 20,945 depts still filed NFIRS in 2025 (J07). Entity: DE LLC tax Jun 1; CA $800 min franchise tax; FL CE Broker professions (J06).
- Autos: CA SB 766 CARS Act Oct 1 2026 (3-day return ≤$50k); IL e-titling expansion Feb 2026; OK e-titles; OH e-titling (K02).
- Towing: TX TDLR non-consent caps (light-duty tow $272, drop $135, storage $21.03/day), VSF release forms (K04).
- IFTA quarterly: Oct 31, Jan 31, Apr 30, Jul 31 (K03).

## Corrections from the state pass
- CMMC Phase II was suspended Jul 13 2026, so DoD-contractor compliance around DC/Huntsville has no forcing deadline right now.
- WV Hope Scholarship now uses its own portal + TheoPay (not ClassWallet).
- DE LLC tax is $400 (not $300).
- Full per-state summary: _states_summary.csv

## Books, reading & family education (R/P clusters, Sep 25 2026)
- **School library-materials laws (process/transparency):** TX HB 900 (2023, partly struck) + SB 13 (2025: parent catalog access, do-not-lend lists, board approval after 30-day public notice, 90-day challenge process); NE LB 390 (catalog + opt-in checkout alerts by 2026-27); NC H 805 (2025: online catalog incl. classroom libraries, parent opt-out); FL HB 1069 (2023) (+HB 1467 2022, verify); IN HEA 1447 (2023); TN (2022, HB 843 2024); UT HB 29 (2024); SC Reg 43-170 (verify year); GA SB 226 (2023); ID HB 710 (2024); IA SF 496 (2023); KY SB 150 (2023)/SB 5 (verify). Struck down: MO SB 775 (Nov 2025), AR Act 372 (Dec 2024).
- **Freedom-to-read laws (written collection & reconsideration policies):** IL HB 2789 (Jan 2024); MD HB 785, MN, WA HB 2331 (2024); CA AB 1078 (2023), AB 1825 (2024); NJ A3446 (signed Dec 2024); CT HB 7287 (2025); DE HB 119 (Sep 2025); OR SB 1098, RI SB 238 (2025); CO, VT (verify).
- **Science of reading:** 40+ states (EdWeek). Three-cueing bans: AR, LA, FL, IN, NC, OH, SC, TX, WV, WI, KY, MN, VA, MO (2025 bills AL, GA, ID unverified). Approved-curriculum mandates: AR, CO, FL, GA, LA, SC, TN, TX, VA, CA (adoption Jan 2027), IN.
- **3rd-grade retention/reading plans:** mandatory retention AL, AZ, AR, FL, IN, LA, MS, NC, SC, TN; conditional AK, CO, DE, GA, IA, MO, NM, OH, RI, WA; coming WV 2026-27, MD 2027-28, OK 2027-28, WI 2027, NV 2028, UT by 2030; MI repealed.
- **Homeschool regulation (HSLDA tiers, partly unverified):** no notice CT, ID, IL, IN, MO, NJ, OK, TX; high MA, NY, PA, RI, VT, ND; moderate e.g. FL, OH, CO.
- **Auto-renewal laws (family subscriptions):** FTC click-to-cancel struck down Jul 8 2025; state laws CA (Jul 2025), NY (Nov 2025), MD (Jun 2026), CT (Jul 2026), CO, MA, ME, AR.
- **Other:** TX opened most new bookstores (21 in 2024); Imagination Library state funding cuts WA, IN, MO; 13 states don't conform to federal K-12 529 expansion.
