# Bitewing: a cheaper, better Weave (plus an in-house membership-plan manager) for independent dental offices

**One-liner:** Flat-priced two-way texting, reminders, recall and reactivation, digital forms, reviews and text-to-pay for independent dental offices, bundled with an in-house dental membership-plan manager so uninsured patients become recurring revenue. No phone hardware and no annual contract.

## Snapshot
- **Replaces:**
  - **Weave** does not publish pricing. Estimates: Core $300–$400/mo, Plus $400–$500/mo, Premium $500–$700/mo, Enterprise $800–$1,200/mo, plus about $400 port/setup. Annual contracts are typical, and customers report **15–25% renewal increases** (NoShowCost, estimates triangulated from G2, Capterra and r/Dentistry, verified 2026-04-28).
  - **Solutionreach, RevenueWell**: pricing not verified in this pass.
  - **Kleer, BoomCloud** (membership-plan platforms): pricing not verified in this pass.
  - **Dentrix (Henry Schein One) / Eaglesoft (Patterson)** are the practice-management systems we **integrate with, not replace**.
- **Recent price hikes / changes:**
  - Renewal increases of 15–25% are commonly reported for Weave (estimate).
  - **Patterson Companies (Eaglesoft's parent) was taken private by Patient Square Capital in a $4.1B deal that closed Apr 22, 2025.** PE ownership of a PMS vendor is a classic precursor to bundling and price changes; that is our inference, not a reported change.
  - Weave was named the **exclusive ADA-endorsed patient engagement platform for ADA members (2026)**, which strengthens Weave's channel.
- **Who buys:** Owner dentists and office managers at independent 1–3 location general dental practices. The office manager is often the champion, and the owner dentist signs.
- **US market size:** Our estimate is about 200k US dentists and roughly 100k+ independent practice locations (ADA HPI figures not verified in this pass). DSO share is rising, so independents are the target.
- **Urgency trigger (why they'd switch NOW):** Weave annual renewal dates with 15–25% increases, outages and reliability complaints, and uncertainty after the PE take-private of Patterson/Eaglesoft.
- **Fastest-selling states/metros:** Estimate: dense independent-dentist metros such as the NYC/NJ corridor, Chicago, Los Angeles, Houston/Dallas, Atlanta and Phoenix. State dental society meetings are the cluster points.

## Pain points (evidence)
- **[Price]** A G2 reviewer says Weave doesn't offer much for the price and every extra feature costs more (G2, Sep 2026) ([G2](https://www.g2.com/products/weave-weave/reviews)).
- **[Price]** Another says pricing is substantially higher than competitors (G2, Mar 2026) ([G2](https://www.g2.com/products/weave-weave/reviews)).
- **[Price]** A reviewer calls Weave one of the most expensive VoIP services (Capterra, Apr 2025) ([Capterra](https://capterra.com/p/141842/Weave/reviews/)).
- **[Lock-in/Contracts]** Annual contracts with commonly reported 15–25% renewal increases (estimate compiled from reviews and r/Dentistry) ([NoShowCost](https://noshowcost.com/tools/weave-pricing)).
- **[Support]** Support closes tickets without fixing the problem (Capterra, Dec 2025) ([Capterra](https://capterra.com/p/141842/Weave/reviews/)).
- **[Support]** A marketing director says nobody followed up on issues for over a year and they feel "completely forgotten" as paying customers (Capterra, May 2025) ([Capterra](https://capterra.com/p/141842/Weave/reviews/)).
- **[Complexity/UX]** Phones freeze and need frequent restarts (Capterra, Apr 2025). A softphone fails while other apps work fine (Capterra, Jun 2026) ([Capterra](https://capterra.com/p/141842/Weave/reviews/)).
- **[Complexity/UX]** G2's review summary counts dozens of mentions of outages that take down the whole phone system (39 reviews) and messaging or notification failures (57 reviews) (G2, 2026) ([G2](https://www.g2.com/products/weave-weave/reviews)).
- **[Missing features]** Integration gaps: reviewers want the patient account to open inside Open Dental and want other PMS/EHR integrations (G2, 2026; Capterra) ([G2](https://www.g2.com/products/weave-weave/reviews)).
- **[Missing features]** The mobile app lacks features available on desktop, such as AI replies (G2, Nov 2025; Capterra, Apr 2025) ([G2](https://www.g2.com/products/weave-weave/reviews)).

## What we build (the better version)
1. **MVP:** **Two-way texting** from the practice's existing number (we handle 10DLC registration, and text-enabling a landline avoids a phone port), in a web inbox and mobile web app.
2. **MVP:** **Reminders and confirmations** with two-way "C to confirm" and auto-fill of cancellations from an ASAP list.
3. **MVP:** A **recall and reactivation engine** for overdue hygiene and unscheduled treatment. It connects to **Open Dental through its documented API** and to Dentrix/Eaglesoft through a scheduled report/CSV export at MVP stage. We are honest about the limitation and set up the export for the customer.
4. **MVP:** **Digital forms**: medical history, consents and e-signature, with PDF output for upload to the PMS.
5. **MVP:** **Google review requests** after visits, and **text-to-pay** for balances (Stripe).
6. **MVP:** **In-house membership plans.** A plan builder (adult, child, perio maintenance), Stripe autopay, a member roster, discount calculation against the office fee schedule, renewal reminders, a printable member card, and a campaign for uninsured and lapsed patients.
7. **V2:** Cloud VoIP phones through a CPaaS (Telnyx/Twilio), with a caller pop showing next appointment, balance and membership status.
8. **V2:** An AI after-hours receptionist (books into the schedule and answers FAQs) and call recording/QA.
9. **V2:** Deeper Dentrix/Eaglesoft sync through the vendors' partner programs, dental eligibility checks (270/271) through a clearinghouse API, and an analytics dashboard for unscheduled treatment dollars.

## Pricing to win
- **$149/mo per location, month-to-month.** Unlimited users, the membership module included, SMS at cost above a generous included bundle, free setup, and no hardware.
- **Savings:** Against Weave's estimated $300–$700/mo, one location saves **$1,800–$6,600/yr**, before avoided 15–25% renewal increases.
- Membership plans: flat price with **no per-member fee**. We did not verify competitor per-member fees, so avoid naming numbers in marketing until confirmed.

## Go-to-market (first 100 customers)
- **Communities:** r/Dentistry and the Dentaltown message boards. Post a "Weave renewal checklist" (what to negotiate, how to port, what to export).
- **Office managers:** AADOM (American Association of Dental Office Management) chapters and events, since office managers are the champions.
- **State dental associations:** The ADA endorsement is taken by Weave, but state and local societies run their own vendor programs and meetings.
- **Big dental meetings:** Chicago Dental Society Midwinter Meeting, Yankee Dental Congress, Greater New York Dental Meeting, CDA Presents, and the Hinman Dental Meeting.
- **Open Dental user community:** Cost-conscious owners with an API-friendly PMS, which makes this the best first wedge.
- **Partners:** Dental consultants, practice brokers, and dental CPAs (referral fee).
- **SEO:** "Weave alternative", "Weave contract cancellation", "Weave pricing", "in-house dental membership plan software".

## Risks and incumbent moats
- **PMS integration is the moat:** Henry Schein One controls Dentrix integration access, and Patterson (now PE-owned) controls Eaglesoft. Start with Open Dental offices plus CSV export for the rest, and apply to partner programs early.
- **Channel moat:** Weave's ADA endorsement (2026) and its award history.
- **Phones:** Porting and call quality are hard, so we skip VoIP at MVP and text-enable existing numbers.
- **TCPA and 10DLC:** Consent capture is built in.
- **Membership plans:** State insurance and discount-plan rules vary. Flag for the per-state pass, and have templates reviewed by a dental-law attorney.
- **HIPAA/BAA on a small-team budget:** Dental offices are covered entities, and we are their business associate.
  - Sign customer BAAs and use AWS HIPAA-eligible services under AWS's self-serve BAA.
  - Use an SMS provider that signs a BAA, or keep message templates PHI-minimal.
  - Stripe handles payments, with no clinical detail in metadata.
  - A free HHS SRA Tool risk assessment, MFA, audit logs, encryption, and a breach runbook.
  - **Cost estimate:** A few hundred dollars a month plus a pen test and cyber insurance.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 2 | 3 | 4 | **16** |

## Sources
- [Weave reviews, G2](https://www.g2.com/products/weave-weave/reviews)
- [Weave reviews, Capterra](https://capterra.com/p/141842/Weave/reviews/)
- [Weave Pricing 2026 (estimates), NoShowCost](https://noshowcost.com/tools/weave-pricing)
- [Patterson Companies Completes Acquisition by Patient Square Capital, Business Wire (Apr 22, 2025)](https://www.businesswire.com/news/home/20250422266470/en/Patterson-Companies-Completes-Acquisition-by-Patient-Square-Capital)
- [Latham Advises on Patient Square's US$4.1B acquisition of Patterson](https://www.lw.com/en/news/2025/04/latham-advises-on-patient-square-capital-completed-us4-1-billion-acquisition-of-patterson-companies)
- [Weave Named Exclusive Patient Engagement Platform Endorsed for ADA Members (2026)](https://s21.q4cdn.com/507868397/files/doc_news/Weave-Named-Exclusive-Patient-Engagement-Platform-Endorsed-for-American-Dental-Association-Members-2026.pdf)
