# AdvisorVault: a cheaper, simpler Redtail/Wealthbox + compliance stack for small RIAs

**One-liner:** CRM plus a compliance-in-a-box kit for 1–10 person RIAs: Reg S-P incident response, vendor oversight, an annual compliance review, a marketing-rule review log and communications archiving. One flat price.

> **Evidence status: THIN.** The research budget ran out before 2025–2026 complaints could be gathered for Redtail, Wealthbox, Orion or Smarsh/Global Relay. Pain score is provisional. Re-research before prioritizing.

## Snapshot
- **Replaces:**
  - **Redtail CRM (owned by Orion), fetched Sep 24, 2026:**
    - Launch: $39/user/mo annual or $45 monthly, max 5 users.
    - Growth: $59/user/mo annual or $65 monthly, with Imaging, Speak compliant texting and email archiving included.
    - Enterprise: custom ([Redtail pricing](https://redtailtechnology.com/pricing/)).
  - **Wealthbox, fetched Sep 24, 2026:** Basic $59, Pro $75, Premier $99 per user/mo. Enterprise custom. AI Notetaker add-on is $49/user/mo (intro rate) ([Wealthbox pricing](https://www.wealthbox.com/pricing/)).
  - **Smarsh / Global Relay archiving, Salesforce Financial Services Cloud, Orion:** prices **not verified this pass**.
  - **Also replaced:** Outsourced compliance consultants (typically retainer-based; not verified).
- **Recent price hikes / changes:**
  - **SEC Regulation S-P amendments** (adopted May 2024) ([SEC press release 2024-58](https://www.sec.gov/newsroom/press-releases/2024-58)). They require:
    - A written incident response program.
    - Customer notification within 30 days of a breach involving sensitive customer information.
    - Service-provider oversight.
  - **Compliance deadlines:** Larger entities had 18 months, smaller entities 24 months. Background, verify: that puts larger entities at about Dec 3, 2025 and smaller entities at about **Jun 3, 2026**, with smaller RIAs defined as under $1.5B AUM. **Small RIAs are now past their deadline** and exposed in SEC exams.
  - No 2025–2026 CRM price-hike evidence was found this pass.
- **Who buys:** Founders or CCOs of 1–10 person SEC- or state-registered RIAs, often the same person.
- **US market size:** Estimate (background, not verified this pass). About 15k SEC-registered RIAs plus about 15k state-registered advisers. Serviceable market: about 20k small firms at $100–$500/mo, a modest dollar pool.
- **Urgency trigger (why they'd switch NOW):**
  - The **Reg S-P compliance date for smaller entities has passed** (Jun 2026, verify), and SEC exams will test incident-response programs.
  - Annual compliance reviews in Q4.
- **Fastest-selling states/metros:** Estimate. RIA-dense states: CA, NY, TX, FL, IL, NJ, MA, PA. State-registered adviser concentrations follow population.

## Pain points (evidence)
- **[Complexity/UX]** Redtail users complain about slow performance, with waiting "on every single screen" (multiple reviewers) ([Software Advice](https://www.softwareadvice.com/crm/redtail-crm-profile/reviews/)).
- **[Support]** A 2–10 person advisory firm waited 9 business days for an integration and called out a lack of support (Oct 2019) ([Software Advice](https://www.softwareadvice.com/crm/redtail-crm-profile/reviews/)).
- **[Missing features]** Limited customization: the CRM couldn't be tailored to the firm's needs (Aug 2019). Needed fields for specialized tracking were unavailable (Apr 2021) ([Software Advice](https://www.softwareadvice.com/crm/redtail-crm-profile/reviews/)).
- **[Complexity/UX]** Activities must be manually pushed to "today" view, and contacts can't be searched by nickname ([Software Advice](https://www.softwareadvice.com/crm/redtail-crm-profile/reviews/)).
- **[Price]** Wealthbox's AI notetaker is a separate $49/user/mo add-on, nearly doubling a Basic seat ([Wealthbox pricing](https://www.wealthbox.com/pricing/)).
- **[Compliance burden]** Reg S-P now requires every RIA to maintain an incident response program and notify customers within 30 days ([SEC](https://www.sec.gov/newsroom/press-releases/2024-58)). Small firms usually handle this with Word templates and consultants (background).
- **Gap:** No 2025–2026 Reddit (r/CFP, r/financialplanning) or G2 complaints were collected. This does not meet the 8+ complaint target and needs a follow-up pass.

## What we build (the better version)
1. **MVP:** A simple advisor CRM: households, accounts, tasks, meeting notes and pipelines. Imports from Redtail and Wealthbox CSV.
2. **MVP:** **Reg S-P kit.**
   - Incident response program generator.
   - Breach triage workflow with a 30-day notification clock.
   - Customer notice templates.
   - A service-provider inventory with an oversight attestation log.
3. **MVP:** An annual compliance review workspace: policies, testing checklist, evidence uploads, and a CCO sign-off PDF for the exam binder.
4. **MVP:** A marketing-rule review log. Submit ads, social posts and testimonials; AI flags performance-advertising and testimonial-disclosure issues; approval is recorded.
5. **MVP:** AI meeting notes (opt-in, recorded consent) included in the base price.
6. **V2:** Email and SMS archiving (books-and-records retention, WORM storage via a partner) to replace a separate archiving vendor.
7. **V2:** Custodian integrations (Schwab, Fidelity, Pershing, Altruist) for account data, and a Form ADV/CRS delivery tracker.
8. **V2:** State-registered adviser packs: state books-and-records and exam-prep checklists (NASAA model rules).

## Pricing to win
- **Plans:** Solo $79/mo (CRM + compliance kit). Team $199/mo (up to 10 users). Archiving add-on is flat per firm.
- **Example (estimate):** A 3-person RIA on Wealthbox Pro + AI notetaker pays 3 × ($75 + $49) = **$372/mo**, plus archiving and compliance templates. AdvisorVault Team costs $199/mo, saving about $2,000/yr before archiving and consultant savings.

## Go-to-market (first 100 customers)
- **Associations:** NAPFA, the XY Planning Network (XYPN), FPA chapters, and the Investment Adviser Association (IAA) small-firm programs.
- **Communities:** r/CFP, r/financialplanning (pro threads), Kitces community, and XYPN forums.
- **Conferences:** T3 Advisor Conference, XYPN LIVE, NAPFA conferences, Kitces events.
- **Partners:** Compliance consultants (offer them the platform to run clients) and custodial RIA-onboarding teams.
- **SEO pages:**
  - "Reg S-P incident response plan template RIA"
  - "Reg S-P small RIA compliance date"
  - "Redtail alternative"
  - "Wealthbox alternative cheaper"

## Risks and incumbent moats
- **Integrations** (custodians, Orion/Black Diamond portfolio tools): Mitigation: CSV and custodian feeds in V2, and coexist with portfolio tools.
- **Regulatory liability:** Mitigation: position as tooling (not legal advice), templates reviewed by compliance counsel, and E&O insurance.
- **Archiving requires WORM/SEC 17a-4-style storage:** Mitigation: use a partner.
- **Low price gap on CRM alone:** Redtail is already $39–$65/user. The wedge is compliance bundling, not CRM price.
- **Thin evidence:** Validate demand with 15 RIA interviews before building.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 2 | 3 | 4 | 3 | 2 | **14** |

## Sources
- [Redtail CRM pricing (fetched Sep 24, 2026)](https://redtailtechnology.com/pricing/)
- [Wealthbox pricing (fetched Sep 24, 2026)](https://www.wealthbox.com/pricing/)
- [SEC Adopts Amendments to Regulation S-P (SEC press release 2024-58)](https://www.sec.gov/newsroom/press-releases/2024-58)
- [Redtail CRM reviews (Software Advice)](https://www.softwareadvice.com/crm/redtail-crm-profile/reviews/)
