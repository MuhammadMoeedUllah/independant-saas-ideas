# WashClub: flat-priced unlimited-membership billing, retention and cancel-compliance for independent car washes (a cheaper Rinsed, with a detailer mode vs Urable)

**One-liner:** A membership CRM that sits beside an independent car wash's POS (DRB/Sonny's/ICS/WashAssist). It handles decline recovery, downgrade instead of cancel, a self-serve member portal with **state-compliant online cancellation**, and win-back texts, for a flat fee with no 4% commission.

## Snapshot
- **Replaces:**
  - **Rinsed** (checked Sep 24 2026):
    - Car Wash CRM is **$765/mo per location on a yearly plan or $849/mo monthly, plus $599 implementation and a 4% commission on Rinsed checkouts**.
    - Salespath is $900 yearly or $999/mo monthly per location, plus $599. It has a 12-month minimum on yearly and 3 months on monthly, and tablets are extra.
    - Support Agent is $449–$499/mo per location, plus $499.
    - Source: [Rinsed pricing](https://www.rinsed.com/pricing).
  - **DRB (SiteWatch/Patheon), Sonny's (Control, WashAssist), ICS:** tunnel POS and controllers, quote-only and tied to hardware. Not priced in this pass.
  - **Detailers:** Urable costs Express $70, Pro $110 or Enterprise $183 per month, with unlimited users and no contract ([Urable pricing](https://www.urable.com/pricing)). Mobile Tech RX was not priced.
- **Recent price hikes / changes:**
  - No dated hike found.
  - The structural issue is that Rinsed's per-location fee is stacked on a 4% take of membership checkouts, on top of the POS subscription.
  - Regulatory window: state automatic-renewal laws (for example California's ARL amendments requiring online cancellation and annual reminders) apply to recurring wash memberships. They were not verified in this pass because the leginfo page was blocked. Verify in the per-state pass.
- **Who buys:** The owner or GM of an independent express-tunnel, flex or in-bay automatic wash (1–5 locations) that sells unlimited memberships. For the detailer mode, mobile detailers and small detail shops.
- **US market size:** Not sized in this pass. Estimate: tens of thousands of US car-wash sites, with the independent (non-PE) share shrinking as roll-ups consolidate. Verify with the International Carwash Association and Census NAICS 811192.
- **Urgency trigger (why they'd switch NOW):**
  - Member churn and card declines directly cut recurring revenue. Rinsed itself markets a "15% reduction in churn" ([Rinsed](https://www.rinsed.com/pricing)), which shows how much the problem is worth.
  - State auto-renewal and click-to-cancel rules (to verify).
  - The contract anniversary on Rinsed yearly plans.
- **Fastest-selling states/metros (inference):** TX, FL, GA, AZ, NC, TN and OH, where the express-tunnel build-out is densest. Also CA and NY for auto-renewal-law compliance (to verify).

## Pain points (evidence)
**Evidence is thin.** This pass captured pricing, not operator reviews (Reddit was blocked). The case rests on the price gap. Validate the pain with 10 operator calls, starting with r/carwash and ICA members.
- **[Price]** Rinsed CRM costs $765–$849/mo per location **plus a 4% commission on Rinsed checkouts** plus $599 setup. A 3-site operator pays about $2.3k–$2.5k/mo before commission ([Rinsed pricing](https://www.rinsed.com/pricing)).
- **[Lock-in]** Salespath has a 12-month minimum on the yearly plan and a 3-month minimum on monthly, and tablets are sold separately (same source).
- **[Price]** Support Agent, an AI or outsourced member-support product, adds another $449–$499/mo per location plus $499 (same source).
- **[Missing features / value signal]** Rinsed's own claims ("15% reduction in churn," "16% increase in membership revenue") show that decline and downgrade workflows are worth paying for, so a cheaper equivalent has a clear ROI story (same source).
- **[Detailers]** Detailers are already well served cheaply by Urable ($70–$183, unlimited users, no contract), so the detailer mode is an add-on, not the wedge ([Urable pricing](https://www.urable.com/pricing)).

## What we build (the better version)
1. **MVP:** A **member portal and self-serve account page** covering card update, plan change, pause, add or remove a vehicle (plate), and **one-click online cancellation** with an optional single save offer, built to the strictest state auto-renewal rules. It includes annual reminder emails and a consent log.
2. **MVP:** **Decline recovery (dunning)**, with smart retries timed to paydays, text and email card-update links, and account updater, using Stripe or the wash's existing processor (processor integration is V2).
3. **MVP:** A **downgrade-instead-of-cancel flow** and win-back campaigns by segment (lapsed 30, 60 or 90 days, weather-triggered "it's sunny" texts).
4. **MVP:** A churn dashboard showing members by plan, monthly recurring revenue (MRR), churn and decline rate, and revenue per member, from a POS CSV export (daily upload or SFTP).
5. **MVP:** A **detailer mode**: recurring maintenance-detail memberships, booking and a deposit.
6. **V2:** Direct POS integrations for membership status and license-plate recognition (LPR) and RFID sync (DRB, Sonny's/WashAssist, ICS). This is the hard part; partner or reverse-engineer exports.
7. **V2:** A tablet "driveway" sales app for attendants, with commission tracking, to compete with Salespath.
8. **V2:** An AI member-support inbox (a Support Agent equivalent) at flat cost.

## Pricing to win
- **Our prices:** $249/mo per location, month to month, with no implementation fee and **no commission**. Detailer mode is $49/mo.
- **Example:** A 3-location operator on Rinsed CRM monthly pays about **$2,547/mo plus a 4% commission** (for example, 4% of $20k a month in portal checkouts is $800, which is illustrative). On WashClub it pays $747/mo, saving **about $21.6k/yr before commission**. With the illustrative $800/mo commission, the saving is **about $31.2k/yr**.

## Go-to-market (first 100 customers)
- **Associations and shows:** International Carwash Association (The Car Wash Show) and the regional associations: Southwest Car Wash Association, Western Carwash Association, Midwest Carwash Association and the Northeast Regional Carwash Convention.
- **Communities:** r/carwash and r/AutoDetailing (for detailer mode), plus car-wash-owner Facebook groups.
- **Media:** Professional Carwashing & Detailing magazine and car-wash-investor podcasts and newsletters.
- **Partners:** Equipment distributors and car-wash consultants who build new independent tunnels. Pitch "membership stack in a day."
- **SEO:** "Rinsed pricing," "car wash membership cancellation law [state]," and a "car wash churn calculator."

## Risks and incumbent moats
- **POS lock-in.** Membership status lives in the tunnel POS and LPR system. Without integration we are an overlay, so start with CSV sync and pursue a DRB or Sonny's partner API.
- **PE roll-ups** (large chains) buy enterprise tools, so target independents with 1–5 sites.
- **Payments.** Some POS vendors control the processor, and dunning then needs processor access.
- **Unverified pain.** Price is the only captured evidence, so run interviews before building.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 2 | 5 | 2 | 3 | 2 | **14** |

## Sources
- [Rinsed pricing (checked Sep 24 2026)](https://www.rinsed.com/pricing)
- [Urable pricing (checked Sep 24 2026)](https://www.urable.com/pricing)
