# ESA Desk: a cheaper, better FACTS / Blackbaud for microschools, small private schools and ESA vendors

**One-liner:** Enrollment, tuition billing and ESA "get-paid" workflow in one place. It splits each family's bill between the ESA wallet (ClassWallet, Odyssey, Step Up) and the parent, generates itemized ESA-compliant invoices, tracks each claim to settlement and keeps the compliance binder (accreditation, testing, attendance).

## Snapshot
- **Replaces:**
  - **FACTS Tuition Management:** quote-based. Capterra shows "$1,000 per user/mo" (likely a placeholder; verify). Reviewers call it overpriced, and it applies automatic parent late fees ([Capterra](https://www.capterra.com/p/10027955/FACTS-Tuition-Management/)).
  - Blackbaud, Veracross and Alma: enterprise, quote-based, mostly out of reach for microschools (not re-priced in this pass).
  - The status quo for most microschools is spreadsheets plus Stripe or Venmo plus manual portal uploads.
  - Closest point solution: **GetESAPaid, $39/mo or $390/yr** (invoice generator, rejection checker, audit binder) ([GetESAPaid](https://getesapaid.com/become-an-esa-vendor)).
- **Recent price hikes / changes (switching windows):**
  - **Texas TEFA (2026–27, year one):**
    - Provider portal (run by **Odyssey**) opened **Dec 9 2025**; family applications opened **Feb 4 2026**.
    - Awards: **$10k+** for private-school students, **up to $30k** for students with IEP disabilities, **$2,000** for homeschoolers.
    - Private schools must be **accredited**, have operated **2+ years** and give a **nationally norm-referenced test** ([Texas Comptroller, Nov 25 2025](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312)).
  - **Arkansas (Jun 2026):** a Department of Education assessment found ClassWallet "fragmented, inefficient and increasingly misaligned", with manual workarounds, weak reporting and slow responses ([Grand Canyon Times](https://grandcanyontimes.com/report-finds-esa-vendor-classwallet-fragmented-inefficient-and-increasingly-misaligned)).
  - **Arizona:** Treasurer Kimberly Yee sought vendor proposals (responses due **Jul 29 2026**) for an ESA vendor to track misspending and fraud ([AZ Capitol Times, Jun 5 2026](https://azcapitoltimes.com/news/2026/06/05/state-treasurer-seeks-esa-vendor-to-track-misspending-fraud/)).
  - **About 18 states** now run ESA programs on three payment rails:
    - **ClassWallet:** AZ, AR, TN, WV, NC, IN, NH, AL, SC
    - **Odyssey:** TX, IA, UT, GA, LA, WY, MO
    - **Step Up For Students:** FL
    ([GetESAPaid](https://getesapaid.com/become-an-esa-vendor))
- **Who buys:** Microschool founders (10–150 students), small private and faith-based schools, hybrid and homeschool co-ops, and ESA vendors (tutors, therapists, curriculum and enrichment providers). The founder or head of school decides alone and pays by card.
- **US market size:** The National Microschooling Center estimates about **1.5M students (~2% nationally)** in microschools ([NMC, Nov 19 2025](https://microschoolingcenter.org/news-blog/tuition)). Estimate: about 30k US private schools (NCES Private School Survey; not re-checked this pass), plus tens of thousands of ESA vendors across 18 states.
- **Urgency trigger (why they'd switch NOW):** Texas TEFA year one (2026–27) brings a wave of new ESA money and first-time vendors. ClassWallet dissatisfaction and state procurements (AR, AZ) are in progress. Every new ESA state adds another portal to handle.
- **Fastest-selling states/metros:** **Texas** (Houston, DFW, Austin, San Antonio), **Arizona** (Phoenix), **Florida** (FES/PEP), then Utah, Iowa, Arkansas, Tennessee, and new ESA states such as Georgia, Louisiana, Alabama and the Carolinas.

## Pain points (evidence)
- **[Complexity/UX]** Arkansas found ClassWallet needed manual workarounds and had limited reporting, weak compliance monitoring and slow response times (Jun 2026) ([Grand Canyon Times](https://grandcanyontimes.com/report-finds-esa-vendor-classwallet-fragmented-inefficient-and-increasingly-misaligned)).
- **[Payments]** Arizona ESA families surveyed by the Heritage Foundation cited **reimbursement delays that discourage providers from participating**, plus confusing costs and too few marketplace vendors ([Grand Canyon Times](https://grandcanyontimes.com/report-finds-esa-vendor-classwallet-fragmented-inefficient-and-increasingly-misaligned)).
- **[Complexity/UX]** A homeschool parent calls ClassWallet "poorly designed, slow, and hard to work with" ([Grand Canyon Times](https://grandcanyontimes.com/report-finds-esa-vendor-classwallet-fragmented-inefficient-and-increasingly-misaligned)).
- **[Payments]** Vendors are confused that "approval does not necessarily mean settlement". Payout timing is opaque ([GetESAPaid](https://getesapaid.com/become-an-esa-vendor)).
- **[Complexity]** Invoices get rejected over documentation, eligibility, credential or workflow mismatches, and each state and platform has different rules ([GetESAPaid](https://getesapaid.com/become-an-esa-vendor)).
- **[Complexity]** It is unclear whether credential requirements apply to the business, the individual provider or both, depending on the state ([GetESAPaid](https://getesapaid.com/become-an-esa-vendor)).
- **[Price]** A finance director calls FACTS "over priced" relative to its service ([Capterra](https://www.capterra.com/p/10027955/FACTS-Tuition-Management/)).
- **[Support]** Voicemails, emails and chats to FACTS went unanswered ([Capterra](https://www.capterra.com/p/10027955/FACTS-Tuition-Management/)).
- **[Complexity/UX]** FACTS is "difficult to update or change parameters", and its automatic month-end late fees confuse families ([Capterra](https://www.capterra.com/p/10027955/FACTS-Tuition-Management/)).
- **[Compliance burden]** TEFA requires accreditation, 2+ years of operation and norm-referenced testing, which new microschools must document ([Texas Comptroller](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312)).

## What we build (the better version)
1. **MVP** Enrollment and re-enrollment forms, a waitlist, contracts with e-sign, and family accounts.
2. **MVP** **Split-payer tuition ledger:** each invoice is tagged by payer (ESA program, parent, scholarship, sibling discount) and tracks the ESA portion separately from the parent's balance. Parents autopay the remainder by card or ACH.
3. **MVP** **ESA invoice generator** per platform (Odyssey TX/IA/UT, ClassWallet AZ/AR/TN, Step Up FL): itemized lines, service dates, student ID and the required fields, as PDF plus CSV. A pre-submit "rejection checker" flags missing fields.
4. **MVP** **Claim tracker:** submitted, approved, settled (with payout reference), plus days-outstanding aging and alerts when state payouts lag. Parents see what the ESA covered.
5. **MVP** **Compliance binder:** accreditation certificates, 2-year operating proof, norm-referenced test roster and scores, attendance, teacher credentials, with expiry reminders.
6. **MVP** Parent messaging, a calendar and simple daily attendance.
7. **V2** Multi-state vendor mode for tutors and therapists who serve families in several ESA states (one identity, many portals).
8. **V2** Gradebook and progress reports (lite SIS) plus transcript export.
9. **V2** Microschool network mode for KaiPod, Prenda-style or co-op networks: consolidated reporting across pods.
10. **V2** AI assistant that reads each state's ESA handbook updates and alerts on rule changes affecting eligible expenses.

## Pricing to win
- **Vendor/tutor: $19/mo. Microschool: $79/mo up to 100 students, $149/mo up to 300.** Month-to-month, free setup. Parent card payments at processor cost plus a disclosed margin.
- **Example:** a 60-student microschool running spreadsheets, a separate e-sign tool and GetESAPaid ($39) switches to $79/mo all-in. A small private school on FACTS plus Blackbaud (quote-based, often thousands per year) saves more. Collect real quotes in the state pass.

## Go-to-market (first 100 customers)
- **Microschool networks:** National Microschooling Center, KaiPod Catalyst (founder accelerator), Prenda guide community, the Texas Private Schools Association, and state school-choice parent groups (Arizona ESA parent groups, TEFA family groups).
- **Facebook groups:** "Arizona ESA Families", "Texas Education Freedom Accounts parents and providers", "Florida PEP/FES families", "Microschool Founders".
- **Reddit:** r/Microschools, r/homeschool, r/TeachersInTransition (teachers starting microschools).
- **Partners:** accreditation bodies (Cognia, and state private-school accreditors approved by TEPSAC), norm-referenced testing providers, charter/microschool consultants.
- **SEO:** "TEFA vendor invoice template", "ClassWallet invoice rejected", "Odyssey ESA provider payment", "get paid by ESA Texas".

## Risks and incumbent moats
- **No public APIs from ClassWallet or Odyssey:** we generate invoice files and guided upload steps, not integrations. Browser-automation assist in V2, within platform ToS.
- **Rules churn by state:** we keep a rules table per program. The AI watcher flags changes.
- **Political risk:** ESA programs could be litigated or defunded. Diversify across 18 states and keep the core tuition tool useful without ESA.
- **Platform vendors may add vendor tools themselves:** our multi-state and multi-payer ledger is the moat.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 3 | 4 | 3 | **17** |

## Sources
- [Texas Comptroller: final rules and key dates for TEFA (Nov 25 2025)](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312)
- [TEFA Providers and Vendors page](https://educationfreedom.texas.gov/providers-vendors/)
- [Report finds ESA vendor ClassWallet "fragmented, inefficient" – Grand Canyon Times (2026)](https://grandcanyontimes.com/report-finds-esa-vendor-classwallet-fragmented-inefficient-and-increasingly-misaligned)
- [State treasurer seeks ESA vendor to track misspending, fraud – AZ Capitol Times (Jun 5 2026)](https://azcapitoltimes.com/news/2026/06/05/state-treasurer-seeks-esa-vendor-to-track-misspending-fraud/)
- [How to become an ESA vendor (every state) – GetESAPaid](https://getesapaid.com/become-an-esa-vendor)
- [How ESAs Affect Microschools' Tuition – National Microschooling Center (Nov 19 2025)](https://microschoolingcenter.org/news-blog/tuition)
- [FACTS Tuition Management – Capterra](https://www.capterra.com/p/10027955/FACTS-Tuition-Management/)
- [Arizona ClassWallet info – AZ Dept of Education](https://www.azed.gov/esa/classwallet)
- [Despite breakdowns in two states, ESA provider Student First seeks to expand – Yahoo News (not read; lead)](https://www.yahoo.com/news/despite-breakdowns-two-states-esa-110151215.html)

## Corrections from the state pass (Sep 2026)
- **West Virginia:** the Hope Scholarship became universal on Jul 1 2026 ($5,435.62) and now runs on its own portal plus TheoPay, not ClassWallet (see states/WV-west-virginia.md).
- **Arizona:** ESA enrollment is 106,253 students for 2026–27 (AZ Dept of Ed, Sep 21 2026). **Iowa:** $8,148 per student for 2026–27 via Odyssey. **South Carolina:** 15,000+ students at $7,500. **New Hampshire:** EFA hit its 12,500-student cap in Aug 2026. See each state file.
