# OfficeKeys: a flat-price password and access manager for 5–50-person offices leaving LastPass (and 1Password's price cliff)

**One-liner:** A shared-password vault for small offices with one flat price per office. It adds the missing SMB layer: **"who has access to what" maps, one-click offboarding, shared 2FA codes, and a guided LastPass-exit rotation plan**. It's built on audited open-source vault cryptography rather than homegrown crypto.

## Snapshot
- **Replaces:**
  - **1Password** (usecarly, Jul 15, 2026):
    - Teams Starter Pack **$24.95/mo flat for up to 10 users**.
    - Business **$8.99/user/mo, annual only**.
    - No free tier.
    - **Team of 11 cliff:** $24.95/mo becomes **$98.89/mo**.
    - TeamPassword (page updated 2026) says 1Password **raised prices in March 2026**. The prior list prices, per the costbench headline, were $7.99/user Business and $19.95 Starter Pack. Confirm the exact old values.
  - **LastPass** (TeamPassword, 2026): Teams $4.25/user/mo, Business $7/user/mo, Business Max $9/user/mo.
  - **Bitwarden** (TeamPassword, 2026): Teams **$4/user/mo**, Enterprise $6/user/mo. A Jan 2026 increase hit personal plans only. This is the cheap, trusted incumbent to beat.
- **Recent price hikes / changes, breaches and fines:**
  - **Dec 14, 2025:** the UK ICO fined LastPass **£1.2M (~$1.6M)** over the 2022 breach, which affected ~1.6M UK users. LastPass serves **100,000 businesses** (Forbes).
  - **Dec 25, 2025:** TRM Labs traced **~$35M in crypto thefts** to cracked 2022 LastPass vault backups, with activity continuing into **Sept 2025**. Any vault with a weak master password remains at risk offline (The Hacker News).
  - News headlines report a US class settlement that reimburses crypto losses, reportedly up to $24M (Bloomberg Law and Coinfomania headlines; terms not verified in this pass).
  - **March 2026:** 1Password price increase (TeamPassword).
- **Who buys:** office managers, owners and **MSPs** serving 5–50-person offices: dental and medical front desks, law and CPA firms, real-estate brokerages, agencies, nonprofits. The MSP is often the real decision-maker.
- **US market size:** about 6M US employer firms (Census, estimate). LastPass alone reports 100,000 business customers (Forbes, Dec 2025). Offices with 5–50 staff that share logins number in the low millions (estimate).
- **Urgency trigger (why they'd switch NOW):**
  - Continued news of crypto theft from 2022 LastPass vaults, plus the ICO fine (Dec 2025). Cyber-insurance questionnaires increasingly ask about password management and MFA (verify per carrier).
  - 1Password's March 2026 increase and the 10-to-11-user cliff.
  - An employee leaving with shared credentials, which is the everyday trigger.
- **Fastest-selling states/metros:** MSP-dense SMB markets (Dallas, Houston, Phoenix, Atlanta, Tampa, Chicago suburbs), and healthcare and legal clusters where HIPAA or client-confidentiality rules make offboarding audits matter.

## Pain points (evidence)
- **[Price]** 1Password's jump from the 10-user Starter Pack ($24.95/mo) to Business at 11 users ($98.89/mo) is nearly 4x for one extra person (usecarly, Jul 15, 2026) ([source](https://www.usecarly.com/blog/1password-pricing/))
- **[Price]** As soon as a small team needs SSO, provisioning or real reporting, it has to move to 1Password Business at $8.99/user. A 20-person team pays about $2,158/yr versus about $578 on cheaper tools (TeamPassword, 2026; competitor source) ([source](https://teampassword.com/blog/1password-alternatives))
- **[Lock-in/Contracts]** 1Password Business is annual-only with no monthly option, and there is no free tier (usecarly, Jul 15, 2026) ([source](https://www.usecarly.com/blog/1password-pricing/))
- **[Missing features]** TRM Labs traced ~$35M in crypto thefts through 2025 to cracked 2022 LastPass vaults. Weak master passwords turned one breach into a multi-year attack window (The Hacker News, Dec 25, 2025) ([source](https://thehackernews.com/2025/12/lastpass-2022-breach-led-to-years-long.html))
- **[Missing features]** The UK regulator fined LastPass £1.2M for failing to implement sufficiently robust security measures (Forbes, Dec 14, 2025) ([source](https://www.forbes.com/sites/daveywinder/2025/12/14/lastpass-data-breach---insufficient-security-exposed-16-million-users/))
- **[Support]** A multi-year paying customer left because LastPass eliminated human support and replaced it with bots and community forums (Trustpilot, Jul 16, 2026) ([source](https://www.trustpilot.com/review/www.lastpass.com))
- **[Support]** A billing glitch downgraded a premium user to free, and support then refused help because free users don't get agent support (Trustpilot, Sept 1, 2026) ([source](https://www.trustpilot.com/review/www.lastpass.com))
- **[Lock-in/Contracts]** A user couldn't cancel a recurring LastPass subscription (no email, phone or chat) and blocked the card after three years of non-use (Trustpilot, Aug 23, 2026). Another still gets renewal invoices a year after cancelling (Trustpilot, Feb 7, 2026) ([source](https://www.trustpilot.com/review/www.lastpass.com))
- **[Complexity/UX]** A 15-year customer left over constant master-password prompts at each login step and moved to Bitwarden (Trustpilot, Sept 5, 2026). A premium user is repeatedly locked out despite the correct master password (Trustpilot, Jan 24, 2026) ([source](https://www.trustpilot.com/review/www.lastpass.com))

**Honest read:** this is **weak on price gap.** Bitwarden is $4/user and trusted, and writing new vault crypto is a liability. The only credible version is:
- **(a)** Built on audited open-source vault components (e.g., Bitwarden-compatible clients and server). License and trademark terms must be checked, since Vaultwarden is unofficial and Bitwarden's server licensing varies by component.
- **(b)** Sold on the **office-access layer and MSP workflow**, not on the vault.
- **(c)** Distributed through MSPs.
If that layer can't be built as a clean add-on, drop this idea.

## What we build (the better version)
1. **LastPass exit wizard.** Import the LastPass CSV, **rank credentials by risk** (reused, old, finance or crypto, admin accounts), and generate a rotation checklist with per-site "change password" links and progress tracking. **MVP** (this ships even as a standalone free tool)
2. **Access map:** a grid of people × shared accounts (who can see what), with alerts for "shared with a former employee." **MVP**
3. **One-click offboarding:** remove a person, list every credential they could see, and queue rotation tasks for the office manager. **MVP**
4. **Shared TOTP / 2FA codes** for shared admin logins (bank, payroll, domain registrar), with a view log. **MVP**
5. **Vault and browser autofill** using an established open-source client (Bitwarden-compatible) under OfficeKeys branding where licensing allows. **MVP** (depends on the licensing decision; otherwise V2)
6. **MSP console:** multi-tenant management, per-office flat billing, monthly access-review report PDFs for clients, and PSA ticket hooks (ConnectWise, Autotask, HaloPSA). **V2**
7. **Cyber-insurance evidence pack:** an export showing password-manager adoption, MFA on shared accounts and offboarding logs. **V2**
8. **Breach watch:** check office domains against known breach corpora and alert on exposed staff emails. **V2**

## Pricing to win
| Plan | OfficeKeys | Incumbent |
|---|---|---|
| Office **$29/mo flat** | Up to 25 users, access map, offboarding, shared 2FA, month-to-month | 1Password Business 25 × $8.99 ≈ $225/mo (annual); Bitwarden Teams 25 × $4 = $100/mo |
| Office Plus **$49/mo flat** | Up to 50 users, SSO (V2), insurance evidence pack | 1Password Business 50 × $8.99 ≈ $450/mo |
| MSP **$15/office/mo** wholesale | Multi-tenant console; the MSP resells at its own margin | Per-seat MSP password tools |

**Savings example (estimate):** a 15-person law office on 1Password Business (15 × $8.99 ≈ $135/mo) pays $29, saving **≈$1,270/yr**.

## Go-to-market (first 100 customers)
- **MSP channel first:** r/msp, r/sysadmin, MSPGeek, and ConnectWise/Kaseya user communities. Offer a free LastPass-exit rotation audit that MSPs run for their clients.
- **"Switch from X" SEO:**
  - "LastPass alternative for small business"
  - "LastPass crypto theft what to do"
  - "LastPass export and rotate passwords"
  - "1Password 11 users price"
  - "1Password Teams Starter Pack alternative"
- **Verticals:** state bar associations' practice-management resources, dental and medical office manager Facebook groups, and CPA firm-tech newsletters.
- **Launch:** Product Hunt, plus a free standalone "LastPass Exit Checklist" web tool as a lead magnet.

## Risks and incumbent moats
- **Trust.** A new password vendor is a hard sell right after a breach story. Answer: open-source audited crypto, a published third-party pen test, a bug bounty, and no custom cryptography.
- **Bitwarden's price.** Answer: don't compete on the vault. Compete on offboarding and access mapping plus the MSP workflow, and consider an integration with Bitwarden instead of a replacement.
- **Licensing of open-source vault components** (Bitwarden's server licensing varies by component; Vaultwarden is an unofficial reimplementation). Answer: legal review before the MVP. The fallback is an access-layer add-on that sits beside the customer's existing vault.
- **Liability.** Answer: security-focused terms, cyber-liability insurance and a limited-liability contract.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 2 | 2 | 3 | 4 | **14** |

## Sources
- [1Password Pricing in 2026: Every Plan, Fee, and Gotcha – usecarly](https://www.usecarly.com/blog/1password-pricing/) (Jul 15, 2026)
- [1Password Alternatives for Teams (2026) – TeamPassword](https://teampassword.com/blog/1password-alternatives) (updated 2026; competitor source)
- [LastPass Data Breach — 1.6 Million Users Exposed – Forbes](https://www.forbes.com/sites/daveywinder/2025/12/14/lastpass-data-breach---insufficient-security-exposed-16-million-users/) (Dec 14, 2025)
- [LastPass 2022 Breach Led to Years-Long Cryptocurrency Thefts, TRM Labs Finds – The Hacker News](https://thehackernews.com/2025/12/lastpass-2022-breach-led-to-years-long.html) (Dec 25, 2025)
- [LastPass on Trustpilot](https://www.trustpilot.com/review/www.lastpass.com) (1.4/5, 932 reviews; complaints Jan–Sept 2026)
- [LastPass Agrees to Reimburse Crypto in Data Breach Settlement – Bloomberg Law](https://news.bloomberglaw.com/litigation/lastpass-agrees-to-reimburse-crypto-in-data-breach-settlement) (headline only; not read)
- [1Password Business Pricing 2026 – Costbench](https://costbench.com/software/secrets-management/1password-business/) (headline only)
