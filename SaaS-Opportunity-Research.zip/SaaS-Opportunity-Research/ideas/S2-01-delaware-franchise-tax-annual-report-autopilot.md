# ParCheck: a cheaper, better Harbor Compliance / LegalZoom / registered-agent bundle for Delaware corporations and LLCs

**One-liner:** A flat-priced autopilot for the 2.28M+ Delaware entities owned from anywhere. It checks the franchise tax with both legal methods before you pay, preps and files the Mar 1 annual report, reminds LLCs of the $400 Jun 1 tax, flags scam mailers, and bundles a no-uplift registered agent through a licensed Delaware partner.

## Snapshot
- **Replaces:**
  - **Harbor Compliance, Delaware registered agent:** "Starting at $99 for new customers per state, renewing at $159 annually" ([Harbor Compliance, fetched Sep 24 2026](https://www.harborcompliance.com/delaware-registered-agent)). Annual-report filing is priced separately and wasn't shown.
  - **Northwest Registered Agent, Delaware:** $125/yr. Help with the Delaware Annual Report is mentioned, but no franchise-tax calculation is offered ([Northwest, fetched Sep 24 2026](https://www.northwestregisteredagent.com/registered-agent/delaware)).
  - **Stripe Atlas:** $500 one-time (Delaware incorporation plus the first year of registered agent), then $100/yr. The page offers no franchise-tax or annual-report help ([Stripe Atlas, fetched Sep 24 2026](https://stripe.com/atlas)).
  - **LegalZoom registered agent and compliance bundles:** about $299/yr (background, **not verified**; see J06). Law-firm or CPA annual-report filing fees are also not verified; our estimate is $150–$500 per filing.
  - **Carta / Pulley cap-table tools**, which some startups use for the franchise-tax figure. Prices not verified in this pass.
- **Recent price hikes / changes:**
  - **Delaware's LLC/LP/GP annual tax is now $400.** The Division states: "…they are required to pay an annual tax of $400.00" ([DE Division of Corporations](https://corp.delaware.gov/frtax/)). Earlier research (J06) listed $300. The effective date of the increase needs verifying.
  - **Harbor Compliance's renewal is 61% above its intro price** ($99 to $159).
  - **FinCEN's final rule (Aug 2026) exempts U.S. companies from BOI reporting** ([FinCEN](https://www.fincen.gov/boi), via J06). Paid "BOI filing" upsells are now dead weight, which opens a "here's what you actually still owe" message.
  - **Scam mailers.** The Division warns of "a deceptive solicitation that has been mailed to numerous Delaware corporations from a company named Corporate Records Service," which asks for $125 ([DE Division of Corporations](https://corp.delaware.gov/frtax/)).
- **Who buys:**
  - Founders and finance leads of VC-backed and bootstrapped Delaware C-corps.
  - Owners of Delaware LLCs: holding companies, real-estate SPVs, e-commerce and agencies.
  - Fractional CFOs, startup CPAs and startup law firms that manage dozens to hundreds of entities.
  - Almost all buy with a card.
- **US market size:**
  - Delaware has "more than 2.28 million" entities.
  - **334,461 new entities were formed in 2025:** 235,393 LLCs, 74,716 corporations, 21,189 LPs/LLPs and 3,163 statutory trusts.
  - "Nearly 70%" of U.S. IPOs in 2025 chose Delaware ([DE Division of Corporations stats](https://corp.delaware.gov/stats/)).
  - Willingness to pay is low per entity ($50–$160/yr) but recurring, with multi-entity customers through accountants.
- **Urgency trigger (why they'd switch NOW):**
  - **Corporations:** the annual report and franchise tax must be received by **Mar 1**. Late filing costs a $200 penalty plus 1.5%/mo interest.
  - **LLCs, LPs and GPs:** $400 due **Jun 1**, with a $200 penalty plus 1.5%/mo if late.
  - **Foreign corporations:** annual report due Jun 30 ($250 fee) ([DE Division of Corporations](https://corp.delaware.gov/frtax/)).
  - The Dec–Feb selling window is next up (Mar 1 2027). Registered-agent renewals and their uplift arrive on each company's anniversary.
- **Fastest-selling states/metros:** National, since the law is Delaware's but the buyers are everywhere. Estimate: SF Bay Area, NYC, Boston, Austin, Miami, Seattle, LA startup hubs, plus Wilmington law and accounting firms as partners.

## Pain points (evidence)
Honest note: this is mainly a **structural, law-driven pain**. Review-site complaint volume about registered agents is moderate. Web search was unavailable this pass, so founder-forum threads were not collected.
- **[Price / shock]**
  - Delaware bills corporations under two methods:
    - **Authorized Shares:** $175 minimum; 5,001–10,000 shares is $250; each additional 10,000 shares adds $85.
    - **Assumed Par Value Capital (APVC):** $400 per million or portion of a million, with a $400 minimum.
  - Official guidance is to "use the method that results in the lesser tax," with a $200,000 maximum, or $250,000 for an identified Large Corporate Filer ([DE franchise-tax calculation](https://corp.delaware.gov/frtaxcalc/); [DE annual report info](https://corp.delaware.gov/frtax/)).
  - **Our calculation from that table:** a typical startup with **10,000,000 authorized shares** owes **$85,165** under Authorized Shares.
  - Under APVC, with 8M issued shares and $500k gross assets, the same startup owes **$400**. The assumed par of $0.0625 × 10M shares gives $625k of capital, which is $400 per "portion of a million."
  - Getting the lower figure requires knowing to file under APVC with issued shares and total gross assets.
- **[Scams]** The Division warns about "Corporate Records Service" mailers asking Delaware corporations for $125 ([DE Division of Corporations](https://corp.delaware.gov/frtax/)).
- **[Price / renewal uplift]** Harbor Compliance's Delaware registered agent goes from $99 to $159/yr at renewal ([Harbor Compliance](https://www.harborcompliance.com/delaware-registered-agent)).
- **[Price / hike]** The Delaware LLC/LP/GP annual tax is now $400 ([DE Division of Corporations](https://corp.delaware.gov/frtax/)). Owners who budgeted $300 get surprised, and the late penalty is $200 plus 1.5%/mo.
- **[Billing / lock-in]** A LegalZoom customer says registered-agent and business-management fees "kept piling on without clear opt-in transparency" and cancelling was "unnecessarily difficult" ([Trustpilot, Sep 2026](https://www.trustpilot.com/review/legalzoom.com), via J06). LegalZoom is otherwise rated 4.6/5, so this is a minority complaint.
- **[Billing]** A Bizee customer reports being charged three times in one day for a service address, with refunds refused (Sep 16 2026). Bizee rates 4.8/5 on 26,142 reviews ([Trustpilot](https://www.trustpilot.com/review/bizee.com)).
- **[Missing features]** A Bizee reviewer says the service only makes you "compliant at the state level" and the operating agreement didn't work for bank use (Aug 30 2026) ([Trustpilot](https://www.trustpilot.com/review/bizee.com)).
- **[Missing features]** Stripe Atlas charges $100/yr after year one, but its page offers no franchise-tax or annual-report help ([Stripe Atlas](https://stripe.com/atlas)). Registered agents like Northwest help with "paperwork formalities" but don't compute the tax ([Northwest](https://www.northwestregisteredagent.com/registered-agent/delaware)).
- **[Regulatory churn]** BOI went from mandatory to exempt for U.S. companies (final Aug 2026), leaving owners unsure what they still owe ([FinCEN](https://www.fincen.gov/boi), via J06).

## What we build (the better version)
1. **MVP:** **Entity inbox.** Add one or many Delaware file numbers, or import a cap-table CSV (authorized and issued shares, par value). A dashboard shows each entity's type, due date, status and amount owed.
2. **MVP:** **Two-method franchise-tax checker.** It computes Authorized Shares and APVC side by side from the official tables, using issued shares, total gross assets (from the return's balance sheet) and par value. It explains the gap in plain English and outputs the exact figures to enter in the Delaware eCorp annual report. A free public version is the lead magnet.
3. **MVP:** **Annual-report prep.** Officers, directors and principal-address fields are prefilled from last year, followed by a guided filing walkthrough and a stored receipt.
4. **MVP:** **Deadline autopilot.** Email and SMS reminders at 60, 30, 7 and 1 days for Mar 1, Jun 1 and Jun 30. A penalty-and-interest calculator covers late filers.
5. **MVP:** **Scam-mailer checker.** Snap a photo of any "annual report" or "records" letter. The AI flags known deceptive solicitations (for example the Division's Corporate Records Service alert) and states what is actually owed and to whom.
6. **MVP:** **Accountant view.** Bulk entities, client-level billing and white-label reminder emails.
7. **V2:** **Registered agent at a flat $49/yr with no renewal uplift**, fulfilled by a licensed Delaware commercial registered agent partner. Includes mail scanning and AI triage of service-of-process.
8. **V2:** **One-click filing and payment** through the partner's filer access.
9. **V2:** **Foreign-qualification tracker** for the states where a Delaware entity is registered (CA, NY and TX annual/biennial reports), sharing J06's entity engine.
10. **V2:** **"Fix it for next year" playbook.** A law-firm partner offers board consent and charter-amendment templates for founders who want fewer authorized shares or cleaner par values.

## Pricing to win
- **Free:** two-method franchise-tax checker and deadline reminders for one entity.
- **Autopilot, $49/yr per entity:** annual-report prep, both-method worksheet, scam-mailer checker, reminders, receipts.
- **Autopilot + Agent, $99/yr per entity (V2):** includes registered agent, with a price lock and no renewal uplift.
- **Firm plan, $299/yr for up to 25 entities, then $8/entity.**
- **Savings, typical startup:** Harbor renewal ($159) plus a CPA or lawyer to prep the filing (estimate $150–$300) comes to about $300–$460/yr. Our $99 saves roughly **$200–$360/yr**.
- **The bigger win:** never paying a six-figure Authorized Shares amount by mistake, and never paying a $200 late penalty plus 1.5%/mo.
- Month-to-month; annual prepay optional; free migration from any registered agent.

## Go-to-market (first 100 customers)
- **SEO and free tool:** pages such as "Delaware franchise tax calculator," "Delaware franchise tax too high / $85,000 notice," "Assumed Par Value Capital method explained," "Corporate Records Service scam," "Delaware LLC tax $400 due June 1," and "Harbor Compliance renewal $159 alternative."
- **Seasonal blitz, Dec 2026–Feb 2027:** Hacker News "Show HN," Indie Hackers, r/startups, r/Entrepreneur and r/smallbusiness posts on "how we avoided an $85k Delaware tax bill," plus Product Hunt launch in January.
- **Partners:**
  - Startup banks' and neobanks' perks directories; accelerators (a perks line in Techstars- and YC-style batches).
  - Startup CPA firms and fractional CFOs via the white-label firm plan.
  - Startup law firms' Delaware corporate practices for V2 charter fixes.
- **Outbound:** new-formation data (Delaware formed 74,716 corporations and 235,393 LLCs in 2025) matched to company websites. Target founders in their first Feb–Mar filing season.

## Risks and incumbent moats
- **Free calculators exist**, and Carta, Clerky or Stripe Atlas could add the feature. Answer: win on the full job (checker, prep, reminders, scam triage, agent with no uplift, multi-entity firm view), not the calculator alone.
- **Registered-agent licensing:** acting as a Delaware registered agent requires a Delaware address and licensing. Answer: fulfill through a licensed partner and white-label it (V2).
- **Accuracy liability** for tax figures. Answer: show every input and formula (from the Division's published tables), require user confirmation, and add disclaimers and E&O insurance. We prepare filings; the owner submits in MVP.
- **Seasonality and low ARPU.** Answer: annual prepay, the multi-entity firm channel, and bundling with J06's national entity and license tracking.
- **Rule changes** (the LLC tax already rose to $400). Answer: a rules table monitored against corp.delaware.gov and updated centrally, which is itself a reason to subscribe.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 5 | 4 | 4 | **19** |

## Sources
- [DE Division of Corporations, annual report and tax information (fetched Sep 24 2026)](https://corp.delaware.gov/frtax/)
- [DE Division of Corporations, how to calculate franchise taxes](https://corp.delaware.gov/frtaxcalc/)
- [DE Division of Corporations, statistics / 2025 annual report](https://corp.delaware.gov/stats/)
- [DE Division of Corporations, 2025 Annual Report (PDF)](https://corpfiles.delaware.gov/Annual-Reports/Division-of-Corporations-2025-Annual-Report.pdf)
- [DE Division of Corporations, pay taxes / file annual report](https://corp.delaware.gov/paytaxes/)
- [Harbor Compliance, Delaware registered agent pricing](https://www.harborcompliance.com/delaware-registered-agent)
- [Northwest Registered Agent, Delaware](https://www.northwestregisteredagent.com/registered-agent/delaware)
- [Stripe Atlas pricing](https://stripe.com/atlas)
- [Trustpilot, Bizee](https://www.trustpilot.com/review/bizee.com)
- [Trustpilot, LegalZoom](https://www.trustpilot.com/review/legalzoom.com)
- [FinCEN, BOI](https://www.fincen.gov/boi)

## Verification (Sep 24 2026)
- ✅ Corporations: the annual report and franchise tax are due "no later than March 1st", with a $200 penalty and 1.5%/month interest. The tax is at least $175 under Authorized Shares or $400 under APVC, and at most $200,000 ($250,000 for a Large Corporate Filer, now added) ([DE Division of Corporations](https://corp.delaware.gov/frtax/))
- ✅ LLC/LP/GP annual tax is "$400.00", due "on or before June 1st", with a $200 penalty plus 1.5%/month. The page doesn't give the date of the $300→$400 increase, so that stays (verify) ([DE Division of Corporations](https://corp.delaware.gov/frtax/))
- ✅ Foreign corporations: annual report due on or before June 30, $250 fee, $250 penalty ([DE Division of Corporations](https://corp.delaware.gov/frtax/))
- ✅ Authorized Shares rates are $175 for up to 5,000 shares, $250 for 5,001–10,000, and $85 for each additional 10,000 or part. APVC is $400 per million or portion. The page says to "use the method that results in the lesser tax". By these tables, 10M authorized shares gives $250 + 999 × $85 = **$85,165**, and APVC comes to $400. Both figures hold ([DE franchise-tax calculation](https://corp.delaware.gov/frtaxcalc/))
- ✅ The Division warns about "Corporate Records Service" mailers that ask for $125 ([DE Division of Corporations](https://corp.delaware.gov/frtax/))
- ✅ Statistics: more than 2.28M entities, and 334,461 formed in 2025 (235,393 LLCs, 74,716 corporations, 21,189 LPs/LLPs, 3,163 statutory trusts). "Nearly 70%" of US IPOs in 2025 chose Delaware ([DE stats](https://corp.delaware.gov/stats/))
