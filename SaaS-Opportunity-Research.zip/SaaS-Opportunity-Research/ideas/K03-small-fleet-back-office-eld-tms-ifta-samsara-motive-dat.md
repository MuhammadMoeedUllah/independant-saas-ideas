# HaulDesk: a no-contract back office (TMS, IFTA, settlements, broker fraud check) for owner-operators and 1–20 truck fleets, replacing Samsara/Motive lock-in and per-seat TMS

**One-liner:** One month-to-month app for small carriers. It handles loads, AI-read rate confirmations, invoicing and factoring packets, driver settlements, **quarterly IFTA built from your ELD data**, compliance reminders, and a double-brokering check. It works with any ELD and any load board, and has no multi-year contract.

## Snapshot
- **Replaces:**
  - **Load boards:** DAT carrier plans are Standard $59, Enhanced $149, Pro $169, Select $259 and Office $339 per month, verified on dat.com Sep 10 2026 ([Small Fleet HQ](https://smallfleethq.com/reviews/dat-load-board)). We do not replace the load board (it has network effects); we cut the tools around it.
  - **Carrier TMS** (May 2026):
    - AscendTMS: free for 3 or fewer users, paid $49–$149 per user per month.
    - TruckLogics: $36/mo, annual billing, includes IFTA.
    - Truckbase: $290/mo billed annually or $490/mo billed monthly.
    - Tailwind: $99 per user per month.
    - Rose Rocket: about $65 per user per month (estimate).
    - Alvys: $410 per seat per month.
    - Axon: $233+/mo. PCS: $183+/mo.
    - Source: [BestCarrierTMS pricing guide, May 2026](https://bestcarriertms.com/tms-pricing-guide.php). McLeod is quote-only and was not priced.
  - **ELD/telematics:** Samsara and Motive sell on multi-year contracts with hardware. Current list prices were not captured in this pass; see the comparisons from [Small Fleet HQ](https://smallfleethq.com/elds/motive-vs-samsara) and [Airpinpoint](https://airpinpoint.com/compare/samsara-vs-motive).
- **Recent price hikes / changes:**
  - **DAT renewal increases of 25%–45%** with minimal notice. Parent company Roper Technologies treats "pricing optimization as a strategic priority" ([Small Fleet HQ, Sep 10 2026](https://smallfleethq.com/reviews/dat-load-board)).
  - TMS vendors typically raise prices 3–7% a year. Implementation, training, EDI and integrations add 20–60% to the sticker price, and EDI setup costs $250–$2,000 per broker ([BestCarrierTMS](https://bestcarriertms.com/tms-pricing-guide.php)).
  - Samsara auto-renewal, early-termination-fee and downsizing complaints run through Aug 2026 (see below).
- **Who buys:** Owner-operators with their own authority, and small fleets of 2–20 power units. The buyer is the owner, often with a spouse or one office person doing dispatch and billing. They pay by card and are very price-sensitive during a freight recession.
- **US market size (estimate):** Several hundred thousand active FMCSA-registered for-hire carriers. The large majority run 10 or fewer trucks; the commonly cited figure is about 95%. Verify against FMCSA MCMIS and census data in the per-state pass.
- **Urgency trigger (why they'd switch NOW):**
  - **The Q3 2026 IFTA return is due Oct 31, 2026.** IFTA returns are due quarterly, on the last day of the month after each quarter.
  - Samsara and Motive contract renewal dates, where carriers try to escape auto-renewals.
  - DAT renewal notices.
  - Cash squeeze from the freight recession.
- **Fastest-selling states/metros (inference):** TX (DFW, Houston, Laredo), CA (Inland Empire, Central Valley), IL (Chicago suburbs), GA (Atlanta), FL, IN, OH and NJ. These are dense small-carrier and immigrant-owned fleet hubs.

## Pain points (evidence)
- **[Lock-in/Contracts]** A business tried to cancel Samsara 30 days before expiration and was auto-renewed for **three more years** over "missing information" (BBB, Jan 2026) ([BBB Samsara complaints](https://www.bbb.org/us/ca/san-francisco/profile/electronics-and-technology/samsara-1116-881058/complaints)).
- **[Lock-in/Contracts]** A small business that shrank its fleet could not reduce its contracted devices and paid **nine months** for trucks it no longer ran (BBB, Feb 2026) (same source).
- **[Lock-in/Contracts]** A customer received non-working equipment and poor support, then was hit with an early termination fee when asking to cancel (BBB, Apr 2026) (same source).
- **[Billing]** Samsara kept charging for **two years** after a documented cancellation (BBB, Dec 2025). Another firm was billed for three months after returning equipment and waited for a $1,262.72 refund (BBB, Aug 2026). BBB shows 90 complaints in 3 years (same source).
- **[Billing/Lock-in]** An owner-operator called Motive twice to cancel, still got a new-year bill, never received return instructions, and was then charged more fees. Posters recommend credit-card chargebacks and a hardware-you-keep ELD, and one argues Motive broke California's auto-renewal law by sending no renewal notice (TruckersReport, Mar–Jun 2024) ([thread](https://www.thetruckersreport.com/truckingindustryforum/threads/motive-cancelled.2503764/)).
- **[Price]** DAT renewals jumped 25%–45% with little notice, and one carrier called the notice tone-deaf during a freight recession ([Small Fleet HQ](https://smallfleethq.com/reviews/dat-load-board)).
- **[Fraud]** Carriers call on loads that do not exist. In March 2025 about 19,000 fake loads were posted under a major broker's name, and a December 2025 reviewer says only "CHEAP brokers" post (same source).
- **[Price]** Per-user load-board seats cost a 10-truck fleet about $2,940–$8,940 a year. DAT's Trustpilot rating is 2.7/5, against 4.6 on G2 (same source).
- **[Hidden fees]** TMS sticker prices omit implementation, EDI ($250–$2,000 per broker), driver-app seats and premium support (10–20% extra) ([BestCarrierTMS](https://bestcarriertms.com/tms-pricing-guide.php)).
- **[Price]** Seat-based TMS pricing, such as Alvys at $410 per seat per month, prices out 2–5 truck fleets (same source).

## What we build (the better version)
1. **MVP:** Load entry by **forwarding or uploading a rate confirmation**. AI extracts the broker, MC number, stops, times, rate and accessorials, and creates the load, calendar and driver dispatch sheet.
2. **MVP:** A **broker and double-brokering check** on every rate confirmation. It looks up the MC/DOT number through the FMCSA QCMobile API, checks authority age, insurance on file, and whether the phone and email match past loads, and gives a red/yellow/green result.
3. **MVP:** A driver app (PWA) to upload proof of delivery (POD) and bill of lading (BOL) photos, auto-cropped to PDF. It also builds an **invoice and factoring packet** (invoice, rate confirmation, BOL, POD) and sends it by email or portal upload to the broker or factor (OTR, RTS, TAFS and others via email-in).
4. **MVP:** **Quarterly IFTA.** Import miles by jurisdiction from Motive, Samsara, or any ELD's CSV or IFTA report, and fuel receipts from fuel-card CSVs or photo OCR. It calculates tax per state and exports each state's return format with an audit binder (4-year retention).
5. **MVP:** Driver settlements (percent, per-mile or flat, with deductions and escrow) and expense tracking with QuickBooks export.
6. **MVP:** Compliance calendar covering IRP, UCR, 2290 HVUT, annual inspection, medical cards, CDL expiry, drug and alcohol clearinghouse queries, and insurance COI, with text reminders.
7. **MVP:** An "escape your contract" kit that tracks ELD, DAT and TMS renewal dates and generates certified cancellation letters 60/30 days ahead.
8. **V2:** A bring-your-own-device ELD app, self-certified and listed on the FMCSA ELD registry, sold month to month with a cheap commodity plug-in. This is the hard part.
9. **V2:** A load-board aggregator view (DAT, Truckstop and 123Loadboard through their APIs) with lane profitability (cost per mile after fuel, tolls and deadhead).
10. **V2:** An AI dispatcher assistant that drafts broker rate-negotiation emails and check-calls, and an EDI connector at cost.

## Pricing to win
- **Our prices:**
  - Solo $39/mo (1 truck).
  - Fleet $99/mo (up to 10 trucks, unlimited office users).
  - Fleet+ $199/mo (up to 30 trucks).
  - IFTA is included.
  - Month to month. No hardware lock-in, no setup fee, free migration.
  - V2 ELD at about $20 per truck per month with no contract (target).
- **Example:** A 5-truck fleet on a seat-based TMS (2 seats × $99) that also pays an IFTA filing service (not priced in this pass) moves to HaulDesk Fleet at $99/mo. It saves at least about $1.2k/yr on TMS alone, and stops the 3–7% yearly increases and per-broker EDI setup fees.

## Go-to-market (first 100 customers)
- **OOIDA (Owner-Operator Independent Drivers Association):** Land Line magazine and radio ads, plus an OOIDA member discount.
- **Communities:** r/Truckers, r/FreightBrokers (for broker-side fraud-check buzz), TruckersReport.com forums, and trucking Facebook groups (many of them Punjabi, Russian/Ukrainian and Spanish-language). Localize the UI into those languages as a wedge.
- **New-authority outreach:** FMCSA publishes new MC authority grants daily. Reach new carriers in their first 30 days before they sign ELD contracts.
- **Factoring partners:** Factoring companies (OTR Solutions, RTS, TAFS and others) want clean packets. Pitch a referral deal or a white-label packet builder.
- **Trade shows:** Mid-America Trucking Show (Louisville, spring) and GATS (Dallas, Aug).
- **SEO/content:** "IFTA calculator," "cancel Samsara contract," "Motive cancellation," and "DAT alternative," published before each IFTA deadline (Oct 31, Jan 31, Apr 30, Jul 31).

## Risks and incumbent moats
- **ELD certification and hardware.** The MVP avoids this by importing from any ELD; the self-certified ELD comes in V2.
- **Load-board network effects.** We integrate with load boards instead of replacing them.
- **Free TMS bundled by factoring companies.** We differentiate on the IFTA, fraud-check and contract-escape tools. Partner with factors where possible.
- **Freight-recession budgets.** Keep a free tier for IFTA calculations and upsell later.
- **IFTA accuracy liability.** Show calculations transparently. The carrier files and signs; we prepare.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 5 | 3 | 3 | 4 | 4 | **19** |

## Sources
- [Small Fleet HQ: DAT Load Board Review 2026 (prices verified Sep 10 2026)](https://smallfleethq.com/reviews/dat-load-board)
- [BestCarrierTMS: Carrier TMS pricing guide (May 2026)](https://bestcarriertms.com/tms-pricing-guide.php)
- [BBB: Samsara complaints (Dec 2025–Aug 2026 entries)](https://www.bbb.org/us/ca/san-francisco/profile/electronics-and-technology/samsara-1116-881058/complaints)
- [TruckersReport forum: "Motive cancelled" (Mar–Jun 2024)](https://www.thetruckersreport.com/truckingindustryforum/threads/motive-cancelled.2503764/)
- [Small Fleet HQ: Motive vs Samsara ELD](https://smallfleethq.com/elds/motive-vs-samsara)
- [Airpinpoint: Samsara vs Motive (2026) pricing and contracts](https://airpinpoint.com/compare/samsara-vs-motive)
