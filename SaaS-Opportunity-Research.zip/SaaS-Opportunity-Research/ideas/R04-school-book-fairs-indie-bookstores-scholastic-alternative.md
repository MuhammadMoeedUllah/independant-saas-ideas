# OpenBookFair: a better Scholastic Book Fairs for PTAs/PTOs, run with local independent bookstores

**One-liner:** An online-plus-in-person book fair platform. A local indie bookstore supplies and sells the books, and the PTA gets a branded fair site with:
- age-banded, school-configurable curation, with no toy aisle;
- parent pre-loaded e-wallets with spending caps and optional title preferences;
- teacher wish lists;
- a "every kid gets a book" donation pool;
- **cash** profit paid out to the school.

## Snapshot
- **Replaces:**
  - **Scholastic Book Fairs**, the near-monopoly: **FY2024 book fair revenue was $541.6M**, more than half of Scholastic's children's publishing segment, and schools earned **$200M+ in cash and credits** ([Wikipedia/Scholastic filings](https://en.wikipedia.org/wiki/Scholastic_Corporation)). Scholastic targeted **about 90,000 fairs in FY2025** (Q3 FY25 call, Mar 20 2025) ([MarketBeat transcript](https://www.marketbeat.com/earnings/reports/2025-3-20-scholastic-co-stock)).
    - School earnings, as posted for the 2026–27 fair year:
      - **30% in Scholastic Dollars** under $1,700 in sales;
      - **40%** at $1,700–$3,999;
      - **50%** at $4,000+;
      - or **25% cash** at every tier.

      ([Scholastic Dollars page](https://bookfairs.scholastic.com/content/fairs/hub/scholastic-dollars.html))
    - Scholastic Dollars are spendable only in Scholastic's catalog, and bonus rewards expire after 6 months.
  - **Literati** (the main challenger): 25% cash or 30% in Titlewave credit, plus a volunteer discount (as of Nov 2023) ([Substack comparison](https://nicolevbennett.substack.com/p/book-fair-comparison-literati-vs)). Trustpilot rating 4.3★ from 61 reviews, 2026 ([Trustpilot](https://ca.trustpilot.com/review/literati.com)).
  - **Others:** Barnes & Noble in-store fairs (gift card or cash, with a minimum), Barefoot Books (20% in Barefoot Bucks), BookFair.org (online-only, 15–25%), and regional firms at about 15–20% (WeAreTeachers, Feb 2024) ([WeAreTeachers](https://www.weareteachers.com/book-fair-companies/)).
  - **Indie bookstore fairs:** for example Hicklebee's (San Jose) paid "about 20% in cash for a fair selling $4K–10K" (parent reports on Berkeley Parents Network; older posts) ([BPN](https://www.berkeleyparentsnetwork.org/recommend/arts/books-school)).
- **Recent price hikes / changes (switching windows):**
  - **Oct 2023 content-collection controversy.** Scholastic moved about 30 diversity-themed titles into an optional "Share Every Story, Celebrate Every Voice" collection that schools could leave out, citing laws in 30+ states. It reversed on **Oct 25 2023** after backlash ([NPR](https://www.npr.org/2023/10/17/1206219484/scholastic-book-fair-diversity-book-bans), [Wikipedia](https://en.wikipedia.org/wiki/Scholastic_Corporation)).
  - Both sides lost trust. Some Texas districts and schools (Grapevine-Colleyville ISD, Lorena ISD, some Keller ISD schools) switched to Literati, I55 or SkyTree, one saying Scholastic "refused to provide a list of titles" ([Texas Scorecard](https://texasscorecard.com/state/texas-schools-drop-woke-scholastic-book-fairs/)).
  - **Texas HB 900 and SB 13** now require board approval and public listing of *library* materials ([TEA](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials)). Fair purchases are family purchases, not library acquisitions, but many PTAs want a pre-published title list to avoid controversy (inference).
  - Scholastic management says **pressure on families' discretionary spending** is lowering participation (Q3 FY25 call) ([MarketBeat](https://www.marketbeat.com/earnings/reports/2025-3-20-scholastic-co-stock)).
- **Who buys:**
  - **PTA/PTO book fair chairs** (volunteers) and school librarians. They schedule one or two fairs a year and decide in one meeting.
  - The **supply-side partner** is the local indie bookstore owner.
- **US market size:**
  - About 90,000 Scholastic fairs a year and $541.6M in fair revenue, so an average fair sells about **$6,000** (derived estimate).
  - Estimate: about 99k public plus about 30k private K-12 schools (NCES, commonly cited; verify).
  - Supply side: estimate of about 2,500+ ABA member independent bookstores (verify with ABA).
- **Urgency trigger (why they'd switch NOW):**
  - Fall fairs are booked Aug–Oct and spring fairs Jan–Mar.
  - Chairs rotate every year, and each new chair re-evaluates.
  - Scholastic Dollars are illiquid versus cash.
  - The inequity story (kids with no money).
  - PTAs want to avoid content controversy in either direction.
- **Fastest-selling states/metros:** Suburbs with strong indie bookstores and high PTA fundraising: the Bay Area, Seattle, Portland, Denver/Boulder, Twin Cities, Chicago North Shore, NJ/NY suburbs, Boston, Austin and DFW, and Northern Virginia. In TX and FL, "pre-published title list" demand is high.

## Pain points (evidence)
- **[Price]** Scholastic pays only **25% in cash**. The 30–50% rewards come as Scholastic Dollars restricted to its own catalog, and bonus rewards expire in 6 months ([Scholastic](https://bookfairs.scholastic.com/content/fairs/hub/scholastic-dollars.html)).
  - A parent who compared fairs noted that taking cash and buying elsewhere narrows the gap to Literati to 5 points (Nov 2023) ([Substack](https://nicolevbennett.substack.com/p/book-fair-comparison-literati-vs)).
- **[Price]** A student op-ed says fair items are "exorbitantly overpriced". A parent spent **$70 on 5 items**, while the same amount bought 200+ used books at a library sale (The Central Trend, Mar 2023) ([Central Trend](https://thecentraltrend.com/112815/opinion/scholastic-book-fairs-how-the-inequalities-outweigh-nostalgia/)).
- **[Missing features / Equity]** A Romper writer saw kids "hanging off to the side" and children leaving items at the register for lack of money. She calls the fair "a nightmare if you didn't have money" and "a corporation raking in millions off the work of volunteers" (Romper, 2023, updated Feb 2024) ([Romper](https://www.romper.com/life/scholastic-book-fair-school-equity-sponsor)).
- **[Complexity/UX]** A parent called the "tchotchkes" a major distraction. An estimated 73% of Literati sales went to books versus fewer at Scholastic, which also stocks pricier hardcovers (Nov 2023) ([Substack](https://nicolevbennett.substack.com/p/book-fair-comparison-literati-vs)).
- **[Complexity/UX]** Parents complain that many titles are TV and toy tie-ins and that toys are "the big hit" ([BPN](https://www.berkeleyparentsnetwork.org/recommend/arts/books-school)).
- **[Lock-in]** Well-funded schools pile up thousands in store credit and run bigger, more profitable fairs, while poorer schools can't. The rewards system reinforces the gap (Central Trend, Mar 2023) ([Central Trend](https://thecentraltrend.com/112815/opinion/scholastic-book-fairs-how-the-inequalities-outweigh-nostalgia/)).
- **[Trust / Content]** In 2023 authors and educators accused Scholastic of "caving to censorship" over its opt-out collection ([NPR](https://www.npr.org/2023/10/17/1206219484/scholastic-book-fair-diversity-book-bans)). A Texas district said Scholastic "refused to provide a list of titles" in advance ([Texas Scorecard](https://texasscorecard.com/state/texas-schools-drop-woke-scholastic-book-fairs/)). Both sides want transparency.
- **[Support/UX, challenger]** A Literati customer in 2026 found the gift card system confusing and the website laggy, and preferred Scholastic ([Trustpilot](https://ca.trustpilot.com/review/literati.com)). The challenger's e-wallet is still a weak spot.
- **[Price, indie trade-off]** Parents who used indie stores praised the curation, but one reported that a Books Inc. fair made "less than half" of typical Scholastic revenue (2007). Scholastic kept winning on returns and convenience ([BPN](https://www.berkeleyparentsnetwork.org/recommend/arts/books-school)).
- *Evidence gap:* r/PTA and r/Parenting are blocked from this environment. Pull recent threads manually.

## What we build (the better version)
1. **MVP: Fair site in 10 minutes.** A school-branded page with dates, volunteer sign-ups, a flyer generator, and QR codes for take-home flyers in English and Spanish.
2. **MVP: Bookstore-powered catalog.**
   - The partner indie store uploads its fair inventory (CSV/ISBN, or a sync from Square or IndieCommerce/Bookmanager where possible).
   - We enrich it with covers, age bands and descriptions from open metadata.
   - The PTA selects **curation settings**: grade bands, a books-only or small-extras toggle, a price-point mix (a target share under $10), and a **pre-published title list** the school can review before the fair.
   - The school's policy stays the school's decision. We don't judge content.
3. **MVP: Parent e-wallet with controls.**
   - Pre-load funds with a spending cap.
   - Optional "check with me first" or "only from this list" preference per child, set by the parent (neutral: a parent-level setting, never a school-wide filter).
   - Receipt emails.
   - This fixes the gift-card confusion complaint made against Literati.
4. **MVP: Teacher wish lists and an "every kid gets a book" pool.** Families and local sponsors fund a pool, and every child without money gets a voucher that looks identical to anyone else's at checkout. This addresses the inequity complaint and matches Scholastic's "Share the Fair" feature.
5. **MVP: Online fair** (two weeks around the in-person dates), shipped to school or home by the bookstore, plus **mobile POS for the in-person fair** (Stripe Terminal/Tap to Pay). Volunteers see e-wallet balances. End-of-day reconciliation.
6. **MVP: Cash payout ledger.** Transparent split per sale: bookstore revenue, school cash, platform fee. Automatic payout to the PTA's bank account, and a treasurer report (PTAs need clean books for 990s and audits).
7. **V2: Bookstore dashboard.** Multi-school fair calendar, inventory kits, returns tracking, reorder of best sellers, and author-visit booking.
8. **V2: Scholastic-free "no-bookstore-nearby" mode.** Drop-ship from a wholesaler partner for rural schools, with a smaller cash share.
9. **V2: Bridges to R01 and R02.** Library-approved "wish list for our library" purchases, and a read-a-thon (R02) whose prizes are fair vouchers.

## Pricing to win
- **Free for PTAs.**
- **Bookstores pay 3% of fair GMV** plus card processing (or $99/fair flat for fairs under $3k).
- Target school share: **25–30% in cash** (versus Scholastic's 25% cash or 30–50% in Scholastic Dollars). The bookstore sets the rate; we recommend a floor of 25% cash.
- Worked example for a $6,000 fair (an estimate at about the Scholastic average):
  - The school gets **$1,500–$1,800 cash**, versus $1,500 cash or $3,000 in Scholastic Dollars.
  - The indie store grosses about $6,000, pays about $3,300–$3,600 cost of goods (estimate at a typical 40–45% trade discount), gives $1,500–$1,800 to the school, and pays $180 to us. The store margin is thin (estimate: $600–$1,000 before labor). The pitch to stores is customer acquisition (new families), not fair profit.
- **Honest caveat:** in pure dollars, Scholastic's 50% credit tier beats any cash offer. We win on **cash**, curation, no toys, equity tools and local-bookstore support, not on nominal percentage.

## Go-to-market (first 100 customers)
- **Supply first (bookstores):**
  - ABA (American Booksellers Association) and regional associations: NAIBA, NEIBA, SIBA, MPIBA, PNBA, NCIBA/SCIBA, GLIBA, MIBA.
  - Their fall trade shows (Sep–Oct) and the ABA Winter Institute.
  - Recruit 10 bookstores that already run school fairs. Each brings 5–20 schools.
  - Pitch: "Run 3x more fairs with the same staff."
- **Demand (PTAs):**
  - PTO Today: its forums, the "book fair alternatives" newsletter and the PTO Today Expo.
  - State PTA conventions.
  - Local parent Facebook groups in target metros.
  - "Scholastic book fair alternative", "book fair with no toys", "book fair cash profit" and "Scholastic Dollars vs cash calculator" SEO pages.
  - Chair-to-chair referral: $100 in free books for the school.
- **School librarians:** AASL and state school library conferences (shared with R01). The pitch is a pre-published list, a librarian wish list, and no trinkets.
- **Timing:** recruit bookstores in Oct–Nov and book spring fairs (Feb–Apr) now.

## Risks and incumbent moats
- **Scholastic's scale and convenience.** It supplies roll-in cases, trained reps, exclusive paperback editions, and 50% credit that libraries rely on. *Mitigation:* target PTAs who want cash, no toys and local stores. Accept a niche of mid- and high-income suburbs first.
- **Literati already occupies the "better fair" position**, with well-reviewed setup and Titlewave credit. *Mitigation:* differentiate on local bookstores, the online-first e-wallet with parent controls, and the equity pool. Or consider partnering as software for regional fair companies.
- **Unit economics for bookstores are thin.** Physical logistics are hard: kits, returns, staffing. *Mitigation:* we are software, not inventory. Bookstores choose which schools and when. The online fair cuts handling.
- **Payments and money transmission.** Pre-loaded e-wallets can look like stored value. *Mitigation:* the bookstore is merchant of record, so wallets are store credit with that merchant, via Stripe Connect. Legal review of state gift-card and escheat rules is needed.
- **Content controversy.** *Mitigation:* the school sees the title list ahead of the fair, and parents set their own child's preferences. We never curate by ideology. Publish the neutrality policy (same as R01).

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 2 | 3 | 3 | 4 | **15** |

## Sources
- [Scholastic Dollars and earnings tiers (Scholastic Book Fairs)](https://bookfairs.scholastic.com/content/fairs/hub/scholastic-dollars.html)
- [Scholastic Q3 FY2025 earnings call transcript (MarketBeat, Mar 2025)](https://www.marketbeat.com/earnings/reports/2025-3-20-scholastic-co-stock)
- [Scholastic Corporation (Wikipedia: FY24 fair revenue, 2023 reversal)](https://en.wikipedia.org/wiki/Scholastic_Corporation)
- [U.S. book bans are taking a toll on Scholastic Book Fairs (NPR, Oct 2023)](https://www.npr.org/2023/10/17/1206219484/scholastic-book-fair-diversity-book-bans)
- [Texas schools drop Scholastic book fairs (Texas Scorecard)](https://texasscorecard.com/state/texas-schools-drop-woke-scholastic-book-fairs/)
- [Book Fair Comparison: Literati vs Scholastic (Substack, Nov 2023)](https://nicolevbennett.substack.com/p/book-fair-comparison-literati-vs)
- [Literati reviews (Trustpilot, 2026)](https://ca.trustpilot.com/review/literati.com)
- [12 Best Book Fair Companies (WeAreTeachers, Feb 2024)](https://www.weareteachers.com/book-fair-companies/)
- [Book fairs recommendations (Berkeley Parents Network)](https://www.berkeleyparentsnetwork.org/recommend/arts/books-school)
- [How to make sure every kid can buy a book (Romper, updated Feb 2024)](https://www.romper.com/life/scholastic-book-fair-school-equity-sponsor)
- [Scholastic Book Fairs: inequalities outweigh nostalgia (The Central Trend, Mar 2023)](https://thecentraltrend.com/112815/opinion/scholastic-book-fairs-how-the-inequalities-outweigh-nostalgia/)
- [Read-A-Thon: book fair alternatives](https://www.read-a-thon.com/solutions/book-fair-alternatives)
- [TEA: SB 13 requirements (Aug 2025)](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials)
