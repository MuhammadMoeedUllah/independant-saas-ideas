# Coursehouse: a cheaper, better Kajabi / Teachable / Circle for solo creators and coaches

**One-liner:** Courses, community, checkout and email in one place for a flat $49–99/mo. 0% platform fees, unlimited contacts, free data export and white-glove migration from Kajabi or Teachable.

## Snapshot
- **Replaces:**
  - **Kajabi** (Ruzuku, May 22, 2026, updated Aug 31, 2026), monthly prices:
    - Kickstarter $89 → **eliminated**
    - Basic $149 → **$179** (+20%)
    - Growth $199 → **$249** (+25%)
    - Pro $399 → **$499** (+25%)
    Basic's contact limit fell from **10,000 to 2,500 (−75%)**.
  - **Teachable** (Erika Friday, Jun 2, 2025): new plans from Jun 2, 2025, applied at renewals on or after Jun 29, 2025. Product limits were cut roughly in half.
    - Starter $29–39/mo + **7.5% transaction fee**
    - Builder $69–89
    - Growth $139–189
    - Advanced $309–399
  - **Circle** (SchoolMaker, updated Sept 10, 2026). **No free plan.** Stripe fees come on top of these.
    - Professional $89 annual / $129 monthly + **2% transaction fee**
    - Business $199/$219 + 1%
    - Enterprise $419/$499 + 0.5%
  - **Thinkific, Mighty Networks and Skool**: tiered or flat plans, not re-verified in this pass (verify before publishing comparisons).
- **Recent price hikes / changes:**
  - **Kajabi raised prices 20–25% for all existing customers** from their first billing on or after **Jan 13, 2026**, with **no grandfathering**, and cut Basic's contacts 75%.
  - **Teachable restructured in June 2025**: higher prices, half the product limits, and a 7.5% fee on Starter.
- **Who buys:** solo course creators, coaches, consultants, fitness and yoga instructors, B2B trainers, and paid-community owners earning roughly $1k–50k/mo. The buyer is the creator, paying with a card and deciding in days.
- **US market size:** rough estimate, unverified. Tens of thousands to low hundreds of thousands of paying US accounts across Kajabi, Teachable, Thinkific, Circle, Mighty and Skool. The dollar pool is high because average spend is $150–500/mo.
- **Urgency trigger (why they'd switch NOW):**
  - Kajabi's Jan 13, 2026 hike is hitting renewals through the year, and annual renewals keep landing through Jan 2027.
  - Kajabi Basic users with more than 2,500 contacts are forced up to $249.
  - Teachable renewals under the June 2025 structure, and its 7.5% Starter fee.
- **Fastest-selling states/metros:** no state-law driver. Creator density is highest in CA (LA, SD, Orange County, where Kajabi is based), TX (Austin, Dallas), FL (Miami, Tampa), NY, and UT and AZ (coaching and MLM-adjacent creator hubs).

## Pain points (evidence)
- **[Price]** Kajabi raised every plan 20–25%, killed the $89 tier and gave legacy customers no grandfathered pricing, effective on billing from Jan 13, 2026 (Ruzuku analysis, 2026) ([source](https://www.ruzuku.com/learn/articles/kajabi-2025-price-increase))
- **[Price]** Kajabi cut the Basic plan's contact limit from 10,000 to 2,500, which pushes list-heavy creators up a tier (Ruzuku, 2026) ([source](https://www.ruzuku.com/learn/articles/kajabi-2025-price-increase))
- **[Price]** A Teachable user reacting to the 2025 change: going "from $249/mo to $399/mo... and for half the courses" (Erika Friday, Jun 2, 2025) ([source](https://www.erikafriday.com/blog/teachable-pricing-increase-2025-how-does-it-compare-to-kajabi-now))
- **[Price]** Another Teachable user saw their bill go "from $1000/yr to $3100/yr", and many said they planned to migrate (Erika Friday, Jun 2, 2025) ([source](https://www.erikafriday.com/blog/teachable-pricing-increase-2025-how-does-it-compare-to-kajabi-now))
- **[Lock-in/Contracts]** A departing Kajabi customer was charged **$179 to retrieve their own client data** (Trustpilot, Jul 2, 2026) ([source](https://www.trustpilot.com/review/kajabi.com))
- **[Missing features]** Kajabi changed a creator's sender domain without notice, and open rates fell from about 30% to 7–10% (Trustpilot, Aug 21, 2026) ([source](https://www.trustpilot.com/review/kajabi.com))
- **[Lock-in/Contracts]** A Kajabi creator's members kept being charged after they cancelled, hurting the creator's reputation (Trustpilot, Jun 17, 2026) ([source](https://www.trustpilot.com/review/kajabi.com))
- **[Price]** A prospective user was charged $167 on email verification during what was billed as a 14-day trial (Trustpilot, Jul 23, 2026) ([source](https://www.trustpilot.com/review/kajabi.com))
- **[Support]** Kajabi's AI support "pretended" someone was working on the problem, then sent a satisfaction survey (Trustpilot, Sept 19, 2025) ([source](https://www.trustpilot.com/review/kajabi.com))
- **[Complexity/UX]** A Kajabi user calls the platform "too old, too slow and soooo difficult and unlogical" (Trustpilot, Dec 2, 2025). Kajabi is rated **3.5/5 across 2,342 reviews** ([source](https://www.trustpilot.com/review/kajabi.com))
- **[Price]** Circle has no free plan, and its 0.5–2% platform fee stacks on Stripe's roughly 2.9% + $0.30, so the "fees stack up fast" (SchoolMaker, Sept 10, 2026) ([source](https://schoolmaker.com/blog/circle-so-pricing))

## What we build (the better version)
1. **Course builder:** modules, lessons, drip schedules, quizzes and certificates, with video on Mux or Bunny Stream (adaptive and DRM-lite) and PDFs. **MVP**
2. **Checkout in the creator's own Stripe with 0% platform fee:** one-time, subscriptions, payment plans, coupons, order bumps, upsells and free trials. **MVP**
3. **Community spaces:** feed, comments, events and DMs, attached to courses. **MVP** basic. Gamification, leaderboards and level unlocks (Skool-style) are **V2**.
4. **Email broadcasts and simple automations** sent from the creator's **own authenticated domain** (SPF/DKIM guided setup). We never silently switch the sender. **MVP**. The visual automation builder is **V2**.
5. **Unlimited contacts on every plan.** Email volume above 50k/mo is billed at cost. **MVP**
6. **Landing and sales pages** with AI copy from the course outline, plus a custom domain. **MVP**
7. **White-glove migration:** import from Kajabi, Teachable and Thinkific (course structure, videos by URL or bulk upload, members CSV with course access). Stripe subscriptions carry over when the creator used their own Stripe; otherwise it's a guided card re-collection campaign. **MVP**
8. **Free, instant full data export** (members, purchases, progress, content). **MVP**
9. **Mobile:** installable PWA with push notifications. **MVP**. Branded iOS and Android apps are **V2**.
10. **Live sessions and calendar** (Zoom and Google Meet links, replays auto-posted). **V2**
11. **Affiliate program** (tracked links, commissions, payouts report). **V2**
12. **AI course assistant** that answers student questions from lesson transcripts and escalates to the creator (reuses A05). **V2**
13. **Built-in forms and booking** for coaching calls and applications (reuses A01 and A02). **V2**

## Pricing to win
- **Creator $49/mo:** unlimited courses, products and contacts, 0% fees, community, email up to 50k sends/mo.
- **Pro $99/mo:** adds automations, affiliates, 3 admins, priority migration, and email up to 250k sends/mo.
- Month-to-month, 20% off annual (no forced annual), migration free, export always free.
- **Savings:** Kajabi Growth ($249 monthly billing) to Pro ($99) saves **$1,800/yr**; on Kajabi's annual billing (Growth $199/mo) the gap is about $1,200/yr. Kajabi Basic with more than 2,500 contacts, forced to $249, to Creator ($49) saves **$2,400/yr**. Teachable Growth ($189 monthly) to Pro ($99) saves **about $1,080/yr**, plus no 7.5% Starter fee.

## Go-to-market (first 100 customers)
- **"Kajabi price increase" landing page** with a live savings calculator (plan + contacts, showing what you pay now vs. with us) and "we migrate you in 72 hours free".
- **SEO:**
  - "Kajabi price increase 2026"
  - "Kajabi alternative cheaper"
  - "Kajabi contact limit 2,500"
  - "leave Teachable 7.5% fee"
  - "Circle transaction fee alternative"
  - "export data from Kajabi"
- **Communities:** r/Entrepreneur, r/juststart, r/sidehustle, r/elearning, r/Coaching, r/personaltraining and r/yoga (teacher-business threads), plus creator Facebook groups about online courses and coaching businesses. Verify niche platform subreddits before posting.
- **Partners:** freelance "Kajabi experts" and course-launch agencies (30% recurring referral plus paid migration gigs), YouTube reviewers of course platforms (affiliate), and creator podcasts.
- **Direct:** find creators whose sites are on Kajabi (mykajabi.com subdomains or Kajabi-hosted checkout) and email them a personalized savings estimate before their renewal.

## Risks and incumbent moats
- **Payment lock-in.** Subscriptions on Kajabi Payments can't be moved without card re-entry. Mitigate with a guided re-collection campaign, overlap months and grandfathering incentives. Easy when the creator used their own Stripe.
- **Video hosting costs.** Pass heavy video through Mux or Bunny at-cost tiers, and cap included storage and bandwidth fairly.
- **Email deliverability.** Enforce the creator's own domain, warm-up guidance and list hygiene.
- **Expected feature breadth** (apps, funnels, podcasts). Keep MVP focused on course + checkout + community + email, and ship branded apps in V2.
- **Network effects** (Skool discovery, Circle brand). Most creators bring their own audience, so a marketplace isn't needed at MVP.
- **Creator churn** (launch-cycle businesses). Offer an annual discount and low-usage "pause" pricing to keep them.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 5 | 3 | 5 | 3 | **20** |

## Sources
- [Kajabi Price Increase 2026: The Math by Plan and Tenure – Ruzuku](https://www.ruzuku.com/learn/articles/kajabi-2025-price-increase) (May 22, 2026, updated Aug 31, 2026)
- [Kajabi on Trustpilot](https://www.trustpilot.com/review/kajabi.com) (3.5/5, 2,342 reviews)
- [Teachable Pricing Increase 2025 – Erika Friday](https://www.erikafriday.com/blog/teachable-pricing-increase-2025-how-does-it-compare-to-kajabi-now) (Jun 2, 2025)
- [Circle.so Pricing 2026 – SchoolMaker](https://schoolmaker.com/blog/circle-so-pricing) (updated Sept 10, 2026)
- [12 Best Kajabi Alternatives for Course Creators (2026) – Circle Blog](https://circle.so/blog/kajabi-alternatives)

## Verification (Sep 24 2026)
- ✅ Kajabi Basic $149→$179, Growth $199→$249, Pro $399→$499, Kickstarter $89 eliminated, effective first billing on or after Jan 13 2026 with no grandfathering — confirmed verbatim ([source](https://www.ruzuku.com/learn/articles/kajabi-2025-price-increase))
- ✅ Basic contacts cut 10,000 → 2,500 — confirmed by Ruzuku and by Kajabi's own page (Basic 2,500 contacts, 5 products) ([source](https://kajabi.com/pricing))
- ✅ Kajabi current prices $179/$249/$499 monthly — confirmed; annual billing is $143/$199/$399, so the Growth-to-Pro saving is ~$1,200/yr on annual billing (note added) ([source](https://kajabi.com/pricing))
- ✅ Teachable new plans from Jun 2 2025, applied at renewals on or after Jun 29 2025, Starter $29–39 + 7.5% fee, user quotes — confirmed ([source](https://www.erikafriday.com/blog/teachable-pricing-increase-2025-how-does-it-compare-to-kajabi-now))
- Scores unchanged.
