# ClaimKit: a cheaper field-documentation and supplement tool that sits beside Xactimate for restoration and insurance roofing contractors

**One-liner:** Photo, moisture and scope documentation plus an AI supplement writer that turns field evidence into carrier-ready line-item requests. Flat-priced with unlimited users, as a cheaper alternative to stacking CompanyCam, Encircle and DocuSketch on top of Xactimate.

## Snapshot
- **Replaces / sits beside:**
  - **Xactimate (Verisk)**, as verified Aug 7 2026: Pro is $350 for 1 month, $880 for 3 months, $1,725 for 6 months, or $2,690 for 12 months. Standard is $1,575 for 6 months or $2,390 for 12 months. It allows a single login at a time and is Windows-centric ([Fervor Studio, Aug 7 2026](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).
  - **CompanyCam** (annual billing, checked Sep 24 2026): Core $63/mo for 1 user, Crew $129/mo for 3 users, Scale $199/mo for 3 users. Every extra user is $29/mo. Marketing Suite is $79/mo ([CompanyCam pricing](https://companycam.com/pricing)).
  - **Encircle** and Cotality Claims Connect are quote-only ([Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)). DocuSketch was not priced in this pass.
  - **Roofing CRMs** such as JobNimbus still require a separate Xactimate seat ([Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).
- **Recent price hikes / changes:**
  - No dated Xactimate list-price hike was confirmed in this pass.
  - The ongoing pain is that carriers pay scopes based on Xactimate price lists and routinely reject overhead and profit (O&P), which pushes contractors to supplement.
  - CompanyCam's $29-per-user model scales costs up as crews grow.
- **Who buys:** The owner, estimator or project manager at a water/fire/mold restoration firm or an insurance-focused roofing/exteriors contractor with 3–50 staff.
- **US market size:** Not sized from a primary source in this pass. A rough estimate is tens of thousands of restoration and insurance-roofing firms. Cross-check against IICRC-certified firm counts and Census NAICS 562910 and 238160 in the per-state pass.
- **Urgency trigger (why they'd switch NOW):**
  - Catastrophe events such as hurricanes, hail and freezes, when documentation volume spikes and new techs need seats immediately.
  - Supplement denials on open claims (money left on the table).
- **Fastest-selling states/metros:** An inference based on catastrophe-exposed markets: FL and the Gulf Coast (hurricanes), TX, OK and CO (hail), plus the Upper Midwest and Northeast (freeze and water losses).

## Pain points (evidence)
Six direct complaints were found in this pass, plus two pricing-structure pains.
- **[Price/Lock-in]** Xactimate is "very expensive" and allows only one login at a time (Software Advice reviewer, via [Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).
- **[Missing features]** Logging in on one device logs you out on another, and switching can take half an hour because the software freezes (Google Play user, via [Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).
- **[Price/Payment]** An 11–50-person contractor says carriers pay scopes based only on Xactimate pricing and decline its O&P about 85% of the time (Software Advice, via [Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).
- **[Complexity]** Xactimate works only on Windows, and the iPad option isn't helpful for everyone (Software Advice, via [Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).
- **[Price/Complexity]** Verisk charges for training on the system, which a reviewer calls the "most non user friendly system" (Software Advice, via [Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).
- **[Support]** A 51–200-person contractor says system upgrades broke features and locked them out of jobs, and support took 2–4 days (Software Advice, via [Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).
- **[Price]** CompanyCam's per-seat model: a 10-person crew on the Crew plan pays $129 + 7×$29 = $332/mo billed annually, before the $79 marketing add-on ([CompanyCam pricing](https://companycam.com/pricing)).
- **[Price]** Tool stacking: a roofing CRM plus a separate Xactimate seat plus photo documentation means paying three vendors for one claim workflow ([Fervor Studio](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)).

## What we build (the better version)
1. **MVP:** Photo and video capture by room and elevation, with automatic tagging (AI labels such as "water line at 14 in.", "hail bruise", "missing shingle"), timestamps and GPS. Unlimited users.
2. **MVP:** Moisture mapping and drying logs: daily readings per material, equipment placed and removed (dehumidifiers, air movers), and a drying chart for IICRC S500-style documentation.
3. **MVP:** **AI supplement writer.** Compare the carrier's estimate (PDF upload) with our field evidence and draft a line-item supplement letter that cites the photos, measurements and code items. Export as PDF, and as ESX where partners allow.
4. **MVP:** Claim tracker: carrier, adjuster, claim number, deductible, approvals, supplement status, and depreciation to recover.
5. **MVP:** Homeowner portal with e-sign on the work authorization and a certificate of completion, plus SMS updates.
6. **MVP:** Room sketch from phone LiDAR or manual dimensions to a floor plan PDF. Deeper integration comes in V2.
7. **V2:** O&P justification builder (lists the trades on the job and generates a coordination narrative).
8. **V2:** Contents inventory (pack-out) with photo-to-line-item AI.
9. **V2:** Integrations with Xactimate (via XactAnalysis where permitted), JobNimbus, AccuLynx, and StormDesk (C02).

## Pricing to win
- **Our prices:** $149/mo flat with unlimited users and jobs, supplement writer included. Or $99/mo documentation-only. Month-to-month.
- **Example savings:** The 10-person crew from above pays $332/mo for CompanyCam Crew. With us it pays $149/mo, saving about $2.2k a year. That is before supplement wins, which is the real ROI pitch: one recovered O&P line on a single claim can cover a year of the subscription.
- **We do not replace Xactimate.** Contractors keep the seat carriers require.

## Go-to-market (first 100 customers)
- **Associations:** RIA (Restoration Industry Association), IICRC-certified firm directories, and state restoration and roofing associations.
- **Trade shows:** The Experience (RIA) and IRE (for insurance roofers). Supplement-focused workshops.
- **Reddit:** r/Roofing, r/Construction, r/sweatystartup. Post "adjuster denied O&P: here's the doc package that got it paid" content.
- **Partners:** Supplement-writing services and public adjusters. White-label the supplement writer for them.
- **Catastrophe-response ads:** Geo-targeted to restoration firms and roofers in NOAA-declared event areas within 48 hours.
- **SEO pages:** "CompanyCam alternative unlimited users", "Xactimate supplement template", "how to get O&P paid".

## Risks and incumbent moats
- **Verisk's carrier network is the real moat.** Carriers expect Xactimate estimates, so we deliberately complement rather than replace it.
- **ESX export and import rights** may be restricted. MVP outputs are PDF-first.
- **AI accuracy on supplements.** A human reviews every draft, and each line item cites its evidence.
- **Regulation.** Several states restrict contractors from acting as public adjusters (for example Texas, per general knowledge; verify in the per-state pass), so supplement-writing must stay documentation, not negotiation.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 3 | 4 | 3 | **17** |

## Sources
- [Fervor Studio: Xactimate Review 2026 (verified Aug 7 2026)](https://fervorstudio.ca/news/xactimate-review-pricing-alternatives/)
- [CompanyCam pricing (checked Sep 24 2026)](https://companycam.com/pricing)
- [CapOut: Xactimate Pricing (Feb 5 2026; no dollar figures)](https://capout.ai/resources/blog/xactimate-pricing)
