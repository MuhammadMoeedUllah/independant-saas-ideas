# GuideLedger: a cheaper, better FareHarbor / Peek for licensed outfitters and guides in the Mountain West, with state license and federal permit paperwork built in

**One-liner:** Booking, deposits, waivers and guide rosters for hunting, fishing, rafting and pack-trip outfitters, with no guest fee. It turns every trip into the records that state outfitter boards and federal land agencies ask for: use reports, rosters, and permit fees owed by land unit.

## Snapshot
- **Replaces:**
  - **FareHarbor (Booking Holdings):** a **6% booking fee added to the guest's checkout price** in North America; rates are not published (per D07's sources, 2026: [Roverd, Jul 10 2026](https://www.roverd.com/fareharbor-review-alternatives/), [CaptainBook](https://www.captainbook.io/blog/fareharbor-pricing-fees-explained)).
  - **Peek Pro:** a customer-paid fee with no monthly base. **Rezdy:** from $99/mo ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/)).
  - The status quo for most hunting and fishing outfitters is phone, email, paper deposits, Excel rosters and hand-filled agency reports (estimate; not surveyed this pass). Hunting-outfitter-specific tools were not priced this pass (verify).
- **Recent price hikes / changes:**
  - **FareHarbor "Desk" migration (2026).** An operator called it "HORRIBLE" (Apr 2026) ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
  - **EXPLORE Act (Public Law 118-234, enacted Jan 4 2025).** Title III includes **Sec. 311, special recreation permit and fee**, and **Sec. 316, Forest Service and BLM temporary special recreation permits for outfitting and guiding** ([GovInfo](https://www.govinfo.gov/app/details/PLAW-118publ234); [law text](https://www.govinfo.gov/content/pkg/PLAW-118publ234/html/PLAW-118publ234.htm)).
  - **BLM implemented Title III updates on Feb 2 2026** "to reduce administrative barriers, streamline permit processing, and improve consistency and transparency" ([BLM Special Recreation Permits](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits)).
  - My understanding is that the permit fee is about 3% of adjusted gross receipts, with new exclusions (e.g., revenue from services on non-federal land) (verify). Either way, operators need revenue split by land unit.
  - **All-in pricing laws:** Colorado **HB25-1090** bans advertising without the maximum total price ([CO General Assembly](https://leg.colorado.gov/bills/hb25-1090)), and the FTC fee rule covers short-term lodging ([FTC](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)). Fee-on-top checkouts are a growing legal risk.
- **Who buys:** Owner-outfitters with 1–30 guides:
  - big-game hunting and drop camps
  - fly-fishing and float trips
  - whitewater rafting
  - horse pack trips
  - backcountry ski and hut trips
  - guest/dude ranches that sell guided rides and hunts

  The owner decides and pays by card. Buying is seasonal: they switch in the off-season.
- **US market size:** Estimate only.
  - Several thousand licensed outfitters across ID, MT, WY, CO and AK, plus tens of thousands of licensed guides.
  - Idaho licenses outfitters at **$400/yr** and guides at **$105** renewal ([Idaho OGLB](https://dopl.idaho.gov/oglb/)). Rosters were not counted this pass; verify with board licensee searches.
  - Market size is small, but average ticket per client is high. Hunts often run $3k–$10k+ (estimate), so deposits and payment volume are large.
- **Urgency trigger (why they'd switch NOW):**
  1. The **off-season (Dec–Mar)** follows fall hunting season, and next season's bookings and deposits open in winter.
  2. EXPLORE Act permit changes are rolling out in 2026 (BLM since Feb 2 2026), so operators must re-learn fee and reporting rules.
  3. FareHarbor Desk migration pain.
  4. Colorado HB25-1090 all-in pricing.
- **Fastest-selling states/metros:**
  - **Idaho:** Salmon, Riggins, Stanley, McCall (rafting, hunting)
  - **Montana:** Bozeman, Livingston, Missoula, Ennis (fly-fishing, hunting)
  - **Wyoming:** Jackson, Cody, Pinedale (hunting, pack trips, dude ranches)
  - **Colorado:** Buena Vista/Cañon City (Arkansas River rafting), Western Slope hunting units
  - Then Alaska and Utah (Moab)

## Pain points (evidence)
Outfitter-specific complaint threads were **not** collected this pass (no search budget). The evidence below is from the booking incumbents (reused from D07) and from the regulators' own requirements. Next pass: collect evidence from MOGA, IOGA and WYOGA member forums and hunting-outfitter Facebook groups.
- **[Price]** FareHarbor's 6% fee is added at the guest's checkout, inflating the advertised price at the last step. On a $6,000 hunt that is $360 per client ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/); [Hamza Liaqat, "The 6% Fee Math"](https://hamzaliaqat.com/blog/fareharbor-pricing-2026)). The $360 is our arithmetic.
- **[Price/Transparency]** FareHarbor doesn't publish its rates ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/)).
- **[Complexity/UX]** An operator (Apr 2026) called the new "Desk" platform "HORRIBLE" and not user-friendly ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Support]** An operator (Mar 2026) said training lasts 7 days, "then you are left." Another (Mar 2026) described 20 days of delays with the product closed to bookings ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Billing]** A reviewer (Aug 2026) said charges continued for months after cancellation ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Missing features / regulatory load]** Idaho requires **outfitter use reports**, roster requests and amendment requests. Late renewals cost a $150 penalty, and unlicensed outfitting or guiding "are a crime (IC § 36-2104)" ([Idaho OGLB](https://dopl.idaho.gov/oglb/)). Generic tour software doesn't produce these records.
- **[Missing features / regulatory load]** Federal land permits require applicants to describe participant fees, and BLM is changing permit processes under the EXPLORE Act ([BLM](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits)). Revenue has to be split by land unit and trip type, which tour tools don't track.
- **[Missing features]** Hunting outfitters juggle client draw and tag results, license numbers, horse and gear manifests and multi-day camp logistics. FareHarbor and Peek are built for timed-slot tours, not multi-day trips with tag contingencies (inference from D07 product scope).

## What we build (the better version)
1. **MVP: Trip and hunt catalog with all-in pricing.** Multi-day trips, drop camps, float days and ski-hut nights. Show the full price from the first screen, including guide gratuity guidance and lodging taxes, to satisfy CO HB25-1090 and the FTC lodging rule.
2. **MVP: Large deposits and payment plans.** 30–50% deposits, balance autopay, and draw-contingent refund rules ("full refund if you don't draw the tag"). Payments go through Stripe Connect.
3. **MVP: Client file.** Hunting/fishing license and tag numbers, draw results, firearm/archery, dietary and medical notes, and digital waivers (minor and guardian flow).
4. **MVP: Guide roster and credential tracker.** State guide license, first aid/CPR, and boat or outfitter-specific certifications, with expiry alerts and the board's roster-request data pre-filled.
5. **MVP: Trip log to agency reports.** Every completed trip records client-days by operating area and land unit (USFS, BLM, state, private). One click generates the **state outfitter use report** (starting with Idaho's format) and a **federal actual-use/post-use summary with estimated permit fee** by unit (fee formula configurable; verify current rules).
6. **MVP: Offline-first guide app.** Manifests, check-ins and incident notes work with no cell signal and sync later.
7. **MVP: Import** from FareHarbor/Peek CSVs and spreadsheets, with AI column mapping.
8. **V2:** Horse, gear and camp inventory; meal planning per manifest.
9. **V2:** Referral/booking-agent commissions (hunting booking agents), plus a sportsman's show lead-capture mode (tablet at the booth, then an instant quote).
10. **V2:** Montana and Wyoming report formats, multi-state operators, and Alaska.

## Pricing to win
- **GuideLedger:** **$0 guest fee.** $79/mo in season and **$19/mo off-season "hibernate"** (keeps data, reporting and deposit intake). A $149/mo Pro tier adds multi-unit permit reporting and booking-agent tools. Processing at Stripe cost plus a disclosed markup. No contract, free migration.
- **Savings example (estimate):** An outfitter grossing $400k/yr through FareHarbor adds about $24k in 6% fees to clients' bills. GuideLedger costs about $600–$1,000/yr on the seasonal plan. The operator can take $20k+ of pricing room, or advertise a lower all-in price, and reclaims the hours spent on agency reports.

## Go-to-market (first 100 customers)
- **State outfitter associations (verify names):**
  - Idaho Outfitters & Guides Association (IOGA)
  - Montana Outfitters & Guides Association (MOGA)
  - Fishing Outfitters Association of Montana (FOAM)
  - Wyoming Outfitters & Guides Association (WYOGA)
  - Colorado Outfitters Association
  - Colorado River Outfitters Association
  - Dude Ranchers' Association
  - America Outdoors (national outfitter trade group)

  Offer a member discount and a free "use report autopilot" webinar in Jan–Feb.
- **Sportsman shows (verify dates):** Western Hunting & Conservation Expo (Salt Lake City, Feb), The Fly Fishing Show (Denver, Jan) and regional sportsman expos. Run a booth-to-quote demo.
- **Regulator-adjacent SEO:** "Idaho outfitter use report," "Forest Service outfitter actual use report template," "BLM SRP post-use report EXPLORE Act," "FareHarbor alternative for outfitters," "hunting outfitter booking software no fee."
- **Facebook groups** for hunting outfitters, fly-fishing guides and whitewater guides. Guides move between outfitters, so the roster tool spreads through them.
- **Partners:** outfitter insurance brokers (credential tracking lowers risk) and CPAs who serve seasonal outfitters.

## Risks and incumbent moats
- **Small, seasonal market.** Mitigation: hibernate pricing keeps churn low, and expanding to guest ranches, rafting and ski-hut operators widens the pool. Same codebase as D07 BookTrail (shared core).
- **Agency formats vary** by state board, national forest and BLM field office. Mitigation: ship Idaho first (fetched requirements), make the report builder field-mappable, and treat fee math as an "estimate to verify with your permit administrator."
- **High-ticket deposits mean chargeback and fraud risk.** Mitigation: Stripe Radar, signed deposit terms, ACH for large balances.
- **OTA and booking-agent distribution** is how some hunts sell. Mitigation: V2 agent portal. Direct and repeat clients dominate in hunting (estimate).
- **Evidence gap:** outfitter-specific complaints are unverified. Validate with 15 owner interviews before building beyond the D07 core.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 4 | 3 | 2 | **16** |

## Sources
- [Idaho Outfitters and Guides Licensing Board: licenses, fees, use reports, IC § 36-2104](https://dopl.idaho.gov/oglb/)
- [BLM Special Recreation Permits: EXPLORE Act Title III updates effective Feb 2 2026](https://www.blm.gov/programs/recreation/permits-and-passes/special-recreation-permits)
- [GovInfo: Public Law 118-234, EXPLORE Act (Jan 4 2025)](https://www.govinfo.gov/app/details/PLAW-118publ234)
- [Public Law 118-234 text (Title III, Secs. 311 and 316)](https://www.govinfo.gov/content/pkg/PLAW-118publ234/html/PLAW-118publ234.htm)
- [Colorado HB25-1090 Protections Against Deceptive Pricing Practices](https://leg.colorado.gov/bills/hb25-1090)
- [FTC: Rule on Unfair or Deceptive Fees takes effect May 12 2025](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)
- [FareHarbor Review 2026 – Roverd (Jul 10 2026; competitor)](https://www.roverd.com/fareharbor-review-alternatives/)
- [FareHarbor Pricing & Fees Explained 2026 – CaptainBook](https://www.captainbook.io/blog/fareharbor-pricing-fees-explained)
- [FareHarbor Pricing 2026: The 6% Fee Math – Hamza Liaqat](https://hamzaliaqat.com/blog/fareharbor-pricing-2026)
- [FareHarbor reviews – Trustpilot](https://www.trustpilot.com/review/fareharbor.com)
