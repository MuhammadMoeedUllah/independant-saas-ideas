# LaunchShelf: a cheaper, better BookFunnel + NetGalley/Booksprout + Payhip stack for indie and self-published authors

**One-liner:** One flat-price "author HQ" that delivers ebooks and ARCs, builds and owns the reader list, runs a zero-platform-fee direct store, and tracks the ARC and launch team, replacing 3–5 separate subscriptions.

## Snapshot
- **Replaces** (prices dated):
  - **BookFunnel** (pricing page updated June 8, 2026; new plans effective **Feb 20, 2026**):
    - First-Time Author $30/yr, up from $20. It cannot collect emails and has no ARC or direct-sales delivery.
    - **Mid-List $200/yr**, previously $100/yr plus $50/yr for mailing-list integration.
    - Bestseller $300/yr, previously $250/yr.
    - Audiobook add-ons run from $2/mo plus $0.04 per delivered hour to $30/mo unlimited.
    - Existing customers are grandfathered.
    - ([BookFunnel pricing](https://www.bookfunnel.com/pricing/); [BookFunnel blog](https://blog.bookfunnel.com/2026/new-plans/); [old pricing](https://bookfunnel.com/pricing-old/))
  - **NetGalley:** the publisher pricing page could not be fetched. Secondary 2026 sources report about **$575 per title for 6 months** direct, or about $199 for 3 months via an IBPA co-op ([Read & Rate blog](https://www.readnrate.com/blog/netgalley-alternatives-indie-authors)). UK co-ops run £400–£800 ([WIPsage, May 14, 2026](https://www.wipsage.com/blog/netgalley-indie-authors-co-op-worth-it)). Treat both as secondary estimates.
  - **BookSirens:** Promote costs $10 per ARC plus **$2 per reader download**. Author plan is $100/yr for 2 pen names ([BookSirens pricing](https://www.booksirens.com/pricing)).
  - **Booksprout:** $90–$229/yr by campaign volume, per a secondary 2026 source. The pricing page did not render this pass ([Read & Rate](https://www.readnrate.com/blog/netgalley-alternatives-indie-authors)).
  - **StoryOrigin:** free Basic plan without email capture. Standard is $100/yr per Storyfinch (July 7, 2026) ([Storyfinch](https://storyfinch.app/blog/bookfunnel-alternative)); another source says $10/mo ([Read & Rate](https://www.readnrate.com/blog/netgalley-alternatives-indie-authors)).
  - **Payhip** (Sept 2026): Free plan takes 5% of sales; Plus is $29/mo plus 2%; Pro is $99/mo with no transaction fee, plus Stripe/PayPal fees on every plan ([Payhip pricing](https://payhip.com/pricing)).
  - **Kickstarter:** 5% platform fee plus 3% + $0.30 per pledge in processing ([Kickstarter fees](https://www.kickstarter.com/help/fees)).
  - **BookBub Featured Deals:** the pricing page blocks automated fetch, so current prices were **not verified** this pass. Author complaints are below.
  - **Typical stack *estimate*:** BookFunnel Mid-List $200 + BookSirens $100 + StoryOrigin $100 + Payhip Plus $348 = **about $750/yr**. That is before an email service provider, and before NetGalley at about $575 per title.
- **Recent price hikes / changes:**
  - **BookFunnel repricing (Feb 20, 2026):** the tier most authors need, with ARCs, direct-sales delivery and list integration, went from $150 to $200/yr for new signups ([BookFunnel blog](https://blog.bookfunnel.com/2026/new-plans/)).
  - **Amazon KDP print royalty cut, effective June 10, 2025:** paperbacks under $9.99 went from 60% to 50% ([Self-Publishing with Dale](https://selfpub.substack.com/p/kdp-print-royalty-change-2025-what-authors-need-to-know)). This pushes authors toward direct sales.
  - **Title flood:** Bowker counted **about 3.5M self-published ISBNs in 2025, up 38.7%**, out of 4,172,222 US ISBN titles. Commentators link the jump partly to AI ([BoSacks, Mar 18, 2026](https://www.bosacks.com/bosacks-speaks-out/bosacks-speaks-out-four-million-books-and-the-question-nobody-wants-to-ask); [Digital Publishing Report](https://digital-publishing-report.com/en/2026/massive-surge-in-self-published-titles)). Discovery gets harder, so an owned reader list is worth more.
- **Who buys:** self-published and hybrid authors, mostly genre fiction (romance, romantasy, fantasy/sci-fi, thriller, cozy mystery). The best targets earn $500–$10k+/mo. Small presses and author-services firms running several pen names also qualify. The buyer is the author, paying by card.
- **US market size:**
  - There is no authoritative count of self-published authors. Bowker reports about **3.5M self-published titles in 2025**, but titles are not authors, and the figure includes low-content and AI output.
  - Written Word Media's 2025 survey of 1,346 authors found **13% earn >$5k/mo, 20% earn $500–$5k/mo, and 44% earn ≤$100/mo** ([WWM 2025](https://www.writtenwordmedia.com/2025-indie-author-survey-results-insights-into-self-publishing-for-authors/)).
  - *Estimate:* a few hundred thousand US authors actively publish, and perhaps a third of them earn enough to pay $10–$25/mo for tools.
- **Urgency trigger (why they'd switch NOW):**
  - BookFunnel raised Mid-List for new signups on Feb 20, 2026. The base plan doubled ($100 → $200/yr), but like-for-like with list integrations it rose 33% ($150 → $200/yr). Existing customers are grandfathered, so only new signups feel it.
  - The KDP paperback royalty cut (June 2025) is pushing authors to sell direct.
  - About 30% of authors already sell direct, and about 30% of the rest plan to start within 12 months ([WWM 2025](https://www.writtenwordmedia.com/2025-indie-author-survey-results-insights-into-self-publishing-for-authors/)).
  - Q4 launch and holiday-bundle season.
- **Fastest-selling states/metros:** authors are location-independent, so buyers cluster in communities, not cities. Romance and romantasy readers and authors cluster around the romance-bookstore boom (Texas and elsewhere, see R05).

## Pain points (evidence)
- **[Price]** BookFunnel's Mid-List plan rose to $200/yr for new signups: double the old $100 base plan, or +33% versus the old $150 plan with integrations. BookFunnel cited "nearly 10 years without pricing changes" (Feb 2026) ([BookFunnel blog](https://blog.bookfunnel.com/2026/new-plans/)).
- **[Price/Missing features]** The $30 BookFunnel entry plan only delivers files; it cannot capture reader emails, so list building really starts at $200/yr. Authors also pay for audiobook, ARC and support-desk features they never use (July 7, 2026) ([Storyfinch](https://storyfinch.app/blog/bookfunnel-alternative)).
- **[Missing features]** BookFunnel has no ARC/reviewer database of its own, and its group promos give "inconsistent results" because they depend on other authors' mailing lists (Aug 13, 2026) ([Reedsy](https://reedsy.com/blog/bookfunnel/)).
- **[Price/ROI]** On NetGalley, only about a third of indie-title downloaders post reviews, which works out to $20–$50 per review (secondary, 2026) ([Read & Rate](https://www.readnrate.com/blog/netgalley-alternatives-indie-authors)). Co-op feedback rates run 5–15%, and reviews don't automatically cross-post to Amazon or Goodreads (May 14, 2026) ([WIPsage](https://www.wipsage.com/blog/netgalley-indie-authors-co-op-worth-it)).
- **[Quality]** An author paid Booksprout $19 and got 6 reviewers whose profiles showed "multiple overdue reviews" and unrealistic review counts (May 13, 2026) ([Trustpilot](https://www.trustpilot.com/review/booksprout.co)).
- **[Quality/Compliance]** A Booksprout reviewer claimed to read 10 books a day; the review looked bot-written, and Amazon deleted it (May 23, 2026). Booksprout rates **1.7/5 on 39 reviews** ([Trustpilot](https://www.trustpilot.com/review/booksprout.co)).
- **[ROI]** An author got zero Booksprout reviews after a month, while a competitor produced 14 verified reviews in a week (Apr 11, 2025). Another got no readers for Spanish-language novels (Aug 11, 2026) ([Trustpilot](https://www.trustpilot.com/review/booksprout.co)).
- **[Support]** An author paid for BookBub's New Releases email. The book appeared only in a small "see more" link, and support never replied (June 3, 2026) ([Trustpilot](https://www.trustpilot.com/review/bookbub.com)).
- **[ROI]** A BookBub author "wasted thousands" and never got a Featured Deal (May 2, 2026). Another says BookBub mostly builds free-book followers, not buyers (Aug 15, 2025). BookBub rates **2.9/5 on 2,401 reviews** ([Trustpilot](https://www.trustpilot.com/review/bookbub.com)).
- **[Price]** KDP cut paperback royalties under $9.99 from 60% to 50% (June 10, 2025) ([Dale L. Roberts](https://selfpub.substack.com/p/kdp-print-royalty-change-2025-what-authors-need-to-know)).
- **[Missing features]** Over 80% of authors call marketing "the hardest part." Authors with lists earn a median of about $300/mo versus about $15/mo without (WWM 2025) ([WWM](https://www.writtenwordmedia.com/2025-indie-author-survey-results-insights-into-self-publishing-for-authors/)).
- **[Price]** An author with eight novels is still "in the red," and authors ask for "deals on promos" (June 11, 2025) ([WWM mid-year](https://www.writtenwordmedia.com/we-asked-indie-authors-how-2025-is-going-heres-what-they-said/)).

## What we build (the better version)
1. **MVP: Book vault and secure delivery.**
   - Upload EPUB/PDF once and get branded landing pages.
   - Send-to-Kindle, Kobo, Apple and Nook walkthroughs, watermarking, and per-link download caps.
   - An AI reader help desk that answers "how do I get this onto my Kindle" around the clock. This matches BookFunnel's core feature.
2. **MVP: Built-in reader list.**
   - Reader-magnet signup pages with stored consent records, tagged by series and pen name.
   - Two-way sync to MailerLite, Kit or Mailchimp.
   - Basic newsletters included, so small authors can skip a separate email service.
3. **MVP: ARC team manager.**
   - Reader application form covering genres, where they review, and past review links.
   - Approve or waitlist readers and deliver watermarked ARCs.
   - Reviewers self-report their review links, with automatic reminders.
   - Reviewer reliability scores (downloaded vs reviewed); ghost readers drop off after N misses.
   - Built-in FTC-style disclosure text for reviewers.
   - **No paid reviews, and no conditioning on positive reviews.**
4. **MVP: Launch-team tracker.** Street-team tasks, a share kit (graphics, preorder links), a launch-day checklist, and a preorder countdown page.
5. **MVP: Direct store at 0% platform fee.**
   - Stripe checkout for ebooks, bundles, series discounts, coupons, and signed-paperback preorders.
   - Automatic delivery through the vault.
   - Stripe Tax for US sales tax and EU VAT on digital goods, or an optional merchant of record.
6. **MVP: Crowdfunding fulfillment lite.** Import a Kickstarter backer CSV, then deliver digital rewards and collect shipping addresses.
7. **MVP: AI copilot.** Drafts blurbs, ARC reminder emails, newsletters, and BookBub/promo-site submission text from the book's metadata.
8. **V2: Audiobook delivery** through a private feed or in-app player, priced at cost instead of a monthly add-on.
9. **V2: Opt-in cross-author ARC reader network.** Reviewers carry a reliability score across authors, which builds network effects against BookSirens and Booksprout.
10. **V2: Print-on-demand and special-edition fulfillment** through third-party printer APIs for signed and sprayed-edge editions (the Kickstarter trend).
11. **V2: Newsletter swaps and group promos** (StoryOrigin parity), and cross-retailer royalty dashboards.

## Pricing to win
- **Free:** 1 book, 250 deliveries/mo, list up to 500 readers.
- **Author: $12/mo or $120/yr.** Unlimited books, 3 pen names, ARC team, launch tracker, direct store at 0% platform fee (Stripe fees only), list up to 5k readers.
- **Pro: $24/mo or $240/yr.** 10 pen names, audio, Kickstarter fulfillment, AI copilot, list up to 25k.
- **Savings *estimate*:** a typical ~$750/yr stack (BookFunnel Mid-List + BookSirens + StoryOrigin + Payhip Plus) versus $120–$240/yr, so **$500–$630/yr saved**. On $1,000/mo of direct sales, Payhip Plus costs $29 + 2% = $49/mo, while LaunchShelf Author costs $12/mo with no platform cut (Stripe fees apply on both).
- No annual lock-in. We import ARC reader lists, email lists and BookFunnel landing-page assets free.

## Go-to-market (first 100 customers)
- **Communities:**
  - Alliance of Independent Authors (ALLi) partner-member discount.
  - 20BooksTo50K and similar Facebook groups (Wide for the Win, Kickstarter-for-authors groups). Verify current activity levels.
  - Self Publishing Formula / The Self Publishing Show audience, The Creative Penn (Kickstarter coverage April 2026).
  - Indie Author Magazine, and the Written Word Media blog and newsletter.
- **Conferences:** Author Nation (Las Vegas; the successor to 20Books Vegas; verify dates), NINC, and romance reader/author events where authors table.
- **Switching pages (SEO):**
  - "BookFunnel alternative after the 2026 price change"
  - "Booksprout alternative"
  - "NetGalley alternative for indie authors"
  - "Payhip vs 0% fee store"
- **Free tools as lead magnets:** ARC reader-reliability calculator; "is my ARC team worth it" report; Kindle delivery link generator.
- **Affiliate program:** 30% recurring for author-coaches, cover designers and editors, who already recommend BookFunnel.
- **Kickstarter wave:** the publishing category has passed $380M in pledges across 69k+ projects, and the average publishing backer spent $72 last year ([Indie Author Magazine](https://indieauthormagazine.com/how-authors-are-succeeding-on-kickstarter-in-2026/)). Target authors with live campaigns for fulfillment.

## Risks and incumbent moats
- **BookFunnel's reader trust.** Readers know the BookFunnel app, and it supports readers directly. Mitigation: a polished delivery flow, an AI help desk and human backup, and grandfathered migration.
- **Review-policy compliance.** Amazon's review rules and the FTC's rule on fake and incentivized reviews (effective late 2024; not re-verified this pass) forbid buying reviews or conditioning a free copy on a positive one. Mitigation: ARC copies go out with no strings, disclosures are built in, and we never guarantee review counts. This also sets us apart from services accused of bot reviews.
- **Low willingness to pay.** 44% of authors earn ≤$100/mo. Mitigation: a free tier plus a flat price below the stack, aimed at the 33% earning $500+/mo.
- **Piracy and file handling.** Watermarking plus revocable links.
- **Tax on digital goods.** EU VAT and US state sales tax on ebooks. Mitigation: Stripe Tax or a merchant-of-record option.
- **Cheap point-solution competitors:** Storyfinch ($29/yr magnets), StoryOrigin (free tier), Payhip (free plus 5%). Our edge is the combined workflow plus the ARC reliability network.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 4 | 4 | 3 | **19** |

*Sales speed lowered 5 → 4 after verification: the like-for-like BookFunnel increase is +33%, not a doubling, and existing customers are grandfathered.*

## Sources
- [BookFunnel author pricing (updated June 8, 2026)](https://www.bookfunnel.com/pricing/)
- [BookFunnel blog: New Plans (2026)](https://blog.bookfunnel.com/2026/new-plans/)
- [BookFunnel old pricing page](https://bookfunnel.com/pricing-old/)
- [BookSirens pricing](https://www.booksirens.com/pricing)
- [Read & Rate: NetGalley alternatives for indie authors (2026)](https://www.readnrate.com/blog/netgalley-alternatives-indie-authors)
- [WIPsage: NetGalley co-op worth it? (May 14, 2026)](https://www.wipsage.com/blog/netgalley-indie-authors-co-op-worth-it)
- [Storyfinch: BookFunnel alternatives (July 7, 2026)](https://storyfinch.app/blog/bookfunnel-alternative)
- [Reedsy: BookFunnel review (Aug 13, 2026)](https://reedsy.com/blog/bookfunnel/)
- [Payhip pricing](https://payhip.com/pricing)
- [Kickstarter fees](https://www.kickstarter.com/help/fees)
- [Indie Author Magazine: Kickstarter in 2026](https://indieauthormagazine.com/how-authors-are-succeeding-on-kickstarter-in-2026/)
- [Trustpilot: Booksprout](https://www.trustpilot.com/review/booksprout.co)
- [Trustpilot: BookBub](https://www.trustpilot.com/review/bookbub.com)
- [Self-Publishing with Dale: KDP print royalty change 2025](https://selfpub.substack.com/p/kdp-print-royalty-change-2025-what-authors-need-to-know)
- [BoSacks: Four million books (Mar 18, 2026)](https://www.bosacks.com/bosacks-speaks-out/bosacks-speaks-out-four-million-books-and-the-question-nobody-wants-to-ask)
- [Digital Publishing Report: Massive surge in self-published titles](https://digital-publishing-report.com/en/2026/massive-surge-in-self-published-titles)
- [Written Word Media: 2025 Indie Author Survey](https://www.writtenwordmedia.com/2025-indie-author-survey-results-insights-into-self-publishing-for-authors/)
- [Written Word Media: How indie authors are doing in 2025 (June 11, 2025)](https://www.writtenwordmedia.com/we-asked-indie-authors-how-2025-is-going-heres-what-they-said/)

## Verification (Sep 25 2026)
- ✅ BookFunnel new plans effective Feb 20, 2026 — blog post (Jan 19, 2026) lists First-Time Author $30/yr (up from $20), Mid-List $200/yr, Bestseller $300/yr, says existing customers keep their plans, and cites "nearly 10 years" without price changes ([source](https://blog.bookfunnel.com/2026/new-plans/))
- ⚠️ "Mid-List doubled to $200/yr" — old page shows Mid-List $100/yr plus $50/yr for mailing-list integration ($150 total) and Bestseller $250. The base plan doubled, but like-for-like it is +33%. Text corrected; Sales speed lowered 5 → 4 ([source](https://bookfunnel.com/pricing-old/))
- ✅ Current tiers — pricing page (modified June 8, 2026): First-Time has no email collection, ARC or direct sales; Mid-List includes all three. The audiobook add-on runs $20/yr + $0.04/hr up to $300/yr unlimited, which matches the $2–$30/mo monthly equivalents ([source](https://www.bookfunnel.com/pricing/))
- ✅ KDP paperback royalty cut — paperbacks under $9.99 went from 60% to 50%, effective June 10, 2025 (secondary source; Amazon's own KDP page not checked) ([source](https://selfpub.substack.com/p/kdp-print-royalty-change-2025-what-authors-need-to-know))
- ✅ Payhip — Free has a 5% fee, Plus is $29/mo + 2%, Pro is $99/mo with no transaction fee, and PayPal/Stripe fees apply on every plan ([source](https://payhip.com/pricing))
