# TagTrue: a cheaper, better compliance layer (Metrc reconciliation + hemp-law product audit) for small dispensaries, cultivators and hemp retailers

**One-liner:** A compliance co-pilot that sits beside your POS. It reconciles your inventory against the state track-and-trace system (Metrc and others) every day, reads lab certificates (COAs) with AI, and flags every product that breaks state rules or the new federal hemp definition before an inspector or the deadline catches it.

## Snapshot
- **Replaces / sits alongside:**
  - **Metrc** is the state-mandated seed-to-sale system. Per [Metrc Partners, page modified Sep 7 2026](https://www.metrc.com/partners/), it holds 30 regulatory contracts:
    - Listed markets: AL, AK, CA, CO (plus Colorado Industrial Hemp), DC, Guam, LA, ME, MD, MA, MI, MS, MO, MT, NV, NJ, OH, OK, OR, RI, SD, WV.
    - Partner portals also appear for IL, KY, MN, NY and the US Virgin Islands.
    - Metrc claims a "100% contract renewal rate."
    - Licensee fees (per-tag and subscription charges) are set per state contract and were **not verified in this pass**.
  - **BioTrack** (other state contracts) was not verified in this pass.
  - **Dispensary POS vendors:** Dutchie, Flowhub, Treez. Pricing is quote-based and not verified. A Dutchie reviewer says a promotional first-year price **tripled at renewal** ([Trustpilot](https://www.trustpilot.com/review/dutchie.com)).
- **Recent price hikes / changes:**
  - **Federal hemp redefinition.** H.R. 5371, the bill that ended the 2025 shutdown, was signed **Nov 12 2025**. It "rewrites the federal definition of hemp to effectively ban products with more than 0.4 milligrams of THC per container" ([Wikipedia: 2025 federal shutdown](https://en.wikipedia.org/wiki/2025_United_States_federal_government_shutdown)).
    - The provision was widely reported to take effect one year after enactment, around **Nov 12 2026**. That date is **not verified in this pass; confirm it.**
  - **Texas.** Background knowledge, not verified in this pass: the Governor vetoed SB 3, a THC ban, in June 2025, then ordered age-21 limits by executive action.
  - **Metrc footprint.** Portals for large markets (NY, IL, MN, KY) suggest recent contract wins. Dates were not verified.
- **Who buys:**
  - Owners and compliance managers at single-store and small-chain dispensaries, craft cultivators and manufacturers.
  - Hemp-THC brands and smoke/vape/CBD shops that must clean up their catalogs before the federal change.
- **US market size:**
  - Estimate: roughly 15k–20k licensed cannabis retail and production licensees in adult-use and medical states, plus tens of thousands of hemp-THC retailers (smoke shops, c-stores).
  - These are rough estimates, not verified. The hemp segment may shrink sharply after the federal change.
- **Urgency trigger (why they'd switch NOW):**
  - The federal hemp change around **Nov 12 2026** (verify) forces every hemp-THC seller to audit its SKUs for total THC per container.
  - State inspections and Metrc discrepancy penalties.
  - POS renewal price shocks.
- **Fastest-selling states/metros:**
  - Mature, competitive Metrc markets with many independents: MI, OK, CA, CO, MO, MA, NJ.
  - For hemp: TX, FL, GA, TN, NC, which have large intoxicating-hemp retail footprints (estimate, verify).

## Pain points (evidence)
- **[Reliability]** A Dutchie POS "went down at 9am," and the operator is frustrated with service consistency ([Trustpilot, Jun 2026](https://www.trustpilot.com/review/dutchie.com)).
- **[Payments]** Duplicate charges ("charged for both purchases") on Dutchie's payment rails, and the customer was banned after disputing the charge with their bank ([Trustpilot, Aug–Sep 2026](https://www.trustpilot.com/review/dutchie.com)).
- **[Support/Migration]** An operator says Dutchie staff "lacked the leadership to provide the training required." Inventory was mismanaged during the migration, and the operator switched providers ([Trustpilot, Oct 2025](https://www.trustpilot.com/review/dutchie.com)).
- **[Price/Lock-in]** A Dutchie deal that was "great for 1 year" tripled on renewal ([Trustpilot](https://www.trustpilot.com/review/dutchie.com)). Dutchie's profile averages 2.7/5 on 18 reviews.
- **[UX]** A Dutchie storefront was described as "not even navigable," with no mobile app ([Trustpilot, Aug 2026](https://www.trustpilot.com/review/dutchie.com)).
- **[Regulatory/Forced]** Metrc is mandated by state contract in 20+ jurisdictions, and there is no competitive alternative for the state record ([Metrc Partners](https://www.metrc.com/partners/)). Operators can only choose the tools around it.
- **[Regulatory]** The federal 0.4 mg THC per container cap, signed Nov 12 2025, turns much of today's hemp-THC catalog into non-compliant inventory ([Wikipedia summary of H.R. 5371](https://en.wikipedia.org/wiki/2025_United_States_federal_government_shutdown)).
- **Evidence gap:** Reddit (r/weedbiz, r/CannabisIndustry) is blocked from our fetcher, and the search budget ran out. Metrc fee complaints, Flowhub/Treez reviews and BioTrack state lists are still needed. Target 6+ more complaints in the per-state pass.

## What we build (the better version)
1. **MVP: a Metrc read-only connector.** The licensee pastes their user API key. Nightly, we pull packages, transfers and sales.
2. **MVP: a daily reconciliation report.** It compares POS on-hand quantities with Metrc packages and flags variances, unreported sales, lab-test status holds, expiring tags and stuck transfers. Each flag comes with a to-do list.
3. **MVP: a COA reader.** Upload lab PDFs and AI extracts cannabinoids (total THC including THCA conversion), batch, lab and date. Each batch is linked to its SKUs.
4. **MVP: a hemp-2026 catalog audit.** Upload a product list or connect Shopify or a POS.
   - It computes total THC per container against the 0.4 mg federal cap and each state's rules.
   - It outputs a "sell-through / pull / reformulate" list with dates.
5. **MVP: an inspection-ready binder.** Licenses, SOPs, training logs, waste logs and camera-retention checklists, with expiry reminders.
6. **V2: reconciliation write-back** (adjustments and waste entries submitted to Metrc with user approval). This needs per-state validated-integrator status.
7. **V2: BioTrack and state-system connectors** (for non-Metrc states).
8. **V2: a label generator** for state-specific warning labels and QR-to-COA pages.
9. **V2: a lightweight POS** for single-store operators once the reconciliation wedge has earned trust.

## Pricing to win
- **Our plans:**
  - **$149/mo per license**, covering reconciliation, the COA reader and the binder.
  - **Hemp audit:** a one-time $199 for up to 500 SKUs, then $29/mo for monitoring.
  - No contracts and no payment-processing lock-in.
- **Comparison:** POS suites are quote-based and tripled at renewal in one report. We don't replace the POS at first, so the pitch is avoiding fines and compliance-staff hours rather than a like-for-like saving. Savings are unquantified until POS prices are verified.

## Go-to-market (first 100 customers)
- **State cannabis trade associations** in MI, OK, MO, MA and NJ (for example the Michigan Cannabis Industry Association and the Oklahoma cannabis associations), plus their compliance webinars.
- **Compliance consultants and cannabis attorneys** as a resale and referral channel, since each consultant manages 10–50 licensees.
- **Hemp-deadline blitz before Nov 2026:** SEO for "0.4 mg THC per container calculator," outreach to hemp brands and distributors, and smoke-shop distributor newsletters.
- **Communities:** r/weedbiz, r/CannabisIndustry, cannabis-operator LinkedIn groups, and MJBizCon (Las Vegas, typically December).

## Risks and incumbent moats
- **Metrc API access** requires each state's integrator approval and the licensee's own API key. We start read-only in the states with easy access. Write-back is V2.
- **Banking and payments.** We avoid touching payments entirely.
- **Market volatility.** Hemp demand may collapse after the federal change, and cannabis retail is consolidating under price compression. The per-license SaaS model survives because every surviving licensee still has to reconcile.
- **Liability.** We flag issues but do not certify compliance.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 2 | 3 | 2 | **14** |

## Sources
- [Metrc: Partners (state contracts list, modified Sep 7 2026)](https://www.metrc.com/partners/)
- [Trustpilot: Dutchie reviews](https://www.trustpilot.com/review/dutchie.com)
- [Wikipedia: 2025 United States federal government shutdown (H.R. 5371 hemp provision, signed Nov 12 2025)](https://en.wikipedia.org/wiki/2025_United_States_federal_government_shutdown)
