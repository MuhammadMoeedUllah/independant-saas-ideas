# LessonLedger: a cheaper, better My Music Staff / Teachworks / TutorBird for tutors, music teachers and test-prep studios, ESA-ready

**One-liner:** Lesson scheduling, a makeup-credit ledger, family invoicing and a mobile app for private-lesson businesses. It also makes a tutor an approved, paid ESA vendor in any state without extra paperwork.

## Snapshot
- **Replaces** (Jan 2026 prices, via [Teach 'n Go comparison](https://www.teachngo.com/blog/teachworks-vs-tutorbird)):
  - **Teachworks:** Starter **$16.49/mo + $0.32/lesson**, Growth **$47.99 + $0.189/lesson**, Premium **$187.99 + $0.065/lesson**.
  - **TutorBird:** **$14.95/mo + $4.95 per additional tutor**.
  - **My Music Staff:** not verified this pass (reviewers call it "reasonably priced") ([Capterra](https://www.capterra.com/p/148451/My-Music-Staff/reviews/)).
  - Wise: not re-priced.
- **Recent price hikes / changes:** We found no 2025–26 incumbent price hike. The new angle is **ESA money**. Texas TEFA gives homeschoolers **$2,000** for 2026–27, and about 18 states run ESAs where tutors and lesson providers can be paid vendors ([Texas Comptroller](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312); [GetESAPaid](https://getesapaid.com/become-an-esa-vendor)).
- **Who buys:** Independent music teachers, multi-teacher music schools, tutoring centers, test-prep and academic coaching businesses (1–30 teachers).
- **US market size:** Estimate only: hundreds of thousands of independent music teachers and tutors (mostly solo). Tutoring centers and music schools number in the tens of thousands. Verify with Census NAICS 611610 and 611691 (exam prep and tutoring) in the state pass.
- **Urgency trigger (why they'd switch NOW):** Weak on price. Incumbents are cheap. The switch driver is **ESA-state demand** (families want to pay with TEFA/ESA money, and a tutor who can't invoice the portal loses the client) plus fall term start in Aug–Sep.
- **Fastest-selling states/metros:** ESA states: Texas, Arizona, Florida, Utah, Iowa, Arkansas, Tennessee. Then large metros for music schools.

## Pain points (evidence)
- **[Payments]** My Music Staff has no physical POS integration, so card details are keyed in by hand or sent through the portal (Capterra, Jun 2026) ([Capterra](https://www.capterra.com/p/148451/My-Music-Staff/reviews/)).
- **[Complexity/UX]** My Music Staff invoicing "sometimes charges twice", and the owner has to work around it to get amounts right (Capterra, Nov 2022) ([Capterra](https://www.capterra.com/p/148451/My-Music-Staff/reviews/)).
- **[Missing features]** It is hard to tell teacher-absence makeup credits from student-absence credits, which complicates studio policy (Capterra, Sep 2023) ([Capterra](https://www.capterra.com/p/148451/My-Music-Staff/reviews/)).
- **[Missing features]** There is no native mobile app, only the mobile website (multiple reviews, 2023–2026) ([Capterra](https://www.capterra.com/p/148451/My-Music-Staff/reviews/)).
- **[Complexity/UX]** The interface is "clunky", and owners spend time walking parents through makeup-lesson steps (Capterra, Jan 2026) ([Capterra](https://www.capterra.com/p/148451/My-Music-Staff/reviews/)).
- **[Missing features]** There are no open APIs and Zapier is limited, and the booking widget can't be customized (Capterra, Dec 2025) ([Capterra](https://www.capterra.com/p/148451/My-Music-Staff/reviews/)).
- **[Price]** Teachworks' per-lesson fees make monthly costs "unpredictable" with seasonality and growth ([Teach 'n Go, Jan 2026](https://www.teachngo.com/blog/teachworks-vs-tutorbird); competitor source).
- **[Complexity/UX]** Teachworks' interface is described as "dated", with a steep learning curve ([Teach 'n Go](https://www.teachngo.com/blog/teachworks-vs-tutorbird); competitor source).
- **[Missing features]** TutorBird users want more flexible invoicing for complex billing and more customizable reports and invoice layouts ([Teach 'n Go](https://www.teachngo.com/blog/teachworks-vs-tutorbird); competitor source).
- **[Payments / ESA]** ESA vendors hit invoice rejections and opaque settlement timing on ClassWallet and Odyssey ([GetESAPaid](https://getesapaid.com/become-an-esa-vendor)).

## What we build (the better version)
1. **MVP** Recurring lesson scheduling (weekly slots, term calendars, holidays), and online booking for trial lessons.
2. **MVP** **Makeup-credit ledger** with explicit reasons (teacher cancel, student cancel, weather) and policy rules (expiry, max per term). Parents self-book makeups from open slots.
3. **MVP** Family invoicing: monthly flat, per-lesson or per-term tuition. Autopay plus Tap to Pay on iPhone/Android (POS). Transparent processing.
4. **MVP** **ESA mode:** tag families by ESA program, generate itemized, portal-ready invoices for Odyssey, ClassWallet or Step Up, track claims to settlement, and store W-9 and credential documents.
5. **MVP** Native-feel PWA for teachers (attendance, lesson notes, practice assignments) and parents.
6. **MVP** Open API plus Zapier and webhooks. Free import from My Music Staff, Teachworks and TutorBird.
7. **V2** Practice tracker and recital/event sign-ups. Studio website builder.
8. **V2** Teacher payroll for multi-teacher schools (per lesson, per student) with 1099 summaries.
9. **V2** AI lesson-note summaries emailed to parents and progress reports for ESA documentation.

## Pricing to win
- **Solo: $12/mo flat (unlimited students). School: $39/mo + $4/teacher.** No per-lesson fees. ESA mode included.
- **Example:** a Teachworks Growth tutoring center running 600 lessons/mo pays $47.99 + (600 × $0.189) = **about $161/mo**. With 5 teachers on LessonLedger it pays $59, saving about **$1,220/yr**. A solo teacher on TutorBird ($14.95) saves little on price. The pitch there is ESA income and POS.

## Go-to-market (first 100 customers)
- **Communities:** r/musicteachers, r/piano (teachers), r/Tutoring, r/SAT (tutors), Facebook "Independent Music Teachers" and "Piano Teachers Central", MTNA (Music Teachers National Association) state chapters and the MTNA national conference.
- **ESA angle:** partner with ESA parent Facebook groups in TX, AZ and FL ("find an ESA-approved piano teacher"), and list vendors in a free directory to create two-sided pull.
- **SEO:** "how to become a TEFA vendor as a tutor", "ESA approved music lessons Arizona", "My Music Staff alternative with app".

## Risks and incumbent moats
- **Low price gap:** incumbents are already cheap, so we win on ESA income, POS and UX, not price.
- **ESA platform rules:** same as F06. File-based invoices, not APIs.
- **Crowded category** (Opus1, Teach 'n Go, Duet Partner, Wise): ESA mode is the wedge. It could be the same codebase as F06 (a vendor tier).

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 2 | 2 | 5 | 4 | 3 | **16** |

## Sources
- [Teachworks vs TutorBird vs Teach 'n Go (2026) – Teach 'n Go](https://www.teachngo.com/blog/teachworks-vs-tutorbird)
- [My Music Staff reviews – Capterra](https://www.capterra.com/p/148451/My-Music-Staff/reviews/)
- [My Music Staff alternatives – Bizzly](https://www.bizzly.net/guides/mymusicstaff-alternatives)
- [How to become an ESA vendor (every state) – GetESAPaid](https://getesapaid.com/become-an-esa-vendor)
- [Texas Comptroller TEFA final rules and dates (Nov 25 2025)](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312)
