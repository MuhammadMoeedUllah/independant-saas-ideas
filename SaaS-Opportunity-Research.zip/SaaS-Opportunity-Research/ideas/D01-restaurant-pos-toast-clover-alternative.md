# FlatTab POS: a cheaper, better Toast / Clover for counter-service cafés, food trucks and quick-service restaurants

**One-liner:** A bring-your-own-device (iPad/Android + Tap to Pay) counter-service POS with flat software pricing, pass-through processing, no hardware lease and no multi-year contract, sold through a free "what is your POS really costing you?" statement X-ray.

> Researcher note: the user brief referenced a "2025 per-order fee backlash." The evidence found shows Toast's 99-cent per-order fee backlash happened in **early 2023** (fee added, then reversed after outcry). The 2024-2026 changes are a +0.23% processing increase (Sept 2024) and ongoing hidden-cost complaints. No FTC action against Clover was found in this pass; the Clover "switching window" is Fiserv's forced Payeezy-to-Clover migration and the resulting securities suits (2025).

## Snapshot
- **Replaces:**
  - **Toast** (per UpMenu, updated May 12, 2026): Starter Kit $0/mo at ~3.09%-3.69% + $0.15; Point of Sale plan $69/mo at ~2.49% + $0.15; Custom/multi-location by quote. Hardware: Flex terminal $799-$1,199, Toast Go 2 handheld $409-$699, KDS $599-$1,199, kiosk $1,099-$1,899. UpMenu estimates real all-in monthly totals of $300-$700 for a small café/food truck and $1,000-$2,000+ for full-service ([UpMenu](https://www.upmenu.com/blog/toast-pricing/)).
  - **Clover** (per PaymentPop, Sept 23, 2026): Restaurant processing 2.3% + 10c in person, 3.5% + 10c keyed; equipment subscriptions on a 36-month term: Restaurant Starter $179/mo, Standard $239/mo, Advanced $354/mo; Rapid Deposit 1.75% ([PaymentPop](https://paymentpop.com/merchant-accounts/clover-pos-customer-reviews/)).
  - **Square for Restaurants, SpotOn:** direct competitors; current list prices not verified in this pass.
- **Recent price hikes / changes:**
  - **Early 2023:** Toast added a $0.99 fee to online orders over $10, then removed it after widespread backlash ([NRN add](https://www.nrn.com/restaurant-segments/toast-is-adding-a-99-cent-fee-to-all-orders-over-10), [NRN removal](https://www.nrn.com/restaurant-segments/toast-to-remove-99-cent-fee-on-orders-over-10), [Restaurant Business](https://www.restaurantbusinessonline.com/technology/toast-remove-99-cent-fee-after-widespread-backlash), [Entrepreneur](https://www.entrepreneur.com/business-news/toast-inc-removes-hidden-fee-after-outrage-from-customers/456156)).
  - **Sept 1, 2024:** Toast processing increase of +0.23% per transaction; on $100k/mo of sales that is about $2,760/yr more ([KORONA POS, updated Mar 19, 2026](https://koronapos.com/blog/toast-processing-rate-increase-2024/)). Competitor blogs report further 2026 increase notices, but no official figures were found ([Sleft Payments](https://www.sleftpayments.com/learning-hub/toast-pos-raised-fees-options-2026), [Reforming Retail, Aug 4, 2026](https://reformingretail.com/index.php/2026/08/04/another-toast-rate-increase-and-a-merchants-way-out/)).
  - **Clover / Fiserv:** about 200,000 legacy Payeezy merchants were migrated to Clover from late 2023 through H1 2024. A July 25, 2025 securities class action says the growth this produced was presented as organic, and that merchants were leaving Clover for Square and Toast ([Payments Dive](https://www.paymentsdive.com/news/fiserv-sued-over-clover-migration/754200/), [Bloomberg Law](https://news.bloomberglaw.com/securities-law/fiserv-top-brass-misrepresented-clovers-prospects-suit-says), [consolidated suits](https://www.paymentsdive.com/news/judge-combines-fiserv-lawsuits/819924/)). Separate suit over alleged lax security ([Payments Dive](https://www.paymentsdive.com/news/fiserv-sued-over-alleged-lax-security/810831/)). Earlier: Bobo v. Clover Network TCPA settlement (Jan 2024, up to $15M) per PaymentPop.
- **Who buys:** Owner-operators of cafés, coffee shops, bakeries, food trucks, fast-casual and single-location QSR (1-3 terminals). Buyer is the owner, often after a contract anniversary or a surprise statement.
- **US market size:** Estimate: the National Restaurant Association commonly cites about 1 million restaurant and foodservice locations (not re-verified in this pass). The counter-service, small-ticket subset is estimated in the hundreds of thousands.
- **Urgency trigger (why they'd switch NOW):** Contract anniversaries of Toast and Clover (36-month Clover equipment terms signed during the 2023-24 migration wave end in 2026-27), processing increase letters, and Fiserv turmoil (stock down about 73% from its peak per [TIKR](https://www.tikr.com/blog/down-73-from-peak-can-fiserv-nasdaq-fisv-stock-deliver-better-returns-in-2026)).
- **Fastest-selling states/metros:** High-density café and food-truck metros: Los Angeles, Austin, Portland, Denver, NYC, Miami. States with high minimum wages (CA, WA, NY) squeeze margins hardest, so fee savings matter more there (inference).

## Pain points (evidence)
- **[Price]** Toast began charging diners $0.99 on online orders over $10. Operators said they got no clear advance notice, and Toast reversed the fee after the outcry ([UpMenu owner quote](https://www.upmenu.com/blog/toast-pricing/), [Hospitality Technology](https://hospitalitytech.com/toasts-new-order-processing-fee-stirs-debate)).
- **[Price]** Toast raised processing by 0.23% from Sept 2024, which works out to thousands of dollars a year for a mid-volume restaurant ([KORONA](https://koronapos.com/blog/toast-processing-rate-increase-2024/)).
- **[Price]** Chargebacks ($15-$25 each), PCI fees, SMS overages and hardware financing interest are cited as hidden costs on top of the plan fee ([UpMenu](https://www.upmenu.com/blog/toast-pricing/)).
- **[Support / payouts]** A restaurant co-owner (Mar 2025) reported three weeks without a single deposit from Toast ([Capterra](https://www.capterra.com/p/136301/Toast-POS/reviews/)).
- **[Support / payouts]** A restaurant director (June 2026) said they had waited almost a year for returned funds ([Capterra](https://www.capterra.com/p/136301/Toast-POS/reviews/)).
- **[Support]** An owner (Mar 2025) said support could not resolve their issues and they might as well "light it on fire" ([Capterra](https://www.capterra.com/p/136301/Toast-POS/reviews/)).
- **[Complexity/UX]** An owner (Mar 2024) called the back end useless for remote troubleshooting because fixes need someone on site. A GM (Mar 2025) described frequent glitches, crashes and slow screen transitions ([Capterra](https://www.capterra.com/p/136301/Toast-POS/reviews/)).
- **[Missing features]** A hospitality payroll manager (Nov 2025) could not export order data to spreadsheets for analysis ([Capterra](https://www.capterra.com/p/136301/Toast-POS/reviews/)).
- **[Lock-in/Contracts]** Clover reviewers cite non-cancelable 36-month equipment contracts, billing that continued after cancellation and equipment return, charges above the quoted price, and deposit holds ([PaymentPop](https://paymentpop.com/merchant-accounts/clover-pos-customer-reviews/)).
- **[Lock-in]** Fiserv moved about 200k merchants onto Clover through a forced migration rather than by choice ([Payments Dive](https://www.paymentsdive.com/news/fiserv-sued-over-clover-migration/754200/)).
- **[Lock-in/Contracts]** Toast contracts are described as 2-3 years with auto-renewal and early termination fees "in the thousands." This is a competitor's claim and should be verified against Toast's terms ([Sleft Payments](https://www.sleftpayments.com/learning-hub/toast-pos-raised-fees-options-2026)).

## What we build (the better version)
1. **MVP: Statement X-ray (lead magnet).** The owner uploads a Toast, Clover or Square PDF statement. AI extracts the effective rate, junk fees, hardware lease balance and months left, and gives an ETF estimate plus a "you would save $X/yr" report. This can ship in week 1 on its own.
2. **MVP: Counter-service POS on iPad/Android.** Menu, modifiers, combos, open tabs, split checks, tip prompts, discounts, and refunds with manager PIN.
3. **MVP: Tap to Pay on iPhone/Android plus low-cost card readers** through Stripe Terminal. No hardware lease, and customers can bring their own tablet.
4. **MVP: Kitchen display on any tablet**, plus ticket printing to standard ESC/POS printers.
5. **MVP: One-click menu import** from a PDF, a photo or a Toast/Clover/Square menu export, using AI parsing.
6. **MVP: Daily sales email and simple reports** (item mix, hourly sales, tips by employee) with CSV export of everything.
7. **MVP: Month-to-month billing, with a data-export button always visible.**
8. **V2: Offline mode** (store-and-forward card-present transactions).
9. **V2: QR order-and-pay at the table, online ordering** (shares the D02 engine), and loyalty (phone-number based).
10. **V2: Integrations** with 7shifts/Homebase alternatives (D04), QuickBooks/Xero, and DoorDash/Uber Eats order injection.
11. **V2: Negotiated interchange-plus pricing** once volume justifies it.

## Pricing to win
- **FlatTab:** $0 software for 1 register (Tap to Pay), then $49/mo per location for unlimited devices, KDS and reports. Processing is passed through at our Stripe cost plus a small, disclosed markup. There is no contract, no lease and no ETF, and migration is free.
- **Why small tickets win:** At Stripe's published card-present rate (2.7% + 5c, to be verified at build time), a $15 ticket costs about $0.46 to process. On the Toast POS plan (2.49% + 15c) the same ticket costs about $0.52, before the $69/mo plan fee and hardware.
- **Typical café savings (estimate):** 4,000 transactions/mo at $15 is about $240/mo less processing, plus $20/mo on the plan and $50-$150/mo on hardware financing avoided. That is roughly $3,000-$5,000/yr, before counting Toast's add-on modules.
- **Honest caveat:** For large-ticket full-service restaurants the processing gap is thin. Lead with counter-service and small tickets.

## Go-to-market (first 100 customers)
- **"Switch from Toast / Clover" SEO pages** plus a free Statement X-ray tool, targeting "Toast fees," "Clover contract cancel" and "Clover early termination fee."
- **Reddit:** r/restaurateur, r/restaurantowners, r/smallbusiness, r/foodtrucks (answer fee threads and offer X-ray reports; no spam).
- **Food truck associations and commissary kitchens:** these are dense clusters of card-paying owner-operators. Offer free onboarding days at commissaries.
- **State restaurant associations** (California Restaurant Association, Texas Restaurant Association, NYS Restaurant Association and others): member-discount programs and webinar slots.
- **National Restaurant Association Show** (Chicago, May): a booth is expensive. Instead, run a demo-van or meetup outside the show.
- **Referral:** One free month per referred location. Bookkeepers and restaurant CPAs get a revenue share.
- **Cold email:** Pull Clover and Toast users from BuiltWith/online-ordering footprints (toasttab.com order links in Google Maps listings) and send a personalized "your estimated fees" note.

## Risks and incumbent moats
- **Payments/PCI:** We use Stripe Terminal (PCI burden on Stripe) and never touch raw PANs.
- **Offline reliability:** Restaurants cannot go down on a Friday night. Mitigation: start with counter-service and ship store-and-forward in V2.
- **Hardware lock-in and ETFs:** Mitigation: the X-ray tool calculates the contract end date; we time the switch and optionally offer an ETF buyout credit for larger accounts.
- **Toast ecosystem** (payroll, marketing, capital): we stay deliberately narrow and integrate with others.
- **Square is cheap and good:** Our edge over Square is AI setup, flat multi-device pricing and white-glove migration. This is weak, and it is why the Price gap score is 2.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 2 | 2 | 2 | 5 | **15** |

## Sources
- [Toast Pricing Breakdown 2026 – UpMenu (May 12, 2026)](https://www.upmenu.com/blog/toast-pricing/)
- [Toast is adding a 99-cent fee – NRN](https://www.nrn.com/restaurant-segments/toast-is-adding-a-99-cent-fee-to-all-orders-over-10)
- [Toast to remove 99-cent fee – NRN](https://www.nrn.com/restaurant-segments/toast-to-remove-99-cent-fee-on-orders-over-10)
- [Toast to remove 99-cent fee after widespread backlash – Restaurant Business](https://www.restaurantbusinessonline.com/technology/toast-remove-99-cent-fee-after-widespread-backlash)
- [Toast Inc. Removes Hidden Fee After Outrage – Entrepreneur](https://www.entrepreneur.com/business-news/toast-inc-removes-hidden-fee-after-outrage-from-customers/456156)
- [Toast's New Order Processing Fee Stirs Debate – Hospitality Technology](https://hospitalitytech.com/toasts-new-order-processing-fee-stirs-debate)
- [Toast processing rate increase – KORONA POS](https://koronapos.com/blog/toast-processing-rate-increase-2024/)
- [Toast POS Raised Fees Again – Sleft Payments (competitor)](https://www.sleftpayments.com/learning-hub/toast-pos-raised-fees-options-2026)
- [Another Toast Rate Increase – Reforming Retail (Aug 4, 2026)](https://reformingretail.com/index.php/2026/08/04/another-toast-rate-increase-and-a-merchants-way-out/)
- [Toast POS Reviews – Capterra](https://www.capterra.com/p/136301/Toast-POS/reviews/)
- [Clover POS Reviews 2026 – PaymentPop (Sept 23, 2026)](https://paymentpop.com/merchant-accounts/clover-pos-customer-reviews/)
- [Fiserv sued over Clover migration – Payments Dive](https://www.paymentsdive.com/news/fiserv-sued-over-clover-migration/754200/)
- [Judge combines Fiserv lawsuits – Payments Dive](https://www.paymentsdive.com/news/judge-combines-fiserv-lawsuits/819924/)
- [Fiserv sued over alleged lax security – Payments Dive](https://www.paymentsdive.com/news/fiserv-sued-over-alleged-lax-security/810831/)
- [Fiserv Top Brass Misrepresented Clover's Prospects – Bloomberg Law](https://news.bloomberglaw.com/securities-law/fiserv-top-brass-misrepresented-clovers-prospects-suit-says)
- [Down 73% From Peak – TIKR](https://www.tikr.com/blog/down-73-from-peak-can-fiserv-nasdaq-fisv-stock-deliver-better-returns-in-2026)
