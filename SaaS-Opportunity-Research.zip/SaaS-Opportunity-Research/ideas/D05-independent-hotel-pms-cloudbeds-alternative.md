# InnDesk: a cheaper, better Cloudbeds / Little Hotelier for independent motels, inns and B&Bs

**One-liner:** A simple property management system for 5-60 room independent properties, with a commission-free booking engine that shows all-in pricing, a channel manager, payments and guest messaging, for one flat fee per property instead of per-room pricing plus booking fees.

## Snapshot
- **Replaces:**
  - **Cloudbeds:** per-room pricing from about $15/room/mo at the entry tier, with per-property minimums. Tiers are Flex, One, Experience and Enterprise (per Houseful, July 9, 2026) ([Houseful](https://housefulhospitality.com/cloudbeds-vs-little-hotelier/), [Cloudbeds pricing](https://www.cloudbeds.com/pricing/)).
  - **Little Hotelier (SiteMinder):** Basics about $39/mo **plus a 1% booking fee**. Pro about $109/mo for small properties, scaling with room count ([Houseful](https://housefulhospitality.com/cloudbeds-vs-little-hotelier/)).
  - **ThinkReservations, WebRezPro:** quote-based ("contact vendor") ([Capterra compare](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
  - **OTAs (Booking.com, Expedia):** commissions are commonly cited at about 15-25% per booking. This is an industry estimate that was not verified with a source in this pass.
- **Recent price hikes / changes:**
  - **May 12, 2025:** The **FTC Rule on Unfair or Deceptive Fees** took effect for short-term lodging and live-event tickets. It requires the total price, including mandatory fees such as resort fees, to be shown up front ([FTC press release](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025), [FTC FAQ](https://www.ftc.gov/business-guidance/resources/rule-unfair-or-deceptive-fees-frequently-asked-questions), [Hotel Dive](https://www.hoteldive.com/news/ftc-junk-fees-rule-takes-effect-hotels/747738/)). Older booking engines that add fees at checkout create compliance risk.
  - No 2024-2026 list-price increase by Cloudbeds or Little Hotelier was documented in this pass.
- **Who buys:** Owner-operators of independent motels, roadside inns, boutique hotels, B&Bs, guesthouses and small cabin clusters, typically 5-60 rooms. Buyer is the owner or innkeeper, often family-run.
- **US market size:** Estimate: tens of thousands of independent (non-branded) hotels and motels, plus B&Bs and inns in the low tens of thousands. Unverified estimate; AHLA and innkeeping associations should be checked in a later pass.
- **Urgency trigger (why they'd switch NOW):** FTC all-in pricing rule (effective May 12, 2025) plus state junk-fee laws. Channel sync failures cause overbookings. Payment payout delays. Slow season (Nov-Feb in most markets) is when migrations happen ([Houseful advises migrating in slow season](https://housefulhospitality.com/cloudbeds-vs-little-hotelier/)).
- **Fastest-selling states/metros:** Drive-to tourism corridors with many independents: Smoky Mountains TN/NC, Florida Gulf Coast and Keys, Wisconsin Dells, Branson MO, Myrtle Beach SC, the Jersey Shore, Cape Cod, New England B&B country (VT/ME/NH), California wine country, Route 66 motels (AZ/NM/TX).

## Pain points (evidence)
*Note: the Capterra comparison page mixes Cloudbeds and ThinkReservations reviews. We did not capture which product each review below refers to.*
- **[Support]** Reviewers report long waits and difficulty reaching qualified support. One said support was "non existent" for technical issues ([Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
- **[Missing features]** A reviewer said reports showed an "890% commission" instead of the real percentage. Others called reports "useless" and said their accountants couldn't read them ([Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
- **[Reliability]** A reviewer reported "almost daily" blackouts since late 2023 ([Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
- **[Reliability]** Reviewers reported channel manager integration failures with Expedia and Booking.com, which is the classic overbooking risk ([Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
- **[Payments]** One proprietor went "TEN DAYS without payments." Another claimed to have "lost 22 THOUSAND dollars of deposits" ([Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
- **[Support/Missing features]** Group booking fixes reportedly took "a year of complaining" ([Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
- **[Complexity/UX]** A reviewer said the guest-facing checkout page is not user-friendly ([Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
- **[Price]** A small hotel owner said subscription fees, add-ons and processing add up to "a significant monthly expense" ([Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)).
- **[Price]** Little Hotelier's entry plan charges a 1% fee on every booking on top of the monthly fee ([Houseful](https://housefulhospitality.com/cloudbeds-vs-little-hotelier/)).
- **[Complexity/UX]** Cloudbeds needs more onboarding time. Little Hotelier's integration list "can feel limiting" ([Houseful](https://housefulhospitality.com/cloudbeds-vs-little-hotelier/)).
- *Evidence gap:* r/hotels and innkeeper forum threads were not pulled this pass.

## What we build (the better version)
1. **MVP: Tape-chart calendar** (drag-and-drop reservations, room moves, housekeeping status) that works on a phone.
2. **MVP: Commission-free booking engine** on the property's own domain, with **FTC-compliant all-in pricing** (mandatory fees included in the first price shown), plus a Google Business Profile link.
3. **MVP: Payments through Stripe.** Deposits, card-on-file, automated balance charges and **next-day payouts shown in a clear payout ledger**, which answers the "ten days without payments" pain.
4. **MVP: Automated guest messaging.** Confirmation, pre-arrival with door codes, and a checkout review request (SMS and email).
5. **MVP: Owner-friendly reports.** Occupancy, ADR, RevPAR, and OTA commission owed with the correct math. Accountant-ready CSV/QuickBooks export plus lodging-tax reports by jurisdiction.
6. **MVP: iCal sync** with Airbnb/Vrbo and simple OTAs, clearly labeled as not real-time.
7. **V2: Real-time two-way channel manager** with Booking.com and Expedia through a white-label channel-manager API partner (for example Channex.io; terms to be verified), or through our own certification later.
8. **V2: Rate suggestions.** AI pricing from local events and a comp set pulled from public rates.
9. **V2: Online check-in with ID capture**, digital registration cards, and keyless lock integrations.
10. **V2: Direct-booking nudges.** An "OTA guest to direct" re-marketing email with a best-rate guarantee.

## Pricing to win
- **InnDesk:** $79/mo flat for up to 15 rooms, $149/mo for 16-40 rooms, $229/mo for 41-60 rooms. Channel manager included from V2. **No per-booking fee.** Processing at Stripe cost plus a disclosed markup. Month-to-month, free migration during slow season.
- **Savings example (estimate):** A 30-room motel on Cloudbeds at about $15/room/mo pays about $450/mo. InnDesk costs $149/mo, saving about $3,600/yr. A Little Hotelier Basics user with $300k/yr in bookings pays $3,000/yr in 1% booking fees on top of the subscription.
- **Bigger prize:** Every point of OTA share moved to direct (at about 15-25% commission, estimate) is worth far more than the software bill. Frame the ROI in those terms.

## Go-to-market (first 100 customers)
- **Hotel and lodging associations:** state lodging associations (for example the Florida Restaurant & Lodging Association, the California Hotel & Lodging Association, and the Tennessee Hospitality & Tourism Association; verify vendor programs), AHLA, and the Asian American Hotel Owners Association (AAHOA). AAHOA members own a large share of US independent motels, so it is a key channel. Innkeeper groups: PAII, Select Registry, and state B&B associations.
- **"FTC junk-fee rule compliance check":** a free audit of the property's booking engine as a lead magnet.
- **Conferences:** AAHOACON, the Independent Lodging Congress, and state lodging shows.
- **Reddit and forums:** r/hotels and r/hospitality, plus innkeeper Facebook groups.
- **"Switch from Cloudbeds / Little Hotelier / ThinkReservations" SEO pages** and a migration guide.
- **Referral:** Revenue-management consultants and hotel brokers.

## Risks and incumbent moats
- **Channel manager certification:** Booking.com and Expedia connectivity is the hardest part. Mitigation: launch with a white-label channel API partner and iCal for small properties.
- **Overbooking liability:** Any sync bug costs the owner money and trust. Mitigation: conservative inventory buffers, alerts, and a parallel run during onboarding.
- **Payments:** Stripe handles PCI. Chargebacks on no-shows need clear policies.
- **Data migration:** Future reservations must move cleanly. Provide migration as a service.
- **Crowded market** (Cloudbeds, Little Hotelier, ThinkReservations, WebRezPro, innRoad, RMS, Mews). We win on flat price, simplicity and AAHOA/motel-owner distribution.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 2 | 3 | 3 | **14** |

## Sources
- [Cloudbeds vs Little Hotelier – Houseful (July 9, 2026)](https://housefulhospitality.com/cloudbeds-vs-little-hotelier/)
- [Cloudbeds pricing page](https://www.cloudbeds.com/pricing/)
- [Compare Cloudbeds vs ThinkReservations – Capterra](https://www.capterra.com/compare/158839-182891/Cloudbeds-vs-ThinkReservations)
- [Compare Little Hotelier vs Cloudbeds – Capterra](https://www.capterra.com/compare/144307-158839/Little-Hotelier-vs-Cloudbeds)
- [FTC Rule on Unfair or Deceptive Fees to Take Effect on May 12, 2025 – FTC](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)
- [Rule on Unfair or Deceptive Fees FAQ – FTC](https://www.ftc.gov/business-guidance/resources/rule-unfair-or-deceptive-fees-frequently-asked-questions)
- [How the FTC's junk fees rule sets a standard for hotel pricing – Hotel Dive](https://www.hoteldive.com/news/ftc-junk-fees-rule-takes-effect-hotels/747738/)
- [FTC Junk Fee Rule is effective May 12, 2025 – Hotel Law Blog](https://hotellaw.jeffer.com/ftc-junk-fee-rule-is-effective-may-12-2025.html)
