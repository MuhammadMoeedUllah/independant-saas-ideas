# DoorLedger: a cheaper, better AppFolio / Buildium / Avail for small landlords and property managers (1-300 doors)

**One-liner:** Flat per-door property management software with rent collection, trust-style owner/tenant ledgers, maintenance and leasing. A built-in state compliance engine covers security deposit caps and return deadlines, notice periods, all-in rent advertising and move-in photo rules, and there are no per-transaction or per-signature nickel-and-dime fees.

## Snapshot
- **Replaces:**
  - **AppFolio Property Manager:** Core, Plus and Max tiers, all quote-only. The pricing page says Core carries a **"50 unit minimum"** and that **"Minimum spend and units apply"** ([AppFolio pricing, viewed Sept 2026](https://www.appfolio.com/pricing)). Third-party trackers report Core at about **$1.40/unit/mo** plus onboarding fees. That figure is not confirmed by AppFolio ([PricingNow, 2026](https://pricingnow.com/question/appfolio-property-manager-pricing/)).
  - **Buildium (RealPage):** Essential from **$62/mo**, Growth from **$192/mo**, Premium from **$400/mo**. Add-ons: incoming EFT **$2.35** (Essential) or **$1.35** (Growth) per transaction, eSignature **$5/doc** (Essential) or **$1/doc** (Growth), screening $17-$35, bank account setup $99 on Essential, and inspections $99 setup plus $40-$95/mo on Essential. Community association pricing is phone-only ([Buildium pricing, viewed Sept 2026](https://www.buildium.com/pricing/)).
  - **TurboTenant:** Free, Essentials **$149/yr**, Pro **$199/yr**. Tenants pay 3.49% on cards and a $55 application fee ([RenPro, June-July 2026](https://renpro.com/turbotenant-vs-avail/)).
  - **Avail (Realtor.com):** Free Unlimited, and **Unlimited Plus at $9/unit/mo** (verified July 2026) ([RenPro](https://renpro.com/turbotenant-vs-avail/)).
  - Yardi Breeze, Rent Manager and DoorLoop: pricing not verified in this pass.
- **Recent price hikes / changes:**
  - **Buildium:** A manager reported **"6 price increases in the last 2.5 years"** after the acquisition (Capterra, Dec 4, 2025). An owner said phone support was removed unless they paid about **$1,000/yr more** (Capterra, Mar 24, 2026) ([Capterra](https://www.capterra.com/p/47428/Buildium-Property-Management-Software/reviews/)). EFT transaction fees rose by roughly **40% in 2023** ([ClearLead Digital, 2026](https://www.clearleaddigital.com/blog/buildium-review)).
  - **Avail:** Unlimited Plus went from $7/unit (earlier sources) to **$9/unit/mo** in 2026 ([RenPro](https://renpro.com/turbotenant-vs-avail/)).
  - **AppFolio:** Core now has a published 50-unit minimum, and support is increasingly AI-first (see pain points).
- **Who buys:** Independent landlords with 5-50 doors, "accidental" property managers, and small PM companies (1-10 staff, 50-300 doors). The buyer is the owner or broker-owner.
- **US market size:** Estimate: millions of individual US landlords plus tens of thousands of small PM firms. NARPM membership is in the thousands (to be verified). This is one of the largest SMB software pools we have seen. Market sizing in this file is an estimate.
- **Urgency trigger (why they'd switch NOW):**
  - **Colorado HB25-1090 took effect Jan 1, 2026.** It bans separately charged "junk fees" such as rent payment processing fees, CAM charges and property-tax pass-throughs. Rent must be advertised as one all-in figure "clearly and conspicuously," and violations carry damages at 18% interest ([Otten Johnson, Sept 24, 2025](https://www.ottenjohnson.com/news/hb25-1090-colorados-residential-landlords-must-eliminate-junk-fees-in-2026-including-cam-charges/)).
  - California security deposit cap AB 12 ([BiPact 2026 guide, not fetched; verify](https://bipactapp.com/blog/california-security-deposit-law-2026)). The move-in/move-out photo rule (AB 2801, 2025) is from memory and should be verified.
  - Buildium's repeated increases, plus the **year-end / 1099 migration window** (switch on Jan 1 for clean books).
- **Fastest-selling states/metros:** Colorado (HB25-1090 now in force), California (deposit cap, rent-control cities such as LA, SF and Oakland), Washington (statewide rent-cap law HB 1217 signed 2025; verify), New York, Oregon, plus high-landlord-count Sun Belt states (TX, FL, GA, AZ, NC).

## Pain points (evidence)
- **[Price]** A Buildium manager counted six price increases in 2.5 years and said the cost has kept rising since the acquisition (Dec 2025) ([Capterra](https://www.capterra.com/p/47428/Buildium-Property-Management-Software/reviews/)).
- **[Support/Price]** A Buildium owner said phone support was removed and direct help now costs about $1,000/yr more. Tickets come back with AI-generated answers (Mar 2026) ([Capterra](https://www.capterra.com/p/47428/Buildium-Property-Management-Software/reviews/)).
- **[Price/Hidden fees]** Buildium's EFT fees rose about 40% in 2023. A 100-door manager on Growth pays about **$337/mo** against a $192 sticker once EFT and eSign fees are added (third-party estimate) ([ClearLead](https://www.clearleaddigital.com/blog/buildium-review)).
- **[Support]** An AppFolio accountant said the team doesn't answer questions and sends users to AI instead (Sept 2025) ([Capterra](https://www.capterra.com/p/92228/AppFolio-Property-Manager/reviews/)).
- **[Lock-in/Price]** An AppFolio PM director said the minimum unit count and minimum monthly spend force small clients to pay for capacity they don't use (2022, older). The current pricing page still lists a 50-unit minimum ([Capterra](https://www.capterra.com/p/92228/AppFolio-Property-Manager/reviews/); [AppFolio](https://www.appfolio.com/pricing)).
- **[Missing features]** An AppFolio COO said rent can only be processed monthly, while their portfolio needs weekly billing, so they rely on manual workarounds (Oct 2024) ([Capterra](https://www.capterra.com/p/92228/AppFolio-Property-Manager/reviews/)).
- **[Accounting]** An AppFolio president said bill payments don't default to the correct bank account, and multiple accounts distort the balance sheet's cash section (July 2025) ([Capterra](https://www.capterra.com/p/92228/AppFolio-Property-Manager/reviews/)).
- **[Accounting]** A Buildium broker-owner said management and maintenance fees sit on separate lines with no automatic payout, so they make manual bank transfers (Mar 2026) ([Capterra](https://www.capterra.com/p/47428/Buildium-Property-Management-Software/reviews/)).
- **[Accounting]** A Buildium accountant said the bank feed is inconsistent and they reconcile every transaction by hand (May 2026) ([Capterra](https://www.capterra.com/p/47428/Buildium-Property-Management-Software/reviews/)).
- **[Complexity/UX]** A Buildium designated broker said preset reports are limiting (June 2026) ([Capterra](https://www.capterra.com/p/47428/Buildium-Property-Management-Software/reviews/)).
- **[Price]** Avail's Unlimited Plus rose to $9/unit/mo, and RenPro describes repeated per-unit hikes ([RenPro, July 2026](https://renpro.com/turbotenant-vs-avail/)).
- **[Trust/Support]** RenPro's summary of TurboTenant complaints includes a BBB complaint (late Jan-early Feb 2026) about unauthorized account activity that changed bank payout settings, and no live phone support ([RenPro](https://renpro.com/turbotenant-vs-avail/)).

## What we build (the better version)
1. **MVP: Rent collection.** ACH through Stripe/Plaid with a **flat, disclosed fee** (or landlord-absorbed). Weekly, biweekly or monthly schedules, partial payments, autopay and late-fee rules capped by state.
2. **MVP: Owner/tenant/deposit ledgers** with bank feed import, one-click owner draws, and automatic payout of management and maintenance fees. Owner statements and 1099-MISC/NEC export.
3. **MVP: State compliance engine** (the wedge). It knows each state's (and major city's) security deposit cap, return deadline and itemization rules, notice periods (entry, rent increase, non-renewal) and rent-cap math (CA AB 1482, WA, OR). It also checks **Colorado HB25-1090 all-in rent** in listings and leases. Alerts appear before a deadline is missed, and every rule links to its statute.
4. **MVP: Move-in/move-out photo inspections** on a phone, time-stamped and auto-attached to the deposit disposition letter.
5. **MVP: Unlimited e-sign** for leases and notices, with state-aware notice templates that the landlord's attorney reviews (we don't give legal advice).
6. **MVP: Maintenance requests** with AI triage (urgency, trade, photo), vendor dispatch by text, and tenant updates.
7. **MVP: One-click migration** from Buildium, AppFolio, Avail and TurboTenant CSV exports (tenants, leases, balances, deposits).
8. **V2: Listing syndication** and a vacancy site, **tenant screening via partner API** (TransUnion SmartMove type), and state application-fee cap checks.
9. **V2: Trust-account three-way reconciliation** for broker-held funds (state real estate commission rules), with CPA access.
10. **V2: AI assistant for human-reviewed tenant messages**, plus real phone and chat support from people.

## Pricing to win
- **DoorLedger:** **$1/door/mo** with a $29/mo minimum and a $249/mo cap up to 300 doors. Unlimited e-sign and inspections are included. Tenant ACH is free to the landlord, or $1 flat if passed through where legal (blocked automatically in Colorado). No onboarding fee, no annual contract, and free migration.
- **Savings example (estimate):** A 100-door PM on Buildium Growth runs about $337/mo, per ClearLead's worked example. On DoorLedger it's $100/mo, a saving of about **$2,800/yr**. A 40-door manager who can't meet AppFolio's 50-unit Core minimum pays $40/mo.

## Go-to-market (first 100 customers)
- **NARPM** (National Association of Residential Property Managers): exhibit at national and chapter events and offer a member discount.
- **Local landlord and REIA associations:** state apartment and landlord associations and local real estate investor associations (REIAs). Many in CO, CA and WA hold 2026 "new law" seminars, where we sponsor a compliance talk.
- **Communities:** r/Landlord, r/PropertyManagement, r/realestateinvesting and BiggerPockets forums; answer "Buildium raised prices again" threads with a switching guide.
- **Free lead magnets:** a "Colorado HB25-1090 listing checker" and a "Security deposit deadline calculator by state." SEO pages: "Buildium alternative," "AppFolio under 50 units," "Avail price increase."
- **Partners:** real estate CPAs and bookkeepers (year-end migration), and landlord-tenant attorneys (template review and referral).
- **Timing:** a Nov-Jan "switch before 1099 season" campaign.

## Risks and incumbent moats
- **Trust accounting and payments are hard.** Mitigation: Stripe/Plaid rails, a reconciliation-first design and CPA advisors. Start with owner-landlords before broker trust accounts.
- **Legal-rule accuracy:** state and city rules change constantly. Mitigation: rules as versioned data with statute links, a counsel-reviewed update cadence, and clear "not legal advice" language.
- **Free competitors** (TurboTenant, Avail free tiers) cover solo landlords. We win on accounting, compliance and no tenant-fee friction for landlords with 5 or more doors.
- **Switching cost** of historical ledgers. Mitigation: import opening balances plus a PDF archive of old statements.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 2 | 3 | 5 | **18** |

## Sources
- [AppFolio Property Manager Pricing (viewed Sept 2026)](https://www.appfolio.com/pricing)
- [Buildium Pricing (viewed Sept 2026)](https://www.buildium.com/pricing/)
- [Buildium Review 2026: Pricing, Hidden Fees & Alternatives – ClearLead Digital](https://www.clearleaddigital.com/blog/buildium-review)
- [AppFolio Property Manager Pricing 2026 – PricingNow (third-party estimate)](https://pricingnow.com/question/appfolio-property-manager-pricing/)
- [AppFolio Property Manager Reviews – Capterra](https://www.capterra.com/p/92228/AppFolio-Property-Manager/reviews/)
- [Buildium Reviews – Capterra](https://www.capterra.com/p/47428/Buildium-Property-Management-Software/reviews/)
- [TurboTenant vs Avail (July 2026): Pricing, Fees, and Complaints – RenPro](https://renpro.com/turbotenant-vs-avail/)
- [HB25-1090: Colorado Residential Landlords Must Eliminate "Junk Fees" in 2026 – Otten Johnson (Sept 24, 2025)](https://www.ottenjohnson.com/news/hb25-1090-colorados-residential-landlords-must-eliminate-junk-fees-in-2026-including-cam-charges/)
- [California Security Deposit Limit 2026: AB 12 – BiPact (not fetched; verify)](https://bipactapp.com/blog/california-security-deposit-law-2026)
