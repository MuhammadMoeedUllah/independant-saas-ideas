# StayDesk: a cheaper, better Guesty / Hostaway / OwnerRez for STR hosts and small managers (1-30 units), with direct booking and tax/permit compliance

**One-liner:** A flat per-property STR operating system. It combines a unified inbox and calendar, a commission-free direct-booking site (to offset Airbnb's 15.5% host-only fee), cleaner scheduling, and a **permit and lodging-tax ledger** that shows which taxes the platforms collect for you and which you still have to file yourself, city by city.

## Snapshot
- **Replaces:**
  - **Guesty:** quote-based. A reviewer said Guesty quoted a 1% payment fee but charged 1.6% ([Capterra, June 2026](https://www.capterra.com/p/159377/Guesty/reviews/)).
  - **Hostaway:** quote-based; pricing not verified in this pass.
  - **OwnerRez:** per-property sliding scale shown at **$88/mo for one property** (as fetched Sept 2026; verify). Premium add-ons (PM module, QuickBooks, hosted websites, SMS, Rezzy AI) cost extra ([OwnerRez pricing](https://www.ownerrez.com/pricing)).
  - **Hospitable:** free Essentials tier. Paid Host, Professional and Mogul plans add properties at **$10-$15/property/mo**, plus Dynamic Pricing at **$5/property**, guest vetting at $2-$8 and security deposits at a 2% fee ([Hospitable pricing, Sept 2026](https://hospitable.com/pricing)).
  - **PriceLabs:** separate pricing tool; price not verified.
- **Recent price hikes / changes:**
  - **Airbnb moved software-connected (PMS) hosts to a 15.5% host-only fee on Oct 27, 2025**, and new PMS-connected hosts from Aug 25, 2025. The old split was about 3% host and 14-16% guest. Keeping the same payout needs roughly a **14.8% rate increase** ([Rental Scale-Up, updated July 21, 2026](https://www.rentalscaleup.com/airbnb-host-only-fee/)). This makes direct bookings worth far more to hosts. Hosts discussed it on Airbnb's own forum ([Airbnb Community thread: "New 15.5% fee for hosts using property management software"](https://community.withairbnb.com/t5/Ask-about-your-listing/New-15-5-fee-for-hosts-using-property-management-software/m-p/2171026)).
  - **Marketplace tax collection keeps expanding.** Louisiana covered accommodation intermediaries from Jan 6, 2025 (occupancy taxes) and July 1, 2025 (sales tax). Maryland will require marketplaces to collect **county** lodging taxes from July 1, 2027. Hosts still owe local taxes the platforms don't collect, and all taxes on direct bookings ([Avalara MyLodgeTax, Nov 4, 2025](https://www.avalara.com/mylodgetax/en/blog/2025/11/more-states-require-short-term-rental-marketplaces-like-airbnb-and-vrbo-to-collect-lodging-taxes.html)).
  - A reviewer who upgraded from Guesty Lite to Guesty Pro said their revenue halved after the switch ([Capterra, Aug 2025](https://www.capterra.com/p/159377/Guesty/reviews/)). Whether Lite was formally sunset was not verified.
- **Who buys:** Owner-hosts with 2-10 listings and small co-hosting or management companies with 10-30 units. The buyer is the owner, and the purchase is a card purchase.
- **US market size:** Estimate: hundreds of thousands of US hosts with 2 or more listings, plus several thousand small STR management companies. Not verified in this pass; check against AirDNA or Key Data counts.
- **Urgency trigger (why they'd switch NOW):**
  - The PMS host-only fee (live since Oct 27, 2025) raises the cost of every OTA booking, so hosts need direct booking and repricing now.
  - Annual PMS renewals.
  - City permit renewals and new lodging-tax regimes (e.g., Maryland 2027).
  - World Cup 2026 host cities drew many new STR hosts who need tax registration ([Avalara, July 2025](https://www.avalara.com/mylodgetax/en/blog/2025/07/what-short-term-rental-hosts-need-to-know-about-lodging-taxes-for-the-2026-world-cup.html)).
- **Fastest-selling states/metros:** Vacation markets with heavy local tax and permit burden: Florida (Gulf and Atlantic coasts, Orlando), Tennessee (Smokies, Nashville), Colorado mountain towns, Arizona (Scottsdale), Texas (Hill Country, Galveston), the Carolinas coast, and Hawaii. Maryland ahead of its July 1, 2027 change. City list is an estimate.

## Pain points (evidence)
- **[Price]** PMS-connected hosts now pay a 15.5% host-only Airbnb fee instead of about 3%. Keeping the same payout requires raising rates by about 14.8% ([Rental Scale-Up](https://www.rentalscaleup.com/airbnb-host-only-fee/)).
- **[Support/Billing]** A Guesty customer (CEO, Apr 2026) had a billing problem unresolved for five months despite escalations. Guesty told them to pay the invoice first and take a credit later ([Capterra](https://www.capterra.com/p/159377/Guesty/reviews/)).
- **[Price/Hidden fees]** A Guesty owner (June 2026) said Guesty stated a 1% fee but actually charged 1.6%, with currency-conversion discrepancies ([Capterra](https://www.capterra.com/p/159377/Guesty/reviews/)).
- **[Price]** A listing manager (Apr 2026) said Guesty is expensive for smaller property managers ([Capterra](https://www.capterra.com/p/159377/Guesty/reviews/)).
- **[Lock-in/Migration]** A CEO (Aug 2025) said revenue halved the moment they moved from Guesty Lite to Guesty Pro ([Capterra](https://www.capterra.com/p/159377/Guesty/reviews/)).
- **[Complexity/Bugs]** A reviewer (Mar 2026) reported Guesty automation bugs, broken cleaner photo uploads and an inaccurate price optimizer. Another (Nov 2025) described a slow UI that has to be refreshed to see messages ([Capterra](https://www.capterra.com/p/159377/Guesty/reviews/)).
- **[Onboarding/Hidden cost]** A Trustpilot reviewer (Sept 11, 2026) described an undisclosed ~$2,500 website rewrite and failed Vrbo historical sync, and said it took a month to get an accounting consult. Guesty's overall TrustScore is still 4.6 ([Trustpilot](https://www.trustpilot.com/review/guesty.com)).
- **[Support]** A Hostaway owner (Nov 2025) said "24/7 phone support" goes unanswered, and dynamic-pricing sync pushed rates below their minimum on Airbnb ([Capterra](https://www.capterra.com/p/152433/Hostaway/reviews?page=3)).
- **[Reliability]** A Hostaway owner (July 2026) had multiple double bookings on the platform they picked to prevent exactly that ([Capterra](https://www.capterra.com/p/152433/Hostaway/reviews?page=3)).
- **[Complexity/UX]** A Hostaway managing director (Oct 2025) said data doesn't sync to the OTAs, which forces duplicate entry. A manager (Aug 2026) said cleaners need a separate email per host ([Capterra](https://www.capterra.com/p/152433/Hostaway/reviews?page=3)).
- **[Price]** A thread in a professional hosts Facebook group is titled "OwnerRez or Hospitable? OwnerRez is double the cost" ([Facebook](https://www.facebook.com/groups/professionalhosts/posts/6937054203057879/)).

## What we build (the better version)
1. **MVP: Unified calendar and inbox.** iCal sync for all OTAs at launch, plus the Vrbo/Booking.com APIs. The official Airbnb API follows once partner approval lands (see risks). AI drafts guest replies for human approval.
2. **MVP: Commission-free direct-booking site** per host, with all-in pricing (FTC fee rule), Stripe payments, damage deposits, guest ID check and repeat-guest emails.
3. **MVP: Airbnb fee repricing calculator.** Imports current rates and cleaning fees, shows payout before and after the 15.5% change, and suggests new rates or direct-booking discounts.
4. **MVP: Permit registry per property.** Permit number, expiry, occupancy cap, required listing display and renewal reminders.
5. **MVP: Lodging-tax ledger.** Per booking, shows which state, county and city taxes the OTA collected versus what the host owes. It produces a monthly or quarterly return worksheet for each jurisdiction and includes direct bookings.
6. **MVP: Cleaner and turnover board.** Auto-scheduled from checkouts, with one cleaner login across many hosts and photo checklists.
7. **MVP: Owner statements** for co-hosts and managers, with a commission split.
8. **V2: Official Airbnb and Booking.com connectivity**, plus dynamic pricing (native, or PriceLabs integration).
9. **V2: Tax e-filing** in top jurisdictions (or a partnership with a filing provider).
10. **V2: Smart-lock codes and noise-sensor alerts**, and a guidebook.

## Pricing to win
- **StayDesk:** **$12/property/mo** (minimum $19). Direct-booking site and cleaner board included. The tax and permit module is +$4/property. No setup fee, no contract, no payment-fee markup beyond Stripe's cost plus 0.5% (disclosed).
- **Savings (estimate):** A 5-property host on OwnerRez's shown sliding scale (starting at $88 for one) plus add-ons, or on Guesty quotes, can cut software cost by half or more. The bigger lever is **shifting 15-20% of bookings to direct**. On $300k gross, every 10% moved off PMS-connected Airbnb saves about $4,650 in Airbnb host fees (15.5% × $30k), or about $3,750 net of roughly 3% card processing (estimate).

## Go-to-market (first 100 customers)
- **Communities:** r/AirBnBHosts, r/airbnb_hosts, r/vrbo and BiggerPockets short-term rental forums. Answer "15.5% fee" and "Guesty alternative" threads with the calculator.
- **Facebook groups** for professional hosts, co-hosts and regional host groups (Smokies, Gulf Coast, Scottsdale).
- **Local host alliances and STR associations** that fight city ordinances, plus VRMA and state vacation rental associations (verify names). Sponsor their permit and tax workshops.
- **Free tools:** "Airbnb 15.5% fee calculator" and a "What lodging taxes do I owe in <city>?" lookup, then capture emails.
- **Partners:** STR accountants and bookkeepers, cleaners and turnover companies (who refer hosts), and STR property brokers.
- **SEO:** "Guesty alternative," "Hostaway alternative," "OwnerRez cheaper," and "<city> STR permit renewal."

## Risks and incumbent moats
- **Airbnb API access** is gated to approved partners, which is the biggest build risk. Mitigation: launch on iCal plus Vrbo/Booking, apply to the Airbnb partner program early, or partner with an API-connected channel manager.
- **iCal lag** causes double bookings. Mitigation: aggressive polling, buffer rules and a direct-booking-first strategy.
- **Tax accuracy liability.** Mitigation: position it as a worksheet with rate sources and dates, not a filed return, until e-file partnerships exist.
- **Crowded market** (Hospitable free tier, Lodgify, Hostfully, Smoobu). The wedge is compliance plus the fee calculator plus flat price.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 2 | 4 | 4 | **16** |

## Sources
- [Airbnb Host-Only Fee Change: Split Fee Ends – Rental Scale-Up (updated July 21, 2026)](https://www.rentalscaleup.com/airbnb-host-only-fee/)
- [New 15.5% fee for hosts using property management software – Airbnb Community (thread title)](https://community.withairbnb.com/t5/Ask-about-your-listing/New-15-5-fee-for-hosts-using-property-management-software/m-p/2171026)
- [Louisiana and Maryland require STR marketplaces to collect lodging taxes – Avalara MyLodgeTax (Nov 4, 2025)](https://www.avalara.com/mylodgetax/en/blog/2025/11/more-states-require-short-term-rental-marketplaces-like-airbnb-and-vrbo-to-collect-lodging-taxes.html)
- [Lodging taxes for the 2026 World Cup – Avalara MyLodgeTax (July 2025)](https://www.avalara.com/mylodgetax/en/blog/2025/07/what-short-term-rental-hosts-need-to-know-about-lodging-taxes-for-the-2026-world-cup.html)
- [Guesty Reviews – Capterra](https://www.capterra.com/p/159377/Guesty/reviews/)
- [Guesty – Trustpilot](https://www.trustpilot.com/review/guesty.com)
- [Hostaway Reviews (page 3) – Capterra](https://www.capterra.com/p/152433/Hostaway/reviews?page=3)
- [Hospitable Pricing (Sept 2026)](https://hospitable.com/pricing)
- [OwnerRez Pricing (Sept 2026)](https://www.ownerrez.com/pricing)
- [Email Blast Aug 28, 2025: Airbnb Service Fee Changes for API Hosts – OwnerRez](https://www.ownerrez.com/support/articles/email-blast-2025-08-28-airbnb-service-fee-changes-for-api-hosts)
- ["OwnerRez or Hospitable? OwnerRez is double the cost" – Professional Hosts Facebook group (title only)](https://www.facebook.com/groups/professionalhosts/posts/6937054203057879/)
