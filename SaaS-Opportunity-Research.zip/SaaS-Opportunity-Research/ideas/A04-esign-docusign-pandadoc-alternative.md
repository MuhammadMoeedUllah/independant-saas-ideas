# SignFlat: a cheaper, better DocuSign / PandaDoc / Dropbox Sign for owner-operated service businesses

**One-liner:** One link to quote, sign and collect a deposit, with unlimited envelopes at a flat monthly price. No per-seat pricing, no envelope caps and no auto-renew traps.

## Snapshot
- **Replaces:**
  - **DocuSign** (Verdocs, Apr 14, 2026). There is **no free sending tier**. SMS delivery, KBA and ID-verification fees aren't published, and envelope overage is billed pay-as-you-go at undisclosed rates.
    - Personal $10/mo annual or $15 monthly for **5 envelopes/mo**
    - Standard $25/user/mo annual for **100 envelopes/user/yr**
    - Business Pro $40/user/mo annual for 100 envelopes/user/yr (payments, bulk send, PowerForms)
    - Enhanced/Enterprise is custom (about $20k–$200k+/yr)
  - **PandaDoc** (Eversign, Mar 27, 2026): Free (5 docs/mo, then **$3/doc**). Starter $19 annual / **$35 monthly** per user. Business $49/$65 per user. API is Enterprise-only. Salesforce, web forms (credits), bulk send (credits, annual only), notarization and SMS verification are paid add-ons.
  - **Dropbox Sign** (formerly HelloSign) and **Adobe Acrobat Sign**: per-seat plans, not re-priced in this pass.
- **Recent price hikes / changes:**
  - **Dropbox Sign security breach, disclosed May 2024.** Attackers accessed customer emails, usernames, phone numbers, hashed passwords, **API keys, OAuth tokens and MFA data**.
  - PandaDoc reviewers report new per-document fees on integrations and features stripped from base tiers (2026).
  - DocuSign reviewers report renewals on the wrong plan with refunds refused (2026).
- **Who buys:**
  - Owner-operated firms that send quotes and contracts: contractors and remodelers, cleaners, landscapers, event vendors (DJs, photographers, caterers), agencies and freelancers.
  - Small property managers (leases, addenda).
  - Independent real-estate agents and small brokerages. After NAR's practice changes (effective **Aug 17, 2024**), a written buyer agreement is required before touring.
  The buyer is the owner, paying with a card.
- **US market size:** estimates. Millions of US service businesses send contracts. There are about 1.5M NAR members (estimate), and property management and specialty-trade firms number in the hundreds of thousands.
- **Urgency trigger (why they'd switch NOW):**
  - The DocuSign or PandaDoc annual renewal (refunds refused afterward).
  - Hitting envelope caps (5/mo or 100/user/yr).
  - New per-document fees.
  - Breach worries (Dropbox Sign).
  - Agents sending far more documents per client since Aug 2024.
- **Fastest-selling states/metros:**
  - CA, where home-improvement contracts have a statutory down-payment cap, so a tool that enforces it is a selling point (verify in the state pass).
  - TX, where agents use TREC-promulgated forms.
  - FL and AZ, with high residential construction and real-estate volume.
  - Metro focus: Sun Belt growth metros (Phoenix, Dallas, Houston, Tampa, Orlando, Charlotte).

## Pain points (evidence)
- **[Lock-in/Contracts]** DocuSign auto-renewed a subscription on a card the customer hadn't approved for it (Trustpilot, Sept 2026) ([source](https://www.trustpilot.com/review/docusign.com))
- **[Lock-in/Contracts]** A DocuSign reviewer says the refund policy applies only the first time, so miss the renewal date and you are "bound for life" (Trustpilot, Sept 2026) ([source](https://www.trustpilot.com/review/docusign.com))
- **[Price]** A reviewer calls DocuSign's basic plan an "incredible RIPOFF" at $15 for 5 envelopes a month (Trustpilot, Aug 2026) ([source](https://www.trustpilot.com/review/docusign.com))
- **[Lock-in/Contracts]** A user says DocuSign is "impossible to cancel", with website loops and no working cancel path (Trustpilot, Sept 2026) ([source](https://www.trustpilot.com/review/docusign.com))
- **[Support]** DocuSign support chat ended without any reply during setup (Trustpilot, Sept 2026) ([source](https://www.trustpilot.com/review/docusign.com))
- **[Lock-in/Contracts]** A long-term DocuSign client was renewed onto the wrong tier without warning, then told refunds aren't permitted (Trustpilot, Aug 2026). DocuSign is rated **1.3/5 across 1,247 reviews** ([source](https://www.trustpilot.com/review/docusign.com))
- **[Lock-in/Contracts]** PandaDoc charged a full annual renewal and refused a refund requested the same day (Trustpilot, Jul 29, 2026) ([source](https://www.trustpilot.com/review/pandadoc.com))
- **[Price]** A long-term PandaDoc subscriber found "covert" new **$2/document** fees on automated integrations that used to be included (Trustpilot, Jul 10, 2026) ([source](https://www.trustpilot.com/review/pandadoc.com))
- **[Price]** A PandaDoc user blew through API credits mid-month with no warning and was refused credit or a partial refund (Trustpilot, Jun 19, 2026) ([source](https://www.trustpilot.com/review/pandadoc.com))
- **[Missing features]** After upgrading to annual, a PandaDoc customer saw base-tier features cut and had to rebuild all templates (Trustpilot, Jan 15, 2026) ([source](https://www.trustpilot.com/review/pandadoc.com))
- **[Support]** A PandaDoc customer waited 3 weeks for a reply on an urgent issue, with no phone option (Trustpilot, Jun 21, 2026). PandaDoc is rated **2.2/5 across 688 reviews** ([source](https://www.trustpilot.com/review/pandadoc.com))
- **[Lock-in/Security]** In the 2024 Dropbox Sign breach, attackers took API keys, OAuth tokens, hashed passwords and MFA info ([source](https://www.helpnetsecurity.com/2024/05/02/dropbox-sign-breached/))

## What we build (the better version)
1. **Upload a PDF or Word file and AI places the fields** (signature, initials, date, text, checkbox) for each signer role. **MVP**
2. **Unlimited envelopes and templates, flat price**, with unlimited senders on the Team plan. **MVP**
3. **Legal-grade audit trail:** ESIGN/UETA consent screen, IP, timestamp and device, a tamper-evident SHA-256 hashed final PDF, and a certificate of completion. **MVP**
4. **Sign anywhere:** email, **SMS link**, QR code, or in-person tablet or kiosk mode (reuses A01 kiosk). **MVP**
5. **Quote, sign and deposit in one link.** Line items, optional add-ons the client can tick, taxes, e-signature, and a Stripe deposit or full payment at signing. **MVP**
6. **Reminders, expiry, and sequential or parallel signers.** Decline-with-reason. **MVP**
7. **Self-serve signing links** (PowerForms-style) for waivers, leases and buyer agreements, embeddable on a website. **MVP**
8. **Template import from DocuSign or PandaDoc** by uploading the PDF, with AI re-tagging of fields. **MVP**
9. **Bulk send from a CSV** (e.g., 200 tenant lease addenda). **V2**
10. **SMS OTP and ID verification** at pass-through cost. **V2**
11. **Integrations:** Google Drive/Dropbox auto-filing, QuickBooks (deposit becomes an invoice), Jobber and Housecall Pro, Zapier, and a public API. Zapier and Drive are **MVP**, the rest **V2**.
12. **State-aware contract guardrails** (e.g., cap the deposit field where a state caps home-improvement down payments, and remind the user of required notices). The user supplies the legal text; we don't author legal forms. **V2**
13. **Remote online notarization** through a partner (e.g., Proof). **V2**

## Pricing to win
- **Free:** 3 documents/mo, full audit trail.
- **Solo $12/mo:** unlimited documents, 1 sender, quotes and deposits (Stripe fees pass through).
- **Team $29/mo flat:** up to 10 senders, shared templates, bulk send when it ships.
- SMS OTP and ID verification at cost. Month-to-month, and a **cancel button that works**.
- **Savings:** a 3-person office on DocuSign Standard ($75/mo annual, capped at 300 envelopes/yr) moving to $29 saves **about $550/yr** with no cap. A 3-person sales team on PandaDoc Business ($147–195/mo) moving to $29 saves **$1,400–2,000/yr**.

## Go-to-market (first 100 customers)
- **Communities:** r/Contractor, r/HomeImprovement (pros), r/sweatystartup, r/smallbusiness, r/freelance, r/PropertyManagement, r/realtors, r/WeddingPhotography.
- **Associations:** NARPM (residential property managers), NARI and NAHB Remodelers, local REALTOR boards (CE lunch-and-learns on NAR buyer agreements), and wedding/event vendor associations.
- **SEO:**
  - "cancel DocuSign subscription"
  - "DocuSign refund after renewal"
  - "DocuSign alternative unlimited envelopes"
  - "PandaDoc alternative no per seat"
  - "PandaDoc $2 per document fee"
  - "Dropbox Sign breach alternative"
  - "quote and deposit e-sign for contractors"
- **Cross-sell** to A01/A03 customers ("send the estimate by text, collect deposit").
- **Directories:** Capterra and G2, the Zapier app directory, and Product Hunt.

## Risks and incumbent moats
- **Trust and legal validity.** Follow the ESIGN/UETA consent and record-retention requirements, publish our legal-compliance page, and exclude documents e-sign can't cover (wills, certain notices).
- **Security expectations.** Encrypt at rest, run pen tests, and start SOC 2 Type I within 6 months. Use the Dropbox Sign breach as the reason we store no long-lived OAuth tokens without need.
- **Crowded cheap market** (SignWell, BoldSign, Zoho Sign, and Acrobat bundles). Differentiate with quote + deposit + SMS for trades instead of generic e-sign.
- **Brokerage-mandated tools** for agents (transaction-management suites). Target independent agents, teams and property managers first.
- **Integration moats** (Salesforce/CPQ): enterprise only, so ignore.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 4 | 4 | 4 | **19** |

## Sources
- [DocuSign Pricing 2026: Plans, Envelope Limits, Hidden Fees – Verdocs](https://verdocs.com/blog/docusign-pricing) (Apr 14, 2026)
- [DocuSign on Trustpilot](https://www.trustpilot.com/review/docusign.com) (1.3/5, 1,247 reviews)
- [PandaDoc Pricing 2026 – Eversign](https://eversign.com/blog/pandadoc-pricing-guide) (Mar 27, 2026)
- [PandaDoc on Trustpilot](https://www.trustpilot.com/review/pandadoc.com) (2.2/5, 688 reviews)
- [Dropbox says attackers accessed customer and MFA info, API keys – Help Net Security](https://www.helpnetsecurity.com/2024/05/02/dropbox-sign-breached/) (May 2, 2024)
- [A recent security incident involving Dropbox Sign – Dropbox Sign](https://sign.dropbox.com/blog/a-recent-security-incident-involving-dropbox-sign)
- [NAR Final Reminder of Practice Change Implementation on August 17, 2024 – NAR](https://www.nar.realtor/newsroom/national-association-of-realtors-provides-final-reminder-of-august-17-nar-practice-change-implementation)
- [Consumer Guide to Written Buyer Agreements – NAR](https://www.nar.realtor/the-facts/consumer-guide-to-written-buyer-agreements)
