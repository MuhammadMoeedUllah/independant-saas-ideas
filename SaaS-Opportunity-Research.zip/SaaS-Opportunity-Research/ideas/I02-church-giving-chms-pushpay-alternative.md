# TitheBox: a cheaper, better Pushpay / ChurchStaq for small and mid-size churches

**One-liner:** Online and text giving, a member directory, kids' check-in, volunteer scheduling and year-end contribution statements for churches with 50–1,000 attendees. One flat monthly price, processing at cost, month-to-month terms, and no 2–3 year contracts.

## Snapshot
- **Replaces:**
  - **Pushpay** (Giving, ChMS and "ChurchStaq" bundles, each in Core/Advanced/Complete tiers; Catholic "ParishStaq"): **no published prices**, so every quote goes through sales. Its own pricing page lists **1-, 2- or 3-year contracts**; **early cancellation means paying the contract balance**; payment is by automatic ACH. Check scanning starts at **$0.29/check** ([Pushpay pricing, accessed Sep 24 2026](https://pushpay.com/product/pricing/)).
  - A competitor estimates Pushpay at **about $199–$399/mo** for giving only, **$399–$799/mo** with the app, and **$500–$1,500+/mo** with the ChMS. It puts processing at **2.9% + $0.30 (card)** and **1% + $0.30 (ACH)** (ChurchMemberPro, Feb 11 2026, updated Apr 4 2026; competitor estimate) ([ChurchMemberPro](https://churchmemberpro.com/blog/pushpay-review/)).
  - **Planning Center** (the popular low-cost option): modular, with free tiers per product (e.g. Giving free for 10 donations/mo, Check-Ins free for 10 check-ins/day). Giving costs **2.15% + $0.30 (card)** and **$0.30 flat (ACH)**, with "no contracts, cancel anytime". Paid tier amounts were not displayed in our fetch ([Planning Center pricing, accessed Sep 24 2026](https://www.planningcenter.com/pricing)).
  - Tithe.ly, Subsplash and Ministry Platform: not re-priced in this pass.
- **Recent price hikes / changes (switching windows):**
  - **Private-equity ownership.** Pushpay was **taken private in May 2023 by Sixth Street and BGH Capital for about NZ$1.3B**. The same competitor warns of the pricing pressure typical under PE ([ChurchMemberPro](https://churchmemberpro.com/blog/pushpay-review/)).
  - **Rebrand and bundling.** Pushpay acquired **Church Community Builder** ([ChurchTechToday](https://churchtechtoday.com/pushpay-acquires-church-community-builder/)) and now sells it bundled as "ChurchStaq" ([Pushpay pricing](https://pushpay.com/product/pricing/)). Bundling usually raises the total bill at renewal.
  - **Denominational splits.** Thousands of churches left the United Methodist Church in 2019–2023 and had to rebuild their admin, giving and database stack outside denominational systems (widely reported; verify count).
- **Who buys:** Senior or executive pastors, church administrators and finance chairs. Churches under ~300 attendees usually decide with the pastor plus a finance or elder board.
- **US market size:** Estimate: about 350,000–380,000 US congregations, with the median congregation under 100 regular attendees (Hartford Institute / National Congregations Study figures as commonly cited; verify).
- **Urgency trigger (why they'd switch NOW):**
  - Pushpay's multi-year contract end dates.
  - **Year-end statements (January)** and the fall stewardship season.
  - A church-plant launch or a denominational split, where the church needs its own stack.
  - **Q4 is peak giving:** sell in Sep–Oct to go live before Advent.
- **Fastest-selling states/metros:** TX, GA, NC, TN, AL, OK and SC (dense Protestant congregations), plus suburban growth metros (DFW, Houston, Atlanta, Nashville, Charlotte). Estimate.

## Pain points (evidence)
- **[Price]** A senior pastor calls Pushpay "extraordinarily expensive": $150/mo plus the highest per-donation fees he found (Capterra, Jan 2021) ([Capterra](https://www.capterra.com/p/142580/Pushpay/reviews/)).
- **[Lock-in/Contracts]** A board chair found the church was in a **two-year contract it could not cancel**, even after paying in full and asking to leave (Capterra, May 2023) ([Capterra](https://www.capterra.com/p/142580/Pushpay/reviews/)).
- **[Price]** A finance manager left over high processing fees on top of a renewal and subscription charge (Capterra, Aug 2022) ([Capterra](https://www.capterra.com/p/142580/Pushpay/reviews/)).
- **[Support]** A lead pastor says bank-account linking was still unresolved after a year, with missed appointments and blame-shifting (Capterra, Sep 2024) ([Capterra](https://www.capterra.com/p/142580/Pushpay/reviews/)).
- **[Support/Sales]** An owner says sales promised a free period and implementation help, then support pointed them to self-guided courses. He called the sales team deceptive (Capterra, Oct 2022) ([Capterra](https://www.capterra.com/p/142580/Pushpay/reviews/)).
- **[Missing features]** A data and finance manager says ChMS integration "could be better" and doesn't prevent duplicate records (Capterra, Oct 2020) ([Capterra](https://www.capterra.com/p/142580/Pushpay/reviews/)).
- **[Missing features]** An executive pastor says reporting falls short of the church's previous software, and custom reports are hard to run (Capterra, Jul 2019) ([Capterra](https://www.capterra.com/p/142580/Pushpay/reviews/)).
- **[Price transparency]** Pushpay publishes no prices, which one review calls "frustrating for church leaders" who need board budget approval. It also lists annual contracts as standard (ChurchMemberPro, 2026, competitor) ([ChurchMemberPro](https://churchmemberpro.com/blog/pushpay-review/)).

## What we build (the better version)
1. **MVP** Giving: web, text-to-give, QR codes, recurring gifts, fund designations and cover-the-fee (opt-in, dollar amount shown). **ACH-first nudges** to cut fees.
2. **MVP** **Year-end contribution statements** in one click (email plus print batch), with IRS-compliant wording.
3. **MVP** Member and family directory with household merge, and attendance and serving history. Import from Pushpay/CCB, Planning Center, Tithe.ly and Breeze CSVs.
4. **MVP** **Kids' check-in** on a tablet with printed security tags, allergy flags and guardian-match pickup.
5. **MVP** Volunteer scheduling with SMS reminders and swap requests.
6. **MVP** A branded mobile web app (PWA) for giving, events, groups and prayer requests; no app-store fees.
7. **V2** **Child-safety compliance:** volunteer background-check status and expiry, and abuse-prevention training tracking (links to MinistrySafe-style providers). Blocks check-in assignments for anyone not cleared.
8. **V2** Fund accounting export (QuickBooks, by fund and restricted gifts) and a check-scanning batch deposit.
9. **V2** AI "pastor's weekly brief": first-time guests to follow up, lapsed givers, and members missing 3+ weeks.
10. **V2** Multisite and Catholic-parish modes (envelope numbers, offertory).

## Pricing to win
- **$0** under 50 giving units. **$49/mo** up to 300 people. **$99/mo** up to 1,500. **$199/mo** unlimited. Everything included, month-to-month.
- Processing at cost: Stripe card rate (nonprofit discount where eligible) and ACH at 0.8% capped at $5.
- **Example (estimate):** a 250-attendee church giving $500k/yr ($300k card, $200k ACH).
  - On Pushpay at ~$299/mo and 2.9%/1%: roughly **$14,300/yr** ($3,600 subscription + $8,700 card + $2,000 ACH, before per-transaction $0.30).
  - On TitheBox ($49/mo tier): about **$8,800/yr** ($588 + ~$6,600 card at 2.2% + ~$1,600 ACH at 0.8%).
  - That saves about **$5,500/yr**, with no 2–3 year contract. Per-transaction $0.30 is similar on both sides.

## Go-to-market (first 100 customers)
- **Denominational and church-planting networks:** Southern Baptist state conventions and associations, NAMB church planters, Global Methodist Church and other post-UMC networks, Assemblies of God districts, PCA presbyteries, Acts 29. Offer a network discount plus "launch kit" onboarding.
- **Church admin communities:** NACBA (National Association of Church Business Administration) chapters, the Church IT Network, and Facebook groups for church administrators and church communications. r/churchtech and r/Pastors.
- **Church CPAs and bookkeepers** (they see every year-end-statement headache): referral fee.
- **SEO:** "Pushpay alternative no contract", "cancel Pushpay contract", "church giving fees compared", "ChurchStaq alternative".
- **Timing:** Sep–Nov (before year-end giving) and January (after the statement pain).

## Risks and incumbent moats
- **Planning Center is liked and cheap.** Our wedge is churches leaving Pushpay/CCB contracts and small churches that want one simple bundle, not Planning Center's modular setup.
- **Recurring-gift migration:** donors must re-enter cards unless we get a PCI token export. Provide donor re-enrollment campaigns (text links).
- **Child-safety liability:** check-in must be rock-solid offline (local cache) with printed tags.
- **Trust and denominational relationships:** get endorsements from network leaders.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 3 | 4 | **17** |

## Sources
- [Pushpay pricing page (accessed Sep 24 2026)](https://pushpay.com/product/pricing/)
- [Pushpay reviews – Capterra](https://www.capterra.com/p/142580/Pushpay/reviews/)
- [Pushpay review 2026 – ChurchMemberPro (competitor)](https://churchmemberpro.com/blog/pushpay-review/)
- [Planning Center pricing (accessed Sep 24 2026)](https://www.planningcenter.com/pricing)
- [Pushpay acquires Church Community Builder – ChurchTechToday](https://churchtechtoday.com/pushpay-acquires-church-community-builder/)
- [Pushpay alternatives 2026 – ChurchMemberPro](https://churchmemberpro.com/blog/pushpay-alternatives/)
