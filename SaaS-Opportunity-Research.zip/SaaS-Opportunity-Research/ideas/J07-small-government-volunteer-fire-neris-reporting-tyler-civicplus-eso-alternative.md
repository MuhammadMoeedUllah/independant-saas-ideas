# StationLog: a cheaper, simpler ESO / ImageTrend (and later Tyler / CivicPlus) for volunteer fire departments, small towns and special districts

**One-liner:** A $49/mo records system for volunteer and small combination fire departments. It files NERIS incident reports and tracks training hours, apparatus checks and member certifications. Agenda, minutes and permit modules for towns under 25k and special districts come later.

## Snapshot
- **Replaces:**
  - **ESO and ImageTrend** (fire and EMS records management) are quote-based. Pricing was **not verified in this pass**.
  - **Tyler Technologies** (ERP, utility billing, permitting, courts), **CivicPlus** (websites, agendas, recreation), **Granicus** (agendas, meetings, communications) and **OpenGov** (budgeting, permitting) are all quote-based and sold through procurement. Not verified.
  - **The federal NFIRS system** was the free fallback for many small departments. **Its final date was Jan 31 2026 and it is now retired**, replaced by NERIS ([USFA NFIRS page](https://www.usfa.fema.gov/nfirs/)).
- **Recent price hikes / changes:**
  - **Forced migration: NFIRS was sunset on Jan 31 2026** and moved to NERIS, the National Emergency Response Information System, for "fire-based, all-hazards incident reporting and analytics" ([USFA](https://www.usfa.fema.gov/nfirs/)).
  - NERIS is live ([FSRI NERIS site](https://neris.fsri.org/)) and supports integrations and data exchange. Whether small departments can file free through a government web form, or need a compatible vendor, **was not verified** (the rollout dashboard is an ArcGIS embed and could not be read).
  - Vendor price changes were not verified.
- **Who buys:**
  - Fire chiefs and officers of volunteer and combination departments, often buying with a small budget, a department card or a fire association grant.
  - Later, town clerks and administrators and special-district general managers (water, sanitation, fire, parks).
- **US market size:**
  - **20,945 fire departments** submitted 2025 incident data to NFIRS (as of Jan 5 2026), out of "over 22,000" participating ([USFA](https://www.usfa.fema.gov/nfirs/)).
  - Estimate, not verified: most US departments are all- or mostly-volunteer and serve small communities.
  - Local governments, from memory of the 2022 Census of Governments and not re-verified: about 19k municipalities, about 16k townships and about 38k+ special districts.
- **Urgency trigger (why they'd switch NOW):**
  - The **NFIRS retirement on Jan 31 2026**, so every department must report through NERIS.
  - Many states tie fire reporting to state fire marshal requirements and grant eligibility (verify per state).
  - Departments that relied on free NFIRS tools or old state-provided clients must pick a NERIS-compatible path.
- **Fastest-selling states/metros:**
  - States with many volunteer departments: PA, NY, TX, OH, IL, MO, WI, MN, IA, KY. This is an estimate by rural density. Verify with the USFA National Fire Department Registry in the per-state pass.

## Pain points (evidence)
- **[Forced migration]** NFIRS "has retired and [is] no longer available." Jan 31 2026 was the final date, and every reporting department had to move to NERIS ([USFA](https://www.usfa.fema.gov/nfirs/)).
- **[Scale of disruption]** 20,945 departments were still filing 2025 data into NFIRS as of Jan 5 2026, days before the sunset ([USFA](https://www.usfa.fema.gov/nfirs/)).
- **[Missing info]** The public NERIS pages don't spell out timeline details, whether a free portal exists, or vendor requirements. Readers are sent to a help desk and an embedded dashboard ([USFA NERIS](https://www.usfa.fema.gov/nfirs/neris/), [FSRI rollout](https://neris.fsri.org/rollout)). Small departments without IT staff face confusion.
- **Evidence gap (significant):** No verified user complaints about ESO, ImageTrend, Tyler, CivicPlus, Granicus or OpenGov were captured.
  - Reddit (r/Firefighting, r/govtech) is blocked from our fetcher.
  - CivicPlus has 0 Trustpilot reviews, and the Tyler Trustpilot page 404'd.
  - The search budget was exhausted.
  - **Needed next:** G2/Capterra reviews for ESO Fire RMS and ImageTrend Elite, state fire-chief association forums, GovTech news on Tyler implementations, and council-meeting minutes that show contract renewals and price increases (public records are a good source).

## What we build (the better version)
1. **MVP: a NERIS incident report** on a mobile-first form that asks only what NERIS needs for the incident type and can be completed on a phone after a call. It validates before submission and exports or submits through the NERIS integration path, once vendor/API access is confirmed.
2. **MVP: a member roster and certifications.** FF1/FF2, EMT, CPR and driver certifications with expiry alerts, plus state certification-hour tracking.
3. **MVP: a training log.** Sign-in by QR code at drills, hours by member and category, and reports ready for ISO/state/insurance.
4. **MVP: apparatus and equipment checks.** Daily and weekly truck checklists on a phone, SCBA and hose testing logs, and photos of defects that auto-create a maintenance ticket.
5. **MVP: a grant-ready export.** Pull the incident counts, training hours and equipment age that AFG/SAFER and state grants ask for.
6. **V2: CAD import.** Pull dispatch times from county CAD by email/CSV parsing to prefill reports.
7. **V2: small-town add-ons.** Meeting agendas and minutes (AI minutes from the recording), a public-notice posting log, and a simple permit/request portal (burn permits, facility rentals, FOIA intake).
8. **V2: a special-district pack.** Board packets, a compliance calendar (audits, rate-hearing notices, filings) and a basic customer portal. Full utility billing is out of scope.

## Pricing to win
- **Our plans:**
  - **Volunteer department:** $49/mo flat (unlimited members, incidents and apparatus), or $490/yr so it fits under small-purchase and card limits.
  - **Combination/small career department:** $149/mo.
  - **Town add-on:** $99/mo.
  - Free data migration from NFIRS exports and spreadsheets, with no implementation fee.
- **Comparison:** Incumbent prices were not verified. The hypothesis is that enterprise RMS pricing plus implementation fees is out of reach for departments with $20k–$100k budgets (estimate).

## Go-to-market (first 100 customers)
- **State fire chiefs' associations and volunteer firefighter associations** (for example Pennsylvania's and New York's volunteer associations): conference booths, newsletter ads and webinars on "NERIS reporting for volunteer departments."
- **County fire coordinators and state fire marshal offices,** which influence tool choice for dozens of departments. Offer a county-wide bundle.
- **The National Volunteer Fire Council (NVFC)** community and resources, plus volunteer-fire Facebook groups.
- **SEO:** "NFIRS replacement," "NERIS reporting software for volunteer fire departments" and "free NERIS form."
- **Card-friendly pricing** that sits under small-purchase thresholds (typically no RFP below a few thousand dollars, depending on the state; verify), so the chief or board can approve at one monthly meeting.

## Risks and incumbent moats
- **Sales speed is honestly slow.** Even small buyers need board or council approval, and there is monthly meeting cadence and fiscal-year budgeting. Volunteer departments can move faster, but they have little money.
- **NERIS integration.** If the government offers a free direct-entry option, the reporting wedge weakens and we must win on training, apparatus and grant features. If vendor integration requires certification, time to market lengthens. **This must be verified first.**
- **Incumbent bundles.** ESO and ImageTrend bundle EMS patient care reporting (ePCR), which has state EMS data requirements (NEMSIS). We stay out of EMS ePCR at first.
- **Security expectations** (CJIS for some records, state cybersecurity rules). We avoid police data.
- **Tyler/Granicus lock-in** through multi-year contracts and ERP entanglement. Town modules are V2 only.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 3 | 2 | 3 | **14** |

## Sources
- [USFA: NFIRS (final date Jan 31 2026; 20,945 departments reported 2025 data)](https://www.usfa.fema.gov/nfirs/)
- [USFA: NERIS overview](https://www.usfa.fema.gov/nfirs/neris/)
- [FSRI: NERIS is live](https://neris.fsri.org/)
- [FSRI: NERIS Rollout Dashboard (ArcGIS embed)](https://neris.fsri.org/rollout)
