# LawLedger: a cheaper, better Clio / MyCase / Smokeball for solo and small law firms

**One-liner:** Matters, intake, time and billing, and state-bar-ready IOLTA trust accounting in one flat-priced app. No forced AI, no hidden tiers, and your payments go to your own processor account.

## Snapshot
- **Replaces:**
  - **Clio Manage (clio.com/pricing, fetched Sep 24, 2026):**
    - Starter "from $49/user/mo", then Core, Signature and Elite tiers, all three listed as **"pricing upon request."** Elite bundles Clio Grow (intake/CRM, AI phone/web agents).
    - Clio for Personal Injury and Clio Draft (document automation) are add-ons, also priced on request ([Clio pricing](https://www.clio.com/pricing/)).
    - Earlier 2026 guides list the old ladder: EasyStart $49, Essentials $89, Complete $149 per user/mo on annual billing, with month-to-month about 10–15% higher ([Accounting Atelier, Mar 6, 2026](https://www.accountingatelier.com/blog/clio-pricing); [CounselStack, Feb 22, 2026](https://www.counselstack.io/blog/legal-practice-management-software-pricing)).
    - Clio Payments: 2.95% + $0.20 per card, 1% on eCheck ([Accounting Atelier](https://www.accountingatelier.com/blog/clio-pricing)).
  - **MyCase:** Basic $49, Pro $69, Advanced $89 per user/mo. LawPay is 2.95% + $0.20, plus a $20/mo premium subscription ([CounselStack, Feb 2026](https://www.counselstack.io/blog/legal-practice-management-software-pricing)).
  - **Smokeball:** Bill $89, Boost $139, Grow $189 per user/mo, usually on an annual commitment ([CounselStack](https://www.counselstack.io/blog/legal-practice-management-software-pricing)).
  - **PracticePanther:** Solo $59, Essential $79, Business $99 per user/mo ([CounselStack](https://www.counselstack.io/blog/legal-practice-management-software-pricing)).
  - **CosmoLex:** $99/user/mo, with accounting included ([CounselStack](https://www.counselstack.io/blog/legal-practice-management-software-pricing)).
  - **Filevine:** quote-only; not verified this pass.
  - **Also needed:** Clio users on lower tiers still need QuickBooks Online for firm accounting, at $38–$340/mo after QBO's Aug 2026 hike (see G02).
- **Recent price hikes / changes:**
  - **Tier restructure, 2026:** Clio moved from published EasyStart/Essentials/Complete prices (early 2026) to Starter/Core/Signature/Elite with most tiers "pricing upon request" (Sep 2026). Buyers can no longer compare prices without a sales call.
  - **About 34% hike:** One reviewer reports a 34% per-user monthly increase, explained as the cost of AI (Aug 17, 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
  - **Forced AI:** Firms report automatic enrollment in Clio's AI platform, AI features blocking basic billing entry, and in-app banner ads for "Clio Work" (Aug–Sep 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
  - **Background (verify):** Clio's 2025 acquisition of vLex, about $1B, is the likely source of the Clio Work / AI push. Not re-verified this pass.
- **Who buys:** Solo attorneys and 2–20 lawyer firms: family, criminal defense, estate planning, immigration, PI, real estate. The managing partner or office manager buys with a card.
- **US market size:** Estimate (background, not verified this pass):
  - About 1.3M US lawyers (ABA profile). A large share of private practitioners are in solo or small firms.
  - Serviceable market: roughly 150k–250k small firms at $50–$150 per user/mo, a large dollar pool.
- **Urgency trigger (why they'd switch NOW):**
  - Clio's 2026 AI-driven repricing and opaque tiers.
  - Annual renewals.
  - Attorney confidentiality worries about client data being used for AI (ABA Formal Op. 512, Jul 2024 — background, verify).
  - State trust-account compliance deadlines, for example California's annual CTAPP registration and self-assessment due Feb 1 (background, verify).
- **Fastest-selling states/metros:**
  - States with large solo/small-firm bars: CA, NY, TX, FL, IL, NJ, GA.
  - States with active trust-account enforcement programs: CA (CTAPP), NJ (random audit program), FL (monthly reconciliation rule). Background, to verify in the per-state pass.

## Pain points (evidence)
- **[Price]** A long-time Clio user says prices rose 34% per user per month, and that Clio's explanation tying it to AI was misleading (Aug 17, 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
- **[Product direction / confidentiality]** A long-time user objects to being auto-enrolled in Clio's AI platform without consent, and to attorney-client information being used for AI features (Sep 4, 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
- **[Complexity/UX]** Forced AI integration got in the way of simple billing entry, with no option to switch it off (Aug 24, 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
- **[Complexity/UX]** A user complains about aggressive in-app ads and banner promotions for the Clio Work upsell (Aug 6, 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
- **[Missing features / accounting]** Extensive QuickBooks Online sync failures, poor support communication, and many billing errors needing manual correction (Aug 15, 2026). Another user cites QBO sync problems and weak reporting (Sep 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
- **[Missing features / accounting]** On EasyStart, firms without the QBO integration must manually re-enter every transaction from Clio into QBO. Trust accounting still requires three-way reconciliation work ([Accounting Atelier, Mar 2026](https://www.accountingatelier.com/blog/clio-pricing)).
- **[Lock-in/Contracts]** No migration help, and a phone-only, difficult cancellation process (Sep 9, 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
- **[Billing]** A reviewer reports unauthorized credit card charges and dismissive customer service (Sep 10, 2026) ([Trustpilot](https://www.trustpilot.com/review/clio.com)).
- **[Billing]** A customer who deactivated a license was still billed for two licenses for two months, and a refund was refused on a technicality (Jun 3, 2026) ([Trustpilot p.2](https://www.trustpilot.com/review/clio.com?page=2)).
- **[Support]** An attorney says support was "almost non-existent after the sale," and Clio demanded a higher tier before it would help with data migration (Aug 2022) ([Capterra](https://www.capterra.com/p/105428/Clio/reviews/?page=16)).
- **[Price, competitor]** Smokeball users report unexpected monthly merchant-services fees of $20–$69 ([CounselStack](https://www.counselstack.io/blog/legal-practice-management-software-pricing)).
- **Balance note:**
  - Clio's Trustpilot score is 3.6/5 (about 297 reviews, Sep 2026), so complaints are concentrated rather than universal.
  - Several comparison sources (CounselStack, Accounting Atelier) are vendor or affiliate blogs. Treat them as directional.

## What we build (the better version)
1. **MVP:** Import from Clio, MyCase, PracticePanther and Smokeball (CSV exports of contacts, matters, time entries and trust ledgers). An AI maps fields and flags trust-balance mismatches on import.
2. **MVP:** Matters, contacts, a conflict check (fuzzy name search across all parties), tasks, a court-date calendar, and a document folder per matter.
3. **MVP:** **IOLTA trust accounting done right:**
   - A per-client trust ledger that blocks overdrafts.
   - Earned-fee transfers linked to invoices.
   - A **one-click three-way reconciliation report** (bank vs. trust journal vs. client ledgers), with bank CSV/Plaid import and AI matching.
   - Printable month-end packets for bar audits.
4. **MVP:** Time and expense tracking, flat-fee and hourly invoices, evergreen retainers with auto-replenish requests, and LEDES export (1998B) for insurance defense.
5. **MVP:** Payments through the firm's own Stripe account (Connect Standard) with **trust/operating account separation**: card fees always hit operating, never trust. Pass-through pricing, no markup.
6. **MVP:** An intake form and lead pipeline (website form to consult booking to engagement letter e-sign to retainer paid) that replaces Clio Grow.
7. **MVP:** An **AI "off by default" policy.** AI drafting (engagement letters, client updates, time-entry cleanup) is opt-in per matter, with a written no-training/no-retention statement for bar ethics files.
8. **V2:** State rule packs, starting with CA, FL, NY, TX, NJ and IL:
   - Record-retention periods.
   - Reconciliation frequency reminders.
   - A CA CTAPP self-assessment helper.
   - IOLTA remittance and interest-reporting notes.
9. **V2:** Built-in operating-account bookkeeping (GL, P&L, 1099s), so small firms can drop QBO.
10. **V2:** A client portal (secure messages, document requests, invoices), court-rule deadline calculators by state, and a mobile app with timers.

## Pricing to win
- **Plans:** Solo $39/mo flat, with everything including trust accounting and intake. Firm $29/user/mo (2+ users). No annual lock-in. Free concierge migration.
- **Payments:** At processor cost through the firm's own Stripe account.
- **Example, 3-attorney firm (estimate):**
  - Clio Essentials at the early-2026 list price ($89 × 3 = $267/mo) plus Clio Grow (quote-only; estimate $100+/mo) plus QBO Plus ($140/mo) ≈ **$500+/mo**.
  - LawLedger Firm = $87/mo, with bookkeeping included from V2.
  - Savings: about **$4,900/yr** (estimate; Clio upper-tier and Grow prices are now quote-only).

## Go-to-market (first 100 customers)
- **Communities:** r/LawFirm, r/Lawyertalk, r/Ask_Lawyers (vendor-rules-permitting), Lawyerist Insider community, solo/small-firm Facebook groups (e.g., "Lawyers Working Smarter"-type groups), ABA Law Practice Division.
- **State bars:**
  - Solo & Small Firm sections of state bars. Many run member-benefit programs and practice-management advisors, for example the Florida Bar LegalFuel and similar PMA programs in other states (verify each).
  - Get listed as a member benefit and offer free CLE on "trust accounting and three-way reconciliation."
- **Conferences:** ABA TECHSHOW (Chicago, spring), state bar annual meetings, Clio Cloud Conference counter-programming, ILTACON (too big; skip).
- **SEO "switch from X" pages:**
  - "Clio price increase 2026"
  - "Clio pricing upon request"
  - "Clio AI opt out"
  - "Clio alternative trust accounting"
  - "MyCase vs LawLedger"
  - "three-way reconciliation software IOLTA [state]"
- **Partners:** Legal bookkeepers and fractional law-firm CFOs (they feel the reconciliation pain). Offer a 20% recurring referral fee.

## Risks and incumbent moats
- **Trust accounting errors are career-ending for lawyers.** Mitigation: an immutable ledger, overdraft blocks, a reconciliation engine tested against sample bar audit packets, and E&O insurance for us.
- **Integration breadth** (Clio has hundreds of integrations). Mitigation: Zapier plus the 10 integrations small firms actually use (Google/Microsoft 365, Dropbox, QBO, LawPay export, DocuSign alternative).
- **Payments incumbents** (LawPay, a bar-endorsed partner in many states). Mitigation: support LawPay as a connector and Stripe as the default.
- **Security/confidentiality:** SOC 2 Type I within 6–9 months, encryption, and no model training on client data. This is a sales point against Clio's AI push.
- **Crowded category** (MyCase, PracticePanther, Smokeball, CosmoLex, Actionstep, Lawcus). Mitigation: a flat price, trust accounting as the hero feature, and an "AI off by default" stance.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 3 | 4 | 4 | **19** |

## Sources
- [Clio pricing page (fetched Sep 24, 2026)](https://www.clio.com/pricing/)
- [Clio reviews (Trustpilot, 3.6/5, Sep 2026)](https://www.trustpilot.com/review/clio.com)
- [Clio reviews page 2 (Trustpilot)](https://www.trustpilot.com/review/clio.com?page=2)
- [Clio Pricing Breakdown 2026 (Accounting Atelier, Mar 6, 2026)](https://www.accountingatelier.com/blog/clio-pricing)
- [Legal Practice Management Software Pricing 2026 (CounselStack, Feb 22, 2026)](https://www.counselstack.io/blog/legal-practice-management-software-pricing)
- [Clio reviews page 16 (Capterra)](https://www.capterra.com/p/105428/Clio/reviews/?page=16)
- [Clio (Wikipedia)](https://en.wikipedia.org/wiki/Clio_(software_company))
