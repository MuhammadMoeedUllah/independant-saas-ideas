# PostedUp: a cheaper, better Poster Guard / GovDocs / Mineral for small multi-state employers

**One-liner:** A $9-per-location labor-law compliance feed that keeps your required posters (paper and electronic) current. It also checks job ads against pay-transparency rules, tracks minimum-wage and sick-leave changes by city, and tells you in plain English what to do by when.

## Snapshot
- **Replaces:**
  - **Poster Guard (ComplyRight)** prices are per location, per year ([posterguard.com, checked Sep 24 2026](https://www.posterguard.com/)):
    - Right to Work/E-Verify service: $29.95/yr.
    - Binder service: $98.95/yr.
    - **E-Service for remote workers: $15.95 per employee per year.**
    - Mandatory Employee Handout service: $289 for 12 months.
    - The price of the core poster compliance service is not shown on the homepage (not verified).
  - **GovDocs** (enterprise poster and minimum-wage content) is quote-based. Not verified.
  - **Mineral** (HR compliance and advice) is mostly sold bundled through PEOs, brokers and insurers. Direct pricing was not verified in this pass.
  - Payroll and HR add-ons (Gusto, BambooHR) bundle some compliance alerts. Not analyzed here.
- **Recent price hikes / changes:**
  - No dated incumbent price hike was found.
  - The churn comes from the law itself. Poster Guard's own homepage lists five mandatory poster changes dated **September 2026 alone**: DC Paid Family Leave, Connecticut Electronic Monitoring, Louisiana Earned Income Credit, Louisiana Child Labor, and Virginia Seizure First Aid ([posterguard.com](https://www.posterguard.com/)).
  - Poster Guard says it has shipped more than 1,000,000 replacement posters since 2004.
- **Who buys:**
  - Owners and office managers of employers with 5–200 staff, especially multi-location ones (restaurants, retail, clinics, franchises, home-services).
  - Employers with remote staff in other states, and in-house recruiters posting jobs.
- **US market size:** Estimate: about 6 million US employer firms (Census SUSB order of magnitude, not re-verified in this pass). Every one of them must display federal and state posters, and many must also display city/county notices.
- **Urgency trigger (why they'd switch NOW):**
  - **Pay-transparency laws** now reach most large labor markets, and more take effect through 2027 (see list).
  - Minimum-wage changes on Jan 1 and Jul 1, and city ordinances.
  - **Scam "compliance" mailers** frighten owners into paying for posters that are free. We can turn that fear into a trustworthy, cheap subscription.
- **Fastest-selling states/metros:**
  - Pay-transparency states: CA, CO, WA, NY, NJ, IL, MN, MA, VT, MD, plus DE in 2027.
  - Local-ordinance-heavy metros: NYC, Chicago/Cook County, Los Angeles/SF Bay Area, Seattle, Denver, Minneapolis/St. Paul, Cleveland/Columbus (local pay transparency, not verified in this pass).

### Pay-transparency changes with dates ([Hunton, Dec 16 2025](https://www.hunton.com/hunton-retail-law-resource/several-states-enact-pay-transparency-laws-what-employers-need-to-know-in-2026))
- **New Jersey: Jun 1 2025.** Job postings need a good-faith range and a benefits description, and current employees must be told about promotion opportunities.
- **Vermont: Jul 1 2025.** Explicitly covers remote roles that report to a Vermont office.
- **Massachusetts: Oct 29 2025.** Employers with 25+ employees must give ranges in postings, promotions and transfers.
- **Washington: 2025 amendment** adds a 5-business-day grace period to fix a non-compliant posting.
- **California: Jan 1 2026 amendment** redefines "pay scale" as a good-faith estimate of the expected hiring range.
- **Delaware: Sep 26 2027**, a new law requiring a good-faith min–max range.
- **Already in force** (not re-verified in this pass): Colorado (2021), New York, Illinois (Jan 1 2025), Minnesota (Jan 1 2025), Maryland (Oct 1 2024), Washington, California.

## Pain points (evidence)
- **[Scams/Price]** A Utah business got an official-looking letter from "LLCS" demanding **$114** for posters and threatening "fines in excess of $7,000 per instance." The Utah Labor Commission said "we see these quite often" and that all required posters are free online ([KSL Investigates, Dec 13 2023](https://www.ksl.com/article/news/features/ksl-investigates/small-business-owner-warns-of-letters-threatening-fines-for-noncompliance-over-workplace-posters/51572864)).
- **[Scams]** The BBB issued a scam alert: "Don't pay for free labor law posters" (Illinois; [WEVV](https://www.wevv.com/news/illinois/bbb-scam-alert-dont-pay-for-free-labor-law-posters/article_f7c5fea4-8680-59bf-a7de-7042485fcb81.html), headline from search results, article not opened).
- **[Scams]** Poster vendors themselves publish warnings about lookalike scam mailers, which shows how common the problem is ([GovDocs: Employers beware](https://www.govdocs.com/employers-beware-labor-law-poster-vendor-scams/); [Poster Compliance Center](https://www.postercompliance.com/blog/small-business-scam/); both are headlines from search results).
- **[Complexity]** Five mandatory poster changes across four jurisdictions in one month (Sep 2026) is more than a small employer can track by hand ([posterguard.com](https://www.posterguard.com/)).
- **[Price model]** Remote-worker e-posters are priced **per employee** ($15.95 per employee per year), so the bill grows with headcount even though the content is the same ([posterguard.com](https://www.posterguard.com/)).
- **[Complexity]** The rules differ by state: MA applies at 25+ employees, NJ requires internal promotion notices, VT covers remote roles, and WA now allows a 5-day cure. One national job ad cannot comply everywhere without per-state checks ([Hunton, Dec 2025](https://www.hunton.com/hunton-retail-law-resource/several-states-enact-pay-transparency-laws-what-employers-need-to-know-in-2026)).
- **[Complexity]** California redefined "pay scale" on Jan 1 2026, so job ads written under the old rule may now be non-compliant ([Hunton](https://www.hunton.com/hunton-retail-law-resource/several-states-enact-pay-transparency-laws-what-employers-need-to-know-in-2026)).
- **Evidence gap:** No direct user reviews of Mineral, Poster Guard or GovDocs were captured. ComplyRight and LaborLawCenter have essentially no Trustpilot reviews, and the search budget ran out. Next pass: Capterra/G2 for Mineral, BBB profiles for poster vendors, and r/smallbusiness and r/humanresources threads.

## What we build (the better version)
1. **MVP: location-aware poster packs.** Enter your addresses and get the federal, state, county and city posters as print-ready PDFs.
   - The posters are sourced from the free official agency files, with source links shown.
   - Mailed laminated replacements are available at cost.
2. **MVP: an e-poster portal for remote and hybrid staff.** A single link per employee, acknowledgment tracking and an audit log, at a flat price rather than per employee.
3. **MVP: a law-change feed with actions.** When a rule changes, you get an email or SMS in plain English: what changed, who it affects, what to do and by what date. It includes "print these 2 pages and replace the old ones."
4. **MVP: a pay-transparency job-ad checker.** Paste a job ad or install the Chrome extension on Indeed/LinkedIn/ZipRecruiter.
   - It flags missing ranges, benefits language and remote-role triggers for CA, CO, WA, NY, NJ, IL, MN, MA, VT, MD and DE, and suggests a compliant rewrite.
5. **MVP: a minimum-wage and sick-leave calendar** for every location. It covers upcoming increases, accrual rules and required notices, with a 30-day alert before each change.
6. **MVP: an "Is this letter real?" checker.** Upload a mailer and AI compares it with known scam patterns and official agency sources.
7. **V2: payroll sync** (Gusto, QuickBooks Payroll, ADP RUN APIs) to flag any wage below an upcoming local minimum.
8. **V2: a handbook builder** with state addenda (sick leave, leave laws) and e-signature acknowledgment.
9. **V2: a franchise/multi-location console** plus white-label for PEOs, payroll resellers and insurance agents.

## Pricing to win
- **Our plans:**
  - **$9/mo per location**, including digital posters, remote e-posters for unlimited employees, the law-change feed and the minimum-wage calendar.
  - **+$9/mo** for the job-ad checker with unlimited checks.
  - Printed replacements at cost (about $5–$15 per shipment, an estimate).
- **Example: 3 locations plus 10 remote staff:**
  - Poster Guard e-service alone is 10 × $15.95 = $159.50/yr, before the core poster service and binders.
  - PostedUp is 3 × $9 × 12 = $324/yr all-in.
  - The advantage grows with remote headcount and with pay-transparency hiring.

## Go-to-market (first 100 customers)
- **Anti-scam SEO and PR:** "Got a labor-law poster letter demanding $114? Here's the free truth." Pitch local TV consumer desks (the KSL story is the template) and BBB chapters.
- **Channels:** r/smallbusiness, r/humanresources, r/restaurateur, r/franchise and SHRM chapter meetups.
- **Partners:** payroll resellers and accountants (Gusto Partner Directory, QuickBooks ProAdvisors), insurance agents who sell EPLI, and franchise brands (one deal covers dozens of locations).
- **Marketplaces:** the Gusto App Directory, the QuickBooks App Store, and a Chrome Web Store listing for the job-ad checker as a top-of-funnel tool.
- **State-deadline campaigns:** cold email to recruiters posting non-compliant ads in MA, NJ and VT (the ads are public), and to Delaware employers ahead of Sep 26 2027.

## Risks and incumbent moats
- **Content accuracy is the product.** We would need a small legal-ops team plus AI monitoring of agency sites and legislatures, show source links and review dates, and carry E&O insurance.
- **Posters themselves are free.** The value is monitoring, localization and action. That must be clear so we don't look like the scammers.
- **Payroll and HR suites bundle this.** We win on multi-location, local ordinances, remote workers and job-ad checking, which the payroll suites do poorly (hypothesis to validate).
- **Mineral is locked in through broker/PEO bundles.** We would go around it via direct SMB buyers and franchise brands.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 3 | 4 | 5 | **18** |

## Sources
- [Poster Guard (ComplyRight) homepage, prices and Sep 2026 updates](https://www.posterguard.com/)
- [KSL Investigates: letters threatening fines over workplace posters (Dec 13 2023)](https://www.ksl.com/article/news/features/ksl-investigates/small-business-owner-warns-of-letters-threatening-fines-for-noncompliance-over-workplace-posters/51572864)
- [Hunton: Several states enact pay transparency laws, 2026 (Dec 16 2025)](https://www.hunton.com/hunton-retail-law-resource/several-states-enact-pay-transparency-laws-what-employers-need-to-know-in-2026)
- [WEVV/BBB: Don't pay for free labor law posters](https://www.wevv.com/news/illinois/bbb-scam-alert-dont-pay-for-free-labor-law-posters/article_f7c5fea4-8680-59bf-a7de-7042485fcb81.html) (search-result title)
- [GovDocs: Employers beware, labor law poster vendor scams](https://www.govdocs.com/employers-beware-labor-law-poster-vendor-scams/) (search-result title)
- [GovDocs: Pay transparency laws by state](https://www.govdocs.com/pay-transparency-laws/) (search-result title)
