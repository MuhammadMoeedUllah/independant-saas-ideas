# UnitLedger: a cheaper, simpler Storable (SiteLink / storEDGE) for independent self-storage operators, with a state lien-sale workflow built in

**One-liner:** Cloud self-storage management for owner-operators with 1-10 facilities. It covers online rentals and e-leases, autopay that actually posts, a facility map, gate-code automation, and a **state-by-state lien and auction workflow** (notice timelines, verified mail or email where allowed, online auction advertising, late-fee caps). It uses flat pricing and lets operators choose their own payment processor.

## Snapshot
- **Replaces:**
  - **Storable Edge (storEDGE):** rated 4.4/5 on 237 reviews. **SiteLink Web Edition:** 4.7/5 on 452 reviews. Both are Storable products.
  - **Easy Storage Solutions:** 4.8/5 on 703 reviews.
  - **6Storage, Storage Commander, CCStorage.** Capterra's self-storage category shows no list prices for these and cites an industry entry range of "$9 to $45+" ([Capterra self-storage category, Sept 2026](https://www.capterra.com/self-storage-software/)).
  - Storable pricing is quote-only and was not verified in this pass. Next step: get quotes and check Easy Storage Solutions' current pricing page, which returned a 404 at /pricing.
- **Recent price hikes / changes:**
  - A SiteLink manager said that since the Storable acquisition, costs go up **"every 1.5-2 years like clockwork"** (Apr 28, 2025) ([Capterra](https://www.capterra.com/p/92752/SiteLink-Web-Edition/reviews/)).
  - An owner said they were **forced onto Storable's merchant services platform** and then had card and refund problems (Nov 2021, older) ([Capterra](https://www.capterra.com/p/92752/SiteLink-Web-Edition/reviews/)).
  - **State lien-law modernization:** the Self Storage Association lobbies states to allow verified mail instead of certified mail, email notices, online auctions instead of newspaper ads, vehicle towing, a standard late fee of "$20 or 20 percent, whichever is greater," and limited tenant-insurance licenses ([SSA advocacy](https://www.selfstorage.org/Advocacy/State-Laws)). Each state amendment changes the workflow operators must follow, and getting it wrong exposes them to wrongful-sale liability.
- **Who buys:** Independent owner-operators and small portfolio owners (1-10 facilities, 100-800 units each), including new conversions and boat/RV storage. The buyer is the owner or a regional manager. REITs and large operators are out of scope.
- **US market size:** Estimate: roughly 50,000+ US self-storage facilities, with independents a large share by count (verify with SSA and industry fact sheets). A mid-size niche with high dollars per facility.
- **Urgency trigger (why they'd switch NOW):**
  - Recurring Storable price increases.
  - Payment-processing lock-in pain.
  - Each state's lien-law update, which means notice templates and timelines must change.
  - New facilities choosing software at opening.
  - Post-acquisition re-platforming when independents buy facilities.
- **Fastest-selling states/metros:** Texas, Florida, California, Georgia, North Carolina, Arizona, Tennessee and Ohio: high facility counts and active development (estimate). Target states with recent lien-law changes first once a per-state pass confirms them.

## Pain points (evidence)
- **[Price]** A SiteLink manager said prices rise every 1.5-2 years since Storable bought it (Apr 2025) ([Capterra](https://www.capterra.com/p/92752/SiteLink-Web-Edition/reviews/)).
- **[Lock-in/Payments]** An owner was forced onto Storable merchant services and then couldn't process some cards or issue refunds (Nov 2021, older) ([Capterra](https://www.capterra.com/p/92752/SiteLink-Web-Edition/reviews/)).
- **[Complexity/UX]** An owner called SiteLink outdated ("a dinosaur") that doesn't keep up with current computers (June 2022) ([Capterra](https://www.capterra.com/p/92752/SiteLink-Web-Edition/reviews/)).
- **[Missing features]** A manager said SiteLink's cloud portal lacked many features despite being marketed as web-based (Oct 2023) ([Capterra](https://www.capterra.com/p/92752/SiteLink-Web-Edition/reviews/)).
- **[Support]** An operations manager said storEDGE support is chat-only, with no notification when a reply arrives, and training for new users is "non-existent" (Oct 2024) ([Capterra](https://www.capterra.com/p/218435/storEDGE/reviews/)).
- **[Billing bugs]** An office manager said automatic payments weren't posting correctly to some customer accounts (Sept 2024) ([Capterra](https://www.capterra.com/p/218435/storEDGE/reviews/)).
- **[Complexity/UX]** A manager said adding a new customer on mobile is "nearly impossible" (Mar 2025) ([Capterra](https://www.capterra.com/p/218435/storEDGE/reviews/)).
- **[Billing/UX]** A property manager said tenants can accidentally switch off autopay when updating a card, and autopay settings aren't reachable in billing (June 2023) ([Capterra](https://www.capterra.com/p/218435/storEDGE/reviews/)).
- **[Implementation]** A manager said the storEDGE implementation team mishandled data setup, and promised phone integration and autopay transfer never came (Sept 2021, older) ([Capterra](https://www.capterra.com/p/218435/storEDGE/reviews/)).
- **[Missing features]** A GM called the storEDGE facility map builder "by far the weakest link" (Aug 2022) ([Capterra](https://www.capterra.com/p/218435/storEDGE/reviews/)).
- *Note:* Storable products still rate 4.4-4.7 on Capterra, so the pain is real but concentrated in price, payments and support. Reddit and SSA forum threads were not fetched in this pass.

## What we build (the better version)
1. **MVP: Online rental and move-in.** Unit picker from the facility map, e-lease with state-specific lien disclosure language, ID capture, and move-in in under 3 minutes.
2. **MVP: Billing that posts.** Autopay (Stripe or the operator's own processor), a rule that tenants can't turn autopay off by accident, prorations, rate-change letters with notice periods, and a clear delinquency ladder.
3. **MVP: Lien and auction workflow engine** (the wedge). Per state: day-count timeline from default, required notice content, delivery method (certified vs verified mail vs email where permitted), advertising method (newspaper vs online), vehicle/boat towing option, and a late-fee cap check. Every step is logged with proof of mailing for wrongful-sale defense.
4. **MVP: Drag-and-drop facility map builder** (AI traces an uploaded site plan) with occupancy heatmap.
5. **MVP: Mobile-first office.** Rent, collect, reserve and write notes on a phone. Built for unmanned and remote facilities.
6. **MVP: Revenue basics.** Street-rate vs in-place rate report, and an existing-customer rate increase (ECRI) planner with state notice rules.
7. **V2: Gate access integrations** (PTI, OpenTech, DoorKing) for automatic lockout on delinquency, and a smart-lock kiosk.
8. **V2: Online auction posting** (StorageTreasures, Lockerfox, etc.) through their partner APIs or assisted posting.
9. **V2: Tenant protection and insurance plans** through a licensed partner, following the state insurance rules the SSA flags.
10. **V2: Multi-facility dashboard** and owner reports for small portfolios.

## Pricing to win
- **UnitLedger:** **$99/mo per facility up to 300 units**, $149 up to 700, $199 beyond. Lien module included. Bring your own processor or use ours at Stripe cost plus 0.4%. No setup fee, no contract, free migration from SiteLink/storEDGE exports.
- **Savings framing:** Storable pricing is quote-only, so savings cannot be computed from public data. Next pass: gather 3-5 operator quotes. The pitch is predictable flat pricing, no forced merchant services, and lien compliance included.

## Go-to-market (first 100 customers)
- **SSA (Self Storage Association)** national events, plus **state self-storage associations** (many states have one, e.g., Texas, Florida, California; verify names). Sponsor their lien-law update sessions, the natural hook.
- **Inside Self-Storage World Expo** and regional operator meetups.
- **Communities:** r/selfstorage and self-storage investing groups on Facebook and BiggerPockets, where new independent owners and conversions cluster.
- **Partners:** self-storage brokers, developers and third-party management firms for small portfolios, plus lien-law attorneys (referral and template review).
- **Free lead magnet:** a "State lien-sale timeline calculator" and a "Wrongful-sale risk checklist."
- **SEO:** "SiteLink alternative," "storEDGE alternative," "self storage software without Storable payments," "<state> self storage lien law."

## Risks and incumbent moats
- **Gate hardware integrations** are the biggest moat. Mitigation: start with facilities using keypad codes via a simple API or manual codes. PTI and OpenTech integrations come in V2.
- **Marketplace demand:** Storable's marketplace ties are not verified here. Mitigation: Google Business, own website and aggregator listings.
- **Lien-law liability.** Mitigation: attorney-reviewed per-state rules, versioned, with "operator confirms" steps.
- **Data migration** of ledgers and delinquency status. Mitigation: import tools and parallel run for one billing cycle.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 3 | 3 | 2 | **14** |

## Sources
- [Self-Storage Software – Capterra category](https://www.capterra.com/self-storage-software/)
- [Storable Edge (storEDGE) Reviews – Capterra](https://www.capterra.com/p/218435/storEDGE/reviews/)
- [SiteLink Web Edition Reviews – Capterra](https://www.capterra.com/p/92752/SiteLink-Web-Edition/reviews/)
- [State Laws / Lien Law Advocacy – Self Storage Association](https://www.selfstorage.org/Advocacy/State-Laws)
