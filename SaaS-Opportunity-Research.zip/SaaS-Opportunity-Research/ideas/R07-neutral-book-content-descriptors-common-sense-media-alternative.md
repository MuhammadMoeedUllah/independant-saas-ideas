# ReadClear: a cheaper, clearer Common Sense Media for books, with neutral content descriptors for parents, teachers and librarians

**One-liner:** Transparent, evidence-labeled content descriptors for children's and YA books, plus family preference profiles and "similar but gentler (or more challenging)" recommendations. The product describes what a book contains and leaves the judgment to the parent, teacher or librarian.

> Positioning rule: **descriptive, not judgmental.** No grades, no "inappropriate" labels, no removal lists. Each family or institution sets its own thresholds, and every descriptor shows where it came from and how confident it is.

## Snapshot
- **Replaces:**
  - **Common Sense Media membership: $3.99/mo** (join page, Sept 2026).
    - Includes unlimited reviews of movies, books and TV, "content filtering preferences," up to 6 kid profiles, and 42,000+ expert reviews across all media. A free limited account also exists ([CSM join](https://www.commonsensemedia.org/join)).
    - Book reviews cover age, quality, educational value, role models, violence, sex, language, consumerism and substances ([CSM ratings](https://www.commonsensemedia.org/about-us/our-mission/about-our-ratings/books)).
  - **Shelf Checkout** (AI app; direct new competitor):
    - Barcode scan, 25 configurable content categories, per-child green/yellow/red verdict.
    - Free to download; paid tiers not disclosed. It does not say whether its AI reads full text or only metadata ([Shelf Checkout](https://www.shelf-checkout.com/)).
  - **Volunteer rating sites:**
    - **BookLooks (shut down Mar 23, 2025**, about 700 books).
    - RatedBooks, Compass Book Ratings, Rated Reads, Book Cave. All free and all advocacy- or volunteer-run ([Book Riot, Jan 10, 2025](https://bookriot.com/booklooks-ratedbooks-and-other-unprofessional-book-review-sites/); [Shelf Checkout blog, Feb 2026](https://www.shelf-checkout.com/blog/booklooks-shutdown-what-parents-need-now/)).
  - **Reading-level tools (difficulty only, no content):**
    - Lexile "Find a Book" from MetaMetrics searches by Lexile, grade and interest ([Lexile Hub](https://hub.lexile.com/find-a-book/search)).
    - **AR BookFinder** from Renaissance shows ATOS level, interest level and quiz availability ([AR BookFinder](https://www.arbookfind.com/)).
    - Pricing for both is not shown on the pages fetched.
  - **Professional reviews (Kirkus, School Library Journal):** paid subscriptions, prices not verified this pass. **Goodreads** has free crowd reviews but no structured content fields.
- **Recent price hikes / changes:**
  - **BookLooks closed March 2025.** Its closure notice said its mission was "largely accomplished." Book Riot notes speculation about copyright and legal pressure ([Book Riot](https://bookriot.com/booklooks-shutting-down/)).
  - **Common Sense Media paywall:** Trustpilot reviewers report 2–3 free reviews a month before a subscription is required, and say a free-month option for low-income families was removed (reviews Jan 2023–Sep 2025) ([Trustpilot](https://www.trustpilot.com/review/commonsensemedia.org)).
  - **Texas SB 13, effective Sept 1, 2025:**
    - Every library item a district buys or accepts as a donation must be **listed publicly for 30 days before school-board approval**.
    - Parents can petition to force a **School Library Advisory Council** (petition threshold: the lesser of 10% of parents or 50 parents).
    - Challenges go on a state form, with a **90-day board decision**.
    - Affects **1,200+ districts** ([TASB, Aug 8, 2025](https://www.tasb.org/news-insights/3-things-to-know-about-sb-13); [Texas Library Association](https://txla.org/advocacy/sb-13-school-library-acquisition-reconsideration-collection-development/sb-13-implementation/)).
  - **Other states:**
    - Utah and South Carolina run statewide lists.
    - Some **Texas districts are "relying on AI"** to judge compliance, with inconsistent results ([Book Riot, Dec 18, 2025](https://bookriot.com/book-censorship-trends-2025/)).
    - Protective "freedom to read" laws: IL (2023), MD, MN, WA, NJ (2024), CA (AB 1078, AB 1825), CO, DE, RI, VA, VT (2025). NY and MA have bills pending ([American Libraries, June 2, 2025](https://americanlibrariesmagazine.org/2025/06/02/banning-the-book-bans/); [Book Riot](https://bookriot.com/book-censorship-trends-2025/)).
- **Who buys:**
  1. **Parents and grandparents** of 6–14-year-olds, especially of advanced readers reading above their age. Homeschool families are a strong subgroup.
  2. **Teachers** building classroom libraries (personal card).
  3. **School librarians and district library coordinators**, especially in Texas under SB 13 (small district budget, P-card).
  4. **Kids' section staff** at indie bookstores (see R05).
- **US market size:**
  - *Estimate:* tens of millions of US households with children. Unverified this pass; check Census.
  - Common Sense Media says "135M families" use it, a global marketing claim ([CSM](https://www.commonsensemedia.org/join)).
  - B2B: 1,200+ Texas districts under SB 13, plus school libraries nationwide.
  - Title universe: 4,172,222 US ISBN titles in 2025 alone ([BoSacks](https://www.bosacks.com/bosacks-speaks-out/bosacks-speaks-out-four-million-books-and-the-question-nobody-wants-to-ask)), against about 42k Common Sense reviews across all media. **Coverage is the gap.**
- **Urgency trigger (why they'd switch NOW):**
  - Texas SB 13 requires a 30-day public listing every acquisition cycle, and districts are using Google Forms and spreadsheets ([TxLA](https://txla.org/advocacy/sb-13-school-library-acquisition-reconsideration-collection-development/sb-13-implementation/)).
  - BookLooks' users lost their source in 2025.
  - Parents buy at back-to-school, before the holidays and at summer reading.
  - The federal and state reading push is bringing more books home (see R08).
- **Fastest-selling states/metros:**
  - **Texas** (SB 13 workflow).
  - Restrictive-law states (FL, IA, UT, SC, and AL by administrative code) and freedom-to-read states (IL, NJ, MD, MN, WA, CA, CO) both need **documented, whole-work, policy-based** reviews. The documentation looks different in each, and the product has to serve both.
  - Homeschool-heavy states (TX, FL, NC, AZ, UT) — *estimate*.

## Pain points (evidence)
- **[Price/Access]** Parents report being cut off after 2–3 free Common Sense reviews a month. One said the free-month option "disappeared," making the site "completely useless" to them (Jan 2023–Sep 2025) ([Trustpilot](https://www.trustpilot.com/review/commonsensemedia.org)).
- **[Trust]** Several Common Sense Media reviewers believe the ratings reflect the reviewers' values rather than theirs, and cite gaps between staff and community scores. Common Sense rates **2.3/5 on 21 Trustpilot reviews** ([Trustpilot](https://www.trustpilot.com/review/commonsensemedia.org)).
- **[Support]** A Common Sense member reported months of unanswered support emails (Dec 2023) ([Trustpilot](https://www.trustpilot.com/review/commonsensemedia.org)).
- **[Accuracy]** Volunteer rating sites (BookLooks, RatedBooks and others) are criticized for **out-of-context excerpts**, inconsistent scores and no editorial standards (Jan 10, 2025) ([Book Riot](https://bookriot.com/booklooks-ratedbooks-and-other-unprofessional-book-review-sites/)). A peer-reviewed analysis in the ALA's intellectual-freedom journal critiques BookLooks' report cards ([JIFP](https://journals.ala.org/index.php/jifp/article/view/8142/11594)).
- **[Coverage]** BookLooks covered only about 700 books before closing. Parents who used it were left without a source ([Shelf Checkout blog, Feb 2026](https://www.shelf-checkout.com/blog/booklooks-shutdown-what-parents-need-now/)).
- **[Missing features]** "Books don't come with content ratings" the way movies, TV and games do, so parents lack a quick, consistent check. This is a vendor's framing of the gap ([Shelf Checkout blog](https://www.shelf-checkout.com/blog/booklooks-shutdown-what-parents-need-now/)).
- **[Complexity/Workload]** Texas librarians face "a great deal of confusion and uncertainty" under SB 13. Suggested tooling is Google Forms, Google Docs and spreadsheets ([TxLA](https://txla.org/advocacy/sb-13-school-library-acquisition-reconsideration-collection-development/sb-13-implementation/)).
- **[Complexity/Workload]** SB 13 makes **every** purchased or donated item go through a 30-day public list and board approval, a recurring process with no purpose-built tool ([TASB](https://www.tasb.org/news-insights/3-things-to-know-about-sb-13)).
- **[Accuracy]** Texas districts using AI to decide which books violate the law produce inconsistent outcomes (Dec 18, 2025) ([Book Riot](https://bookriot.com/book-censorship-trends-2025/)). **This is the core risk of our own product; see Risks.**
- **[Legal]** Sift Books, which edits audiobooks to remove content, drew copyright concerns ([Book Riot](https://bookriot.com/booklooks-ratedbooks-and-other-unprofessional-book-review-sites/)). Altering or reproducing texts is legally exposed.

## What we build (the better version)
1. **MVP: Descriptor card for each title**, with fixed neutral fields:
   - Themes; violence (none, mild, moderate, intense); language; romance and sexual content level; substance use; frightening scenes.
   - Sensitive topics such as death and grief, self-harm, bullying, abuse, racism, illness and divorce.
   - Reading level: Lexile or ATOS **only where licensed or supplied by the user**; otherwise grade band.
   - Each field shows its **evidence type**: publisher metadata and BISAC codes, professional-review summary, verified reader reports, or a short licensed excerpt. It also shows a confidence level and a "last reviewed" date.
2. **MVP: "Not enough data" is a valid answer.** If a title lacks signals, we show a gap instead of guessing, and invite a report.
3. **MVP: Family profiles.** Each child gets an age, a reading band, and topics to "avoid / check / seek." Results say "matches your settings" or "check these 2 items." The parent decides, and profiles never produce a pass/fail grade for the book itself.
4. **MVP: "Similar but gentler / similar but harder" recommendations** from metadata and descriptors, with link-outs to libraries (Libby/OverDrive) and Bookshop.org affiliate revenue for indie stores (ties to R05).
5. **MVP: ISBN barcode scan and batch scan** in a bookstore or library aisle (matches Shelf Checkout).
6. **MVP: Structured crowd reports.**
   - Verified parents, teachers and librarians fill a checklist by chapter range.
   - Reputation-weighted, with dispute and correction flows, visible edit history and a correction SLA.
7. **MVP: Public methodology page** and per-title evidence links. We publish error rates from audits.
8. **V2: School and library tier.** *This overlaps R01 (ClearShelf, school-library compliance). Better to feed ReadClear's descriptor data into R01's workflow than to build a second one.*
   - Import vendor carts (CSV from school library book jobbers).
   - Auto-generate the **SB 13 30-day public acquisition list**, with professional-review citations, awards and descriptors.
   - Comment intake on the state form, a 90-day challenge-clock tracker and a board-packet export.
   - For freedom-to-read states: a reconsideration workflow that documents whole-work review against board policy.
9. **V2: Publisher and author portal.** Publishers self-declare descriptors and license approved excerpts, earning a "publisher-provided" badge. This is a legitimate data source at scale.
10. **V2: Classroom library audit** for teachers: reading-level spread, genres, and any descriptors the teacher wants surfaced.
11. **V2: Browser extension** on retailer, Goodreads and library catalog pages, plus an **API** for bookstores and library catalogs.

## Pricing to win
- **Free:** 10 lookups/mo, 1 child profile.
- **Family: $2.49/mo or $19/yr.** Unlimited lookups, 6 children, recommendations.
- **Classroom: $29/yr** per teacher.
- **School library: $299/yr per campus.** District SB 13 workflow: **$1,500–$5,000/yr by enrollment** (*estimate*, to be validated).
- **vs Common Sense Media ($3.99/mo = $47.88/yr):** Family annual saves about 60%. The price gap is modest, so the real edge is book coverage, transparency and the B2B workflow.
- Affiliate revenue from book link-outs goes partly back to indie stores.

## Go-to-market (first 100 customers)
- **Parents:**
  - Homeschool co-ops and Facebook groups, both faith-based and secular, pitched the same way: "your values, your thresholds."
  - Local parent Facebook groups and kidlit Bookstagram creators; r/Parenting and r/homeschool (research only; Reddit not fetched this pass).
- **SEO:** one page per title, e.g. "What's in [title]? content descriptors and reading level." A long tail of millions of titles with evidence tags.
- **Teachers:** a free TPT "classroom library content inventory" template that funnels into the app; teacher Instagram.
- **Librarians (Texas first):**
  - Texas Library Association conference exhibitor; TASB vendor channels; the 20 regional Education Service Centers and their purchasing cooperatives.
  - Lead offer: "SB 13 acquisition-list publisher, live in a day."
- **Bookstores:** a kids'-section widget and shelf QR codes through SpineDesk (R05).

## Risks and incumbent moats
- **Copyright and data access (biggest risk):**
  - We **cannot ingest full texts without a license**. Scanning purchased books or scraping pirated copies invites litigation; AI-and-books copyright suits have been active in 2024–2026.
  - Quoting long excerpts, as volunteer sites do, is legally exposed and is also the practice critics call "out of context."
  - **Plan:** rely on (a) publisher and ONIX metadata, BISAC codes and jacket copy through licensed aggregators, (b) short fair-use summaries of public professional reviews, or licensed review feeds, (c) structured crowd reports, and (d) publisher-provided descriptors and licensed excerpts.
  - LLMs only summarize inputs we are allowed to use.
- **Accuracy risk:**
  - An AI that confidently mislabels a book can hurt families' trust and authors' sales, and could draw product-disparagement or defamation-style claims.
  - Texas's AI-driven compliance calls are already inconsistent ([Book Riot](https://bookriot.com/book-censorship-trends-2025/)).
  - Mitigation: every claim is tied to its evidence; "insufficient data" beats a guess; humans review the top 5–10k most-searched titles; published audit error rates; fast author and publisher correction channels.
- **Misuse and political risk:**
  - The tool could be used to build removal lists, or be branded a censorship tool, and professional library groups criticize rating systems.
  - Mitigation: no excerpt-only exports; every descriptor sits alongside awards, professional-review context and whole-work framing; no "ban" or "inappropriate" labels.
  - We sell the same workflow to freedom-to-read and restrictive states.
- **Incumbent moats:** Common Sense Media's brand, nonprofit trust and 42k expert reviews; free volunteer sites; Shelf Checkout's AI head start.
- **Low willingness to pay:** consumers pay a few dollars a month at most. The B2B SB 13 workflow and affiliate revenue are needed for real revenue.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 2 | 2 | 3 | 3 | **13** |

## Sources
- [Common Sense Media: Join / membership ($3.99/mo)](https://www.commonsensemedia.org/join)
- [Common Sense Media: About our book ratings](https://www.commonsensemedia.org/about-us/our-mission/about-our-ratings/books)
- [Trustpilot: Common Sense Media](https://www.trustpilot.com/review/commonsensemedia.org)
- [Shelf Checkout homepage](https://www.shelf-checkout.com/)
- [Shelf Checkout: BookLooks shut down, what parents need now (Feb 2026)](https://www.shelf-checkout.com/blog/booklooks-shutdown-what-parents-need-now/)
- [Book Riot: Moms For Liberty is shutting down BookLooks](https://bookriot.com/booklooks-shutting-down/)
- [Book Riot: BookLooks, RatedBooks and other unprofessional review sites (Jan 10, 2025)](https://bookriot.com/booklooks-ratedbooks-and-other-unprofessional-book-review-sites/)
- [Book Riot: 2025 Book Censorship Wrapped (Dec 18, 2025)](https://bookriot.com/book-censorship-trends-2025/)
- [JIFP: Critical content analysis of BookLooks report cards](https://journals.ala.org/index.php/jifp/article/view/8142/11594)
- [TASB: 3 things to know about SB 13 (Aug 8, 2025)](https://www.tasb.org/news-insights/3-things-to-know-about-sb-13)
- [Texas Library Association: SB 13 implementation](https://txla.org/advocacy/sb-13-school-library-acquisition-reconsideration-collection-development/sb-13-implementation/)
- [TEA: SB 13 requirements related to school library materials](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials)
- [American Libraries: Banning the Book Bans (June 2, 2025)](https://americanlibrariesmagazine.org/2025/06/02/banning-the-book-bans/)
- [Lexile Find a Book](https://hub.lexile.com/find-a-book/search)
- [AR BookFinder](https://www.arbookfind.com/)
- [BoSacks: Four million books (Mar 18, 2026)](https://www.bosacks.com/bosacks-speaks-out/bosacks-speaks-out-four-million-books-and-the-question-nobody-wants-to-ask)
