# RebuildLedger: a cheaper, California-compliant Buildertrend / CoConstruct for wildfire-rebuild contractors

**One-liner:** A job system for the contractors rebuilding the 16,000+ structures lost in the January 2025 LA fires. It enforces California's home-improvement payment rules (a fixed price, a down payment of $1,000 or 10% at most, progress payments no larger than work completed), produces lender- and insurer-ready draw packets, and gives every homeowner a free portal. It costs a flat fraction of Buildertrend.

## Snapshot
- **Replaces:**
  - **Buildertrend** no longer publishes plans (2026). It quotes custom prices across 11 annual-volume brackets. Independent 2026 reviews put plans between the mid-$300s and $1,000+ a month ([Projul, updated Apr 23 2026](https://projul.com/blog/buildertrend-pricing-analysis-2026/); [JobTread, Jun 19 2026](https://www.jobtread.com/news/jobtread-opens-a-migration-path-for-builders-facing-the-coconstruct-phase-out)).
  - **CoConstruct** (owned by Buildertrend) takes new projects only **through Mar 31 2027** ([CoConstruct](https://www.coconstruct.com/migration)).
  - **JobTread** is $199/mo + $20 per internal user (Jun 2026, per JobTread).
  - The status quo for most small rebuild GCs is template contracts, spreadsheets for insurance and lender draws, and texting photos to homeowners (estimate; not surveyed).
- **Recent price hikes / changes:**
  - Buildertrend moved to revenue-scaled pricing in 2026, so a rebuild boom raises the bill automatically. A 65% renewal increase was reported in 2022 (via Projul). CoConstruct is being shut down.
  - **Rule change for rebuild buyers:** LA County's recovery site tells survivors that a post-disaster rebuild is legally a "home improvement project." That means the contractor "must use a fixed price contract," down payments "should not be more than $1,000 or 10%," and owners should "never sign any contract or change order that requires a progress payment larger than the value of the work completed" ([LA County Recovery](https://recovery.lacounty.gov/rebuilding/licensed-contractors-and-industry-professionals-list/)). These rules also cover ADUs and solar.
- **Who buys:** The owner or office manager of a CSLB-licensed B (general building) contractor, design-build firm, ADU/prefab builder or remodeler, typically 2–25 staff, taking 2–20 rebuild jobs in Altadena/Pasadena (Eaton) or Pacific Palisades/Malibu (Palisades). Homeowners use the portal for free and pull contractors onto the platform.
- **US market size:**
  - **Beachhead:** 16,264 structures destroyed (Eaton 9,419 + Palisades 6,845) and 2,051 damaged ([CAL FIRE Eaton](https://www.fire.ca.gov/incidents/2025/1/7/eaton-fire), [CAL FIRE Palisades](https://www.fire.ca.gov/incidents/2025/1/7/palisades-fire)). The number of contractors bidding these jobs is unknown. Estimate: low thousands of firms.
  - **Expansion:** every California home-improvement contractor, since the same contract and payment rules apply statewide (tens of thousands of CSLB licensees; verify count). Then other wildfire rebuild zones (Maui/Lahaina, Sonoma, Butte), and national remodelers through C05.
  - This is a niche beachhead that becomes a CA-wide product. Market-size score reflects that.
- **Urgency trigger (why they'd switch NOW):**
  1. Rebuild permits and starts peak in 2026–2027 (LA County publishes a [permitting progress dashboard](https://recovery.lacounty.gov/rebuilding/permitting-progress-dashboard/); figures not extracted this pass).
  2. The CoConstruct cutoff is Mar 31 2027.
  3. Insurance clocks: 36 months to collect replacement cost after a state-of-emergency loss (Ins. Code §2051.5, verify) and limits on additional living expenses (ALE) (verify). Homeowners push builders for speed and paperwork.
  4. The county's public scam warnings make "prove you follow the payment rules" a sales requirement.
- **Fastest-selling states/metros:** Los Angeles County (Altadena, Pasadena, Sierra Madre edge, Pacific Palisades, Malibu, Topanga), then Ventura and Santa Barbara remodelers, then Maui (Lahaina), then statewide CA.

## Pain points (evidence)
Direct review quotes from LA rebuild contractors were not collected (no search budget). Incumbent complaints come from C05's sources, and rebuild-specific pain comes from official guidance.
- **[Price]** Buildertrend costs are "hidden behind non-transparent sales consultations," and promised features were not delivered ([Trustpilot, Jun 2026](https://www.trustpilot.com/review/buildertrend.com)).
- **[Price]** Users report a 65% renewal increase, and nearly $1,000/mo while using only a few features ([Projul summary of ContractorTalk/Reddit](https://projul.com/blog/buildertrend-pricing-analysis-2026/)).
- **[Lock-in/Contracts]** A small builder in hardship was held to the full annual commitment ([Trustpilot, May 2026](https://www.trustpilot.com/review/buildertrend.com)). Reviewers also note there is no bulk data export ([via Projul](https://projul.com/blog/buildertrend-pricing-analysis-2026/)).
- **[Missing features]** Estimating has no proposal-to-invoice link, and tax math is manual ([Trustpilot, May 2026](https://www.trustpilot.com/review/buildertrend.com)). For rebuilds, generic tools don't enforce California's down-payment and progress-payment caps, so compliance depends on the office manager.
- **[Complexity/UX]** The interface is "nearly impossible" for non-tech users, which matters here because many rebuild clients are displaced, older homeowners ([Trustpilot, Jun 2025](https://www.trustpilot.com/review/buildertrend.com)).
- **[Lock-in]** Forced migration: CoConstruct users must leave by Mar 31 2027 ([CoConstruct](https://www.coconstruct.com/migration)).
- **[Trust/compliance]** LA County publishes contractor-scam guidance telling survivors to demand fixed-price contracts, capped deposits and progress payments that never exceed work completed, and to verify CSLB licenses ([LA County Recovery](https://recovery.lacounty.gov/rebuilding/licensed-contractors-and-industry-professionals-list/)). Legitimate contractors must now prove compliance to win jobs.
- **[Scale]** The volume is unprecedented for local builders: 16,264 structures destroyed in two fires ([CAL FIRE](https://www.fire.ca.gov/incidents/2025/1/7/eaton-fire)). Firms that did 3–5 custom homes a year are juggling 10–20 at once and need portals and draw tracking.

## What we build (the better version)
1. **MVP:** California home-improvement contract builder. Fixed-price contract with the required state notices and CSLB license block (clause list reviewed by a CA construction attorney before launch). An **automatic down-payment guard** caps the deposit at the lesser of $1,000 or 10%. E-sign for both spouses and co-owners.
2. **MVP:** Progress-payment guard. Each draw is tied to a milestone with photo and inspection evidence. The app **blocks an invoice larger than the value of work completed** and shows the running "paid vs. earned" line to both sides.
3. **MVP:** Written, e-signed change orders with price and schedule impact, required before the work. They roll into the budget and the next draw automatically.
4. **MVP:** **Draw packet generator** for mortgage-servicer loss-draft departments and insurers. One PDF bundles the invoice, % complete, photos, inspection sign-offs, conditional and unconditional lien releases (CA statutory forms), and license and insurance certificates.
5. **MVP:** Free homeowner portal with schedule, photos, selections, payments, documents, and a CSLB license-verification link. It works for families living elsewhere during the rebuild.
6. **MVP:** Permit tracker for LA County, City of LA, Pasadena and Malibu. Status fields, inspection dates and reminders are entered by hand (no API integrations in the MVP).
7. **MVP:** Sub and supplier roster with 20-day preliminary-notice log and lien-waiver collection before each draw (links to C06 LienClock).
8. **MVP:** Free concierge import from CoConstruct and Buildertrend (CSV/XLS and PDF archives), plus full export at any time.
9. **V2:** AI scope comparison. Upload the insurer's Xactimate scope PDF, map it to our estimate, and flag gaps for supplements (links to C07 ClaimKit).
10. **V2:** Wildfire-code checklist per job for WUI (Chapter 7A) materials and defensible-space items (verify current rules), with photo proof for the final inspection.
11. **V2:** Multi-lot mode for builders doing several rebuilds on one street: shared crews, bulk material orders, neighborhood schedule.
12. **V2:** Maui/Lahaina and statewide "CA home-improvement compliance" editions.

## Pricing to win
- **Our price:**
  - **Rebuild Starter** is $99/mo for up to 3 active jobs.
  - **Rebuild Pro** is $199/mo flat with unlimited jobs, internal users, subs and homeowners.
  - Month-to-month, free migration, and the homeowner portal is always free.
  - Offer 3 months free for CoConstruct users who switch before Mar 31 2027.
- **Theirs:**
  - Buildertrend quotes range from the mid-$300s to $1,000+/mo, on annual terms and scaled to volume.
  - JobTread is $199 + $20/user. A 10-user rebuild firm pays $399/mo there.
- **Savings for a typical customer:** A $6M-volume rebuild GC quoted about $700/mo by Buildertrend saves about $6,000 a year on Rebuild Pro (estimate from the reported range). The bigger win is fewer disputed draws and faster lender releases, which is not quantified.

## Go-to-market (first 100 customers)
- **Direct list:** Firms on LA County's "Licensed Contractors and Industry Professionals List" ([LA County Recovery](https://recovery.lacounty.gov/rebuilding/licensed-contractors-and-industry-professionals-list/)), plus CSLB license lookups for B contractors in LA County. Cold email and phone them with a "free compliant rebuild contract + draw packet" offer.
- **Homeowner pull:** Promote the free portal and a "check your rebuild contract" tool (down-payment and progress-payment calculator) in Eaton and Palisades survivor groups, on Nextdoor, and through Altadena, Pasadena and Palisades chambers and community rebuild workshops (verify schedules). Homeowners invite their contractors.
- **Associations:** BIA of Southern California (LA/Ventura chapter), NARI Los Angeles (verify chapter), AIA Los Angeles and Pasadena & Foothill (architects steer contractor choice), and the California Building Industry Association.
- **Partners:** Public adjusters and restoration firms (C07 tie-in), construction lenders and credit unions financing rebuild gaps, the LA Regional SBDC's disaster-recovery advisors, and bookkeepers who serve builders.
- **SEO:** "California home improvement contract down payment limit," "fire rebuild progress payment rules," "CoConstruct alternative California," "Buildertrend pricing for rebuild contractors," and "LA fire rebuild contract checklist."
- **Later:** A Maui (Lahaina) push through BIA-Hawaii and the Maui Chamber, then statewide CA remodelers through NARI chapters.

## Risks and incumbent moats
- **Time-bound beachhead.** Rebuild demand fades after about 2028. Mitigation: the CA contract and payment guardrails apply to all home-improvement work, so we re-position as the "California-compliant remodeler OS" (C05 national edition).
- **Legal accuracy.** Contract clauses and notices must match the Business & Professions Code and CSLB guidance. Mitigation: attorney-reviewed templates, a version history, and a disclaimer that we are not a law firm.
- **Competitors already running migration plays** (JobTread, Projul). Mitigation: rebuild-specific draw packets, the payment guards, and a free homeowner portal that pulls contractors in.
- **Payments.** Large tickets make card payments impractical. Use ACH and wire through Stripe and track lender checks. We never hold funds (no escrow licensing).
- **Permit integrations.** Jurisdictions have no public APIs, so tracking starts manual. Scraping is fragile, so we avoid promising automation.
- **Insurer and lender variability.** Draw requirements vary by servicer. Start with configurable packet templates and learn from the first 20 jobs.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 4 | 4 | 3 | **19** |

## Sources
- [CAL FIRE: Eaton Fire (9,419 structures destroyed, 1,076 damaged)](https://www.fire.ca.gov/incidents/2025/1/7/eaton-fire)
- [CAL FIRE: Palisades Fire (6,845 structures destroyed, 975 damaged)](https://www.fire.ca.gov/incidents/2025/1/7/palisades-fire)
- [LA County Recovery: Licensed contractors list and "Important Contract and Payment Rules"](https://recovery.lacounty.gov/rebuilding/licensed-contractors-and-industry-professionals-list/)
- [LA County Recovery: Permitting progress dashboard](https://recovery.lacounty.gov/rebuilding/permitting-progress-dashboard/)
- [CoConstruct: Migration to Buildertrend (new projects through Mar 31 2027)](https://www.coconstruct.com/migration)
- [JobTread: Migration path for builders facing the CoConstruct phase-out (Jun 19 2026)](https://www.jobtread.com/news/jobtread-opens-a-migration-path-for-builders-facing-the-coconstruct-phase-out)
- [Projul: Buildertrend Pricing 2026 (updated Apr 23 2026)](https://projul.com/blog/buildertrend-pricing-analysis-2026/)
- [Trustpilot: Buildertrend reviews](https://www.trustpilot.com/review/buildertrend.com)
- [SBA Office of Advocacy: 2025 California profile (703,903 small-business construction employees)](https://advocacy.sba.gov/wp-content/uploads/2025/06/California_2025-State-Profile.pdf)

## Verification (Sep 24 2026)
- ✅ LA County treats a rebuild as a "home improvement project". The page says "Contractors must use a fixed price contract" (no time-and-materials or cost-plus), a down payment of no more than $1,000 or 10% of the contract price "whichever amount is smaller" (which matches the MVP's lesser-of guard), and never a progress payment "larger than the value of the work completed". ADUs and residential solar are covered too ([LA County Recovery](https://recovery.lacounty.gov/rebuilding/licensed-contractors-and-industry-professionals-list/))
- ✅ Eaton Fire: 9,419 structures destroyed and 1,076 damaged ([CAL FIRE Eaton](https://www.fire.ca.gov/incidents/2025/1/7/eaton-fire))
- ✅ Palisades Fire: 6,845 destroyed and 975 damaged, for totals of 16,264 destroyed and 2,051 damaged ([CAL FIRE Palisades](https://www.fire.ca.gov/incidents/2025/1/7/palisades-fire))
- ✅ CoConstruct: "Projects can still be added through March 31, 2027". Historical projects stay viewable afterwards, and no final shutdown date is given ([CoConstruct](https://www.coconstruct.com/migration))
- ⚠️ The 36-month replacement-cost window (Ins. Code §2051.5) and the ALE limits were not checked on an official page and stay (verify)
