# FortiFile: a cheaper, better AccuLynx / JobNimbus + CompanyCam for roofers doing FORTIFIED grant jobs (Oklahoma, Louisiana, and other Gulf and hail-belt states)

**One-liner:** FortiFile is a flat-priced job workflow for roofers doing state-funded FORTIFIED roofs. It combines bid intake, a step-by-step photo checklist for the evaluator, a compliance binder for contractor credentials, and a tracker for grant payments. The goal is certification on the first pass, and the grant check without delay.

## Snapshot
- **Replaces:**
  - **AccuLynx** doesn't publish prices. Third-party estimates put it at about $350–$450/mo for 1–3 users and $900–$1,400/mo for 5–10 users, plus $500–$1,000 onboarding. E-sign, the customer portal and SMS cost extra ([Roofing Software Guide, updated Sep 8 2026](https://roofingsoftwareguide.com/guides/acculynx-pricing/)).
  - **JobNimbus** is quote-only, charging an account fee plus role-based seats ([Roofing Software Guide, updated Sep 23 2026](https://roofingsoftwareguide.com/reviews/jobnimbus-review/)).
  - **CompanyCam** (photo documentation, annual billing, checked Sep 24 2026):
    - Core is $63/mo for 1 user, Crew $129/mo for 3 users, Scale $199/mo for 3 users, and each extra user is $29/mo ([CompanyCam pricing](https://companycam.com/pricing)).
    - A 10-person crew on the Crew plan pays about $332/mo.
  - **Spreadsheets, shared drives and email**, for the program paperwork itself: licenses, certificates of insurance (COIs), subcontractor credentials and grant status.
- **Recent price hikes / changes:**
  - **The change that matters is state program money.** Grant programs now pay for FORTIFIED roofs, and some pay the contractor only after certification:
    - **Oklahoma:** Strengthen Oklahoma Homes pays up to **$10,000 per home**. **Funds go directly to the contractor after completion and submission of the FORTIFIED certification.** Homeowners choose from three qualified bidders ([OID OKReady](https://oid.ok.gov/okready/)).
    - **Louisiana:** the Louisiana Fortify Homes Program pays up to **$10,000 per roof**. New rounds are "to be announced" ([LDI LFHP](https://ldi.la.gov/fortifyhomes/)).
  - Contractor rules tightened in 2025. As of Mar 17 2025, Louisiana requires:
    - An LSLBC license under Act 422 (2025) and R.S. 37:2156.
    - An IBHS directory listing.
    - $1M general liability covering open-roof water intrusion.
    - Workers' comp.
    - The same credentials for subcontractors.
    - No public-adjuster activity.
    - Source: [LFHP contractor rules](https://ldi.la.gov/docs/default-source/documents/fortifyhomes/lfhp-contractors-rules-and-requirements.pdf).
  - Insurer discounts are now published every year. Louisiana's Jul 1 2026 Act 533 report lists 60+ insurers with FORTIFIED Roof discounts from 0.9% to 54% ([LDI Act 533 report](https://ldi.la.gov/docs/default-source/documents/propertycasualty/act-533-fortified-discount-report-2025.pdf)).
  - Incumbent roofing CRMs keep adding paid extras. We found no FORTIFIED-specific workflow in their public materials, but that wasn't verified.
- **Who buys:** The owner, production manager or office manager at a residential roofing company with 2–30 people that is (or wants to be) IBHS FORTIFIED-certified and bids on state grant jobs.
- **US market size:** estimate, not verified.
  - IBHS reports **more than 100,000 families** have chosen FORTIFIED ([FORTIFIED Home, updated Feb 11 2025](https://fortifiedhome.org/)).
  - Buyers are the FORTIFIED-certified roofers in grant states: AL, LA, OK, plus MS, SC and NC (verify each program). A rough estimate is a few thousand firms.
  - It's a niche, but it sits inside the roughly 25k–40k US roofing establishments sized in C02, so it can serve as a wedge into StormDesk.
- **Urgency trigger (why they'd switch NOW):**
  - A new grant round opens, in Oklahoma or when Louisiana announces its next round.
  - A contractor gets a grant job and must deliver evaluator-ready documentation to get paid (Oklahoma) or stay in the program (Louisiana).
  - The COI and license renewal dates Louisiana requires contractors to keep current.
  - Hail season in Oklahoma (Mar–Jun) and hurricane season (Jun–Nov) in Louisiana.
- **Fastest-selling states/metros:**
  - **Oklahoma City and Moore/Norman:** Oklahoma was #3 for major hail in 2025, with 369 events ([III](https://www.iii.org/fact-statistic/facts-statistics-hail)).
  - **Louisiana:** Baton Rouge, Lafayette, Lake Charles and New Orleans.
  - **Next:** Alabama (the Gulf coast and Mobile; verify program details), then Mississippi and South Carolina.
  - **Texas:** a follow-on market. It has no statewide FORTIFIED grant that we could confirm, but coastal WPI-8 windstorm documentation is a similar workflow (verify).

## Pain points (evidence)
Honest caveat: we found no public reviews that complain specifically about FORTIFIED paperwork. The complaints below come from the general roofing-software market. The last four bullets are program *requirements* that create the workload; they are not complaints.
- **[Price]** An AccuLynx user says the price keeps rising with no new features, every new feature costs extra, and it's too expensive for a small business (Software Advice, quoted in [Roofing Software Guide](https://roofingsoftwareguide.com/guides/acculynx-pricing/)).
- **[Price]** An AccuLynx customer cancelled after being "nickel and dimed" for basics such as e-sign and the client portal (G2, quoted in [Roofing Software Guide](https://roofingsoftwareguide.com/guides/acculynx-pricing/)).
- **[Price]** CompanyCam charges $29 per extra user, so a 10-person crew pays about $332/mo before the $79 marketing add-on ([CompanyCam pricing](https://companycam.com/pricing)).
- **[Missing features / data loss]** A JobNimbus user lost about 2,000 job photos, and support said they couldn't be restored (Capterra, via [Roofing Software Guide](https://roofingsoftwareguide.com/reviews/jobnimbus-review/)). On a grant job where payment depends on the photo evidence, that would be fatal.
- **[Lock-in / billing]** A JobNimbus customer says they were billed higher rates than discussed and kept being charged after trying to cancel ([Trustpilot, May 21 2025](https://www.trustpilot.com/review/jobnimbus.com)).
- **[Support]** A JobNimbus customer says support is "NEVER available when we need them" ([Trustpilot, Feb 13 2026](https://www.trustpilot.com/review/jobnimbus.com)).
- **[Process burden: cash flow]** In Oklahoma the grant is paid to the contractor only after the job is complete **and** the FORTIFIED certification has been submitted. The contractor carries the job cost until the paperwork clears ([OID OKReady](https://oid.ok.gov/okready/)).
- **[Process burden: credentials]** Louisiana contractors must keep current copies of every certificate, license and proof of insurance, including for subcontractors. They must disclose conflicts before starting work and may not act as evaluators or public adjusters ([LFHP contractor rules](https://ldi.la.gov/docs/default-source/documents/fortifyhomes/lfhp-contractors-rules-and-requirements.pdf)).
- **[Process burden: evaluator hand-off]** A certified FORTIFIED evaluator documents key elements and submits them to IBHS (the evaluator portal is "FOCUS"). The roofer has to capture the right items at the right stage of the install, before they're covered up ([FORTIFIED Home](https://fortifiedhome.org/), [OID OKReady](https://oid.ok.gov/okready/)).
- **[Sales complexity]** Homeowner savings vary widely: from 0.9% to 54% across 60+ Louisiana insurers. Roofers need a quick way to show "what you'll save" ([LDI Act 533 report](https://ldi.la.gov/docs/default-source/documents/propertycasualty/act-533-fortified-discount-report-2025.pdf)).

## What we build (the better version)
1. **MVP: Grant-job pipeline.** Columns: Lead (grant awardee), Bid submitted, Selected, Pre-inspection, Install, Evaluator visit, Certificate submitted, Certified, Grant paid. The dashboard shows days-to-cash for each job.
2. **MVP: FORTIFIED photo checklist.**
   - Stage-by-stage prompts for installers, e.g. deck attachment, sealed roof deck, drip edge and underlayment, before each layer is covered.
   - Required shots are blocking: a stage can't be closed until its photos are captured.
   - Every photo carries GPS and a timestamp.
   - The checklist content must follow IBHS's current published standard. We'll license or build it with an evaluator partner (verify).
3. **MVP: Evaluator packet export.** A PDF plus a zip, organized the way evaluators ask for it, shared by link. We never write into IBHS's evaluator system ourselves.
4. **MVP: Contractor compliance binder.**
   - Stores the license, IBHS listing, COIs ($1M GL in Louisiana; $500k or $1M in Oklahoma under CIB), workers' comp, and subcontractor credentials.
   - Sends expiry alerts and produces a one-click "program packet".
5. **MVP: Never-delete photo storage** with export. It's the direct answer to the lost-photos complaint.
6. **MVP: Homeowner bid page with e-sign.** Good/better/best quotes (FORTIFIED Roof, plus Silver or Gold where offered). Shows the grant amount against the homeowner's share, and a lookup of insurer discount ranges from the state's published list (Louisiana Act 533 first).
7. **MVP: Unlimited users at one flat price,** so storm-season crews don't raise the bill.
8. **V2:** A module for more states: Alabama, Mississippi, South Carolina and North Carolina program rules, and Texas coastal WPI-8 windstorm documentation (verify all).
9. **V2:** Sync with StormDesk (C02) and ClaimKit (C07). An AI check that flags blurry or missing shots before the crew leaves the roof.
10. **V2:** Grant-round alerts that notify certified contractors when the Oklahoma Insurance Department or Louisiana's Department of Insurance opens a new round, and export a homeowner-lead list where programs publish awardees (verify availability).

## Pricing to win
- **Our price:** $149/mo flat, with unlimited users and jobs, never-delete photo storage and e-sign. $199/mo when bundled with StormDesk (C02). Month-to-month, with free migration of existing CompanyCam or CRM photos.
- **Theirs:** a 10-person crew on CompanyCam Crew pays about $332/mo ([CompanyCam](https://companycam.com/pricing)), plus AccuLynx at an estimated $900–$1,400/mo ([Roofing Software Guide](https://roofingsoftwareguide.com/guides/acculynx-pricing/)), plus spreadsheets for the program paperwork.
- **Savings:** about $1,100–$1,600/mo, or roughly $13k–$19k a year, for a 10-person crew that replaces both. This is an estimate from list and third-party prices.
- **ROI line:** one grant job paid a week sooner on a $10k grant matters more to a small roofer than the subscription cost.

## Go-to-market (first 100 customers)
- **Contractor directories:** the IBHS FORTIFIED provider directory (fortifiedproviders.com is named in the LFHP rules) and state program contractor lists. Outreach to every certified roofer in Oklahoma and Louisiana first.
- **Evaluator partnerships:** FORTIFIED evaluators benefit from complete packets. Offer them a free "evaluator view" so they recommend FortiFile to roofers.
- **State insurance departments and agents:** program webinars and FAQs. Independent agents who sell the discounts can refer roofers.
- **Associations:** Oklahoma and Louisiana roofing contractor associations and home-builder associations (verify names). Also the National Roofing Contractors Association (NRCA).
- **Supply-house counter days:** ABC Supply, SRS and QXO/Beacon branches in Oklahoma City, Tulsa, Baton Rouge and Lafayette.
- **Communities:** r/Roofing, plus roofing-owner Facebook groups. Offer a free "FORTIFIED photo checklist" PDF as the lead magnet.
- **SEO:** "Strengthen Oklahoma Homes contractor", "Louisiana Fortify Homes contractor requirements", "FORTIFIED roof photo checklist", "CompanyCam alternative for FORTIFIED".

## Risks and incumbent moats
- **IBHS standard and branding.** FORTIFIED is IBHS's program and trademark, so we can't imply endorsement. We'll build checklists from public standards with an evaluator partner, name it "for FORTIFIED jobs", and seek an IBHS provider relationship.
- **Program volatility.** Grant rounds depend on appropriations, and Louisiana's lottery is closed until new rounds are announced. We'll diversify across states and keep the product useful for FORTIFIED retail jobs that insurer discounts alone justify.
- **Small niche.** The market is thousands of firms, not hundreds of thousands. Position it as a wedge into StormDesk (C02) and ClaimKit (C07) rather than a standalone company.
- **Incumbents could add a checklist.** CompanyCam and the CRMs have checklist features that could imitate this (not verified). Our moat is the program binder, evaluator packets, grant-payment tracking and flat pricing.
- **No write access to IBHS or state systems.** The product exports packets and guides uploads; it doesn't integrate, and it complies with the portals' terms of service.
- **Regulatory.** The product must never cross into public adjusting: no claim negotiation features, following the Louisiana rule and Texas practice.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 4 | 2 | **16** |

## Sources
- [Oklahoma Insurance Department: Strengthen Oklahoma Homes (OKReady)](https://oid.ok.gov/okready/)
- [Louisiana Department of Insurance: Louisiana Fortify Homes Program](https://ldi.la.gov/fortifyhomes/)
- [LDI: LFHP Contractor Rules and Requirements (Mar 17 2025)](https://ldi.la.gov/docs/default-source/documents/fortifyhomes/lfhp-contractors-rules-and-requirements.pdf)
- [LDI: Act 533 FORTIFIED discount report (Jul 1 2026)](https://ldi.la.gov/docs/default-source/documents/propertycasualty/act-533-fortified-discount-report-2025.pdf)
- [FORTIFIED Home (IBHS), updated Feb 11 2025](https://fortifiedhome.org/)
- [Oklahoma CIB: Roofing Contractor Registration](https://oklahoma.gov/cib/your-industry/roofing.html)
- [Insurance Information Institute: Facts + Statistics: Hail](https://www.iii.org/fact-statistic/facts-statistics-hail)
- [Roofing Software Guide: AccuLynx pricing (updated Sep 8 2026)](https://roofingsoftwareguide.com/guides/acculynx-pricing/)
- [Roofing Software Guide: JobNimbus review (updated Sep 23 2026)](https://roofingsoftwareguide.com/reviews/jobnimbus-review/)
- [CompanyCam pricing (checked Sep 24 2026)](https://companycam.com/pricing)
- [Trustpilot: JobNimbus reviews](https://www.trustpilot.com/review/jobnimbus.com)
