# ClubHouse: a cheaper, better TeamSnap ONE / SportsEngine / LeagueApps for youth sports clubs and rec leagues

**One-liner:** Registration, dues and installment billing, rostering, scheduling, and coach compliance (background checks, SafeSport and concussion training) for youth clubs and leagues with 100–3,000 players. Flat pricing and a desktop admin that actually works.

## Snapshot
- **Replaces:**
  - **TeamSnap:** free for single teams, with paid coach upgrades. **TeamSnap ONE for clubs and leagues is "customized pricing"**, quote only ([TeamSnap pricing, accessed Sep 24 2026](https://www.teamsnap.com/pricing)).
  - **LeagueApps:** no subscription. It takes a **per-transaction percentage** of online payments through its Stripe-powered gateway, plus a one-time setup fee and optional annual app and website fees. The rate is not published ([LeagueApps pricing, accessed Sep 24 2026](https://leagueapps.com/pricing/)).
  - SportsEngine (NBC Sports), GameChanger, PlayMetrics and Demosphere: not re-priced in this pass. Most youth platforms pass a processing or "convenience" fee to parents.
- **Recent price hikes / changes (switching windows):**
  - **TeamSnap ONE forced migration.** A club admin running 150–200 athletes says the move to TeamSnap ONE **removed desktop scheduling, invoicing and auto-rostering**. Their admin time went from about **2 hours a week to 2 hours a day** (Trustpilot, Mar 2026) ([Trustpilot](https://www.trustpilot.com/review/teamsnap.com)).
  - **Compliance pressure on volunteer-run orgs.** The Safe Sport Authorization Act of 2017 requires national governing bodies (NGBs) and their member organizations to train and report on abuse prevention for adults working with minor athletes ([Congress.gov S.534](https://www.congress.gov/bill/115th-congress/senate-bill/534)). State coach background-check and youth concussion laws add per-state requirements (see the state leads). Clubs track this in spreadsheets today.
- **Who buys:** Club directors and registrars of travel soccer, baseball/softball, basketball, volleyball, lacrosse and hockey clubs. Also volunteer boards of rec leagues (e.g. local soccer associations). Registrars and treasurers influence the choice; the board signs. Clubs are often independent 501(c)(3)s.
- **US market size:** Estimate: tens of thousands of youth sports clubs and leagues (every US soccer, baseball, basketball and hockey state association has hundreds of member clubs). Verify with NGB member-club counts in the state pass.
- **Urgency trigger (why they'd switch NOW):**
  - TeamSnap ONE migration pain.
  - **Season windows:** spring registration opens Nov–Jan; fall registration opens Apr–Jun. We sell in Sep–Nov for spring.
  - Background-check and SafeSport renewals for the new seasonal year (Aug–Sep).
- **Fastest-selling states/metros:** TX, CA, FL, GA, NJ, PA, IL, OH, NC and VA suburbs (dense travel-club markets; estimate). Also states with statutory youth-coach background-check requirements (PA clearances are the classic example; verify others).

## Pain points (evidence)
- **[Overall]** TeamSnap's Trustpilot rating is **1.1/5 across 692 reviews** (accessed Sep 24 2026) ([Trustpilot](https://www.trustpilot.com/review/teamsnap.com)).
- **[Missing features / forced migration]** A club admin says TeamSnap ONE removed desktop scheduling, invoicing and auto-rostering, taking admin work from 2 hours a week to 2 hours a day (Trustpilot, Mar 2026) ([Trustpilot](https://www.trustpilot.com/review/teamsnap.com)).
- **[Price/Billing]** A cardholder says TeamSnap took an extra **$600+** from their card, and they couldn't reach anyone (Trustpilot, May 2026) ([Trustpilot](https://www.trustpilot.com/review/teamsnap.com)).
- **[Lock-in/Contracts]** A buyer says features shown in the demo were missing, and TeamSnap charged the **full year** even though they quit after one month (Trustpilot, Dec 2025) ([Trustpilot](https://www.trustpilot.com/review/teamsnap.com)).
- **[Support]** A league member says there is no phone support. A non-user-error issue took 1h15m to resolve by chat, and commissioners get the same slow process (Trustpilot, Jul 2024) ([Trustpilot](https://www.trustpilot.com/review/teamsnap.com)).
- **[Complexity/UX]** A user says the app pushes the ad-free upgrade every time it opens, making accidental subscriptions easy (Trustpilot, Jul 2024) ([Trustpilot](https://www.trustpilot.com/review/teamsnap.com)).
- **[Lock-in]** A user says an account can't be deleted from the web app without contacting support (Trustpilot, Nov 2025) ([Trustpilot](https://www.trustpilot.com/review/teamsnap.com)).
- **[Lock-in/Billing]** A SportsEngine reviewer says there's no way to cancel and "you will get billed every month" (Trustpilot, 2025–26) ([Trustpilot](https://www.trustpilot.com/review/sportsengine.com)).
- **[Support/UX]** A SportsEngine club admin found page and roster setup unintuitive, with "little customer service" despite premium pricing (Trustpilot, 2025–26) ([Trustpilot](https://www.trustpilot.com/review/sportsengine.com)).

## What we build (the better version)
1. **MVP** Registration with age and birth-year validation, uploads (birth certificates), waivers and e-sign, sibling discounts, scholarships and fee-assistance codes.
2. **MVP** **Dues and installment plans** (ACH-first, card fallback), failed-payment retry, and a treasurer dashboard with a QuickBooks export.
3. **MVP** **Desktop-first admin:** drag-and-drop rostering (auto-roster by age, level and school), team formation, and field and practice scheduling with a conflict checker.
4. **MVP** Parent and coach app (PWA): schedules, RSVPs, team chat and SMS blasts, with no ads and no in-app upsells.
5. **MVP** **Coach compliance tracker:** background-check status and expiry, SafeSport and CDC HEADS UP concussion training certificates, and state-specific requirements. Blocks roster assignment until the coach is cleared.
6. **MVP** Import from TeamSnap, SportsEngine and LeagueApps CSV exports.
7. **V2** Integrated background checks through a CRA partner (pass-through price) and ID verification.
8. **V2** Tryouts and evaluations (evaluator scorecards on a phone, AI-assisted team balancing).
9. **V2** Tournament module: brackets, referee assignment, team check-in and hotel-block links.
10. **V2** Referee and volunteer hours (volunteer deposit and buyout fees), uniform ordering.

## Pricing to win
- **$99/mo** up to 500 players, **$199/mo** up to 2,000, **$349/mo** unlimited. Processing at Stripe cost; clubs choose absorb, pass-through, or disclose to parents at checkout. No percentage platform fee, month-to-month.
- **Example (estimate):** a 600-player club collecting $900k/yr in dues. Every 1 percentage point of platform take costs the club or its parents **$9,000/yr**. Our $2,388/yr flat price beats any percentage model above ~0.27%. We ask prospects for their actual LeagueApps or TeamSnap statement to quote exact savings.

## Go-to-market (first 100 customers)
- **State youth sports associations:** US Youth Soccer and US Club Soccer state associations, USA Hockey districts, USA Lacrosse chapters, AAU district offices, and state high-school-age club volleyball regions. Offer a compliance-tracker partnership ("free for state association audits").
- **Communities:** r/youthsports, r/bootroom (soccer coaches), and Facebook groups for club directors and registrars.
- **Events:** the United Soccer Coaches Convention (January) and state association AGMs.
- **SEO:** "TeamSnap ONE alternative", "TeamSnap ONE missing features", "youth club background check tracker [state]".
- **Timing:** Sep–Nov for spring seasons and Mar–May for fall.

## Risks and incumbent moats
- **NGB-mandated platforms:** some state associations require a specific registration system (e.g. an NGB's own player-card platform). We integrate by exporting to the NGB format instead of competing.
- **GameChanger's network effect** for scoring and streaming: we don't compete there.
- **Payments and chargebacks** at season start: use ACH-first to lower cost and risk.
- **Child safety data** (minors' birth certificates): encryption and retention limits.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 3 | 4 | 4 | **18** |

## Sources
- [TeamSnap pricing (accessed Sep 24 2026)](https://www.teamsnap.com/pricing)
- [TeamSnap reviews – Trustpilot](https://www.trustpilot.com/review/teamsnap.com)
- [SportsEngine reviews – Trustpilot](https://www.trustpilot.com/review/sportsengine.com)
- [LeagueApps pricing (accessed Sep 24 2026)](https://leagueapps.com/pricing/)
- [S.534 – Protecting Young Victims from Sexual Abuse and Safe Sport Authorization Act of 2017 – Congress.gov](https://www.congress.gov/bill/115th-congress/senate-bill/534)
