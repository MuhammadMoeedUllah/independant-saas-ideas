# ClearShelf: a cheaper, better Follett Destiny (plus a neutral state-law compliance layer) for K-12 school libraries

**One-liner:** A modern school library catalog and circulation system, sold either whole or as a thin compliance layer on top of Destiny or Alexandria. It gives each school whatever its own state law requires: a public online catalog that includes classroom libraries, parent preferences and checkout notifications, a reconsideration (challenge) workflow with the legal timelines built in, board-policy templates, an audit trail and annual reports. It never judges or rates book content itself.

> **Neutrality statement (product principle):** ClearShelf has no opinion on which books belong in a library. It ships with "state packs" that encode each state's procedural requirements. Some states require transparency, parent restriction and removal-during-review. Others ("freedom to read" states) require written collection-development policies, restrict who may file a challenge, and keep books on the shelf during review. The district's board sets the local rules and ClearShelf enforces the process and keeps the records. We do not scrape challenge lists and we do not auto-flag titles. That is a deliberate contrast with AI "book intelligence" vendors (see Risks).

## Snapshot
- **Replaces:**
  - **Follett Destiny Library Manager:** quote-only. A competitor-published estimate puts it at **$800–$3,000+ per school per year**, with the Destiny Discover "Engage" add-on at **+$300–$800/yr** (LibraryAid comparison page, 2025–26; third-party estimate, unverified) ([LibraryAid](https://libraryaid.net/school-library-management-software)).
    - About **75,000 school libraries** use Destiny, making it the dominant US K-12 system (Library Technology Guides, Mar 2022) ([LTG](https://librarytechnology.org/document/27189)).
  - **Alexandria (COMPanion):** from **$499/yr** (Capterra listing, 2026) ([Capterra](https://www.capterra.com/p/27788/Alexandria/)).
  - **OPALS:** Capterra lists "$25/user/month". OPALS is usually quoted per library or consortium, so verify before relying on it ([Capterra](https://www.capterra.com/p/82990/OPALS/)).
  - **Atriuum (Book Systems):** 90 new contracts and 5,477 total installations in Breeding's 2026 report ([LTG 2026](https://librarytechnology.org/document/32505)). Mandarin M5 and Surpass were not priced in this pass.
  - **Bookmarked** (a new Texas "book intelligence" compliance vendor): **$2–$3 per student per year**, with 150+ Texas districts (K-12 Dive, Apr 2 2026) ([K-12 Dive](https://www.k12dive.com/news/as-ai-enters-book-ban-disputes-heres-what-it-means-for-school-districts/816385/)).
- **Recent price hikes / changes (switching windows):**
  - **PE ownership:** Francisco Partners bought Follett School Solutions (Destiny), announced Sep 1 2021 ([Business Wire](https://www.businesswire.com/news/home/20210901005798/en/Francisco-Partners-Acquires-Follett-School-Solutions)). 2025–26 G2 reviewers say billing and support got worse "since the acquisition" ([G2](https://www.g2.com/products/follett-software-follett-destiny-library-manager/reviews?qs=pros-and-cons)).
  - **Follett's own flip-flop:** in Mar 2022 Follett planned optional parent-notification and title-blocking modules for Florida and Georgia customers, then dropped them on Apr 2 2022 after an outcry from librarians ([LTG](https://librarytechnology.org/document/27189), [SLJ](https://www.schoollibraryjournal.com/story/Follett-changes-course-on-proposed-destiny-changes-in-response-to-library-community-outcry)).
  - Texas districts now run a **Destiny Parent Portal**, where parents view checkouts and restrict titles (Godley ISD), so the incumbent has caught up in Texas ([Godley ISD](https://www.godleyisd.net/academic-programs/center-for-learning-and-innovation-cli/follett-destiny-parent-portal)).
  - **New state deadlines, 2025–2026** (detail in the state map below):
    - **Texas SB 13** is in force from the 2025–26 school year. Parents get catalog access, can submit lists of titles their child may not borrow, and can see checkout records. The board must approve every acquisition after 30 days' public notice. There is a TEA challenge form with a 90-day timeline ([TEA, Aug 28 2025](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials); [TASB](https://www.tasb.org/news-insights/3-things-to-know-about-sb-13)).
    - **Nebraska LB 390** requires a per-building catalog, **opt-in parent checkout notifications** and board policies **before school starts in fall 2026**. That deadline has now passed. KSB also notes that "a paper binder would do" for the catalog, so the remaining pull is late adopters and the ongoing notification workflow ([KSB School Law, Nov 2025](https://www.ksbschoollaw.com/blog/2025/11/24/turning-the-page-nebraskas-new-library-catalog-law-for-schools)).
    - **North Carolina H 805** (2025) requires an online catalog that includes classroom libraries, plus parent opt-out ([PEN America](https://pen.org/report/the-bills-igniting-book-bans/); [Spectrum News](https://spectrumlocalnews.com/nc/charlotte/news/2025/11/23/cataloging-classroom-libraries-)).
    - **Freedom-to-read laws in 2025:** Connecticut (budget bill HB 7287) requires every district to adopt three policies: collection development, display/program, and material review ([CT Public, Sep 2025](https://www.ctpublic.org/news/2025-09-15/connecticut-school-library-book-ban-law-2025)). Delaware HB 119 was signed Sep 18 2025 ([PEN](https://pen.org/chance-conversation-with-pen-america-director-spurs-delaware-freedom-to-read-act/)). Oregon SB 1098 and Rhode Island SB 238 also passed ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)).
- **Who buys:**
  - **District library coordinators and directors of instructional technology**, often with the **assistant superintendent for curriculum**, because the compliance obligation sits in board policy.
  - **Heads of private, charter and parochial schools**, who can buy with a card.
  - **Education service centers** (Texas ESCs) and BOCES-style cooperatives buying for member districts.
- **US market size:**
  - About 75,000 Destiny school libraries alone (LTG 2022).
  - Estimate: about 99,000 public and about 30,000 private K-12 schools (NCES figures as commonly cited; verify).
  - About 20 states now carry some statutory library-materials process requirement (see map). Estimate: 40,000+ schools sit in states with a new procedural obligation since 2022.
- **Urgency trigger (why they'd switch NOW):**
  - Nebraska LB 390 policies were due before fall 2026. The deadline has passed, so this is now a late-adopter and ongoing-notification pull.
  - Texas SB 13 is in its second year of board-approval and challenge workflows. TSLAC rulemaking was expected into spring 2026 ([TASB](https://www.tasb.org/news-insights/3-things-to-know-about-sb-13)).
  - NC classroom-library cataloging.
  - New freedom-to-read policy mandates in CT, DE, OR and RI.
  - Destiny renewal cycles (July 1 fiscal year).
- **Fastest-selling states/metros:**
  - **TX** (about 1,200 districts, estimate), **NE**, **NC**, **FL**, **TN**, **IN**, **UT**, **SC**, **IA**. Their laws require catalogs, notifications or challenge processes.
  - **CT, DE, OR, RI, NJ, IL, MD, MN, WA, CA**. Their laws require written collection-development and reconsideration policies.
  - Same product, different state pack.

### State map (as found in this pass, Sep 2026; "verify" = not confirmed against statute text)
| State | Law (year) | What it requires of school libraries (procedural) |
|---|---|---|
| **TX** | HB 900 (2023); **SB 13 (2025)** | HB 900: vendor rating system, partially struck down in court ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)). SB 13: parent catalog access, parent do-not-lend lists, checkout records, board approval of all acquisitions after 30-day notice, SLAC advisory council on petition, TEA challenge form and 90-day timeline, challenged items removed during review (unverified; not in the TEA letter) (effective 2025–26) ([TEA](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials)) |
| **NE** | **LB 390 (2025)** | Per-building catalog (paper or digital), opt-in parent checkout notifications, board policy before 2026–27 ([KSB](https://www.ksbschoollaw.com/blog/2025/11/24/turning-the-page-nebraskas-new-library-catalog-law-for-schools)) |
| **NC** | **H 805 (2025)** | Online catalog including classroom libraries; parent opt-out of titles for any reason ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)) |
| **FL** | HB 1467 (2022); HB 1069 (2023) | Searchable online list of library and classroom materials (HB 1467, verify); objection process, 5-day removal of challenged "sexual conduct" titles, parent limits on access (HB 1069) ([PEN](https://pen.org/report/the-bills-igniting-book-bans/); [CBS](https://www.cbsnews.com/news/florida-jacksonville-classroom-bookshelves-ron-desantis-house-bill-1467/)) |
| **IN** | HEA 1447 (2023) | Online catalog of library materials; parent request/complaint process ([Wikipedia](https://en.wikipedia.org/wiki/Indiana_HB_1447)) |
| **TN** | Age-Appropriate Materials Act (2022); 2024 amendments (HB 843/SB 2407) | Post library list online; parent challenges; 60-day review; escalation to the state textbook commission ([WCYB, Jul 2024](https://wcyb.com/news/local/tennessee-adds-new-requirements-to-age-appropriate-materials-act-for-schools)) |
| **UT** | HB 29 (2024) | Statewide removal trigger once a set number of districts remove a title ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)) |
| **SC** | Reg. 43-170 (2024, verify year) | State Board review and statewide removal mechanism ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)) |
| **IA** | SF 496 (2023). Enjoined, then the **8th Circuit vacated the injunctions on Apr 6 2026**, so it is now enforceable, narrowed to books describing or depicting sex acts as defined in Iowa criminal law ([Lambda Legal](https://lambdalegal.org/newsroom/iowa-safe-schools_ia_20260406_eighth-circuit-rules-against-temporary-block-of-book-ban-dont-say-lgbtq-law/); [ALA, May 27 2026](https://www.ala.org/news/2026/05/aasl-issues-statement-injunction-senate-file-496)) | Content restrictions; online posting of library lists (unverified) ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)) |
| **GA** | SB 226 (2023) | Complaint process; administrator decision within 10 days ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)) |
| **ID** | HB 710 (2024) | Relocate materials; $250 private damages ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)) |
| **KY** | SB 150 (2023); SB 5 (2024, verify) | Parent review and complaint process (verify SB 5 details) |
| **MO** | SB 775 (2022) | Criminal liability; **struck down Nov 2025** ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)) |
| **AR** | Act 372 (2023) | **Struck down Dec 2024** ([Wikipedia](https://en.wikipedia.org/wiki/Book_banning_in_the_United_States_(2021%E2%80%93present))) |
| *Freedom-to-read* **IL** | HB 2789 / PA 103-0100 (2023, eff. Jan 1 2024) | Adopt ALA Library Bill of Rights or a written equivalent; state grants conditional ([ALA](https://americanlibrariesmagazine.org/2025/06/02/banning-the-book-bans/)) |
| **MD** | HB 785 (2024) | Written collection-development and challenge policies; staff protections ([ALA](https://americanlibrariesmagazine.org/2025/06/02/banning-the-book-bans/)) |
| **MN** | §134.51 (2024, eff. Aug 1 2024) | Selection and challenge policies; librarian-led review ([ALA](https://americanlibrariesmagazine.org/2025/06/02/banning-the-book-bans/)) |
| **NJ** | Freedom to Read Act A3446 (signed Dec 2024; ALA lists effective Dec 9 2025, verify) | Written policies; limits on removal; librarian liability protection |
| **CA** | AB 1078 (2023); AB 1825 (2024) | Written collection-development policy; viewpoint-based removal barred |
| **WA** | HB 2331 (2024) | Written review policies; challenges limited to parents |
| **CT** | HB 7287 budget, SB 1271 language (2025) | Three required policies; only enrolled families may challenge ([CT Public](https://www.ctpublic.org/news/2025-09-15/connecticut-school-library-book-ban-law-2025)) |
| **DE** | HB 119 (signed Sep 18 2025) | Transparent challenge process; school and public libraries ([PEN](https://pen.org/chance-conversation-with-pen-america-director-spurs-delaware-freedom-to-read-act/)) |
| **OR** | SB 1098 (2025) | No removal because of protected-class subject or author; complaint process kept ([RV Times](https://rv-times.com/2025/06/10/oregon-freedom-to-read-library-bill-heads-to-governors-desk/)) |
| **RI** | SB 238 (2025) | Strongest protections, with a private right of action ([PEN](https://pen.org/report/the-bills-igniting-book-bans/)) |
| **CO**, **VT** | CO (2023 per ALA, 2025 per PEN; bill number unverified); VT S.220 (2024, verify) | Freedom-to-read protections (details unverified) |

## Pain points (evidence)
- **[Price]** A district librarian says licensing costs "burden smaller institutions" (G2, Jan 2025) ([G2](https://www.g2.com/products/follett-software-follett-destiny-library-manager/reviews?qs=pros-and-cons)).
- **[Price]** Another district librarian calls Destiny's Resource Manager add-on "cost prohibitive". The reviewer adds that support quality fell after the acquisition and that competitors are gaining traction (G2, Jan 2025) ([G2](https://www.g2.com/products/follett-software-follett-destiny-library-manager/reviews?qs=pros-and-cons)).
- **[Price]** Bulk book import requires paid features (Capterra, Jul 2023) ([Capterra](https://www.capterra.com/p/8972/Destiny-Library-Manager/reviews/)).
- **[Complexity/UX]** A system support specialist calls the interface "old, outdated, and clunky" and says reports take several tries to set up. An Apr 2026 reviewer rated it 0.5/5: "EVERYTHING! It's clunky", with too many workflow steps and broken patron search. On G2's theme counts, reporting and navigation are the top complaint themes, at 24 and 22 mentions ([G2](https://www.g2.com/products/follett-software-follett-destiny-library-manager/reviews?qs=pros-and-cons)).
- **[Support]** A cataloger says "Customer service is horrible", that Destiny isn't built for multi-site districts, and that users get logged out daily at 4:10pm (G2, Apr 2026). A hosted-service customer calls it "trash", citing frequent connection failures (G2, Apr 2026) ([G2](https://www.g2.com/products/follett-software-follett-destiny-library-manager/reviews?qs=pros-and-cons)).
- **[Missing features]** Reviewers say Destiny can't send reports to ParentSquare and has no Google Sheets export (G2, Jan 2025 and Aug 2026) ([G2](https://www.g2.com/products/follett-software-follett-destiny-library-manager/reviews?qs=pros-and-cons)). A 2020 reviewer says it doesn't work with the Skyward SIS without manual work ([Capterra](https://www.capterra.com/p/8972/Destiny-Library-Manager/reviews/)).
- **[Compliance burden]** A North Carolina teacher needed about 8 hours, "probably about two days", to catalog 1,300 classroom books. Some teachers closed their classroom libraries instead, and 2% of Catawba County teachers didn't catalog at all (Spectrum News, Nov 2025) ([Spectrum](https://spectrumlocalnews.com/nc/charlotte/news/2025/11/23/cataloging-classroom-libraries-)).
- **[Compliance burden]** Under SB 13, Mansfield ISD now approves new library books at monthly board meetings using a rubric, and Pearland ISD pulls challenged titles during review (The Texan, Sep 2025) ([The Texan](https://thetexan.news/issues/education/texas-school-districts-craft-policies-on-library-book-approval-childrens-access-under-new-law/article_c622a130-d0da-410b-8e51-06334f191187.html)).
- **[Compliance burden]** New Braunfels ISD closed its non-elementary libraries to audit them for SB 13, then reopened them after community pushback (PEN America, Oct 2025) ([PEN](https://pen.org/press-release/texas-school-district-closes-entire-library-other-remove-dozens-of-books-in-overcomplying-with-new-laws/)). This shows districts lack a workflow tool and overreact.
- **[Trust]** Critics say the AI compliance vendor Bookmarked relies on "hearsay", meaning social media and other districts' ban lists, rather than the books' content. Bookmarked charges $2–3 per student (K-12 Dive, Apr 2026) ([K-12 Dive](https://www.k12dive.com/news/as-ai-enters-book-ban-disputes-heres-what-it-means-for-school-districts/816385/)). Districts on either side of the debate want a vendor that runs the process without making the judgment.
- *Evidence gap:* Reddit (r/SchoolLibrarians, r/Librarians) is blocked from this environment. Collect threads manually before launch.

## What we build (the better version)
1. **MVP: State pack engine.** Pick your state and ClearShelf pre-loads the required steps, timelines, forms and board-policy templates: TX SB 13, NE LB 390, NC H 805, FL, IN, TN, plus freedom-to-read packs for IL, MD, NJ, CT, MN, WA, CA, DE, OR and RI. Every requirement links to its statute citation. Districts can add local rules on top.
2. **MVP: Public online catalog.** A fast, mobile, Google-like search that tolerates typos (G2 reviewers complain that Destiny doesn't). It is per building, includes **classroom libraries**, and embeds on the district website. It imports MARC and CSV from Destiny, Alexandria, Follett Titlewave orders and spreadsheets.
3. **MVP: Phone-camera ISBN scan-in for classroom libraries.** A teacher scans a shelf in minutes, and we fill in title, author and reading level from open bibliographic data. This addresses the NC "two days for 1,300 books" problem.
4. **MVP: Parent portal**, with each feature switched on or off by the state pack:
   - view catalog;
   - opt-in checkout notifications by email or SMS (NE);
   - per-child do-not-lend lists (TX) or opt-outs (NC);
   - a hard block or warning at circulation.
   - Login via magic link, with SIS roster sync by CSV or OneRoster.
5. **MVP: Reconsideration workflow.**
   - Online challenge form. Who may file is a state-pack setting: in CT and WA only parents or enrolled families.
   - Automatic deadline clocks (TX 90 days, GA 10 days, TN 60 days).
   - A "stay on shelf" or "remove during review" toggle set by the state pack.
   - Committee assignment, reading assignments, decision letter templates and appeal tracking.
   - A public outcome log where the law requires one.
6. **MVP: New-acquisition notice board (TX).** Proposed purchases and donations get a public listing with a 30-day countdown, then an exportable board-agenda packet. Board approval is recorded against each title.
7. **MVP: Audit trail and annual report.** Every catalog change, challenge, decision, parent preference and notification is timestamped. One-click reports cover state and board reporting as well as open-records requests.
8. **V2: Full lightweight ILS for small, private and charter schools.** Circulation, holds, barcode and label printing, inventory, self-checkout kiosk, fines-free mode. This replaces Destiny or Alexandria outright.
9. **V2: Destiny and Alexandria sync connectors.** Nightly MARC or report pulls so districts keep Destiny for circulation and add ClearShelf for compliance. SIS integrations: Skyward, PowerSchool, Infinite Campus.
10. **V2: Communications.** Push notices to ParentSquare, Remind or Google Classroom. Spanish and other languages by auto-translation.
11. **V2: Policy change tracker.** We monitor bills and alert customers when their state's rules change, with a redline of the policy template.

## Pricing to win
- **Compliance layer** (sits beside the existing ILS): **$0.50 per student per year**, with a **$500 minimum per district** and a cap of **$6,000 per district**.
  - Versus Bookmarked's $2–3 per student: a 5,000-student district pays **$2,500 instead of $10,000–$15,000**, a 75–85% saving.
  - Month-to-month for private schools at **$39/mo per school**.
- **Full ClearShelf ILS (V2):** **$399 per school per year**, compliance included, with free migration from Destiny or Alexandria.
  - Versus Destiny's third-party-estimated $800–$3,000+ plus add-ons, and Alexandria's $499 starting price.
  - A 10-school district saves an estimated **$4,000–$26,000 a year**.
- No multi-year lock-in, and a data export any time (MARC plus CSV).

## Go-to-market (first 100 customers)
- **Deadline states first.**
  - **Nebraska:** talk to the NLA/NSLA joint fall conference, work with NASB policy services, and cold-email all districts (about 244, estimate) about LB 390 compliance.
  - **Texas:** exhibit at the TLA Annual Conference and TCEA. Partner with ESCs (about 20). Target the TASB Policy Service ecosystem, because SB 13 obligations live in local policy "EFB".
  - **North Carolina:** NCSLMA conference, NCSBA, and the classroom-library scan-in pitch to principals.
- **Freedom-to-read states:**
  - **Connecticut:** the Connecticut Library Consortium was already running SB 1271/HB 7287 info sessions in Aug 2025, so partner with or sponsor them ([CT Public](https://www.ctpublic.org/news/2025-09-15/connecticut-school-library-book-ban-law-2025)).
  - **Elsewhere:** ILA/AISL (IL), MASL (MD), NJASL (NJ). Offer a free "compliant policy pack" as a lead magnet.
- **National:**
  - AASL. Its national conference is biennial, so in off years use AASL webinars and sponsorships.
  - ISTE/ASCD vendor halls.
  - SLJ/School Library Connection newsletter ads.
  - The "Switch from Destiny" SEO page, plus "LB 390 compliance checklist", "SB 13 compliance checklist" and "classroom library catalog app" pages.
- **Private and charter:** state independent-school associations, diocesan school offices, and charter networks. They buy with a card and I07's buyer list overlaps.
- **Neutral positioning in all channels:** "Whatever your state requires, documented." Present at both TLA and freedom-to-read coalitions without taking sides.

## Risks and incumbent moats
- **Incumbent already shipped parent features.** Texas districts use a Destiny Parent Portal ([Godley ISD](https://www.godleyisd.net/academic-programs/center-for-learning-and-innovation-cli/follett-destiny-parent-portal)). *Mitigation:*
  - We win on the multi-state reconsideration and board workflow, classroom libraries, price, and private schools.
  - We don't need to replace circulation to sell.
- **Politics.** Librarians boycotted Follett in 2022 over parent controls ([SLJ](https://www.schoollibraryjournal.com/story/Follett-changes-course-on-proposed-destiny-changes-in-response-to-library-community-outcry)), and parent groups attack vendors perceived as "woke". *Mitigation:*
  - Strict neutrality: no content scoring or scraped ban lists.
  - Features appear only when the state's law requires them.
  - The same product serves freedom-to-read compliance.
  - Publish the neutrality policy.
- **Student privacy and library-record confidentiality.** FERPA, state student-data laws (TX, IL SOPPA, NY Ed Law 2-d) and state library-confidentiality statutes apply. Some states protect minors' circulation records even from parents. *Mitigation:*
  - Signed DPAs (SDPC/NDPA standard) and data minimization.
  - Parent-visibility settings follow the state pack, and legal review of each pack.
- **Litigation churn.** Laws get enjoined (MO SB 775, AR Act 372, TX HB 900 ratings). *Mitigation:* the policy tracker feature; packs are versioned.
- **Procurement.** Districts use POs and board approval. *Mitigation:*
  - Price under typical superintendent signing thresholds.
  - Sell to ESCs and co-ops.
  - Private schools pay by card.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 3 | 2 | 4 | **16** |

*Sales speed lowered 3 → 2 after verification: the lead urgency trigger, the Nebraska LB 390 deadline, fell before fall 2026 and has passed, and a paper catalog satisfies it.*

## Sources
- [Follett to develop tools in response to new legislation (Library Technology Guides, Mar 2022)](https://librarytechnology.org/document/27189)
- [Follett changes course on Destiny changes (SLJ, Apr 2022)](https://www.schoollibraryjournal.com/story/Follett-changes-course-on-proposed-destiny-changes-in-response-to-library-community-outcry)
- [Francisco Partners acquires Follett School Solutions (Business Wire, Sep 2021)](https://www.businesswire.com/news/home/20210901005798/en/Francisco-Partners-Acquires-Follett-School-Solutions)
- [Follett Destiny reviews, cons (G2, 2025–2026)](https://www.g2.com/products/follett-software-follett-destiny-library-manager/reviews?qs=pros-and-cons)
- [Destiny Library Manager reviews (Capterra)](https://www.capterra.com/p/8972/Destiny-Library-Manager/reviews/)
- [School library software pricing comparison (LibraryAid, competitor-published)](https://libraryaid.net/school-library-management-software)
- [Alexandria listing (Capterra)](https://www.capterra.com/p/27788/Alexandria/)
- [OPALS listing (Capterra)](https://www.capterra.com/p/82990/OPALS/)
- [Library Systems Report 2026 (Breeding, LTG)](https://librarytechnology.org/document/32505)
- [Godley ISD: Follett Destiny Parent Portal](https://www.godleyisd.net/academic-programs/center-for-learning-and-innovation-cli/follett-destiny-parent-portal)
- [As AI enters book ban disputes (K-12 Dive, Apr 2026)](https://www.k12dive.com/news/as-ai-enters-book-ban-disputes-heres-what-it-means-for-school-districts/816385/)
- [Bookmarked Texas library laws FAQ (Oct 2025)](https://bookmarked.com/blog/texas-library-laws-faq-how-bookmarked-protects-schools-and-staff)
- [TEA: SB 13 requirements (Aug 28 2025)](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials)
- [TASB: 3 things to know about SB 13 (Aug 2025)](https://www.tasb.org/news-insights/3-things-to-know-about-sb-13)
- [The Texan: districts craft SB 13 policies (Sep 2025)](https://thetexan.news/issues/education/texas-school-districts-craft-policies-on-library-book-approval-childrens-access-under-new-law/article_c622a130-d0da-410b-8e51-06334f191187.html)
- [PEN America: Texas district closes library (Oct 2025)](https://pen.org/press-release/texas-school-district-closes-entire-library-other-remove-dozens-of-books-in-overcomplying-with-new-laws/)
- [PEN America: The Bills Igniting Book Bans (Dec 2025)](https://pen.org/report/the-bills-igniting-book-bans/)
- [Nebraska LB 390 school library catalog law (KSB School Law, Nov 2025)](https://www.ksbschoollaw.com/blog/2025/11/24/turning-the-page-nebraskas-new-library-catalog-law-for-schools)
- [NC classroom library cataloging (Spectrum News, Nov 2025)](https://spectrumlocalnews.com/nc/charlotte/news/2025/11/23/cataloging-classroom-libraries-)
- [Indiana HB 1447 (Wikipedia)](https://en.wikipedia.org/wiki/Indiana_HB_1447)
- [Tennessee Age-Appropriate Materials Act update (WCYB, Jul 2024)](https://wcyb.com/news/local/tennessee-adds-new-requirements-to-age-appropriate-materials-act-for-schools)
- [Florida HB 1467 classroom shelves (CBS News)](https://www.cbsnews.com/news/florida-jacksonville-classroom-bookshelves-ron-desantis-house-bill-1467/)
- [Banning the Book Bans (American Libraries, Jun 2025)](https://americanlibrariesmagazine.org/2025/06/02/banning-the-book-bans/)
- [States Are Banning Book Bans (EdWeek, Jan 2026)](https://www.edweek.org/policy-politics/states-are-banning-book-bans-will-it-work/2026/01)
- [Connecticut's new library book challenge law (CT Public, Sep 2025)](https://www.ctpublic.org/news/2025-09-15/connecticut-school-library-book-ban-law-2025)
- [Delaware Freedom to Read Act (PEN America, Sep 2025)](https://pen.org/chance-conversation-with-pen-america-director-spurs-delaware-freedom-to-read-act/)
- [Oregon SB 1098 (Rogue Valley Times, Jun 2025)](https://rv-times.com/2025/06/10/oregon-freedom-to-read-library-bill-heads-to-governors-desk/)
- [Book banning in the US 2021–present (Wikipedia)](https://en.wikipedia.org/wiki/Book_banning_in_the_United_States_(2021%E2%80%93present))
- [EveryLibrary 2025 legislative landscape report](https://www.everylibrary.org/state_by_state_2025_legislative_landscape_report)

## Verification (Sep 25 2026)
- ✅ TX SB 13 30-day posting and board approval — TEA (Aug 28, 2025): in place before 2025–26. It covers parent catalog access, do-not-lend lists and checkout records. The board approves or rejects proposed materials "at the first open meeting… held 30 days or later" after public posting; a SLAC is formed on petition (10% or 50 parents); and the council has 90 days on a challenge. Removal during review is not in the letter and is marked unverified ([source](https://tea.texas.gov/about-tea/news-and-multimedia/correspondence/taa-letters/senate-bill-13-requirements-related-to-school-library-materials))
- ⚠️ NE LB 390 — catalog by building ("a paper binder would do"), opt-in checkout notifications, and a board policy "before school starts in fall 2026". That deadline has now passed; the text was corrected and Sales speed lowered 3 → 2 ([source](https://www.ksbschoollaw.com/blog/2025/11/24/turning-the-page-nebraskas-new-library-catalog-law-for-schools))
- ✅ NC H 805 — PEN (Dec 18, 2025): schools "must post a catalog online that lists every book in a school or classroom library" and let parents bar any book "for any reason". Spectrum confirms the teacher's two days for 1,300 books and 2% non-compliance in Catawba ([source](https://pen.org/report/the-bills-igniting-book-bans/); [Spectrum](https://spectrumlocalnews.com/nc/charlotte/news/2025/11/23/cataloging-classroom-libraries-))
- ✅ Bookmarked $2–3 per student — K-12 Dive (Apr 2, 2026): $2–$3 per student per year, at least 150 Texas districts, and the CEO concedes the data is partly "hearsay" ([source](https://www.k12dive.com/news/as-ai-enters-book-ban-disputes-heres-what-it-means-for-school-districts/816385/))
- ⚠️ IA SF 496 — the file's "eff. Jul 1 2023" left out the injunctions. The 8th Circuit vacated the preliminary injunction on Apr 6, 2026, and the law is now enforceable in narrowed form (AASL statement May 27, 2026). The row was updated ([source](https://lambdalegal.org/newsroom/iowa-safe-schools_ia_20260406_eighth-circuit-rules-against-temporary-block-of-book-ban-dont-say-lgbtq-law/))
