# RollCall: a cheaper, better Brightwheel / Procare for childcare centers and home daycares, built around subsidy-proof attendance

**One-liner:** Sign-in/out, tuition and co-pay billing, parent messaging and an audit-ready subsidy attendance record, built for the 2026 crackdown on child-care fraud and the return of attendance-based subsidy payment.

## Snapshot
- **Replaces:**
  - **Brightwheel:** "custom pricing" on its pricing page (quote-based, per program size; accessed Sep 2026) ([Brightwheel pricing](https://mybrightwheel.com/pricing/)).
  - **Procare:** quote-based and pitched as flat-rate in its own marketing ([Procare cost blog](https://www.procaresoftware.com/blog/how-much-does-procare-cost/)).
  - Kangarootime and Lillio (HiMama): not re-priced in this pass.
  - Exact list prices were not verified this pass. Get quotes during the state pass.
- **Recent price hikes / changes:**
  - A home daycare provider on Capterra says Brightwheel's price "has increased greatly" (Mar 2025) ([Capterra](https://capterra.com/p/144060/brightwheel/reviews/?page=2)). Procare is running a "why centers are switching from Brightwheel in 2026" campaign ([Procare blog](https://www.procaresoftware.com/blog/why-some-child-care-centers-are-switching-from-brightwheel-in-2026/)).
  - **Regulatory switching window (strong):**
    - **Jan 2026:** after the Minnesota fraud allegations, HHS froze Minnesota's child-care payments. It then ordered all states to provide "written justification, receipts, or photographic evidence" that CCDF funds (about $12.3B in FY2025) go to legitimate providers ([The 74, Jan 2026](https://www.the74million.org/zero2eight/after-minnesota-fraud-allegations-hhs-orders-states-to-justify-child-care-spending/)). Axios reported freezes in five states, including Minnesota, New York and California ([Axios, Jan 5 2026](https://www.axios.com/2026/01/05/trump-child-care-minnesota)).
    - **2026 CCDF Final Rule** (announced May 12 2026, **effective Jul 13 2026**): rescinds the 2024 requirement to pay providers on enrollment and prospectively. States may again **pay on attendance** ([NAEYC](https://www.naeyc.org/our-work/public-policy-advocacy/2026-ccdf-final-rule); [ACF](https://acf.gov/occ/law-regulation/2026-ccdf-final-rule)). Attendance accuracy becomes cash-flow critical for subsidy-dependent providers.
- **Who buys:** Owner-directors of independent centers (30–200 children) and licensed family/group home daycares. Home providers buy by card; small centers buy with the owner's approval.
- **US market size:** Estimate only: more than 100k licensed centers and family child-care homes nationally (Child Care Aware / state licensing counts). Verify the per-state counts in the state pass.
- **Urgency trigger (why they'd switch NOW):** Federal "justify the spend" documentation demands (Jan 2026). States may revert to attendance-based subsidy payment under the rule effective Jul 13 2026, which means state attendance audits and clawback risk. Brightwheel price increases.
- **Fastest-selling states/metros:** States in the fraud spotlight or with heavy subsidy use: **Minnesota, New York, California** (named freezes), plus Texas, Florida, Georgia, Illinois, Pennsylvania. Needs a state-by-state subsidy-system map.

## Pain points (evidence)
- **[Price]** A home daycare provider says Brightwheel's price "has increased greatly" compared with earlier tools (Capterra, Mar 2025) ([Capterra](https://capterra.com/p/144060/brightwheel/reviews/?page=2)).
- **[Complexity/UX]** A director found refunds in Brightwheel billing confusing and hard to log correctly (Capterra, May 2025) ([Capterra](https://capterra.com/p/144060/brightwheel/reviews/?page=2)).
- **[Missing features]** An enrollment manager can't run reports by enrollment start/end date and rebuilds them in spreadsheets (Capterra, Feb 2025) ([Capterra](https://capterra.com/p/144060/brightwheel/reviews/?page=2)).
- **[Complexity/UX]** A Brightwheel update removed the ability to delete enrollment documents (Capterra, Feb 2025) ([Capterra](https://capterra.com/p/144060/brightwheel/reviews/?page=2)).
- **[Support]** There is no direct phone support, and email/chat causes delays for busy staff (Capterra, Mar 2025) ([Capterra](https://capterra.com/p/144060/brightwheel/reviews/?page=2)).
- **[Complexity/UX]** The interface is hard to navigate despite the features (Capterra, May 2025) ([Capterra](https://capterra.com/p/144060/brightwheel/reviews/?page=2)).
- **[Lock-in/Contracts]** Trustpilot reviewers say Brightwheel is "easy to sign up, nearly impossible to cancel", with charges continuing after cancellation (cited in a competitor's [Procare blog](https://www.procaresoftware.com/blog/why-some-child-care-centers-are-switching-from-brightwheel-in-2026/); treat as a lead to verify).
- **[Complexity/UX]** App crashes and slow loading at drop-off, plus glitchy photo uploads (cited in [Procare blog](https://www.procaresoftware.com/blog/why-some-child-care-centers-are-switching-from-brightwheel-in-2026/); competitor source).
- **[Compliance burden]** Providers face new documentation burdens as HHS requires receipts and photo evidence before releasing funds ([The 74](https://www.the74million.org/zero2eight/after-minnesota-fraud-allegations-hhs-orders-states-to-justify-child-care-spending/); [CNN, Jan 3 2026](https://www.cnn.com/2026/01/03/us/child-care-fraud-minnesota)).

## What we build (the better version)
1. **MVP** **Tamper-evident sign-in/out:** parent PIN or QR on a tablet, timestamp, optional photo, geofence and signature. Immutable log with an edit-reason trail. This is the "audit binder" a state or HHS reviewer wants.
2. **MVP** **Subsidy attendance export:** monthly attendance by child and authorization, matched against authorized hours. It flags absences over the state limit and produces a PDF plus CSV in the format the state portal expects. We start with 3–5 high-volume states, then add more.
3. **MVP** **Split billing:** family co-pay plus subsidy portion on the same ledger, autopay (ACH/card), late fees, sibling discounts, year-end tax statements.
4. **MVP** Parent app: daily reports (meals, naps, diapers, photos), messaging, announcements.
5. **MVP** **Ratio and staff check-in** by room, with live ratio alerts against state licensing ratios.
6. **MVP** Enrollment, waitlist and digital forms (immunizations and emergency cards) with expiry reminders.
7. **V2** CACFP meal counts and claim reports.
8. **V2** **Licensing inspection pack:** one-click export of staff files (background checks, CPR, training hours), child files and fire-drill logs, by state checklist.
9. **V2** State portal integrations (e.g., KinderConnect-style swipe systems) where APIs or file uploads exist.
10. **V2** AI "compliance copilot" that reads the state licensing handbook and warns about missing documents.

## Pricing to win
- **Home daycare: $29/mo flat. Center: $1.50 per enrolled child/mo, capped at $199/mo.** Month-to-month. Parent payments at processor cost plus a disclosed small fee.
- **Example:** Brightwheel and Procare are quote-based, so we compare against a prospect's actual invoice. A pitch of "cancel anytime, capped price, audit binder included" beats per-feature upsells. Collect real quotes in the state pass to firm up the savings.

## Go-to-market (first 100 customers)
- **Reddit:** r/ECEProfessionals, r/daycare, r/earlychildhoodeducation. Offer a free "subsidy audit-ready attendance checklist" by state.
- **Facebook groups:** "Home Daycare Providers", "Family Child Care Providers of [State]", "Child Care Center Owners/Directors".
- **Associations:** NAFCC (National Association for Family Child Care), state child-care associations (Texas Licensed Child Care Association, Minnesota Child Care Provider Information Network, Florida's FACCM), and CCR&R agencies as referral partners.
- **Conferences:** the NAEYC annual conference and state early-childhood conferences.
- **SEO:** "child care subsidy attendance software [state]", "Brightwheel cancel", "audit-ready daycare sign-in".

## Risks and incumbent moats
- **State subsidy systems differ** (swipe cards, state portals, paper): we start with a few states and build exports, not integrations.
- **Payments and parent network:** Brightwheel's parent app is familiar. We match the core parent features and make migration easy.
- **Regulatory liability:** we don't certify compliance, we provide records. Clear ToS.
- **Politics can shift:** the documentation push could ease. But attendance-based payment is now allowed again, which keeps records valuable either way.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 2 | 4 | 4 | **17** |

## Sources
- [Brightwheel pricing](https://mybrightwheel.com/pricing/)
- [Brightwheel reviews p.2 – Capterra](https://capterra.com/p/144060/brightwheel/reviews/?page=2)
- [Why Child Care Centers Are Switching from Brightwheel in 2026 – Procare (competitor)](https://www.procaresoftware.com/blog/why-some-child-care-centers-are-switching-from-brightwheel-in-2026/)
- [Procare Software cost – Procare](https://www.procaresoftware.com/blog/how-much-does-procare-cost/)
- [After Minnesota fraud allegations, HHS orders states to justify child care spending – The 74](https://www.the74million.org/zero2eight/after-minnesota-fraud-allegations-hhs-orders-states-to-justify-child-care-spending/)
- [Trump administration to freeze childcare funding in five states – Axios (Jan 5 2026)](https://www.axios.com/2026/01/05/trump-child-care-minnesota)
- [Minnesota families and child care providers scramble – CNN (Jan 3 2026)](https://www.cnn.com/2026/01/03/us/child-care-fraud-minnesota)
- [What Does the 2026 CCDF Final Rule Change? – NAEYC](https://www.naeyc.org/our-work/public-policy-advocacy/2026-ccdf-final-rule)
- [2026 CCDF Final Rule – ACF](https://acf.gov/occ/law-regulation/2026-ccdf-final-rule)
- [Restoring Flexibility in the CCDF – Federal Register (Jan 5 2026)](https://www.federalregister.gov/documents/2026/01/05/2025-24272/restoring-flexibility-in-the-child-care-and-development-fund-ccdf)
