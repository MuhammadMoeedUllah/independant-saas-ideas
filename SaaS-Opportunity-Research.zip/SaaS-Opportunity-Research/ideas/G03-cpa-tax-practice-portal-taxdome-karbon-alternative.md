# SeasonDesk: a cheaper, better TaxDome / Karbon / Canopy for 1–15 person tax and bookkeeping firms

**One-liner:** Client portal, organizers and document requests, engagement letters and e-sign, a workflow board and invoicing for small tax firms. Flat per-firm pricing, free seasonal staff, and no multi-year prepay.

## Snapshot
- **Replaces:**
  - **TaxDome (taxdome.com/pricing, fetched Sep 24, 2026), per seat per year, billed upfront:**

    | Plan | 1-year | 2-year | 3-year |
    |---|---|---|---|
    | Essentials (solo only) | $800 | $750 | $700 |
    | Pro | $1,000 | $950 | $900 |
    | Business | $1,200 | $1,150 | $1,100 |

    Seasonal staff: Pro monthly seats $100/user/mo. Business seasonal seats $500 per 4-month term, auto-renewing on the firm's renewal date. Firms with 25+ seats get a quote ([TaxDome pricing](https://taxdome.com/pricing)).
  - **Karbon, Canopy, Financial Cents, Liscio:** 2026 list prices **not verified this pass** (the comparison page fetched returned 404). Comparison guides exist ([Financial Cents](https://financial-cents.com/resources/articles/taxdome-vs-canopy/); [US Tech Automations](https://ustechautomations.com/resources/blog/karbon-vs-canopy-vs-taxdome-2026)).
  - **Pro tax software** (Drake, Intuit ProSeries/Lacerte, Thomson Reuters UltraTax): 2025–2026 price changes **not verified this pass**. A TaxProTalk thread titled "Drake price increases through the roof!" exists, but its date and contents could not be fetched ([TaxProTalk](https://www.taxprotalk.com/forums/viewtopic.php?f=8&t=31693)).
- **Recent price hikes / changes:**
  - **TaxDome history:**

    | When | Price per user |
    |---|---|
    | Before Feb 13, 2023 (single plan) | $600/yr ($50/mo) |
    | Feb 13, 2023 ("first-ever price change") | $800 on a 1-year term; $600 kept only by prepaying 3 years |
    | Sep 2026 (plan split) | Essentials/Pro/Business; mid-tier Pro is **$1,000/yr** on a 1-year term |

    Sources: [TaxDome blog](https://taxdome.com/blog/everything-you-need-to-know-about-taxdomes-first-ever-price-change); [TaxDome pricing](https://taxdome.com/pricing).
  - **Net effect:** The 1-year per-seat price is up about 67% since early 2023 for the Pro tier, with discounts tied to 2–3 year prepayment.
- **Who buys:** Owners of 1–15 person CPA, EA and bookkeeping firms. Buying happens in the Oct–Dec pre-season window.
- **US market size:** Estimate (background, not verified this pass). About 40k–50k CPA firms, plus tens of thousands of EA-led and unlicensed preparer shops and bookkeeping practices (the IRS reports several hundred thousand active PTIN holders). Serviceable market: about 60k–100k small firms.
- **Urgency trigger (why they'd switch NOW):**
  - The **Oct–Dec 2026 pre-season window** before the 2027 filing season.
  - TaxDome renewals that push 2–3 year prepayment.
  - Seasonal seat costs.
  - The FTC Safeguards Rule / IRS requirement that preparers keep a Written Information Security Plan (WISP) (background, verify), which firms are scrambling to document.
- **Fastest-selling states/metros:** Estimate. High preparer density in TX, FL, CA, NY, GA, IL. State CPA societies with strong tech programs: TXCPA, FICPA, CalCPA, NYSSCPA, PICPA.

## Pain points (evidence)
All of the Capterra reviews below come from [TaxDome's Capterra page](https://www.capterra.com/p/186749/TaxDome/reviews/). Review dates were not captured in the extraction.
- **[Price / Lock-in]** An operations manager cites yearly increases and pressure to pay 3 years upfront to lock in pricing, a strain on small and mid-size firms.
- **[Price]** A firm owner says per-seat pricing feels steep and makes adding staff expensive.
- **[Price / Lock-in]** In 2023, TaxDome let existing users keep $600/yr only by committing to 3 years. Everyone else went to $800 ([TaxDome blog](https://taxdome.com/blog/everything-you-need-to-know-about-taxdomes-first-ever-price-change)).
- **[Price]** Seasonal Business seats cost $500 per 4-month term and auto-renew on the firm's renewal date ([TaxDome pricing](https://taxdome.com/pricing)).
- **[Complexity/UX]** A CPA owner describes a lengthy, months-long configuration before TaxDome became productive, often with paid training on top.
- **[Complexity/UX]** A managing partner says the learning curve is steep when moving from separate tools.
- **[Support]** A CPA managing principal complains there is no phone support and responses take hours.
- **[Reliability]** An admin reports document saves lagging near tax deadlines, with edits not persisting and needing to be redone.
- **[Missing features]** An owner says invoice reporting makes it hard to track recurring revenue and proposal values before the client signs.
- **[Missing features]** A firm president says automation and API integrations are weaker than true CRM platforms.
- **Balance note:**
  - TaxDome is highly rated overall. The pain is price, lock-in and complexity, not failure.
  - Evidence for Karbon, Canopy and pro-tax-software hikes is a gap. Re-check in a follow-up pass.

## What we build (the better version)
1. **MVP:** A branded **client portal** with magic-link login (no password resets in March), secure upload, and mobile photo-to-PDF.
2. **MVP:** **AI organizer and document-request engine.**
   - Sends a personalized checklist from last year's return data (W-2s, 1099s, K-1s, 1098s).
   - Chases clients automatically by SMS and email.
   - Auto-labels uploads and flags what's still missing.
3. **MVP:** Engagement letters with e-sign (ESIGN/UETA audit trail), 7216 consent forms, and Form 8879 signature collection with KBA as a V2 partner integration.
4. **MVP:** Kanban workflow per return or bookkeeping job (Awaiting docs, In prep, Review, Awaiting 8879, E-filed, Invoiced), with due-date and extension tracking.
5. **MVP:** Invoicing and payments through the firm's own Stripe account, plus pay-before-release (the return is released when the invoice is paid).
6. **MVP:** A **WISP generator:** fill in a questionnaire and get a firm-specific Written Information Security Plan. Include a staff acknowledgment log and annual review reminder.
7. **V2:** Secure client messaging, an AI inbox that drafts replies to "where's my refund / what do you still need," and bulk e-mail campaigns (extension notices, estimated-tax reminders).
8. **V2:** Integrations: QBO/Xero (for bookkeeping clients), exports to Drake, UltraTax and ProSeries client lists, and IRS transcript retrieval through a partner.
9. **V2:** Capacity planning, time tracking and realization reports for firms with 5+ staff.

## Pricing to win
- **Plans (per firm, not per seat):**
  - Solo $39/mo.
  - Firm $99/mo (up to 5 full-time users).
  - Plus $199/mo (up to 15 users).
- **Terms:** **Seasonal users free** (Jan–Apr). Month-to-month or annual at −15%, never multi-year prepay. Free migration from TaxDome/Canopy CSV exports.
- **Example:** A 4-person firm on TaxDome Pro 1-year pays 4 × $1,000 = **$4,000/yr**, plus a $500 seasonal seat = $4,500. SeasonDesk Firm costs $1,188/yr, saving **about $3,300/yr**.

## Go-to-market (first 100 customers)
- **Communities:** r/taxpros, r/Accounting, r/Bookkeeping, TaxProTalk forum, and Facebook groups for EAs and tax-practice owners.
- **Associations:** NAEA and state EA societies, NATP, state CPA societies (TXCPA, FICPA, CalCPA, NYSSCPA), and AICPA ENGAGE (Las Vegas).
- **Timing:** A pre-season blitz Oct–Dec 2026 with "Live before Jan 15" white-glove onboarding, and free WISP generator as the lead magnet.
- **SEO pages:**
  - "TaxDome price increase"
  - "TaxDome alternative no 3-year contract"
  - "Canopy alternative small firm"
  - "free WISP template tax preparer"
- **Partners:** Tax software resellers and firm consultants (e.g., practice-management coaches). Offer 20% recurring commission.

## Risks and incumbent moats
- **TaxDome's all-in-one depth** and strong reviews. Mitigation: win on price, simplicity, a mobile-first client experience and no lock-in.
- **Security expectations:** Client PII and SSNs. Mitigation: encryption, MFA, SOC 2 roadmap, and the WISP tooling as proof.
- **Mid-season switching risk:** Nobody switches Feb–Apr. Mitigation: sell Oct–Dec and May–Jul (post-season review).
- **8879/KBA e-signature rules:** Mitigation: use a KBA-capable e-sign partner.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 4 | 4 | 3 | **18** |

## Sources
- [TaxDome pricing (fetched Sep 24, 2026)](https://taxdome.com/pricing)
- [Everything You Need to Know About TaxDome's First-Ever Price Change (TaxDome blog, Dec 2022 / updated Nov 2024)](https://taxdome.com/blog/everything-you-need-to-know-about-taxdomes-first-ever-price-change)
- [TaxDome reviews (Capterra)](https://www.capterra.com/p/186749/TaxDome/reviews/)
- [TaxDome vs Canopy (Financial Cents, 2026)](https://financial-cents.com/resources/articles/taxdome-vs-canopy/)
- [Karbon vs Canopy vs TaxDome 2026 (US Tech Automations)](https://ustechautomations.com/resources/blog/karbon-vs-canopy-vs-taxdome-2026)
- [Drake price increases through the roof! (TaxProTalk thread; not fetched, date unknown)](https://www.taxprotalk.com/forums/viewtopic.php?f=8&t=31693)
