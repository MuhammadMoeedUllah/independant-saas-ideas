# CampFile: a cheaper, better CampMinder / UltraCamp / CampBrain for small day and overnight camps

**One-liner:** Online enrollment, health forms and med logs, cabin and bunk assignments, staff hiring and licensing binders for camps with 50–1,500 campers a summer. One flat annual price, a modern parent portal, and a staff app.

## Snapshot
- **Replaces:**
  - **CampMinder**, **UltraCamp**, **CampBrain** and **Sawyer:** pricing is generally quote-based and was **not verified in this pass**. Get quotes in the state pass.
  - A Software Advice reviewer at an 11–50 employee camp calls CampMinder "quite expensive for a small company" (Dec 2022) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
  - The status quo for small day camps (churches, YMCAs-lite, municipal and school-run camps) is Google Forms plus Stripe plus paper health forms.
- **Recent price hikes / changes:** **No confirmed 2025–26 price hike or acquisition was found in this pass.** The switching window is **seasonal**: camps choose software for next summer in **Sep–Dec**, because early-bird registration opens **Nov–Jan**. Today (Sep 24) is squarely inside that window. State camp licensing and health-form rules drive the paperwork (see the state leads).
- **Who buys:** Camp directors and owners (a for-profit owner can buy with a card), executive directors of nonprofit camps (board-approved), and church and Christian camp directors. After-school program directors are a secondary buyer (overlaps F03 and F05).
- **US market size:** The ACA counts **14,000+ US day and resident camps** (8,400 resident, 5,600 day; about 11,000 nonprofit and about 2,500 for-profit, 2017 data), serving about **14M campers a year** (2013) with about **$18B** in annual industry revenue (2015 estimate) ([ACA facts and trends](https://www.acacamps.org/press-room/aca-facts-trends)). These are small counts but high value per account.
- **Urgency trigger (why they'd switch NOW):** Sep–Dec is the only practical switching window before registration opens. After summer, directors are fresh from pain points (med logs, parent portal complaints). New state licensing inspections come each summer.
- **Fastest-selling states/metros:** Resident-camp belts: NY, PA, ME, NH, MA, WI, MI, NC (mountains), TX Hill Country, CA. Day-camp density is highest in suburban NY/NJ, Chicago, DFW and Atlanta (estimate).

## Pain points (evidence)
- **[Price]** CampMinder is "quite expensive for a small company" (recreational facility, 11–50 employees, Dec 2022) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
- **[Complexity/UX]** The parent-facing side is hard for parents to use and find (2–10 employee camp, Apr 2024) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
- **[Missing features]** There is no dedicated app for camp staff (11–50 employees, Nov 2022) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
- **[Complexity/UX]** When a payment declines, moving the camper back to the waitlist or "applied" status is cumbersome (review summary) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
- **[Complexity/UX]** The system is "rigid", with limited personalization (review summary) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
- **[Support]** In your second season, no live person is assigned to help you start the new season (review summary) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
- **[Complexity/UX]** Steep learning curve, and activity/elective preference reports return only a fixed set of information (51–200 employees, Oct 2018) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
- **[Reliability]** The system slows down at peak usage and in peak season (201–500 employees, Sep 2018) ([Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)).
- *Evidence gap:* the complaints are older and fewer than in other I-cluster ideas. Collect UltraCamp, CampBrain and Sawyer reviews, plus Facebook camp-director group threads, in the state pass.

## What we build (the better version)
1. **MVP** Session-based enrollment: weeks and sessions, age and grade rules, sibling discounts, deposits plus payment plans, a waitlist with auto-offer, and a financial-aid/camperships workflow.
2. **MVP** **Health center:** state-compliant health forms, immunization uploads, allergy and dietary flags, **daily med administration log** on a phone (MAR-style), and incident and injury reports with parent notification.
3. **MVP** Cabin and bunk assignments with bunkmate requests (drag and drop, AI suggestions), and activity/elective sign-ups.
4. **MVP** Modern parent portal (PWA): forms checklist, balance, packing list, and photo gallery with face-match opt-in.
5. **MVP** **Staff app:** rosters, allergy alerts, attendance and headcounts at every transition, and pickup authorization with ID check.
6. **MVP** Import from CampMinder, UltraCamp and CampBrain exports.
7. **V2** **Licensing binder:** a per-state checklist (staff ratios, background checks, lifeguard certs, health-care-provider on site), with inspection-ready PDF exports.
8. **V2** Staff hiring: applications, references, background-check status, contracts and a training tracker.
9. **V2** Camp store and canteen accounts, bus routes, and extended-care billing (for day camps and after-school).
10. **V2** AI parent-question assistant ("what time is pickup on Friday of week 3?") trained on the camp's handbook.

## Pricing to win
- **$990/yr** up to 300 campers, **$1,990/yr** up to 1,500, **$3,490/yr** unlimited. Includes the staff app, health center and parent portal. Processing at Stripe cost. Annual price, but **no multi-year contract**, and free migration by Dec 15.
- **Savings:** CampMinder and peer prices aren't published, so savings are **TBD per quote**. Our position is "flat and all-inclusive". Collect 5–10 real quotes from camps in the state pass.

## Go-to-market (first 100 customers)
- **American Camp Association (ACA):** ACA National Conference (Feb), regional ACA conferences and local sections (e.g. ACA New England; the Tri-State CAMP Conference for NY/NJ/PA), plus the ACA Business Solutions directory.
- **Christian Camp and Conference Association (CCCA):** a large nonprofit camp segment.
- **Facebook groups** for camp directors and camp health-care professionals (camp nurses are strong influencers on the med-log feature). r/CampCounselors for staff-side word of mouth.
- **SEO:** "CampMinder alternative", "camp medication log app", "[state] camp license requirements checklist".
- **Timing:** heavy push Sep–Nov; free migration deadline Dec 15.

## Risks and incumbent moats
- **Small market** (~14k camps): high share needed, so also sell to after-school and day programs.
- **Health data sensitivity:** most camps aren't HIPAA-covered entities, but parents expect strong privacy. Encrypt medical fields and use role-based access.
- **Seasonal cash flow:** annual prepay helps.
- **Incumbent depth** (CampMinder is feature-rich for large resident camps): target small and mid camps first.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 3 | 3 | 2 | **14** |

## Sources
- [CampMinder reviews – Software Advice](https://www.softwareadvice.com/camp-management/campminder-profile/reviews/)
- [ACA facts and trends – American Camp Association](https://www.acacamps.org/press-room/aca-facts-trends)
