# StudioDesk: a cheaper, better HoneyBook / Dubsado for photographers, planners and solo creatives

**One-liner:** Inquiry-to-paid in one flow: lead form, proposal, contract, invoice and scheduler. Flat $19/mo, payments at processor cost, and your money goes straight to your own Stripe account, never held by us.

## Snapshot
- **Replaces:**
  - **HoneyBook:**
    - Plans from Feb 4, 2025: Starter $36/mo, Essentials $59/mo, Premium $125/mo ([Fstoppers, Jan 24, 2025](https://fstoppers.com/business/honeybooks-price-hike-coming-heres-what-need-know-and-how-save-690584)). Premium has since risen to $129 on monthly billing ([Talleflow, 2026](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)).
    - **HoneyBook's own pricing page (Sep 24 2026), billed yearly:** Starter **$29/mo**, Essentials **$49/mo**, Premium **$109/mo**. Monthly billing: Essentials $59, Premium $129 ([HoneyBook pricing](https://www.honeybook.com/pricing)).
    - Payment fees: HoneyBook's pricing page now says **card fees start at 2.7% + 10¢** and ACH is 1.5% ([HoneyBook pricing](https://www.honeybook.com/pricing)). Talleflow's older figures: 2.9% + $0.25 per card; 3.4% + $0.09 for Amex, Discover and card-on-file; an extra 1% for instant payouts ([Talleflow](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)).
  - Dubsado, 17hats and Bonsai: in scope, but 2026 prices were **not verified this pass**.
- **Recent price hikes / changes:**
  - **HoneyBook hike effective Feb 4, 2025:**

    | Plan | Old | New | Increase |
    |---|---|---|---|
    | Starter | $19 | $36 | +89% |
    | Essentials | $39 | $59 | +51% |
    | Premium | $79 | $125 | +63% |

    Source: [Fstoppers](https://fstoppers.com/business/honeybooks-price-hike-coming-heres-what-need-know-and-how-save-690584); see also [AgencyHandy](https://www.agencyhandy.com/honeybook-pricing/).
  - **The 20% loyalty discount for existing users expired Feb 4, 2026**, so legacy users got a second effective increase ([Talleflow](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)).
  - Forced migration from legacy files to "Smart Files," and AI features bundled into core pricing ([Talleflow](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)).
- **Who buys:** Solo and 2–5 person creative service businesses: wedding and portrait photographers, videographers, event and wedding planners, florists, DJs, designers, coaches, bookkeepers, VAs. The owner buys with a card, influenced by peer Facebook groups and educators.
- **US market size:** Estimate, not verified this pass. Several hundred thousand US photographers, planners and creative freelancers are self-employed. Serviceable market: about 300k–600k at $15–$60/mo, a moderate dollar pool. Label as estimate.
- **Urgency trigger (why they'd switch NOW):**
  - The Feb 2026 loyalty-discount expiry.
  - Ongoing payout and fund-hold incidents (BBB 2025).
  - The off-season (Nov–Feb) is when wedding pros rebuild their systems before booking season. That's the next window.
- **Fastest-selling states/metros:** Estimate. Wedding-heavy markets: CA, TX, FL, NY, plus destination metros (Nashville, Austin, Charleston, Scottsdale). Validate in the per-state pass.

## Pain points (evidence)
- **[Price]** HoneyBook's Starter plan went up 89% ($19 to $36) on Feb 4, 2025, leaving creatives "questioning whether the steepness of the jump is justified" ([Fstoppers](https://fstoppers.com/business/honeybooks-price-hike-coming-heres-what-need-know-and-how-save-690584)).
- **[Price]** On top of the subscription, a photographer processing $80,000/yr could pay more than $2,300 in HoneyBook processing fees at Talleflow's 2.9% + $0.25; at HoneyBook's current "from 2.7% + 10¢" it is closer to $2,200, about what Stripe's standard rate would cost ([Talleflow](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)).
- **[Payments/Lock-in]** After a client filed a bank dispute, HoneyBook withdrew $600 twice from a user despite a signed no-refund contract, and quoted up to 90 days for resolution (Nov 16, 2025) ([BBB](https://www.bbb.org/us/ca/san-francisco/profile/records-management/honeybook-inc-1116-878229/complaints?page=1)).
- **[Payments/Support]** A user lost account access for 4 days with frozen funds after a client dispute, then was suspended again without warning over the dispute balance, which stopped their business operating (Sep 30, 2025) ([BBB](https://www.bbb.org/us/ca/san-francisco/profile/records-management/honeybook-inc-1116-878229/complaints?page=1)).
- **[Lock-in]** A user couldn't get standard monthly statements and payment reports without enrolling in HoneyBook's own "HoneyBook Balance" banking product (Nov 16, 2025) ([BBB](https://www.bbb.org/us/ca/san-francisco/profile/records-management/honeybook-inc-1116-878229/complaints?page=1)).
- **[Support]** A virtual-card failure after a fraud alert blocked access to business funds, and weekend support was unavailable despite advertised 7-day support (Aug 24, 2025) ([BBB](https://www.bbb.org/us/ca/san-francisco/profile/records-management/honeybook-inc-1116-878229/complaints?page=1)).
- **[Complexity/UX, Price]** A 1-star Trustpilot reviewer (Jul 22, 2026) called HoneyBook "buggy" with high subscription and card fees, a poor mobile app, mandatory card acceptance and unwanted AI features ([Trustpilot](https://www.trustpilot.com/review/honeybook.com?page=4)).
- **[Reliability]** Users report email drafts cutting off content, contracts failing to send, and a payment marked "paid" in HoneyBook that never reached the bank ([Talleflow](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)).
- **[Product direction]** Long-time users object to the forced move from legacy files to Smart Files and to AI bundled into core pricing ([Talleflow](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)).
- **Balance note:** HoneyBook's overall Trustpilot score is 4.0/5 (725 reviews). Anger is concentrated on price and payments, not the whole product ([Trustpilot](https://www.trustpilot.com/review/honeybook.com?page=4)). BBB shows 17 complaints in 3 years ([BBB](https://www.bbb.org/us/ca/san-francisco/profile/records-management/honeybook-inc-1116-878229/complaints?page=1)). Talleflow is a competitor blog, so treat its claims as directional.

## What we build (the better version)
1. **MVP:** Import from HoneyBook, Dubsado and 17hats (CSV of clients and projects, PDF contract templates). An AI converts old contract PDFs into editable templates.
2. **MVP:** A branded inquiry form and lead pipeline (Inquiry, Proposal sent, Booked, Delivered). Auto-reply within 60 seconds with your brochure and availability.
3. **MVP:** A one-link "proposal, contract, invoice" flow. The client picks a package, e-signs (ESIGN/UETA-compliant audit trail) and pays the retainer in one page.
4. **MVP:** Payments through **Stripe Connect Standard in the creative's own Stripe account**. We never hold funds. Card, ACH, Apple Pay and Klarna at Stripe's own rates, with no markup. Payment schedules and auto-reminders.
5. **MVP:** A scheduler for consults, shoots and meetings, tied to projects, with Google and iCloud calendar sync.
6. **MVP:** An AI assistant that drafts inquiry replies, questionnaires, timeline emails and "your gallery is ready" messages in your voice.
7. **MVP:** Plain reports: monthly statements, income by month, outstanding balances, CSV export. Available on every plan, no banking product required.
8. **V2:** A client portal with questionnaires, a shared timeline, file delivery links and a wedding-day timeline builder for planners.
9. **V2:** Workflows (on booking, send the welcome packet; 30 days out, send the questionnaire), with templates shared by genre (wedding, portrait, brand).
10. **V2:** Gallery-host integrations (Pic-Time, ShootProof, Pixieset links), QuickBooks and Xero sync, and a mobile app.
11. **V2:** Chargeback defense kit: auto-assemble the signed contract, IP and timestamp audit trail, communications and delivery proof into a Stripe dispute response.

## Pricing to win
- **Plans:** Solo $19/mo, all features, unlimited clients. Studio $39/mo (up to 5 team members).
- **Terms:** Payments at Stripe's cost with no platform markup. Month-to-month. Free concierge migration from HoneyBook.
- **Example:** A photographer on HoneyBook Essentials pays $59 × 12 = **$708/yr** on monthly billing, or $49 × 12 = **$588/yr** billed yearly. On StudioDesk Solo it's $228/yr, saving **$360–480/yr** before fees. A Starter user billed yearly ($29/mo) saves only $120/yr. HoneyBook's card fees now start at 2.7% + 10¢, which is at or below Stripe's standard rate, so moving to the creative's own Stripe account removes the platform-held-funds risk but **does not save on card fees and may cost slightly more**.
- **ACH:** HoneyBook charges 1.5% on ACH ([Talleflow](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)). Stripe's ACH pricing is lower and capped (background knowledge; verify). On a $5,000 wedding invoice, that's a meaningful difference.

## Go-to-market (first 100 customers)
- **Reddit:** r/WeddingPhotography, r/photography (business threads), r/videography, r/weddingplanning (the vendor side), r/freelance, r/graphic_design, r/smallbusiness.
- **Facebook groups:** Large wedding-photographer business groups, "Rising Tide"-style creative communities, planner and florist owner groups, HoneyBook user groups (watch for price and payout threads).
- **Educators and influencers:** Photography business educators and YouTubers. Offer an affiliate program at 30% recurring for 12 months.
- **Associations and events:** PPA (Professional Photographers of America), WPPI (Las Vegas trade show), The Knot/WeddingWire vendor communities, state and regional wedding associations.
- **"Switch from X" SEO pages:**
  - "HoneyBook price increase 2025"
  - "HoneyBook loyalty discount ended"
  - "HoneyBook funds held dispute"
  - "HoneyBook alternative for photographers"
  - "Dubsado vs StudioDesk"
- **Launch offer:** "Bring your HoneyBook invoice, get 12 months at $9/mo," timed to the Nov–Feb off-season.

## Risks and incumbent moats
- **Payments dependency:** Stripe Connect KYC and risk. Mitigation: Standard accounts put the merchant relationship and liability with the creative's own Stripe account, not us.
- **Crowded category:** Dubsado, 17hats, Bonsai, Studio Ninja, Sprout Studio, Táve/VSCO Workspace, Plutio. Mitigation: a simpler flow, "your money never touches us," the lowest flat price, and genre templates.
- **HoneyBook brand and community:** Mitigation: educator partnerships and migration concierge.
- **E-sign validity:** Mitigation: ESIGN/UETA audit trail and optional ID check (V2).
- **Lower willingness to pay:** Solo creatives are price-sensitive. Mitigation: keep costs tiny (CRUD + Stripe) and grow volume through communities.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 4 | 5 | 3 | **19** |

*Price gap cut 4 → 3 (Sep 24 2026): HoneyBook's own page shows yearly billing at $29/$49/$109 and card fees from 2.7% + 10¢, so the subscription gap is $120–480/yr and there is no processing-fee saving.*

## Sources
- [HoneyBook's Price Hike Is Coming: Here's What You Need to Know (Fstoppers, Jan 24, 2025)](https://fstoppers.com/business/honeybooks-price-hike-coming-heres-what-need-know-and-how-save-690584)
- [HoneyBook Pricing: Is 89.47% Increase Worth It in 2025? (AgencyHandy)](https://www.agencyhandy.com/honeybook-pricing/)
- [HoneyBook Alternative 2026: Why Users Are Switching (Talleflow, competitor blog)](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead)
- [HoneyBook, Inc. BBB complaints](https://www.bbb.org/us/ca/san-francisco/profile/records-management/honeybook-inc-1116-878229/complaints?page=1)
- [HoneyBook reviews, page 4 (Trustpilot)](https://www.trustpilot.com/review/honeybook.com?page=4)
- [HoneyBook pricing page (accessed Sep 24 2026)](https://www.honeybook.com/pricing)

## Verification (Sep 24 2026)
- ✅ HoneyBook hike effective Feb 4 2025: Starter $19→$36 (+89%), Essentials $39→$59 (+51%), Premium $79→$125 (+63%) — confirmed ([source](https://fstoppers.com/business/honeybooks-price-hike-coming-heres-what-need-know-and-how-save-690584))
- ✅ 20% loyalty discount for existing users expired Feb 4 2026 — stated by Talleflow (a competitor blog); Fstoppers does not mention it ([source](https://www.talleflow.com/blog/why-honeybook-users-are-switching-in-2026-and-what-to-look-for-instead))
- ⚠️ Current prices — HoneyBook's own page shows yearly billing at $29/$49/$109/mo, and Premium at $129 on monthly billing (not $125). Text and savings example corrected ([source](https://www.honeybook.com/pricing))
- ❌ Card fees "2.9% + $0.25" — HoneyBook's own page now says card fees start at 2.7% + 10¢ (ACH 1.5% confirmed). Moving to the creative's own Stripe account gives no fee saving. Corrected ([source](https://www.honeybook.com/pricing))
- **Score change:** Price gap 4 → 3, total 20 → 19. The subscription gap is $120–480/yr depending on plan and billing, and the payment-fee advantage is gone.
