# RouteBook: a cheaper, simpler Skimmer / Pool Brain / ZenMaid for pool-service and residential-cleaning route businesses

**One-liner:** One flat-priced app for recurring route businesses (pool techs and house cleaners). Recurring schedules, checklists with photo proof, chemical or visit logs, and autopay, with no per-pool or per-cleaner meter.

## Snapshot
- **Replaces:**
  - **Skimmer** (list prices checked Sep 24 2026): Getting Started is $1 per serviced location per month (minimum $49). Scaling Up is $2 per location per month (minimum $98). Add-ons: AI Phone $99/mo, Marketing Suite $150/mo, Bookkeeping from $198/mo. Texts are $0.029 each on the lower tier ([Skimmer pricing](https://www.getskimmer.com/pricing)).
  - **Pool Brain** is $50/mo base plus $65 per tech per month, so 2 techs cost $180/mo ([PoolFounder, updated Jul 22 2026](https://www.poolfounder.com/skimmer-vs-poolbrain)).
  - **ZenMaid** has a base fee of $19, $39 or $49 per month plus about $4, $14 or $24 per cleaner per month. A 7-cleaner team on Pro Max costs about $217/mo before SMS bundles, with no annual discount ([Fieldtics, Jun 30 2026](https://fieldtics.com/blog/zenmaid-review)).
  - **Jobber** runs $49–$699/mo plus $29 per extra user ([Jobber pricing](https://www.getjobber.com/pricing/)).
  - Launch27 and Swept were not priced in this pass.
- **Recent price hikes / changes:**
  - A Skimmer reviewer says pricing "quadrupled over the last 5 years" (Software Advice, via [PoolFounder](https://www.poolfounder.com/skimmer-vs-poolbrain)).
  - Skimmer bills per serviced location "regardless of visit frequency," so costs grow with the route.
  - No dated 2025–2026 hike announcement was found.
- **Who buys:** Solo operators to 15-tech owner-operators: pool routes of 50–1,000 pools, and residential maid services with 3–30 cleaners. All card buyers.
- **US market size:**
  - Janitorial services (NAICS 561720) are a rough estimate of 60k+ employer establishments, plus a much larger number of non-employer firms (estimate, verify with Census CBP and Nonemployer Statistics).
  - Pool service companies were not sized in this pass.
  - Willingness to pay per business is low.
- **Urgency trigger (why they'd switch NOW):** Weak. The trigger is bill growth as routes grow (per-pool or per-cleaner meters) rather than any hard deadline. The pool off-season (Oct–Mar) is when switching happens.
- **Fastest-selling states/metros:** An inference. For pool: FL, AZ (Phoenix), TX, CA, NV (Las Vegas), where year-round routes are densest. For cleaning: large metros everywhere.

## Pain points (evidence)
Complaints in this segment are milder and mostly secondhand; the incumbents are already cheap.
- **[Price]** Skimmer pricing "has quadrupled over the last 5 years" (Software Advice reviewer, via [PoolFounder](https://www.poolfounder.com/skimmer-vs-poolbrain)).
- **[Price]** Skimmer bills per serviced location regardless of how often it is visited. A 300-location route on Scaling Up costs about $600/mo ([Skimmer pricing](https://www.getskimmer.com/pricing)).
- **[Complexity]** In Skimmer, setting up a specific work order just to draw autopay is time-consuming (Capterra, via [PoolFounder](https://www.poolfounder.com/skimmer-vs-poolbrain)).
- **[Missing features]** Pool Brain "sometimes runs slow" in the field (Capterra, via [PoolFounder](https://www.poolfounder.com/skimmer-vs-poolbrain)).
- **[Missing features]** Pool Brain's smaller user community limits peer resources and third-party integrations ([PoolFounder](https://www.poolfounder.com/skimmer-vs-poolbrain)).
- **[Price]** ZenMaid's most common complaint is that per-cleaner fees push the bill well past the $19/$39/$49 sticker as a team grows ([Fieldtics](https://fieldtics.com/blog/zenmaid-review)).
- **[Missing features]** ZenMaid's iOS app is rated 3.2/5, and users report slow, glitchy performance ([Fieldtics](https://fieldtics.com/blog/zenmaid-review)).
- **[Missing features]** ZenMaid has no multi-step marketing funnels, no AI quoting and no API ([Fieldtics](https://fieldtics.com/blog/zenmaid-review)).
- **[Support]** ZenMaid's Starter tier is chat-only, and phone support is limited on every plan ([Fieldtics](https://fieldtics.com/blog/zenmaid-review)).

## What we build (the better version)
1. **MVP:** Recurring route scheduling (weekly and biweekly), a route map with drag-to-reorder, and holiday or weather bulk shifts.
2. **MVP:** Visit checklist with required before/after photos, emailed automatically to the customer as a "service report."
3. **MVP (pool mode):** Chemical readings log (FC, pH, TA, CYA, salt), dosage calculator, and a history chart per pool.
4. **MVP (cleaning mode):** Room-by-room checklist, key/lockbox notes, and a cleaner clock-in by GPS.
5. **MVP:** Online booking and instant quote for cleaning (by bedrooms and bathrooms), plus card-on-file autopay through Stripe.
6. **MVP:** Import from Skimmer, Pool Brain, ZenMaid and Jobber CSVs.
7. **V2:** Commercial pool compliance log (daily chemical logs for HOA and hotel pools, printable for health inspectors). Verify rules per state and county in the per-state pass.
8. **V2:** Payroll export for pay per visit or per hour, and tip distribution.
9. **V2:** AI dispatcher that fills cancellations from a waitlist.

## Pricing to win
- **Our prices:** $49/mo flat for up to 3 techs and unlimited pools or clients. $129/mo unlimited. Texts at cost.
- **Pool example:** A 300-pool route on Skimmer Scaling Up pays about $600/mo. On RouteBook it pays $129/mo, saving about $5.6k a year.
- **Cleaning example:** A 7-cleaner ZenMaid Pro Max team pays about $217/mo. On RouteBook it pays $129/mo.

## Go-to-market (first 100 customers)
- **Reddit:** r/pools and r/sweatystartup (a major hub for pool-route and cleaning owners). Post "per-pool fee calculator" content.
- **Pool associations and shows:** PHTA (Pool & Hot Tub Alliance), Pool & Spa Show (Atlantic City), Deck Expo / PSP Expo.
- **Pool distributors:** POOLCORP/SCP branches, Heritage Pool Supply, Leslie's Pro counters.
- **Cleaning:** ISSA (for commercial), plus cleaning-business-owner coaching communities and Facebook groups (identify the specific groups in the GTM pass).
- **Affiliates:** YouTube creators who teach "how to start a pool route" and "cleaning business."

## Risks and incumbent moats
- **Incumbents are already cheap and well liked**, so the price gap is small. Churn is driven by bill growth, not anger.
- **Many cheap competitors** (Jobber, Skimmer, Pool Brain, ZenMaid, Launch27, Swept) make customer acquisition cost the main risk.
- **Pool-route buyers and sellers.** Skimmer data is used in route valuations, which makes it sticky. We need an export that route brokers accept.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 2 | 2 | 5 | 4 | 3 | **16** |

## Sources
- [Skimmer pricing (checked Sep 24 2026)](https://www.getskimmer.com/pricing)
- [PoolFounder: Skimmer vs PoolBrain (Mar 30 2026, updated Jul 22 2026)](https://www.poolfounder.com/skimmer-vs-poolbrain)
- [Fieldtics: ZenMaid Review (Jun 30 2026)](https://fieldtics.com/blog/zenmaid-review)
- [Jobber pricing (checked Sep 24 2026)](https://www.getjobber.com/pricing/)
