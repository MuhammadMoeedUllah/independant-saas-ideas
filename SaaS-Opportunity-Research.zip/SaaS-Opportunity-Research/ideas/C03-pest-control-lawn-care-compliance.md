# SprayLog: a cheaper, better PestPac / FieldRoutes / RealGreen for pest-control and lawn-care route businesses

**One-liner:** Route scheduling and billing for pest and lawn operators, with pesticide application records captured on the phone and state reports (for example New York's annual Pesticide Reporting Law filing) generated automatically.

## Snapshot
- **Replaces:**
  - **PestPac (WorkWave)** is custom-priced in Small Business, Professional and Enterprise tiers. Reviewers call it "one of the most expensive" options, with a high base rate plus per-user fees and "modules on top of modules." There is no free trial ([Pest Control Software Guide, Jul 2026](https://pestcontrolsoftwareguide.com/pestpac-review/)).
  - **FieldRoutes** (now a ServiceTitan company) is custom-priced in Growth and Corporate tiers ([same source](https://pestcontrolsoftwareguide.com/pestpac-review/)). One reviewer reports a 3-year agreement (see pain points).
  - **RealGreen**, the lawn-care CRM, was acquired by WorkWave in June 2021 ([BusinessWire](https://www.businesswire.com/news/home/20210622005744/en/Serent-Announces-Acquisition-of-Portfolio-Company-Real-Green-Systems-by-WorkWave-and-Serents-Rollover-Investment-in-the-Combined-Company)). Pricing was not verified in this pass.
  - **GorillaDesk** costs $49/mo (Basic), $99/mo (Pro) and up to $149/mo ([Pest Control Software Guide, Jul 2026](https://pestcontrolsoftwareguide.com/pestpac-review/)).
  - **Jobber** is often used by small lawn and pest shops at $49–$699/mo ([Jobber pricing, checked Sep 24 2026](https://www.getjobber.com/pricing/)).
- **Recent price hikes / changes:**
  - The category is consolidating: WorkWave owns PestPac and RealGreen, and ServiceTitan owns FieldRoutes.
  - Reviewers describe multi-year contracts that are billed in full when a customer leaves early.
  - No dated 2025–2026 list-price hike was confirmed in this pass.
- **Who buys:** The owner or office manager of a residential or commercial pest-control or lawn/tree-care company with 1–30 techs and a licensed applicator on staff.
- **US market size:**
  - A rough estimate, not verified, is about 20k–25k pest-control employer establishments (NAICS 561710).
  - Landscaping services (NAICS 561730) is much larger at roughly 100k+ employer establishments (also an estimate), though only a subset apply pesticides or fertilizer under a license.
  - Confirm both with Census CBP.
- **Urgency trigger (why they'd switch NOW):**
  - New York commercial applicators must file their annual pesticide report by **February 1** for the prior calendar year. Records must include EPA registration number, product, quantity, date, and the full address with 5-digit ZIP ([NYSDEC OGC 3](https://dec.ny.gov/regulatory/guidance-and-policy-documents/ogc-3-pesticide-recordkeeping-and-reporting-of-commercial-applicators)). That makes an Oct–Jan sales window: "file your Feb 1 report in one click."
  - Anger at contract renewals with PestPac and FieldRoutes.
- **Fastest-selling states/metros:**
  - New York is the anchor, because of the annual report. Its search results also surfaced a separate NYC pesticide reporting document, not reviewed.
  - California is next: CDPR has pesticide-use reporting requirements, including a school-site use reporting letter that turned up in search. Verify the details in the per-state pass.
  - Then the Sun Belt pest markets with year-round termite and mosquito work: FL, TX, AZ, GA.

## Pain points (evidence)
- **[Lock-in/Contracts]** A PestPac customer says the vendor overpromised and underdelivered: the data migration included in the agreement was never done, yet they are still billed for the whole contract ([Software Advice, Ron H., Jul 2025](https://www.softwareadvice.com/field-service/pestpac-profile/)).
- **[Complexity]** Nine weeks into a PestPac rollout, a reviewer describes a "very labor intensive process," says they cannot use most features, and calls the migration expensive and incomplete, needing daily manual work ([Software Advice, Debra C., Jul 2025](https://www.softwareadvice.com/field-service/pestpac-profile/)).
- **[Complexity]** PestPac "doesn't lead you to the next step very well" and isn't intuitive ([Software Advice, Ann D., Feb 2025](https://www.softwareadvice.com/field-service/pestpac-profile/)).
- **[Support/Complexity]** PestPac's back end is "convoluted," support staff are not knowledgeable enough, and users must file ticket after ticket ([Software Advice, Emily M., Feb 2025](https://www.softwareadvice.com/field-service/pestpac-profile/)). PestPac's overall rating is 3.9/5 on 256 reviews.
- **[Price]** A startup pest owner calls PestPac one of the most expensive options, with a high base plus per-user fees ([Pest Control Software Guide, Lawrence D.](https://pestcontrolsoftwareguide.com/pestpac-review/)).
- **[Lock-in/Contracts]** A FieldRoutes customer signed a three-year agreement, tried to cancel after 3 months, and had to pay the full three years ([Trustpilot, Mar 2026](https://www.trustpilot.com/review/fieldroutes.com)).
- **[Missing features/Payments]** In FieldRoutes, invoices would not send, payment links broke, and some invoices reached customers 6 weeks late ([Trustpilot, Mar 2026](https://www.trustpilot.com/review/fieldroutes.com)).
- **[Missing features]** FieldRoutes support said it was "impossible" to change invoice numbering or add custom forms ([Trustpilot, Mar 2026](https://www.trustpilot.com/review/fieldroutes.com)).
- **[Support]** A FieldRoutes customer called support eight times without reaching a person and found no way to cancel ([Trustpilot, Aug 2023](https://www.trustpilot.com/review/fieldroutes.com)).
- **[Missing features]** A pest-control operator using Jobber says it has no chemical tracking on invoices or in the mobile app, which is critical for compliance ([Trustpilot, Aug 25 2026](https://www.trustpilot.com/review/getjobber.com)).

## What we build (the better version)
1. **MVP:** Recurring route scheduling (monthly, quarterly, seasonal rounds for lawn programs) with map-based route optimization and a "skip for weather" bulk reschedule.
2. **MVP:** Mobile service ticket with a **chemical application record**: product picked from an EPA-registered product list (EPA reg. no. filled in automatically), quantity, rate, target pest, method, and the address and ZIP captured from GPS. Works offline.
3. **MVP:** **State report generator.** A New York annual Pesticide Reporting Law export (all fields required by OGC 3), plus an application-records PDF for any state inspector audit.
4. **MVP:** Customer notices: pre-application and post-application notices by SMS/email, and a printable lawn flag or door-hanger text.
5. **MVP:** Agreements and autopay: recurring billing by card or ACH through Stripe, with prepay-discount programs for lawn rounds.
6. **MVP:** Import from PestPac, FieldRoutes, RealGreen, GorillaDesk and Jobber exports, plus QuickBooks Online sync.
7. **V2:** Termite/WDO inspection reports and graph diagrams, plus bait-station barcode scanning for commercial accounts (audit-ready logs for food plants).
8. **V2:** More state report templates (for example CA county reporting and other states) and chemical inventory by truck.
9. **V2:** AI upsell engine ("mosquito season starts in 3 weeks: text these 212 lawn customers").

## Pricing to win
- **Our prices:** $99/mo for up to 5 techs, $199/mo unlimited. Compliance reports included. No contract, free migration.
- **Against PestPac and FieldRoutes:** Their pricing is not published and runs on multi-year agreements. Our pitch is "no contract, ever," plus a compliance feature that GorillaDesk and Jobber lack.
- **Against GorillaDesk and Jobber:** Price parity. We win on compliance, not on price.

## Go-to-market (first 100 customers)
- **Associations:** NPMA (National Pest Management Association) and state pest associations. The New York State Pest Management Association is a priority because of the Feb 1 report. For lawn, NALP (National Association of Landscape Professionals).
- **Trade shows:** NPMA PestWorld (fall), plus Equip Exposition for lawn.
- **Distributor partnerships:** Target Specialty Products, Veseris and Univar-type distributors. Their product catalogs (EPA reg. numbers) pre-load into the app, and the distributor promotes it at the counter.
- **Reddit:** r/pestcontrol, r/lawncare, r/sweatystartup: "free NY pesticide annual report generator" as a lead magnet.
- **Lead magnet:** A free web tool, "Upload last year's service tickets CSV → get your NY DEC annual report file," which converts users to paid.
- **SEO pages:** "FieldRoutes 3-year contract", "PestPac alternative", "NY pesticide annual report software".

## Risks and incumbent moats
- **Regulatory formats vary by state and change.** We start with NY, where the rules are verified, and add states one at a time.
- **Termite/WDO paperwork** (state-specific forms) is complex. We push it to V2.
- **Incumbent strengths.** They have commercial and national-account features and deep routing. We stay focused on 1–30-tech owner-operators.
- **Price parity with GorillaDesk and Jobber** means we must win on compliance, so the NY report must be excellent.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 4 | 4 | 3 | **18** |

## Sources
- [Pest Control Software Guide: PestPac Review (Jul 2026)](https://pestcontrolsoftwareguide.com/pestpac-review/)
- [Software Advice: PestPac reviews (3.9/5, 256)](https://www.softwareadvice.com/field-service/pestpac-profile/)
- [Trustpilot: FieldRoutes](https://www.trustpilot.com/review/fieldroutes.com)
- [Trustpilot: Jobber](https://www.trustpilot.com/review/getjobber.com)
- [BusinessWire: WorkWave acquires Real Green Systems (Jun 22 2021)](https://www.businesswire.com/news/home/20210622005744/en/Serent-Announces-Acquisition-of-Portfolio-Company-Real-Green-Systems-by-WorkWave-and-Serents-Rollover-Investment-in-the-Combined-Company)
- [NYSDEC OGC 3: Pesticide Recordkeeping and Reporting of Commercial Applicators](https://dec.ny.gov/regulatory/guidance-and-policy-documents/ogc-3-pesticide-recordkeeping-and-reporting-of-commercial-applicators)
- [CDPR: School-site pesticide use reporting (search result, not reviewed)](https://www.cdpr.ca.gov/cac-letter/school-site-pesticide-use-reporting)
- [NYC DOHMH pesticide reporting PDF (search result, not reviewed)](https://www.nyc.gov/assets/doh/downloads/pdf/pesticide/pesticide-reporting.pdf)
- [Jobber pricing (checked Sep 24 2026)](https://www.getjobber.com/pricing/)
