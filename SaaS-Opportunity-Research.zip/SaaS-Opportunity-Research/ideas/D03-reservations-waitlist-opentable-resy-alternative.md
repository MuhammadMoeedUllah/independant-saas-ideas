# TableKeep: a cheaper, better OpenTable / Resy / SevenRooms for independent full-service restaurants

**One-liner:** Flat-fee reservations, waitlist, deposits and a guest CRM that the restaurant owns. There are no per-cover fees and no percentage fee on deposits, and the restaurant can export its data at any time.

## Snapshot
- **Replaces:**
  - **OpenTable** (per Eat App, Apr 24, 2026): Basic $149/mo + $1.50 per network cover + $0.25 per website cover (or $49/mo flat); Core $299/mo + $1.00 per network cover; Pro $499/mo + $1.00 per network cover ([Eat App](https://restaurant.eatapp.co/blog/opentable-pricing)).
  - **Resy:** from about $249/mo (Eat App, Apr 2026). **SevenRooms, Tock, Yelp Guest Manager:** pricing was not verified in this pass.
- **Recent price hikes / changes:**
  - **Jan 2026:** OpenTable introduced a **2% service fee** on transactions including deposits and prepaid experiences. It was reportedly rolled out mid-contract with limited communication ([Eat App](https://restaurant.eatapp.co/blog/opentable-pricing)).
  - **Summer 2026:** Resy is **merging with Tock** (both owned by American Express), per Eat App. That creates a forced-migration window for Resy and Tock restaurants ([Eat App](https://restaurant.eatapp.co/blog/opentable-pricing)). A later pass should confirm the migration timeline.
  - A Capterra reviewer (Nov 2025) reports OpenTable no longer integrates with SevenRooms ([Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)).
- **Who buys:** Owners and GMs of independent full-service restaurants, wine bars, supper clubs and chef-driven spots taking 500-5,000 covers a month.
- **US market size:** Estimate: 150k-250k US restaurants take reservations. This is an unverified estimate derived from full-service restaurant counts. Willingness to pay is proven at $149-$499/mo plus per-cover fees.
- **Urgency trigger (why they'd switch NOW):** The Jan 2026 OpenTable 2% fee. The Resy/Tock consolidation in summer 2026. One-year auto-renewals come due with 30-day cancel windows ([Eat App](https://restaurant.eatapp.co/blog/opentable-pricing)).
- **Fastest-selling states/metros:** NYC, Chicago, San Francisco, Los Angeles, Washington DC, Miami, Nashville, Austin, Charleston and other dense chef-driven dining metros. California also has deposit and fee disclosure pressure under its all-in pricing law (SB 478; verify restaurant carve-out rules).

## Pain points (evidence)
- **[Price]** OpenTable's new 2% fee on deposits and prepaid experiences arrived mid-contract with little notice. Eat App called the rollout "tone-deaf" ([Eat App](https://restaurant.eatapp.co/blog/opentable-pricing)).
- **[Price]** Per-cover fees scale with success. Eat App's example of a 100-seat restaurant with 1,500 network and 1,000 website covers a month comes to about $1,799-$2,649/mo, or $21.6k-$31.8k a year. This is a competitor's estimate ([Eat App](https://restaurant.eatapp.co/blog/opentable-pricing)).
- **[Price]** An F&B manager (Feb 2025) said the price feels high for a platform used mainly for reservations ([Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)).
- **[Price]** A restaurant director (Oct 2025) singled out the per-cover charge for network bookings, on top of the monthly fee (their example was in GBP) ([Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)).
- **[Lock-in/Contracts]** One-year auto-renewing contracts with 30-day cancellation windows. Guest data stays with OpenTable when the subscription lapses ([Eat App](https://restaurant.eatapp.co/blog/opentable-pricing)).
- **[Lock-in]** A reviewer (Apr 2026) cited limited customization and branding, and restaurants feeling dependent on the platform's ecosystem ([Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)).
- **[Missing features]** A hospitality assistant (Nov 2025) said OpenTable no longer integrates with SevenRooms, which increased their workload ([Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)).
- **[Missing features]** An F&B manager (Feb 2025) found the waitlist feature a poor fit and needed an in-house workaround ([Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)).
- **[Support]** An F&B director (Oct 2024) said customer service has "gone downhill" in recent years ([Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)).
- **[Complexity/UX]** A restaurant owner said the PC web, mobile web and app each work slightly differently. This review is older (2021) ([Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)).
- *Evidence gap:* No first-hand Reddit or Trustpilot threads were pulled this pass. A follow-up should mine r/restaurateur for OpenTable and Resy/Tock migration threads.

## What we build (the better version)
1. **MVP: Booking widget** for the website, Instagram link-in-bio and Google Business Profile link. It has party size, time slots, pacing rules and table-type requests.
2. **MVP: Drag-and-drop floor plan and table management** on an iPad host stand, with turn-time estimates.
3. **MVP: SMS waitlist** with a "your table is ready" text, quoted wait times and a two-way chat.
4. **MVP: Deposits, card holds and no-show fees** through Stripe, with **0% platform fee**. The restaurant pays only Stripe's cost. Prepaid tickets are included for special events and tasting menus.
5. **MVP: Guest CRM the restaurant owns.** Visit history, allergies, VIP tags and notes, with one-click CSV export.
6. **MVP: Import tool** for OpenTable, Resy, Tock and SevenRooms guest exports (CSV mapping with AI column matching). Future reservations are migrated.
7. **MVP: Automated confirmations and reminders** (SMS and email) plus a review-request text after the visit.
8. **V2: Reserve with Google integration.** This requires Google partner approval.
9. **V2: POS spend sync** from Square and Clover to show spend per guest. Toast via Partner Connect.
10. **V2: Private events and buyouts pipeline** with proposals, contracts and deposit schedules.
11. **V2: AI phone host** that answers calls and books, modifies or waitlists guests.

## Pricing to win
- **TableKeep:** Starter $49/mo (reservations, waitlist, CRM). Pro $99/mo (adds deposits, prepaid events, floor plan and SMS bundle). **Unlimited covers, $0 per cover, 0% on deposits.** Month-to-month, free migration.
- **Savings example:** Eat App's 100-seat example pays OpenTable about $1,799-$2,649/mo. On TableKeep Pro it pays $99/mo plus SMS at cost. The trade-off is losing OpenTable network discovery, so the fit is restaurants whose covers mostly come from their own site, Google and Instagram.
- **Deposit example:** $20k/mo in prepaid experiences means a 2% OpenTable fee of $400/mo. On TableKeep that fee is $0.

## Go-to-market (first 100 customers)
- **Resy/Tock migration campaign (summer-fall 2026):** "Moving anyway? Move to something you own." Offer free white-glove import.
- **"OpenTable 2% fee" landing page** plus a cover-fee calculator. Target SEO on "OpenTable alternatives," "OpenTable per cover fee" and "Resy Tock merger."
- **Reddit:** r/restaurateur, r/KitchenConfidential, r/Serverlife (hosts and servers influence tool choice).
- **Chef and restaurant-group communities:** James Beard-adjacent independent restaurant networks and local restaurant alliances. City restaurant associations such as the NYC Hospitality Alliance and the Golden Gate Restaurant Association (verify membership programs).
- **State restaurant associations** plus a presence at the NRA Show (Chicago, May).
- **Referral:** Restaurant consultants and GMs who move between restaurants get one free month per referred location.
- **Cold outreach:** Identify restaurants using OpenTable/Resy widgets on their websites (BuiltWith-style scan) and email a personalized fee estimate.

## Risks and incumbent moats
- **Network effect:** OpenTable's diner network drives covers for some restaurants. Mitigation: target the many independents whose bookings mostly come direct, and add Reserve with Google in V2.
- **Integrations:** Host-stand workflows are sticky. Mitigation: an iPad-first UX, and a free parallel-run month.
- **Data export friction:** Incumbents may limit exports. Mitigation: AI-assisted CSV mapping, and manual entry of future bookings as a service.
- **Payments:** Stripe handles PCI. Deposit and no-show policy wording needs state consumer-law review (CA SB 478 all-in pricing).

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 4 | 4 | 3 | **19** |

## Sources
- [OpenTable Pricing in 2026 – Eat App (Apr 24, 2026)](https://restaurant.eatapp.co/blog/opentable-pricing)
- [OpenTable vs Resy – Eat App](https://restaurant.eatapp.co/blog/opentable-vs-resy)
- [OpenTable for Restaurants reviews – Capterra](https://www.capterra.com/p/17313/OpenTable-for-Restaurants/reviews/)
- [Compare OpenTable vs SevenRooms 2026 – Capterra](https://www.capterra.com/compare/17313-165480/OpenTable-for-Restaurants-vs-SevenRooms)
- [Why Restaurant Franchises Outgrow OpenTable – dev.family](https://dev.family/blog/article/why-restaurant-franchises-outgrow-opentable)
