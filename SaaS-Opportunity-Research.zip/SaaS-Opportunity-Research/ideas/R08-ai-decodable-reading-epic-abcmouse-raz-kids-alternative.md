# Readlings: a cheaper, better Epic / ABCmouse / Reading Eggs / Raz-Kids for families and K-2 classrooms

**One-liner:** AI-generated **decodable** stories matched to each child's phonics level and interests (dinosaurs, soccer, their dog's name), with a plain-English parent dashboard, printable screen-free booklets, a teacher classroom tier, and honest billing at a family price.

## Snapshot
- **Replaces** (prices dated):
  - **Epic** (2026): **$13.99/mo or $84.99/yr** for families. The free tier allows 1 book/day. Verified educators get free access only **7 AM–4 PM**, for up to 40 students; outside those hours, students fall back to 1 book/day ([SpellingJoy](https://spellingjoy.com/best-apps/is-epic-safe-for-kids)).
  - **ABCmouse** (Sept 2026): **$14.99/mo**, $29.99 for 6 months, **$45 for the first year, possibly $59.99 after**. Only the monthly plan comes with a 30-day trial ([Brighterly](https://brighterly.com/blog/abcmouse-pricing/)).
  - **Reading Eggs** (pricing page, Sept 2026): Reading & Math **$13.99/mo or $99.99/yr**; Homeschool Max $41.90/mo or $299/yr. Auto-renews unless canceled 24h before billing ([Reading Eggs](https://readingeggs.com/pricing/)).
  - **Raz-Kids:** **$132/yr per classroom** (up to 36 students), **up from $115** ([SpellingJoy](https://spellingjoy.com/best-apps/app/raz-kids)). **Raz-Plus:** $228/yr retail ([The Learning Standard](https://thelearningstandard.org/apps/raz-plus)).
  - **Amazon Kids+:** Prime monthly **$4.99 → $5.99** (June 5, 2024 for new subscribers; July 8, 2024 for existing ones); annual $48 unchanged ([Cord Cutters News](https://cordcuttersnews.com/amazon-is-raising-the-price-of-amazon-kids-monthly/)).
  - **Read with Ello** (closest AI competitor): **$14.99/mo or $139/yr**, iOS only, 700+ decodable books, speech-recognition coaching ([SpellingJoy](https://spellingjoy.com/best-apps/app/ello)). Launched "Storytime" AI custom stories Sept 30, 2024 ([GlobeNewswire](https://www.globenewswire.com/news-release/2024/09/30/2955384/0/en/Ello-Launches-Storytime-New-Version-of-AI-Reading-App-Where-Kids-Create-Their-Own-Stories.html)).
  - **HOMER** (ages 2–8, owned by HomerLearning/Begin; 30-day trial) and **Hooked on Phonics** (subscription or one-time kits): prices not shown on the pages fetched; **not verified** ([HOMER](https://learnwithhomer.com/); [Hooked on Phonics](https://www.hookedonphonics.com/)).
  - **Accelerated Reader** (Renaissance): district quotes; not verified.
- **Recent price hikes / changes:**
  - **Epic ownership churn:**
    - BYJU's bought Epic for about $500M (July 2021).
    - BYJU's US unit filed Chapter 11 (Feb 1, 2024).
    - EdWeek Market Brief (June 2025) reported a Chinese education company won the bidding to buy Epic for about **$95M** ([Wikipedia](https://en.wikipedia.org/wiki/Epic!); [EdWeek Market Brief](https://marketbrief.edweek.org/financing-investment/chinese-education-company-wins-battle-to-buy-reading-platform-epic-for-95m/2025/06)).
    - Common Sense Privacy gave Epic a "Warning" rating ([SpellingJoy](https://spellingjoy.com/best-apps/is-epic-safe-for-kids)).
  - **Raz-Kids** price went from $115 to $132 per classroom. **Amazon Kids+** monthly price rose 20% (2024).
  - **ABCmouse:** FTC **$10M settlement (2020)** over auto-renewal and billing practices ([Brighterly](https://brighterly.com/blog/abcmouse-pricing/)). Complaints continue through Aug 2026 (below).
  - **Auto-renewal law wave:**
    - The FTC Click-to-Cancel rule was **vacated by the 8th Circuit on July 8, 2025**.
    - States filled the gap: **CA AB 2863 (July 1, 2025)**, AR (Aug 3, 2025), CO (Aug 6, 2025), MA (Sept 2, 2025), **NY (Nov 5, 2025)**, ME (Jan 1, 2026), **MD (June 1, 2026)**, CT (July 1, 2026) ([ZwillGen](https://www.zwillgen.com/auto-renewal/auto-renewal-update-legal-landscape-imposes-complex-obligations-subscription-businesses/)).
  - **Amended COPPA rule:** effective June 23, 2025, **full compliance by Apr 22, 2026**. It requires separate parental consent for third-party disclosure, a written retention policy (no indefinite retention) and a written security program ([Finnegan](https://www.finnegan.com/en/insights/articles/coppas-amended-rule-is-now-in-full-effect-what-operators-need-to-know.html)).
  - **Science of Reading shift:**
    - **At least 26 states** have passed reading laws since 2022.
    - At least 15 have banned three-cueing in the past three years, plus AR, LA and VA earlier ([APM Reports, Oct 16, 2025](https://www.apmreports.org/story/2025/10/16/legislators-reading-laws-sold-a-story)).
    - **H.R. 7890 passed the U.S. House on Sept 16, 2026.** It prioritizes grants for evidence-based reading and bars three-cueing in funded instruction. It revises the $194M Comprehensive Literacy State Development program (23 states) ([EdWeek](https://www.edweek.org/teaching-learning/federal-science-of-reading-legislation-passes-the-house/2026/09)).
    - This helps **decodable** texts and pressures leveled-reader libraries.
- **Who buys:**
  - Parents of 4–8-year-olds (card, self-serve) and homeschool families.
  - K-2 teachers and reading interventionists, often on a personal card.
  - Tutors and microschools (see F06/F07); later, schools and districts.
- **US market size:**
  - *Estimate:* about 20M US children ages 4–8, and several hundred thousand K-2 teachers (unverified this pass; check Census and NCES).
  - Incumbents charge families **$45–$139/yr** and classrooms **$132–$228/yr**.
  - Ello reports 2,500+ App Store reviews at 4.8 stars ([SpellingJoy](https://spellingjoy.com/best-apps/app/ello)), evidence that parents will pay for AI reading help.
- **Urgency trigger (why they'd switch NOW):**
  - Annual auto-renewals hit during back-to-school (Aug–Sept) and after the holidays.
  - Epic's ownership change and privacy rating.
  - Schools must drop cueing-based materials under state laws, and the federal bill passed the House in Sept 2026.
  - Honest-billing laws in CA and NY make "one-click cancel" a selling point.
- **Fastest-selling states/metros:**
  - **Three-cueing-ban states:** IN and WV (strongest overhauls), AR, LA, VA, MO (2025) and others ([APM](https://www.apmreports.org/story/2025/10/16/legislators-reading-laws-sold-a-story); [KCUR](https://www.kcur.org/education/2025-07-12/missouri-three-cueing-ban-education)).
  - **CA and NY** for the honest-billing message.
  - ESA/voucher states where families can spend on curriculum (AZ, FL, UT, IA, AR; *verify each program's vendor rules*, see F06/F07).

## Pain points (evidence)
- **[Lock-in/Billing]** An ABCmouse annual plan auto-renewed with no advance reminder, and the refund was denied (Aug 21, 2026) ([Trustpilot](https://www.trustpilot.com/review/abcmouse.com)).
- **[Lock-in/Billing]** A parent canceled an ABCmouse free trial right away and was still charged the next day (Aug 12, 2026) ([Trustpilot](https://www.trustpilot.com/review/abcmouse.com)).
- **[Lock-in/Billing]** After canceling ABCmouse, a parent was charged $14.99 for a secondary "Assessment Center" subscription they never knowingly bought (Aug 6, 2026) ([Trustpilot](https://www.trustpilot.com/review/abcmouse.com)).
- **[Lock-in/Billing]** A parent was charged $400+ over several years with no renewal reminders, citing the FTC's $10M settlement (Apr 26, 2026). ABCmouse rates **1.2/5 on 83 reviews** ([Trustpilot](https://www.trustpilot.com/review/abcmouse.com)).
- **[Lock-in/Billing]** An Epic subscriber was charged $13.99/mo from Oct 2024 despite repeated cancellation attempts, and stopped it through the bank after 15 months (Apr 11, 2026) ([Trustpilot](https://www.trustpilot.com/review/getepic.com)).
- **[Price]** An Epic user says about "90% of its books are behind a paywall" now (Jan 20, 2026) ([Trustpilot](https://www.trustpilot.com/review/getepic.com)).
- **[Support]** Epic charged a parent after they canceled, then locked the account when they disputed the charge (Dec 19, 2025) ([Trustpilot](https://www.trustpilot.com/review/getepic.com)).
- **[Content quality]** An Epic reviewer found a factual error in a sports book and little representation of women's hockey (Dec 18, 2025) ([Trustpilot](https://www.trustpilot.com/review/getepic.com)).
- **[Lock-in/Billing]** Reading Eggs kept charging after cancellation (Dec 2, 2025). Reading Eggs rates **2.2/5 on 26 reviews** ([Trustpilot](https://www.trustpilot.com/review/readingeggs.com)).
- **[Screen time]** A parent said their child became focused on the game rather than reading, with little reading progress (Jan 21, 2024). An older review calls it "heavily gamified" (2023) ([Trustpilot](https://www.trustpilot.com/review/readingeggs.com)).
- **[Complexity/UX]** A Raz-Plus review found the rewards system can distract from reading. Its quizzes explain nothing on wrong answers, and it needs adult oversight to align with phonics instruction ([The Learning Standard](https://thelearningstandard.org/apps/raz-plus)).
- **[Price]** Raz-Kids went from $115 to $132 per classroom ([SpellingJoy](https://spellingjoy.com/best-apps/app/raz-kids)). Epic's teacher-free tier stops at 4 PM, so homework reading at home hits the 1-book limit ([SpellingJoy](https://spellingjoy.com/best-apps/is-epic-safe-for-kids)).
- **[Missing features]** Ello is iOS-only, and some App Store users report glitches and weak parental controls ([SpellingJoy](https://spellingjoy.com/best-apps/app/ello)).

## What we build (the better version)
1. **MVP: 5-minute placement check.** The parent or teacher administers it: letter sounds, CVC words, digraphs, blends, silent-e, vowel teams. It places the child on a published, science-of-reading-style scope and sequence, and the teacher can choose which sequence to follow.
2. **MVP: Constrained decodable-story generator.**
   - The LLM writes stories using **only graphemes the child has been taught** plus a capped list of "heart words."
   - An **automatic decodability checker** splits every word into grapheme-phoneme units against a pronunciation dictionary and the child's taught patterns, and rejects any story below the target (e.g., 95% decodable).
   - Safety filter, plus human QA on template families.
3. **MVP: Interest personalization with no child photos or voice required.** Interests, pet names and favorite places go into stories. Children's personal data is kept to the minimum.
4. **MVP: Read-to-me and tap-a-word.** Sound-it-out playback using text-to-speech.
5. **MVP: Printable, screen-free booklets.** Print-and-fold PDFs and take-home packs answer screen-time worries directly.
6. **MVP: Parent dashboard in plain English.**
   - "This week: 6 stories, mastered *sh* and *ch*, next up: *th*."
   - Weekly email, with a suggested 10-minute activity for the parent.
7. **MVP: Honest billing by design.**
   - Monthly or annual, a renewal reminder 7 days before any annual renewal, and **one-click cancel on web and in-app**.
   - Prorated refund in the first 30 days of an annual plan.
   - Built to CA AB 2863 and NY rules from day one.
8. **MVP: Classroom tier.**
   - Teachers create small groups by phonics skill and assign story sets.
   - QR codes for home access with no student emails; consent handled under COPPA's school-authorization provisions.
   - Bulk printables for guided-reading tables.
9. **V2: Read-aloud with speech recognition.** Accuracy and words-correct-per-minute scoring, processed on the device where possible to limit COPPA voice-data exposure.
10. **V2: Knowledge-building decodable nonfiction** tied to K-2 science and social studies units, plus Spanish decodables.
11. **V2: District readiness.** Clever/ClassLink SSO, state student-data privacy agreements, a teacher-reviewed shared story library, and progress-monitoring exports.
12. **V2: ESA marketplace listings** and a tutor/microschool bundle (see F06/F07).

## Pricing to win
- **Free forever:** 3 new stories/week, 1 child, printables included. No trial that silently converts.
- **Family: $5.99/mo or $49/yr**, up to 4 children, unlimited stories.
- **Classroom: $79/yr per teacher**, up to 36 students, unlimited printables.
- **School: from $1,500/yr** (*estimate*).
- **Savings vs incumbents:**
  - Family annual vs Ello $139: 65% less.
  - vs Reading Eggs $99.99: 51% less.
  - vs Epic $84.99: 42% less.
  - Roughly matches ABCmouse's $45–$59.99, but with no renewal traps.
  - Classroom $79 vs Raz-Kids $132 / Raz-Plus $228.
- **Margin:** generated stories are cached and reused across children at the same level and interest, so model cost per family should be cents a month (*estimate*; to be validated).

## Go-to-market (first 100 customers)
- **Parents:**
  - "Cancel ABCmouse / Epic after 4 PM / Reading Eggs alternative" SEO and comparison pages.
  - Local parent Facebook groups and homeschool groups; reading-specialist and speech-language-pathologist Instagram creators.
  - The *Sold a Story* audience (APM); r/Parenting, r/homeschool and r/Teachers (research only; Reddit not fetched this pass).
- **Teachers:**
  - Free decodable packs on **TPT** with a QR code into the app; teacher Instagram.
  - Large science-of-reading teacher Facebook groups.
  - A "free for your first small group" classroom offer that converts to the $79 tier.
- **Schools (after about 50 teachers):** state reading-coach networks in three-cueing-ban states; free pilots in Indiana, West Virginia and Missouri.
- **Tutors and microschools:** cross-sell through F06/F07 customers; ESA vendor listings where rules allow.
- **Trust signals:** apply for Common Sense Privacy and kidSAFE certification; publish the decodability checker's rules.

## Risks and incumbent moats
- **Children's privacy (COPPA 2025 amendments, state student-privacy laws):**
  - Collect as little as possible, with no third-party ads or analytics SDKs in the kids' experience.
  - Written retention policy and security program from day one.
  - Separate consent for any third-party disclosure; school-authorized consent for the classroom tier.
- **AI content safety and quality:** generated stories could include unsafe or nonsense text, or break decodability. Mitigation: constrained templates, an automatic decodability checker, a safety classifier, human review of shared stories, and one-tap "report this story."
- **Pedagogical validity:** we make no efficacy claims (FTC advertising rules) until a study supports them. Add reading-specialist advisors and publish the sequence mapping.
- **Competition:**
  - Ello (funded, 700+ decodables, AI Storytime).
  - Incumbents adding AI; Amazon Kids+ as a cheap bundle; Epic's free teacher tier.
  - Our edge: price, printables, honest billing, cross-platform (web + Android + iOS), and a classroom tier.
- **App-store rules for kids' apps:** Apple's Kids category bans third-party ads and analytics, which we already avoid.
- **Screen-time backlash:** printable-first design turns it into a selling point.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 3 | 4 | 4 | **18** |

## Sources
- [SpellingJoy: Is Epic safe for kids? (2026)](https://spellingjoy.com/best-apps/is-epic-safe-for-kids)
- [Wikipedia: Epic!](https://en.wikipedia.org/wiki/Epic!)
- [EdWeek Market Brief: Chinese education company wins battle to buy Epic (June 2025)](https://marketbrief.edweek.org/financing-investment/chinese-education-company-wins-battle-to-buy-reading-platform-epic-for-95m/2025/06)
- [Brighterly: ABCmouse price breakdown (Sept 2026)](https://brighterly.com/blog/abcmouse-pricing/)
- [Reading Eggs pricing](https://readingeggs.com/pricing/)
- [SpellingJoy: Raz-Kids review 2026](https://spellingjoy.com/best-apps/app/raz-kids)
- [The Learning Standard: Raz-Plus review 2026](https://thelearningstandard.org/apps/raz-plus)
- [Cord Cutters News: Amazon Kids+ monthly price increase (June 5, 2024)](https://cordcuttersnews.com/amazon-is-raising-the-price-of-amazon-kids-monthly/)
- [SpellingJoy: Read with Ello review 2026](https://spellingjoy.com/best-apps/app/ello)
- [GlobeNewswire: Ello launches Storytime (Sept 30, 2024)](https://www.globenewswire.com/news-release/2024/09/30/2955384/0/en/Ello-Launches-Storytime-New-Version-of-AI-Reading-App-Where-Kids-Create-Their-Own-Stories.html)
- [HOMER](https://learnwithhomer.com/)
- [Hooked on Phonics](https://www.hookedonphonics.com/)
- [Trustpilot: ABCmouse](https://www.trustpilot.com/review/abcmouse.com)
- [Trustpilot: Epic](https://www.trustpilot.com/review/getepic.com)
- [Trustpilot: Reading Eggs](https://www.trustpilot.com/review/readingeggs.com)
- [ZwillGen: Auto-renewal legal landscape (updated Apr 27, 2026)](https://www.zwillgen.com/auto-renewal/auto-renewal-update-legal-landscape-imposes-complex-obligations-subscription-businesses/)
- [Finnegan: COPPA's amended rule now in full effect (May 15, 2026)](https://www.finnegan.com/en/insights/articles/coppas-amended-rule-is-now-in-full-effect-what-operators-need-to-know.html)
- [APM Reports: New reading laws sweep the nation (Oct 16, 2025)](https://www.apmreports.org/story/2025/10/16/legislators-reading-laws-sold-a-story)
- [EdWeek: Federal science of reading legislation passes the House (Sept 2026)](https://www.edweek.org/teaching-learning/federal-science-of-reading-legislation-passes-the-house/2026/09)
- [KCUR: Missouri bans three-cueing (July 12, 2025)](https://www.kcur.org/education/2025-07-12/missouri-three-cueing-ban-education)

## Verification (Sep 25 2026)
- ✅ Epic $84.99/yr — "$84.99/year or $13.99/month", a free tier of 1 book/day, educator access 7 AM–4 PM for up to 40 students, and a Common Sense Privacy "Warning" rating. This is a secondary review; Epic's own page was not checked ([source](https://spellingjoy.com/best-apps/is-epic-safe-for-kids))
- ✅ Raz-Kids $115 → $132 — "$132/yr (classroom)" and "Price increased from $115 to $132". This is a secondary review with no date for the increase; Learning A-Z's own page was not checked ([source](https://spellingjoy.com/best-apps/app/raz-kids))
- ✅ Federal science-of-reading bill — H.R. 7890 passed the House Sep 16, 2026 (EdWeek, published Sep 17). It prioritizes SoR-aligned activities, bars three-cueing in grant-funded instruction, and covers the $194M CLSD program in 23 states. The bill number format was corrected ([source](https://www.edweek.org/teaching-learning/federal-science-of-reading-legislation-passes-the-house/2026/09))
- ✅ Reading Eggs — Reading & Math is $13.99/mo or $99.99/yr; Homeschool Max is $41.90/mo or $299/yr ([source](https://readingeggs.com/pricing/))
