# Branchline: a cheaper, simpler LibCal / LibraryMarket (events, rooms, program sign-ups), with a light ILS later, for small and rural public libraries

**One-liner:** A flat-priced, card-payable "front desk in the cloud" for small public libraries: an events calendar with registration and waitlists, meeting-room and study-room booking (with fees, deposits and policy agreements), equipment and "library of things" lending, and a one-page public website widget. It is the fast-selling slice. A lightweight hosted ILS (Koha or Evergreen under the hood) follows as V2 for the tiniest libraries.

## Snapshot
- **Replaces:**
  - **Springshare LibCal** is quote-based. One real contract: **Arlington Public Library paid $4,867/yr** for LibGuides with images and backup, **LibCal up to 50 calendars/rooms**, and LibStaffer for 109 staff (term invoiced through Jun 30 2021; older data) ([contract Exhibit B](https://vrapp.vendorregistry.com/Contract/View/DownloadContractFile?contractFileId=5241eed1-e904-4ddb-8e27-d4173356885e&addDate=08%2F26%2F2022+17%3A34%3A30&fileName=21-LIB-SS-306-RENEWAL.pdf)). LibCal is used by **3,600+ libraries** worldwide (Springshare, Nov 2024) ([Springshare blog](https://blog.springshare.com/2024/11/21/libcal-the-most-popular-event-ticketing-and-kit-management-software-for-libraries)).
  - **LibraryMarket LibraryCalendar** and **Communico** are quote-only, sold through consortia such as MCLS ([MCLS](https://www.mcls.org/eresources-products/vendors/library-market/)).
  - **ILS** (installed base, from Breeding's 2026 report):
    - SirsiDynix Symphony: 2,077 installs.
    - Clarivate Polaris: 599 installs, 195 new contracts in 2025.
    - Koha (ByWater): 1,710.
    - Apollo (Biblionix): 1,005.
    - Atriuum: 5,477.
    - Library.Solution (TLC): 430.
    - VERSO (Auto-Graphics): 557.

    ([LTG, 2026](https://librarytechnology.org/document/32505))
  - Apollo pricing is "quoted on an individual library basis". The subscription includes unlimited users, with paid add-ons for Acquisitions, Syndetics Unbound, Auto-Calling and Gabbie two-way texting ([Biblionix](https://www.biblionix.com/pricing/)).
  - A competitor-published estimate puts Koha hosting at about $500–$2,000/yr (unverified) ([LibraryAid](https://libraryaid.net/school-library-management-software)).
- **Recent price hikes / changes (switching windows):**
  - **SirsiDynix was acquired by Constellation Software's Harris division (Dec 2024).** The long-time CEO left (Breeding 2026) ([LTG](https://librarytechnology.org/document/32505)). Constellation-style owners are known for maintenance-price discipline; expect renewal pressure (inference, not verified).
  - **Auto-Graphics was acquired by Soutron / Bloom Equity (Mar 2025).** ByWater's founders left in late 2024 to start Grove for Libraries (Aspen Discovery) ([LTG](https://librarytechnology.org/document/32505)).
  - **IMLS shock.** The Mar 14 2025 executive order put at risk Grants to States funds (more than $180M in FY24) that pay for ILS consortia, courier services, databases and summer reading at small libraries ([LJ, Oct 2025](https://www.libraryjournal.com/story/concerned-but-committed-small-and-rural-libraries-feeling-the-impact-of-a-defunded-imls)).
    - Funding was restored by court order and appropriations: LSTA stands at $212.5M.
    - The **FY27 proposal zeroes IMLS again**. Maine State Library laid off 8 staff, and Alaska's books-by-mail service has not restarted ([LJ, Apr 2026](https://www.libraryjournal.com/story/one-year-after-the-executive-order)).
- **Who buys:**
  - **Library directors** of small public libraries, often the only full-time professional, with approval from a **library board** that meets monthly.
  - County library systems.
  - **State library agencies and regional consortia** that buy on behalf of members.
- **US market size:**
  - Estimate: about 9,000+ public library administrative entities (IMLS Public Libraries Survey, as commonly cited; verify the exact count).
  - **77% are "small" libraries** (ARSL via LJ, FY2022) ([LJ](https://www.libraryjournal.com/story/concerned-but-committed-small-and-rural-libraries-feeling-the-impact-of-a-defunded-imls)).
  - Example budget: **Burnsville (WV) Public Library runs on $48,000/yr** (LJ, Oct 2025).
  - Total dollar pool is modest. Estimate: 7,000 small libraries × $1,000–$3,000/yr of discretionary software equals **$7M–$21M/yr** for the events and rooms slice.
- **Urgency trigger (why they'd switch NOW):**
  - Budget cuts after the IMLS shock.
  - SirsiDynix and Auto-Graphics ownership changes.
  - Summer reading and fall programming registration seasons.
  - Many small libraries still run events on Google Calendar plus paper sign-up sheets, and room bookings by phone (anecdotal; verify through customer interviews).
- **Fastest-selling states/metros:**
  - States with many tiny libraries and weak consortia: **IA, KS, NE, NY** (small association libraries), **IL, WI, TX, OH, PA, VT, NH, ME**.
  - States whose consortia were hit by IMLS cuts: **ME, AK, WA, OR**.

## Pain points (evidence)
- **[Lock-in/Contracts]** In Breeding's 2024–25 survey, one respondent said SirsiDynix "has relied on customer inertia and locking libraries in to excessive multi year contracts to stay in business" ([Library Perceptions 2025](https://librarytechnology.org/perceptions/2024/)).
- **[Lock-in]** Symphony users are the most likely to consider migrating among major public-library ILSs: **16.2%**, versus 9.7% for Polaris and 1.9% for Apollo ([Library Perceptions 2025](https://librarytechnology.org/perceptions/2024/)).
- **[Complexity/UX]** Symphony reviewers describe it as "not intuitive", "full of bugs", "cumbersome and clunky", and much less user friendly than Book Systems (Capterra, 2018–2019; older) ([Capterra](https://www.capterra.com/p/8965/SirsiDynix-Symphony/reviews/)).
- **[Missing features]** Symphony reports are "clunky and antiquated", and management reports are "grossly inadequate and badly formatted" (Capterra, 2017–2018) ([Capterra](https://www.capterra.com/p/8965/SirsiDynix-Symphony/reviews/)).
- **[Vendor trust]** A Clarivate/Innovative customer said they "aren't happy with Innovative" and are only hopeful about a newer platform ([Library Perceptions 2025](https://librarytechnology.org/perceptions/2024/)).
- **[Price]** A small library said that without federal funds it "would have no funding for internet access or an ILS". Another expects a $10k–$15k hit from losing a state courier service alone, and a regional system needs $80k "just to get through the next fiscal year" (LJ, Oct 2025) ([LJ](https://www.libraryjournal.com/story/concerned-but-committed-small-and-rural-libraries-feeling-the-impact-of-a-defunded-imls)).
- **[Price]** LibCal is sold per module and per calendar count, for example "up to 50 calendars/rooms" and staff counts for LibStaffer. That is about $4.9k/yr for three modules at a mid-size city library (older contract) ([Arlington contract](https://vrapp.vendorregistry.com/Contract/View/DownloadContractFile?contractFileId=5241eed1-e904-4ddb-8e27-d4173356885e&addDate=08%2F26%2F2022+17%3A34%3A30&fileName=21-LIB-SS-306-RENEWAL.pdf)).
- **[Support/Staffing]** Maine State Library cut 8 staff and closed its physical location (LJ, Apr 2026). Small libraries lose the state help desk that set up their tools ([LJ](https://www.libraryjournal.com/story/one-year-after-the-executive-order)).
- **[Counter-evidence: honest]** Public libraries are **sticky and fairly satisfied**. Only 9.7% said they were interested in changing systems, and Breeding says public-library ILS products "have all reached mature levels of functionality" ([Library Perceptions 2025](https://librarytechnology.org/perceptions/2024/)). A full ILS replacement is a slow, low-pain sale. The events and rooms slice is where a new vendor can win quickly.
- *Evidence gap:* no public reviews of LibCal, LibraryMarket or Communico were retrievable in this pass. Reddit r/Librarians is blocked here, so interview 10 directors before building.

## What we build (the better version)
1. **MVP: Events calendar.**
   - Recurring events, age and audience tags, and registration with caps, **waitlists with auto-promote**, and reminders by SMS and email.
   - Attendance headcounts and **state annual-report program statistics** (the IMLS PLS program and attendance categories).
   - An embeddable widget for any website (WordPress, Google Sites, CivicPlus).
2. **MVP: Room booking.**
   - Meeting, study and makerspace rooms with public request forms and the **meeting-room policy acceptance** checkbox.
   - Nonprofit and for-profit fee schedules, Stripe deposits and fees, approval queues, and board-policy reporting on usage by group type.
3. **MVP: "Library of things" and equipment booking** (hotspots, telescopes, laptops, cake pans), with checkout and return reminders. This covers equipment without a full ILS.
4. **MVP: Program registration and summer reading hook.** Paid and free registrations for classes, plus an optional link to R02 ReadRally for summer reading challenges.
5. **MVP: Patron-light accounts.** Email or phone login with no ILS dependency. Optional SIP2/patron-API check against the ILS card number (V2 for most ILSs).
6. **MVP: Import tools.** Import from LibCal, Google Calendar and CSV, and migrate room policies with AI help from existing PDFs.
7. **V2: Branchline ILS Lite** for libraries under about 50k items:
   - hosted Koha or Evergreen with a simplified staff UI;
   - MARC import, Z39.50 copy cataloging, barcode labels;
   - SIP2 for self-check, holds and notices;
   - free migration from Apollo, Atriuum, Symphony, Library.Solution and VERSO exports.
8. **V2: Consortium mode** (shared events across branches or member libraries, shared room inventories), sold to **regional systems and state libraries**.
9. **V2: Digital signage** (the "today's events" TV screen) and a kiosk mode.

## Pricing to win
- **Events + Rooms + Things:** flat, by population. **$49/mo** under 10k, **$99/mo** to 50k, **$199/mo** to 150k. Unlimited calendars, rooms, staff and SMS reminders up to fair use.
  - Versus LibCal's module and calendar-count pricing (about $4.9k/yr across three modules in one older contract).
  - A small library saves an estimated **$1,000–$3,000/yr** against LibCal or LibraryMarket. Those vendor prices are estimates; verify with 3–5 real quotes.
- **ILS Lite (V2):** **$1,200/yr** under 25k population, **$2,400/yr** to 50k. Free migration and month-to-month. Target price below Apollo and Atriuum quotes (unverified; collect quotes).
- **No multi-year contracts.** This is the explicit anti-SirsiDynix message.

## Go-to-market (first 100 customers)
- **ARSL** (Association for Rural & Small Libraries): its annual conference (fall) and its webinar and listserv community. Rural and small directors are the core buyer.
- **State library association conferences** in the fall and spring: ILA (IA and IL), KLA (KS), NLA (NE), NYLA, WLA (WI), OLC (OH), TLA (TX), PaLA (PA), VLA/NHLA/MLA (New England).
- **State library agency consultants and regional library systems.** In NY, IL and WI, member-library systems buy or recommend tools; win one system and get dozens of libraries. A "state libraries hit by IMLS cuts" discount offers consortium pricing to replace lost subsidies.
- **Channels:** Public Libraries Online/PLA webinars; "LibCal alternative" and "library room booking software" SEO pages; free for libraries serving under 2,500 people (the long tail) to seed referrals; a monthly "new library joined" case study.
- **Procurement reality:** directors can often buy under $1,000–$2,500 without full board approval (varies; estimate). Price the MVP under that line. A full ILS switch takes 6–18 months (board, contract end, migration), so it waits for V2.

## Risks and incumbent moats
- **Low urgency.** Satisfied ILS customers (Apollo at 1.9% considering migration) and slow boards. *Mitigation:* lead with the cheap events and rooms slice, which doesn't touch the ILS.
- **Integration.** SIP2 and NCIP, ILS patron APIs, and consortium ILL are deep technical moats. *Mitigation:* V1 needs none of them; V2 builds on open-source Koha or Evergreen.
- **Consortium lock-in.** Many small libraries share an ILS through a state or regional consortium that they cannot leave alone. *Mitigation:* sell the add-on events and rooms layer, which consortia usually don't provide.
- **Small dollar pool.** Revenue per customer is low. *Mitigation:* self-serve onboarding, card billing, and bundles with R02 ReadRally (summer reading) and R01 school features for county-school partnerships.
- **Accessibility and public-sector requirements.** WCAG 2.1 AA is required under the DOJ's 2024 Title II web rule. State and local governments must comply from **Apr 2026** for large entities and **Apr 2027** for small ones (verify dates). *Mitigation:* build accessible from day one and turn it into a selling point, which also acts as a switching trigger against older calendars.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 2 | 3 | 4 | 2 | 2 | **13** |

*(Scored for the events and rooms MVP. A full ILS replacement would score Build ease 2 and Sales speed 1.)*

## Sources
- [Library Systems Report 2026 (Breeding, Library Technology Guides)](https://librarytechnology.org/document/32505)
- [2025 Library Systems Report (American Libraries)](https://americanlibrariesmagazine.org/2025/05/01/2025-library-systems-report/)
- [Library Perceptions 2025 survey (Breeding)](https://librarytechnology.org/perceptions/2024/)
- [SirsiDynix Symphony reviews (Capterra)](https://www.capterra.com/p/8965/SirsiDynix-Symphony/reviews/)
- [Apollo pricing page (Biblionix)](https://www.biblionix.com/pricing/)
- [Arlington Public Library Springshare contract, Exhibit B pricing](https://vrapp.vendorregistry.com/Contract/View/DownloadContractFile?contractFileId=5241eed1-e904-4ddb-8e27-d4173356885e&addDate=08%2F26%2F2022+17%3A34%3A30&fileName=21-LIB-SS-306-RENEWAL.pdf)
- [LibCal: most popular event software (Springshare, Nov 2024)](https://blog.springshare.com/2024/11/21/libcal-the-most-popular-event-ticketing-and-kit-management-software-for-libraries)
- [LibCal for Public Libraries (Springshare)](https://www.springshare.com/public-libraries/libcal)
- [Library Market vendor page (MCLS)](https://www.mcls.org/eresources-products/vendors/library-market/)
- [LibraryAid school library software comparison (competitor-published estimates)](https://libraryaid.net/school-library-management-software)
- [Small and rural libraries feel IMLS defunding (Library Journal, Oct 2025)](https://www.libraryjournal.com/story/concerned-but-committed-small-and-rural-libraries-feeling-the-impact-of-a-defunded-imls)
- [One year after the executive order (Library Journal, Apr 2026)](https://www.libraryjournal.com/story/one-year-after-the-executive-order)
- [IMLS cuts put public libraries at risk (ALA, Apr 2025)](https://www.ala.org/news/2025/04/imls-cuts-put-americas-public-libraries-risk)
