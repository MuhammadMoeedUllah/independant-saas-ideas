# TowLedger: impound and storage-lot compliance plus dispatch for small towing companies (a lighter Towbook / Omadi / Beacon)

**One-liner:** Dispatch, impound and storage-lot management for 1–10 truck towing companies and vehicle storage facilities. It runs the state-specific parts, such as nonconsent fee caps, owner-notice deadlines, release forms and lien-sale timelines, with no call-volume tiers.

## Snapshot
- **Replaces:**
  - **Towbook** (checked Sep 24 2026, [Towbook pricing](https://towbook.com/pricing/)):
    - Basic $109/mo (up to 250 calls a month).
    - Professional $209/mo (500 calls).
    - Ultimate+ $319/mo (1,000 calls).
    - Enterprise $429/mo (1,500 calls), with overage at $149 per extra 1,000 calls.
    - +$109/mo for each additional company, location or division.
    - Month to month, 30-day free trial.
  - **Omadi, Beacon, TOPS, Dispatch Anywhere:** pricing not captured in this pass.
- **Recent price hikes / changes:**
  - **None found.** Towbook is month to month and highly rated (4.8/5 from 82 Capterra reviews) ([Capterra towing software](https://www.capterra.com/towing-software/)).
  - The main cost lever is the call-volume tiers and the per-location fee.
- **Who buys:** The owner of a small towing company, often also a vehicle storage facility (VSF) operator. The mix is police rotation, private-property (nonconsent) and motor-club work.
- **US market size:** Not sized in this pass. Estimate tens of thousands of towing companies (NAICS 488410); verify with Census CBP.
- **Urgency trigger (why they'd switch NOW):** Weak. The strongest trigger is state or city rule changes on nonconsent towing and storage. For example, Texas TDLR sets nonconsent fee caps (light-duty tow $272, drop $135, storage $21.03 a day, impoundment $21.03, effective Nov 1 2021), requires VSF-12/VSF-13 release forms (since Jul 4 2022), and moved to electronic inspections (Dec 16 2022) ([TDLR towing](https://www.tdlr.texas.gov/towing/towing.htm)).
- **Fastest-selling states/metros (inference):** TX (TDLR-regulated nonconsent and VSF), FL, CA, GA and IL (Chicago). These are states and cities with heavy private-property towing and active "predatory towing" legislation. Verify in the per-state pass.

## Pain points (evidence)
**Evidence is thin.** We did not find 8 or more owner complaints in this pass: Reddit was blocked, and Towbook is well liked. Treat this as a compliance-led wedge, not an angry-customer switch.
- **[Price]** Towbook prices by monthly call volume, so a busy season pushes a company from $209 to $319 or $429, with overage of $149 per 1,000 calls ([Towbook pricing](https://towbook.com/pricing/)).
- **[Price]** Each extra company, location or division costs +$109/mo. That is a common setup for operators who keep separate towing and storage-lot entities (same source).
- **[Compliance complexity]** Texas VSFs must collect completed VSF-12 or VSF-13 forms, payment and valid ID before releasing a vehicle. Fees are capped per tow class and per day of storage, and card surcharges are limited ([TDLR](https://www.tdlr.texas.gov/towing/towing.htm)).
- **[Compliance change]** TDLR discontinued VSF-11 (Jul 2022), moved inspections to an electronic system (Dec 2022) and proposed Chapter 85 rule changes (Sep 2023), so paper-based lots keep falling behind (same source).
- **[Missing features, hypothesis]** Many motor-club jobs (Agero, Allstate, Urgently, Honk) come through separate portals with their own rate sheets and payment lag. Validate this in customer interviews; no source was captured.

## What we build (the better version)
1. **MVP:** Call intake and dispatch board with driver app (PWA), GPS arrival, photos of vehicle condition, and e-signature.
2. **MVP:** An **impound and storage module** with a lot map and per-day storage accrual that **auto-caps at the state or city maximum**. Release checklist (ID, proof of ownership, state release form such as TX VSF-12/13) and a printable release receipt.
3. **MVP:** An **owner-notice engine**. It looks up the registered owner (manual entry at first, state DMV or NMVTIS data services in V2), generates certified-mail notices on state-specific deadlines, and tracks lien or abandoned-vehicle sale timelines.
4. **MVP:** Private-property accounts, with signage compliance photos, the property authorization on file, and a patrol log.
5. **MVP:** Invoicing and payments with a surcharge cap enforced per state.
6. **V2:** Motor-club reconciliation. Import motor-club statements and match them to jobs, flagging short-pays and aging.
7. **V2:** Police rotation logs and exports for city and county reports.
8. **V2:** State rulepacks beyond TX (FL, CA, GA, IL, and cities such as Chicago, Denver and Minneapolis). Verify in the per-state pass.

## Pricing to win
- **Our prices:** $99/mo flat for unlimited calls, including impound. $49/mo for each extra entity.
- **Example:** A company doing 700 calls a month is on Towbook Ultimate+ at $319/mo; with a second storage entity it pays $428/mo. On TowLedger it pays $148/mo, saving about $3.4k/yr.

## Go-to-market (first 100 customers)
- **Associations:** TRAA (Towing and Recovery Association of America) and its state affiliates, including the California Tow Truck Association (CTTA) and Texas towing and VSF associations. Present a "TDLR compliance" session.
- **Trade shows:** American Towman ShowPlace and the Florida Tow Show.
- **Communities:** r/TowTrucks and towing-owner Facebook groups.
- **Licensee lists:** TDLR publishes tow and VSF licensee lists for direct outreach in Texas.

## Risks and incumbent moats
- **Towbook is cheap, month to month and well rated.** The switch has to be driven by compliance and storage features.
- **Motor-club integrations** (Agero and others) are gated partnerships, so this is V2.
- **DMV owner lookups** require DPPA-permissible-use access through approved data vendors.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 2 | 2 | 4 | 3 | 2 | **13** |

## Sources
- [Towbook pricing (checked Sep 24 2026)](https://towbook.com/pricing/)
- [Capterra: Towing software category (ratings, Sep 2026)](https://www.capterra.com/towing-software/)
- [Texas TDLR: Towing, Booting and Vehicle Storage](https://www.tdlr.texas.gov/towing/towing.htm)
