# Chairly: a cheaper, better Vagaro / Fresha / Mindbody-Booker for independent stylists, barbers, nail & lash techs and suite renters

**One-liner:** Flat-price booking, deposits, reminders and payouts for beauty pros. No marketplace commission, no à-la-carte add-ons, and you can bring your own card processor.

## Snapshot
- **Replaces:**
  - **Fresha** (pricing page, accessed Sep 24 2026): Independent **$19.95/mo** (1 team member); Team **$14.95 per bookable team member/mo**; Enterprise custom for 20+. **20% one-time commission on marketplace new clients ($6 minimum)**. Card rates 2.29% + $0.20 in person (+$0.10 per tap), 2.79% + $0.20 online, 3.30% + $0.20 keyed. Only 100 texts/mo free, then $0.02 each; marketing texts $0.08. Add-ons: AI Concierge $99.95/location/mo, Client Loyalty $59.95, Insights $9.95 per member, Smart Website $15.95 ([Fresha pricing](https://www.fresha.com/pricing)).
  - **Vagaro** (2026 third-party breakdown): **$30/mo for 1 calendar, +$10/mo per extra calendar** (Vagaro's own page: $10 per license up to 7 licenses, extra staff free after that; new single-location accounts get an intro $23.99/mo for the first 6 months, [Vagaro pricing](https://www.vagaro.com/pro/pricing)). Add-ons: Text Marketing $20, Forms $10, MySite website $20, Branded App $100, Payroll $34 + $5/employee, Data Lake $40, Check-In $10, QuickBooks $10, Xero $30. Card present 2.2%, keyed/online 3.5% + $0.30 ([Koalendar, 2026](https://koalendar.com/blog/vagaro-pricing)).
  - **Mindbody / Booker** (salon line): Mindbody stopped publishing tier prices as of mid-2026. Operators report base plans of $139–$599/mo that often reach $1,000+ after add-ons and marketplace fees ([Vibefam summary of r/gymowner threads, 2026](https://vibefam.com/mindbody-reviews-reddit-2026/)).
  - Also in the set: GlossGenius, Boulevard, Booksy, Squire (barbers). We did not re-verify their prices in this pass.
- **Recent price hikes / changes:**
  - **Fresha, Mar 2025:** moved from "free" software to a **mandatory per-team-member subscription** with little warning, on top of the existing 20% new-client commission ([Sort The Clicks, 2026](https://sorttheclicks.com/fresha-reviews-reddit/)).
  - **Mindbody:** added a "new client discovery fee", which operators discussed in [r/mindbody](https://www.reddit.com/r/mindbody/comments/1pde1yv/did_you_know_about_the_new_new_client_discovery/).
  - **Vagaro:** Trustpilot sits at **3.6/5 (701 reviews)**. The Sept 2026 reviews cluster on billing, frozen funds and outages ([Trustpilot](https://www.trustpilot.com/review/vagaro.com)).
- **Who buys:** Solo stylists, barbers, nail/lash/brow techs, estheticians, salon-suite renters and small salons (2–10 chairs). The owner buys with a card, usually from a phone.
- **US market size:** Estimate only: several hundred thousand US beauty and barber businesses (NAICS 812111–812113), most of them nonemployer booth or suite renters. Confirm with Census County Business Patterns / Nonemployer Statistics in the state pass.
- **Urgency trigger (why they'd switch NOW):** Fresha's 2025 move to a paid subscription broke its "free" promise. The 20% marketplace commissions and per-calendar add-ons pile up. Mindbody added discovery fees. Vagaro users report frozen payouts and outages (Sept 2026).
- **Fastest-selling states/metros:** Salon-suite-heavy Sun Belt metros: Dallas–Fort Worth, Houston, Atlanta, Phoenix, Tampa, Orlando, Charlotte. Also LA and NYC for lash, brow and nail studios. (Qualitative estimate.)

## Pain points (evidence)
- **[Price]** A licensed esthetician called Fresha "deceptively very expensive" and said the "free to get started" pitch is bait; broader 2025–26 Reddit threads call the March 2025 change "greedy" (r/Esthetics, via [Sort The Clicks](https://sorttheclicks.com/fresha-reviews-reddit/)).
- **[Price]** A long-time Fresha user says fee after fee has been added for "lifetime free" clients: 20% on new clients, plus charges for reminder texts that used to be free (Capterra, Oct 2024) ([Capterra](https://capterra.com/p/142138/Shedul-com/reviews/)).
- **[Price]** A wellness business left Fresha because text-message surcharges and processing made it "too expensive" (Capterra, Feb 2025) ([Capterra](https://capterra.com/p/142138/Shedul-com/reviews/)).
- **[Price / Lock-in]** An early Fresha member says the company is not honoring the "free forever" promise made to early adopters 8–10 years ago (Capterra, Sep 2025) ([Capterra](https://capterra.com/p/142138/Shedul-com/reviews/)).
- **[Price]** A Vagaro user was charged a 20% new-client commission on a booking that came from her own Instagram link (Trustpilot, Sep 5 2026) ([Trustpilot](https://www.trustpilot.com/review/vagaro.com)).
- **[Price]** A Vagaro user was billed for 9,000+ marketing emails that were never sent (Jul–Aug 2026), with no credit after weeks (Trustpilot, Aug 24 2026) ([Trustpilot](https://www.trustpilot.com/review/vagaro.com)).
- **[Lock-in/Contracts]** A Vagaro user cancelled within a day but was charged for two months, then had to phone in to stop the charges (Trustpilot, Sep 21 2026) ([Trustpilot](https://www.trustpilot.com/review/vagaro.com)).
- **[Support / Payments]** A Vagaro account was frozen after it had already taken payments, leaving no access to funds or transaction reports (Trustpilot, Sep 18 2026) ([Trustpilot](https://www.trustpilot.com/review/vagaro.com)).
- **[Complexity/UX]** Constant Vagaro shutdowns and glitches blocked payments, and schedule outages cost a shop "thousands" (Trustpilot, Sep 15 2026) ([Trustpilot](https://www.trustpilot.com/review/vagaro.com)).
- **[Support]** Fresha has no phone support and does not always answer emails (Capterra, Feb 2024) ([Capterra](https://capterra.com/p/142138/Shedul-com/reviews/)).
- **[Missing features]** A new lash tech was invisible in Fresha marketplace search despite five-star reviews, and the ranking rules are opaque (r/eyelashextensions, via [Sort The Clicks](https://sorttheclicks.com/fresha-reviews-reddit/)).

## What we build (the better version)
1. **MVP** Instagram/TikTok-ready booking page with one link per stylist or suite and your own subdomain. Services, add-ons and processing times (for color). Mobile-first.
2. **MVP** Deposits, card-on-file and a no-show/late-cancel fee policy enforced automatically, through Stripe Connect or Square (bring your own processor, zero markup option).
3. **MVP** **Zero marketplace commission, ever.** Each client is tagged by source (IG, Google, referral) so the owner can see where bookings come from.
4. **MVP** Unlimited SMS and email reminders and confirmations included, with no per-text surcharges up to a fair-use cap. Two-way texting and a waitlist that auto-fills cancellations.
5. **MVP** Client cards: formulas and color notes, lash maps, before/after photos, allergy and consent forms. E-sign forms are included, not a $10 add-on.
6. **MVP** Free concierge import from Vagaro, Fresha, GlossGenius, Booksy and Square exports (clients, future appointments, notes).
7. **MVP** AI receptionist in DMs and SMS that answers "do you have anything Friday?" and books against real availability.
8. **V2** Suite-owner mode: the suite landlord collects weekly rent, deposits and late fees from renters, and each renter keeps their own booking brand.
9. **V2** Commission and booth-rent payroll splits, tip pooling and 1099 summaries for salon owners.
10. **V2** Rebooking nudges ("you're due for a fill in 2 weeks"), a simple product shop and gift cards.
11. **V2** Google Reserve and Apple Maps booking links, plus a review-request automation.

## Pricing to win
- **Solo: $19/mo flat**, everything included (forms, texts, website, deposits), 0% commission. **Studio (2–10 chairs): $49/mo flat.** Month-to-month, free migration.
- **Example:** a solo lash tech on Vagaro with 1 calendar ($30), Forms ($10), Text Marketing ($20) and MySite ($20) pays **$80/mo** before processing and fees. On Chairly she pays **$19**, saving about **$730/yr**. A 5-chair Fresha salon pays 5 × $14.95 = $74.75 plus 20% on every marketplace new client (on a $150 service that is $30 per new client) plus text overages. On Chairly it pays $49 flat.
- Revenue upside: optional processing at a transparent small markup (for example Stripe's cost + 0.3%), clearly disclosed.

## Go-to-market (first 100 customers)
- **Reddit:** r/Hairstylist, r/salonowners, r/Esthetics, r/eyelashextensions, r/Nails, r/Barber. Answer "Fresha/Vagaro alternatives?" threads honestly and offer free migration.
- **Facebook groups:** Salon-suite owner groups, "Lash Business Owners" groups, barber business groups, and Behind the Chair's community.
- **Trade shows:** America's Beauty Show (Chicago), Premiere Orlando, IBS New York / Las Vegas, and the Barber Expo circuit. A booth demo with "import your Vagaro book in 10 minutes".
- **Partners:** Salon-suite operators (independent suite buildings) as a landlord channel, where one deal brings 20–60 renters. Cosmetology schools, bundled free for graduates for 6 months.
- **SEO:** "Fresha alternative no commission", "Vagaro add-on costs", "switch from Vagaro", "GlossGenius vs", plus calculator pages that show the true monthly bill.
- **Instagram/TikTok creators:** lash and nail educators with affiliate revenue share.

## Risks and incumbent moats
- **Payments dependency:** incumbents make money on processing. We use Stripe Connect or Square so owners can bring their own account. Card-on-file migration needs processor-to-processor token transfer, which Stripe supports for PCI data imports. Otherwise we re-collect cards at the next visit.
- **Marketplace demand:** Booksy, Fresha and Vagaro send new clients. Our counter is that most solo pros fill their books from Instagram and referrals, so we plug into Google Reserve and IG instead of running our own marketplace.
- **Feature breadth / crowded category:** we win on flat price, no commission and migration speed, not feature count.
- **Data lock-in:** exports are often partial. We offer concierge scraping and CSV cleanup with AI.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 4 | 5 | 5 | **22** |

## Sources
- [Fresha pricing page (accessed Sep 24 2026)](https://www.fresha.com/pricing)
- [Fresha Reviews 2026: The 20% Fee Salon Owners Complain About on Reddit – Sort The Clicks](https://sorttheclicks.com/fresha-reviews-reddit/)
- [Fresha reviews – Capterra](https://capterra.com/p/142138/Shedul-com/reviews/)
- [Vagaro Pricing: Real Costs, Hidden Fees – Koalendar (2026)](https://koalendar.com/blog/vagaro-pricing)
- [Vagaro reviews – Trustpilot](https://www.trustpilot.com/review/vagaro.com)
- [Mindbody reviews on Reddit – Vibefam (2026)](https://vibefam.com/mindbody-reviews-reddit-2026/)
- [r/mindbody: "new" new client discovery fee](https://www.reddit.com/r/mindbody/comments/1pde1yv/did_you_know_about_the_new_new_client_discovery/)
- [Mindbody to Acquire Booker Software – Mindbody press](https://www.mindbodyonline.com/company/press/mindbody-to-acquire-booker-software)

## Verification (Sep 24 2026)
- ✅ Fresha Independent $19.95/mo, Team $14.95 per team member, 20% new-client commission ($6 min), card rates, 100 free texts then $0.02, add-on prices — all match the pricing page ([source](https://www.fresha.com/pricing))
- ✅ Fresha moved from free to a mandatory per-team-member subscription in March 2025 "with little warning" ([source](https://sorttheclicks.com/fresha-reviews-reddit/)). Minor fix: "greedy" is attributed to broader Reddit threads, not the one esthetician.
- ✅ Vagaro $30/mo + $10 per extra calendar and add-on prices — confirmed by Koalendar ([source](https://koalendar.com/blog/vagaro-pricing))
- ✅ Vagaro's own page confirms $30/mo and $10 per license, but caps paid licenses at 7 (more staff free) and offers an intro $23.99/mo for 6 months; note added ([source](https://www.vagaro.com/pro/pricing))
- Scores unchanged.
