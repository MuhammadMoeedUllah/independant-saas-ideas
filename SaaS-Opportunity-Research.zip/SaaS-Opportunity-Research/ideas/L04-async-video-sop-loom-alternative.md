# ClipSOP: a cheaper, fairer Loom for small teams that record how-tos, client updates and SOPs

**One-liner:** A browser and desktop screen recorder where **viewers and occasional recorders are always free**. You pay one flat team price, and every recording becomes a written, searchable step-by-step SOP with AI included, not sold as an add-on.

## Snapshot
- **Replaces:**
  - **Loom** (Supademo, updated Aug 18, 2026):
    - Starter (free): **25 videos, 5 minutes max, 720p**.
    - Business: **$18/user/mo**.
    - Business + AI: **$24/user/mo**.
    - Enterprise: custom.
    - Annual plans now use **fixed user tiers** (e.g., 50/100/250, or 101–200 users at one rate).
  - **Cheap challengers already exist:** Cap.so (open source; $9/mo hosted, $20/user team), Tella, Screen Studio, CleanShot X. Prices come from Screenify's Apr 29, 2026 comparison, and Screenify is itself a competitor. Scribe and Tango sell SOP capture (prices not verified in this pass).
- **Recent price hikes / changes:**
  - Atlassian bought Loom (acquisition announced Oct 2023). Loom is being moved onto Atlassian billing and accounts.
  - **The Creator Lite role (free occasional creators) is discontinued.** Creator Lite users are auto-promoted to paid Creators at the next billing date after integration (Atlassian Support). Atlassian staff say Creator Lite is deprecated for all net-new users **after February 2026** (Atlassian Community).
  - One user in that thread saw their price go **from $10 to $18/mo**.
  - Supademo cites an organization with 100 users but only 10 active creators whose cost went **from $240/yr to $24,000/yr**. Screenify reports the same figure from a Hacker News post (early 2026). The primary post was not verified.
  - The free tier shrank from 25 minutes and 100 videos (2022) to **5 minutes and 25 videos**, and old videos are hidden at the cap (Screenify, Apr 29, 2026; competitor source).
- **Who buys:** ops leads, founders and team leads at **5–100-person SMBs**, including agencies, SaaS support and success teams, bookkeeping firms, franchise operators and training-heavy service businesses. A few people record often, many record occasionally, and clients just watch.
- **US market size:** Loom reported more than 25M users and about 200k customers at the time of the Atlassian acquisition (Oct 2023 announcement; not re-verified in this pass). The addressable pool is every SMB using async video or SOP docs: hundreds of thousands of US firms (estimate).
- **Urgency trigger (why they'd switch NOW):** the **first Atlassian-billed renewal** after Creator Lite removal (rolling from Feb 2026). Occasional recorders become paid seats, bills jump, and admins must re-authenticate everyone through Atlassian accounts.
- **Fastest-selling states/metros:** remote-heavy SMB and SaaS hubs such as the SF Bay Area, Austin, Denver, NYC, Seattle, Boston and Salt Lake City. Franchise HQ clusters (Dallas, Atlanta, Phoenix) for SOP use.

## Pain points (evidence)
Loom's own review pages (Trustpilot, Capterra) blocked our fetches. Several bullets below come from secondary sources, and two are from a competitor (Screenify). They are labeled, and should be re-checked on G2 or Reddit before launch copy.
- **[Price]** A customer asks what they get for a rate increase from $10 to $18/mo and is weighing whether to keep the service (Atlassian Community, 2026) ([source](https://community.atlassian.com/forums/Loom-questions/What-features-will-I-expect-to-have-after-rate-increase/qaq-p/3257207))
- **[Price]** With Creator Lite gone, an organization with 100 users but 10 active creators went from $240/yr to $24,000/yr (Supademo analysis, Aug 18, 2026) ([source](https://supademo.com/blog/loom-pricing))
- **[Lock-in/Contracts]** Creator Lite users are auto-promoted to paid seats. Admins must download activity reports and deactivate people before the billing date to avoid charges (Atlassian Support) ([source](https://support.atlassian.com/loom/docs/loom-customer-integration-with-atlassian-pricing-billing-and-role-changes/))
- **[Lock-in/Contracts]** Annual plans now bill in fixed user tiers (e.g., 101–200 users at one rate), so you pay for the whole tier (Atlassian Support; Supademo) ([source](https://support.atlassian.com/loom/docs/loom-customer-integration-with-atlassian-pricing-billing-and-role-changes/))
- **[Missing features]** The free plan is capped at 5 minutes per video and 25 videos at 720p (Supademo, Aug 2026). Older videos are hidden at the cap until you upgrade (Screenify, competitor, Apr 29, 2026) ([source](https://supademo.com/blog/loom-pricing), [source](https://www.screenify.studio/blog/2026-04-29-why-people-leave-loom-2026))
- **[Price]** AI titles, summaries, filler-word removal and Q&A are gated to the Business + AI tier at $24/user (Supademo; Screenify, competitor) ([source](https://www.screenify.studio/blog/2026-04-29-why-people-leave-loom-2026))
- **[Complexity/UX]** The forced move to Atlassian accounts caused temporary lockouts, multi-step re-authentication and lost sessions, and IT teams spent support hours coordinating it (Screenify, competitor, citing Reddit r/sysadmin and G2) ([source](https://www.screenify.studio/blog/2026-04-29-why-people-leave-loom-2026))
- **[Support]** Ongoing stability problems are reported in 2025–26: lag, audio sync issues and login difficulties (Supademo, Aug 2026) ([source](https://supademo.com/blog/loom-pricing))
- **[Missing features]** There are questions about whether recordings are used for AI training under Atlassian terms, about cross-product data sharing, and about EU residency (Screenify, competitor) ([source](https://www.screenify.studio/blog/2026-04-29-why-people-leave-loom-2026))

**Honest read:** pure "cheap Loom" is crowded (Cap, Tella and others). The sharper wedge is **Creator Lite refugees plus SOPs**:
- **(a)** Free unlimited occasional recorders and viewers.
- **(b)** Every video auto-generates a written step-by-step SOP with screenshots, so the output is documentation, not just a video link.
- **(c)** Flat team pricing with no tier buckets.

## What we build (the better version)
1. **Browser recorder** (Chrome/Edge extension plus a web app using MediaRecorder): screen, camera bubble, mic, trim, and instant share link. **MVP**
2. **Fair seat model:** **free "Contributors"** can record up to 10 videos/mo each, viewers are unlimited and free, and only "Power creators" count. We auto-downgrade anyone inactive for 30 days. **MVP**
3. **Auto-SOP.** Transcription plus key-frame capture produce a written step-by-step guide with screenshots. You can edit it and export to Google Docs, Notion, Confluence or PDF. **MVP**
4. **AI included on every paid plan:** titles, summaries, chapters, filler-word removal, translation captions, and "ask this video." **MVP** (summary, chapters, captions). **V2** (Q&A across the library)
5. **SOP library:** folders by team or role, a search inside transcripts, "required viewing" assignments, and view tracking. This is for onboarding and franchise training. **MVP** (library and search). **V2** (assignments and quizzes)
6. **Client-facing mode:** branded share pages, CTA buttons, a comment thread per timestamp, and email alerts when a client watches. **MVP**
7. **Loom importer:** bulk-download Loom MP4s (Loom allows MP4 download per Atlassian staff), re-host them, keep titles and folders, and redirect old links where possible. **MVP** (bulk import from a folder or zip). **V2** (API-assisted)
8. **Native desktop app** (macOS ScreenCaptureKit, Windows) for 4K and system audio. **V2**
9. **Privacy defaults:** no training on customer videos, US or EU storage choice, and SSO. **MVP** (policy and US storage). **V2** (EU region, SSO)
10. **Meeting-notes add-on:** upload a Zoom or Meet recording and get a summary, action items and pushed tasks. **V2**

## Pricing to win
| Plan | ClipSOP | Loom equivalent |
|---|---|---|
| Free | 1 power creator, unlimited viewers, 25 min/video, 50 videos | Starter: 5 min, 25 videos |
| Team **$29/mo flat** | 5 power creators + **unlimited free contributors**, AI + auto-SOP, 1080p | 5 × $24 Business+AI = $120/mo, and every occasional recorder is now a paid seat |
| Company **$79/mo flat** | 20 power creators, SOP library, branding, SSO (V2) | 20 × $24 = $480/mo, or a whole annual user tier |

Month-to-month, with free bulk migration.

**Savings example (using the Supademo scenario):** 100 users, 10 heavy creators. The reported Loom bill is about $24,000/yr. The ClipSOP Company plan is $948/yr.

## Go-to-market (first 100 customers)
- **"Switch from X" SEO:**
  - "Loom Creator Lite removed"
  - "Loom price increase Atlassian"
  - "Loom alternative free viewers"
  - "Loom 5 minute limit"
  - "turn screen recording into SOP"
- **Communities:** r/sysadmin (the Atlassian account migration threads), r/SaaS, r/startups, r/agency, r/Entrepreneur, r/franchise, and customer-success communities (Gain Grow Retain, CS-focused Slack groups).
- **Marketplaces:** Chrome Web Store, Product Hunt, a capped AppSumo launch (strict creator caps), and the Notion and Confluence integration directories.
- **Direct outreach:** a Loom-renewal calculator, "paste your Loom user count and creator count and see the new Atlassian bill versus ours."
- **Partners:** franchise consultants and onboarding and training agencies.

## Risks and incumbent moats
- **Bundling:** Atlassian includes Loom in Teamwork Collection bundles, and Zoom, Slack Clips and Teams all record video. Answer: sell to teams that need SOP output and fair seats, not to Atlassian-wide enterprises.
- **Crowded cheap competitors** (Cap, Tella, Scribe, Tango). Answer: our combination of free contributors plus video-to-SOP plus flat pricing. Validate that no competitor already ships this exact combination.
- **Video hosting and transcoding costs.** Answer: a Cloudflare Stream or Mux class provider, 1080p caps on lower tiers, and a storage cap per plan.
- **Link rot on migration.** Old Loom links can't be redirected unless the customer embeds them. Answer: a CSV of old-to-new links plus a Notion and Confluence link-rewrite tool.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 4 | 4 | **18** |

## Sources
- [Loom Pricing in 2026: Creator Lite Changes and Real Cost – Supademo](https://supademo.com/blog/loom-pricing) (updated Aug 18, 2026)
- [Loom Customer Integration with Atlassian: Pricing, Billing, and Role Changes – Atlassian Support](https://support.atlassian.com/loom/docs/loom-customer-integration-with-atlassian-pricing-billing-and-role-changes/) (2026)
- [What features will I expect to have after rate increase? – Atlassian Community](https://community.atlassian.com/forums/Loom-questions/What-features-will-I-expect-to-have-after-rate-increase/qaq-p/3257207) (2026)
- [Why Teams Are Leaving Loom in 2026 – Screenify Studio](https://www.screenify.studio/blog/2026-04-29-why-people-leave-loom-2026) (Apr 29, 2026; competitor source)
- [Atlassian Fiscal 2026 Cloud Pricing Notice](https://s206.q4cdn.com/270053503/files/doc_downloads/2025/09/Fiscal-2026-Cloud-Pricing-notice.pdf) (Oct 15, 2025 effective; Loom not listed)
