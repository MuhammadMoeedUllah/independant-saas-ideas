# NexusBook: a cheaper, better Avalara / TaxJar for small e-commerce and SaaS sellers

**One-liner:** Flat-priced sales-tax software for sellers with 200 to 25,000 orders a month. It tracks economic nexus in every state, calculates rates, captures exemption certificates, and prepares or files returns for a flat fee per filing instead of a charge per order.

## Snapshot
- **Replaces:**
  - **TaxJar (owned by Stripe since 2021)**, per [TaxJar Support, updated Jun 12 2026](https://support.taxjar.com/article/139-how-much-does-taxjar-cost):
    - Starter runs from $39/mo (200 orders) up to $19,999/mo (10M orders).
    - Professional runs from $99/mo (200 orders) up to $49,999/mo.
    - AutoFile costs $50 per filing on Starter and $55 per filing on Professional, pay as you go.
    - Filing bundles: 25 filings cost $1,125 (Starter) or $1,250 (Professional). Unlimited filing costs $10,000/yr (Starter) or $12,000/yr (Professional).
  - **Avalara (AvaTax + Returns)** publishes no list price. According to [TaxCloud's blog, updated Jun 2 2026](https://taxcloud.com/blog/avalara-pricing/) (a competitor, so possibly biased):
    - Vendr data puts the average spend at **$16,717/yr**, ranging from $3,750 to $75,385.
    - Registration costs $403 per location, up from $349 in 2025.
    - Single-state filing costs $42–$65 per filing plus an activation fee.
    - Managed Returns overage is $80+ per return, and late payments accrue 1.5% a month.
    - Reviewers say sales pushed a $15,000/yr support package.
  - **Vertex** is enterprise-focused. Pricing was not verified in this pass.
- **Recent price hikes / changes:**
  - **TaxJar 2026 repricing.** Per [TaxCloud, 2026](https://taxcloud.com/blog/taxjar-price-increase-2026/), again a competitor source:
    - The changes began rolling out in late February / early March 2026.
    - **Month-to-month customers move to the new pricing on October 1, 2026.** Annual customers move at renewal, from mid-2026 through late February 2027.
    - Professional annual prices by order volume:

      | Orders | Old | New | Change |
      |---|---|---|---|
      | 500 | $2,149 | $2,499 | +16% |
      | 1K | $3,769 | $4,999 | +33% |
      | 2.5K | $5,389 | $11,999 | +123% |
      | 5K | $7,009 | $15,999 | +128% |
      | 10K | $9,169 | $19,999 | +118% |
      | 25K | $11,869 | $24,999 | +111% |

    - AutoFile pay-as-you-go went from $35 to $55 (+57%), and Unlimited went from $7,500 to $12,000 (+60%).
    - TaxJar's own support page confirms the new $55 and $12,000 figures.
  - **Avalara** raised registration from $349 to $403 per location (2025 to 2026, per the same competitor blog). Trustpilot reviewers describe binding annual contracts.
- **Who buys:**
  - Owners and ops/finance leads at Shopify, Amazon, WooCommerce and Etsy brands and small B2B SaaS companies with multistate nexus.
  - Their outsourced bookkeepers and CPAs.
- **US market size:**
  - Estimate: low hundreds of thousands of US online sellers have crossed nexus in more than one state. Not verified; size it with Shopify and Amazon seller counts in the per-state pass.
  - Sales-tax automation already supports many venture-funded challengers (Zamp, Numeral, Kintsugi, TaxCloud, Taxwire, Galvix all publish "TaxJar alternative" content, seen in search results). That shows the dollar pool is real, and also that the space is crowded.
- **Urgency trigger (why they'd switch NOW):**
  - **Oct 1, 2026:** TaxJar month-to-month customers roll onto prices up to about 2.3x higher.
  - Annual TaxJar customers face the same change at renewal through Feb 2027.
  - States dropping the 200-transaction nexus test pull more sellers into (or out of) filing obligations: Illinois on Jan 1 2026 and Kentucky on Aug 1 2026.
- **Fastest-selling states/metros:**
  - Sellers based anywhere. Nexus pressure is highest in the largest destination states (CA, TX, NY, FL, IL, WA).
  - States that just changed their thresholds (IL, KY) create "do I still have to file?" confusion that we can answer.

### Economic-nexus changes worth tracking (from [Avalara blog, as of Aug 1 2026](https://www.avalara.com/blog/en/north-america/2025/06/states-eliminating-economic-nexus-transaction-thresholds.html))
- **States that have dropped the transaction-count threshold and now use sales dollars only:**
  - Alaska (the Remote Seller Commission, for participating local governments)
  - California, Colorado, **Illinois (Jan 1 2026)**, Indiana, Iowa, **Kentucky (Aug 1 2026)**, Louisiana, Maine, Massachusetts, North Carolina, North Dakota, South Dakota, Utah, Washington, Wisconsin, Wyoming
- The same source says 14 states plus DC and Puerto Rico still have transaction thresholds, and names **New Jersey** as the likely next state to drop its threshold.
- Marketplace-facilitator nuances (whether marketplace sales count toward the threshold) vary by state. They were not captured in this pass.

## Pain points (evidence)
- **[Price]** TaxJar Professional renewals rise 110–128% at 2.5K–25K orders a month. AutoFile goes from $35 to $55 per filing, and the average overall increase is put at "~100% or greater" ([TaxCloud, 2026](https://taxcloud.com/blog/taxjar-price-increase-2026/)).
- **[Price/Lock-in]** An Avalara customer paying $352/mo says Pennsylvania filings failed five months in a row, yet the annual contract kept them from cancelling ([Trustpilot, Tamar Daniel, Jun 11 2026](https://www.trustpilot.com/review/avalara.com)).
- **[Support/Price]** An accountant pays about $5k a year for Avalara support alone and still gets looping ticket systems, overcharges and constant errors ([Trustpilot, Jun 30 2026](https://www.trustpilot.com/review/avalara.com)).
- **[Support/Billing]** A reviewer says Avalara overcharged them massively and they cannot reach anyone to cancel or get a refund ([Trustpilot, Sep 2026](https://www.trustpilot.com/review/avalara.com)).
- **[Lock-in]** A four-month struggle to cancel, with no human response since July and invoices still arriving ([Trustpilot, Chris R, Aug 27 2026](https://www.trustpilot.com/review/avalara.com)). This one involves a VAT registration: the profile is Avalara's Europe listing, but it shows the same billing pattern.
- **[Support]** Cases reopened with duplicate questions, and escalations closed without a fix ([Trustpilot, May 26 2026](https://www.trustpilot.com/review/avalara.com)). Avalara's profile averages 3.1/5 on 505 reviews.
- **[Support]** A consumer-goods CEO describes "lousy customer service when it comes to adding new states" at TaxJar ([Capterra, Mar 29 2024](https://www.capterra.com/p/163419/TaxJar/reviews/1570003/)).
- **[Missing features]** TaxJar has "no way to capture tax exempt certificates for clients," and the reviewer says quality has slipped since the acquisition ([Capterra, CTO, Jan 14 2025](https://www.capterra.com/p/163419/TaxJar/reviews/1570003/)).
- **[Price/Support]** TaxJar called an "overpriced poorly supported app," where support said it no longer offers configuration assistance ([Capterra, Oct 2022, older](https://www.capterra.com/p/163419/TaxJar/reviews/1570003/)).
- **[Accuracy]** TaxJar was "not calculating tax rates correctly" ([Capterra, Nov 2021, older](https://www.capterra.com/p/163419/TaxJar/reviews/1570003/)).
- **[Price]** Avalara has no public pricing. Customers who switch report saving 30–70% (competitor claim, [TaxCloud](https://taxcloud.com/blog/avalara-pricing/)).

## What we build (the better version)
1. **MVP: one-click connectors** for Shopify, Stripe, Amazon (settlement reports), WooCommerce, Etsy, Square and a CSV upload. Order history backfills 12 months.
2. **MVP: a nexus radar.** A live threshold meter for all 45 states with sales tax plus DC.
   - It handles calendar-year, rolling 12-month and previous-year tests, and whether marketplace-facilitator sales are included.
   - It flags the states that dropped transaction counts (IL, KY and the others above) automatically.
   - Email/SMS alerts fire at 70%, 90% and 100% of a threshold.
3. **MVP: a registration concierge (DIY).** A per-state checklist with the data you need, a direct portal link, the typical approval time and the filing frequency you'll likely be assigned. The seller data is prefilled so you can copy and paste it.
4. **MVP: a rate engine.** Destination rates down to the address or ZIP+4 level, built from free state-published rate files and SST rate/boundary files. Every rate has a visible source and an "as of" date.
5. **MVP: a filing calendar and return-prep packets.** Per state, each packet lists gross sales, taxable sales, exempt sales, marketplace-collected sales and jurisdiction breakdowns, laid out in the order the state portal asks for them. It exports to PDF/CSV for the seller or their bookkeeper.
6. **MVP: exemption-certificate capture.** A B2B buyer-facing upload link, AI extraction of the certificate number and expiry, and expiry reminders. This closes the gap TaxJar reviewers complain about.
7. **MVP: a SaaS and digital-goods taxability matrix.** It shows which states tax SaaS or digital downloads, and the rate, with law citations.
8. **V2: AutoFile** through state portals for a flat $19 per filing, with payment by ACH debit. We would also apply to become an SST Certified Service Provider, which lets the states pay for filing in the 24 SST member states.
9. **V2: marketplace reconciliation.** It proves Amazon, Etsy and Walmart already remitted tax, so the same sales aren't double-reported.
10. **V2: an accountant console.** A multi-client dashboard with white-label client reports and a partner revenue share.
11. **V2: notice-response AI.** Upload a state letter and get a plain-English explanation plus a draft response.

## Pricing to win
- **Our plans:**
  - **Starter $29/mo:** up to 1,000 orders a month, nexus radar and return-prep for 3 states.
  - **Growth $79/mo:** up to 10,000 orders a month and unlimited states.
  - **Scale $149/mo:** up to 50,000 orders a month.
  - **AutoFile $19 per filing (V2).**
  - Month to month, no activation fees, and free migration by importing TaxJar/Avalara exports.
- **Illustrative savings for a brand with 2,500 orders a month filing monthly in 5 states (60 filings a year):**
  - TaxJar after the repricing: $11,999 plus 60 × $55 = $3,300, so about **$15,299/yr**.
  - NexusBook: $79 × 12 = $948 plus 60 × $19 = $1,140, so about **$2,088/yr**.
  - That is about 86% less. The example is our own arithmetic from list prices, not a customer quote.

## Go-to-market (first 100 customers)
- **"TaxJar Oct 1 price increase" landing page** with a calculator (enter your orders and states, see the old price, the new price and ours). We would run search ads on "TaxJar price increase," "TaxJar alternative" and "Avalara alternative."
- **Shopify App Store and WooCommerce plugin listing** with a free nexus radar (no filing) as the lead magnet.
- **Bookkeepers and fractional CFOs** in e-commerce (Xero/QBO ProAdvisor directories, e-commerce accounting firms). We would offer free accountant seats and a 20% revenue share, since one accountant can bring 10–40 clients.
- **Communities:** r/ecommerce, r/shopify, r/FulfillmentByAmazon, r/AmazonSeller, r/EtsySellers, r/SaaS, Indie Hackers and e-commerce founder Facebook groups. We would post "IL/KY dropped the 200-transaction rule: do you still need to file?" explainers.
- **Cold email** to Shopify stores with a sales-tax app installed (BuiltWith/StoreLeads lists), sent in the two weeks before Oct 1 and before each annual renewal month.

## Risks and incumbent moats
- **Rate accuracy liability.** We would use only authoritative state and SST data, show the source and date for every rate, and offer an accuracy guarantee that covers penalties, capped.
- **Filing automation is brittle** (state portal changes, MFA). That is why filing is V2. The MVP sells nexus tracking, return-prep and exemption capture.
- **Stripe Tax is bundled** for Stripe merchants. Stripe Tax's pricing was not verified in this pass. We win on multichannel sales (Amazon, Shopify) and on filing cost.
- **Crowded category** (Zamp, Numeral, Kintsugi, TaxCloud and others). We differentiate on flat pricing for the long tail, an accountant channel and SaaS taxability. Note the MVP must still integrate with 5+ commerce platforms.
- **SOC 2** will be asked for by bigger sellers. That is a V2 item, handled with a compliance-automation vendor.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 2 | 4 | 4 | **18** |

## Sources
- [TaxJar Support: How much does TaxJar cost? (updated Jun 12 2026)](https://support.taxjar.com/article/139-how-much-does-taxjar-cost)
- [TaxCloud: TaxJar Price Increase 2026 (competitor source)](https://taxcloud.com/blog/taxjar-price-increase-2026/)
- [TaxCloud: Avalara Pricing 2026 (competitor source, Jun 2 2026)](https://taxcloud.com/blog/avalara-pricing/)
- [Trustpilot: Avalara reviews](https://www.trustpilot.com/review/avalara.com)
- [Capterra: TaxJar reviews](https://www.capterra.com/p/163419/TaxJar/reviews/1570003/)
- [Avalara: States eliminating economic nexus transaction thresholds (as of Aug 1 2026)](https://www.avalara.com/blog/en/north-america/2025/06/states-eliminating-economic-nexus-transaction-thresholds.html)
- [TaxCloud Sales Tax Radar: Illinois ends 200-transaction threshold (Jan 1 2026)](https://taxcloud.com/sales-tax-radar/illinois-eliminates-transaction-threshold-2026/) (search-result title, not opened)
- [Zamp: TaxJar review 2026](https://zamp.com/blog/taxjar-review) (search result only, not opened)
