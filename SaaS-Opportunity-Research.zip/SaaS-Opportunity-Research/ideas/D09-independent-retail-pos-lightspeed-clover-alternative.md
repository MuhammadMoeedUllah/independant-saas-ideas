# ShelfPOS: a cheaper, better Lightspeed Retail / Clover for independent boutiques and specialty shops

**One-liner:** Inventory-first retail POS for independent shops. You choose any processor with no penalty, pay a flat per-location price, and get AI product import and Shopify/website sync.

## Snapshot
- **Replaces:**
  - **Clover** (per PaymentPop, Sept 23, 2026): Retail Basic at 2.6% + 10c; Retail Standard/Advanced at 2.3% + 10c. Equipment subscriptions on a **36-month term**: Retail Basic Compact $16/mo, Retail Standard Station Duo $180/mo, Retail Advanced $240/mo. Rapid Deposit costs 1.75% ([PaymentPop](https://paymentpop.com/merchant-accounts/clover-pos-customer-reviews/)).
  - **Lightspeed Retail:** plan prices were not verified in this pass ([Capterra pricing page](https://www.capterra.com/p/120491/Lightspeed-Retail/pricing/)). Reviewers report a fee for *not* using Lightspeed Payments (see below).
  - **Shopify POS Pro:** a competitor; current price not verified this pass.
- **Recent price hikes / changes:**
  - **Late 2025:** A Lightspeed retail owner (Oct 22, 2025) reported service costs rising $40/mo. Another retailer (Sept 28, 2025) received a surprise **$930 invoice for declining Lightspeed's card processing** ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).
  - **2023-2024 Clover forced migration:** Fiserv migrated about 200,000 legacy Payeezy merchants to Clover. The July 2025 securities suits allege merchants were leaving Clover for Square and Toast ([Payments Dive](https://www.paymentsdive.com/news/fiserv-sued-over-clover-migration/754200/)). Those 36-month equipment terms reach their end in 2026-27.
- **Who buys:** Owners of independent boutiques, gift shops, bookstores, outdoor and bike shops, liquor and wine stores, pet stores, garden centers, and museum and park gift shops. Usually 1-5 locations, $300k-$5M revenue. This segment overlaps with D05-D08 venues' retail counters.
- **US market size:** Estimate: hundreds of thousands of independent US retail stores. Unverified; Census County Business Patterns for NAICS 44-45 should be checked.
- **Urgency trigger (why they'd switch NOW):** Clover 36-month terms from the 2023-24 migration wave are expiring. Lightspeed payments-lock penalties and price increases. Holiday season prep (buyers decide Aug-Oct, or in January after the holidays).
- **Fastest-selling states/metros:** Tourist-town retail (the same clusters as D07: Gatlinburg, Key West, Sedona, Charleston, Cape Cod), plus dense boutique metros (NYC, LA, Austin, Nashville, Denver, Portland). Estimate.

## Pain points (evidence)
- **[Lock-in/Price]** A retailer (11-50 employees, Sept 28, 2025) got a surprise $930 invoice for not using Lightspeed's card processing ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).
- **[Price]** A retail owner (Oct 22, 2025) said service costs rose $40/mo, making Lightspeed pricier than competitors ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).
- **[Reliability]** The same owner said nonfunctional card readers forced them to key in card numbers by hand, which carries higher keyed rates ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).
- **[Support]** A retail owner (Dec 23, 2024) reported high account-manager turnover and no follow-up from supervisors ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).
- **[Reliability]** A retail owner (June 2023) said the iPad app crashes frequently and the Bluetooth card reader keeps disconnecting ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).
- **[Reliability]** A retail director (Aug 2022) reported card transactions taking 30 seconds to 3 minutes, and complained about features being removed ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).
- **[Lock-in/Contracts]** Clover reviewers cite non-cancelable 36-month equipment contracts and billing after cancellation and equipment return ([PaymentPop](https://paymentpop.com/merchant-accounts/clover-pos-customer-reviews/)).
- **[Price]** Clover reviewers report hidden equipment and app charges above the quoted price, and deposit holds ([PaymentPop](https://paymentpop.com/merchant-accounts/clover-pos-customer-reviews/)).
- **[Lock-in]** Clover customer-data retention makes switching systems hard ([PaymentPop](https://paymentpop.com/merchant-accounts/clover-pos-customer-reviews/)).
- **[Complexity/UX]** A Lightspeed apparel owner found the system rigid and data export limited. This review is older (2017) ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).
- Overall: Lightspeed Retail has 4.0/5 on 975 Capterra reviews.

## What we build (the better version)
1. **MVP: AI product import.** Photograph a shelf or upload a vendor invoice or catalog PDF to create SKUs with variants (size and color), costs, barcodes and categories.
2. **MVP: Fast checkout** on iPad or Android with a barcode scanner, Tap to Pay or a reader, receipts by SMS or email, returns and exchanges, and store credit and gift cards.
3. **MVP: Processor-agnostic by design.** Stripe Terminal by default, with **no penalty for bringing your own processor** (V2 adds other processor integrations).
4. **MVP: Inventory.** Purchase orders, receiving, low-stock alerts, transfers between locations, and cycle counts with a phone camera.
5. **MVP: Customer profiles and a simple loyalty program**, plus email and SMS "new arrivals" campaigns.
6. **MVP: Reports.** Sell-through, dead stock, margin by vendor and brand, and open-to-buy. CSV export always available.
7. **V2: Two-way Shopify/WooCommerce sync** of inventory and orders, plus Google local inventory ads feed.
8. **V2: AI reorder suggestions** based on sales velocity and seasonality.
9. **V2: Vertical packs.** Serialized bike and outdoor gear with work orders, liquor age checks, and consignment for resale shops.

## Pricing to win
- **ShelfPOS:** $49/mo per location with unlimited registers and staff; $89/mo per location with e-commerce sync and multi-location transfers. Processing at Stripe cost plus a disclosed markup, or bring your own processor for **$0 penalty**. Month-to-month, free data migration.
- **Savings example:** A boutique on Clover Retail Standard pays $180/mo in equipment subscription on a 36-month term. With ShelfPOS on an existing iPad plus a reader, it pays $49/mo, saving about $1,500/yr. It also avoids surprise penalties like the $930 non-processing invoice reported by a Lightspeed user.

## Go-to-market (first 100 customers)
- **"Clover contract ending?" campaign:** an ETF and contract-end calculator for Payeezy-to-Clover migration-era merchants.
- **Independent retail associations:** state retail federations, the American Booksellers Association, and regional gift-trade shows (verify dates). Buying groups for bike shops and outdoor retailers.
- **Main Street and downtown business associations** in tourist towns (bulk onboarding days).
- **Reddit and forums:** r/smallbusiness and r/retail, plus the Shopify community forums.
- **"Lightspeed alternative," "switch from Clover" SEO pages** and a free inventory-import concierge.
- **Referral:** Bookkeepers and retail consultants get a revenue share.

## Risks and incumbent moats
- **Square and Shopify POS are strong and cheap.** The price gap is moderate, so we win on inventory depth for specialty retail plus no processor penalty.
- **Hardware:** barcode scanners, label printers and cash drawers need driver support. Start with a small certified hardware list.
- **Payments:** Stripe handles PCI. Supporting third-party processors in V2 means integration work.
- **Data migration:** Product catalogs with variants are messy. AI import is the differentiator.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 2 | 3 | 5 | **16** |

## Sources
- [Lightspeed Retail reviews – Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)
- [Lightspeed Retail pricing – Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/pricing/)
- [Lightspeed Retail reviews – G2](https://www.g2.com/products/lightspeed-retail/reviews)
- [Clover POS Reviews 2026 – PaymentPop (Sept 23, 2026)](https://paymentpop.com/merchant-accounts/clover-pos-customer-reviews/)
- [Fiserv sued over Clover migration – Payments Dive](https://www.paymentsdive.com/news/fiserv-sued-over-clover-migration/754200/)
- [Fiserv Class Action Lawsuit Guide 2026 – Lawfold](https://lawfold.com/fiserv-class-action-lawsuit/)
