# PlainLedger: a cheaper, better QuickBooks Online / Xero for service businesses

**One-liner:** Books, invoicing, bills and bank reconciliation for 1–50 person service businesses. AI does the categorizing, the price is flat $29–$59/mo, and your QuickBooks history comes over in one click.

## Snapshot
- **Replaces:**
  - **QuickBooks Online, list prices effective Aug 1, 2026 at renewal:**

    | Plan | Old | New | Increase |
    |---|---|---|---|
    | Simple Start | $38/mo | $38/mo (unchanged) | 0% |
    | Essentials | $75/mo | $85/mo | +13% |
    | Plus | $115/mo | $140/mo | +22% |
    | Advanced | $275/mo | $340/mo | +24% |

    Sources: [SWK Technologies, Sep 14, 2026](https://www.swktech.com/2026-quickbooks-price-increases-what-they-mean-for-your-renewal/); [Beancount.io, Aug 25, 2026](https://beancount.io/blog/2026/08/25/quickbooks-online-price-hike-advanced-70-percent-guide).
    - Payroll, Payments, Bill Pay ACH fees and 1099 e-filing are billed separately ([Beancount.io](https://beancount.io/blog/2026/08/25/quickbooks-online-price-hike-advanced-70-percent-guide)).
  - **QuickBooks Desktop, from Feb 1, 2026:** Pro Plus/Mac Plus $1,149/yr (was $999). Premier Plus $1,609/yr (was $1,399). Extra seats $230/yr (was $200) ([SWK](https://www.swktech.com/2026-quickbooks-price-increases-what-they-mean-for-your-renewal/)).
  - **Xero US, current then Oct 1, 2026:** Early $25 → $27, Growing $55 → $59, Established $90 → $97 per month. Xero Payroll (powered by Gusto) is $36/mo + $6 per person ([Xero pricing](https://www.xero.com/us/pricing-plans/); [Booksla, Aug 2026](https://www.booksla.com/xero-price-increase/)).
  - **FreshBooks:** not verified this pass.
- **Recent price hikes / changes:**
  - **QBO price history:**

    | Date | Simple Start | Essentials | Plus | Advanced |
    |---|---|---|---|---|
    | Aug 2023 | $30 | $60 | $90 | $200 |
    | Aug 2024 | $35 | $65 | $99 | $235 |
    | Jul 2025 | $38 | $75 | $115 | $275 |
    | Aug 2026 | $38 | $85 | $140 | $340 |

    Sources: [NerdWallet, updated Mar 2026](https://www.nerdwallet.com/article/small-business/quickbooks-pricing); SWK. **Plus is up 56% and Advanced up 70% in three years.**
  - **QuickBooks Desktop:** Intuit stopped selling new Pro Plus, Premier Plus and Mac Plus subscriptions after Sep 30, 2024. Renewals only, at higher prices ([SWK](https://www.swktech.com/2026-quickbooks-price-increases-what-they-mean-for-your-renewal/)).
  - **Xero:** hike on Oct 1, 2026 (about 7–8%). It is paired with free ACH bill pay and no fee for extra users ([Booksla](https://www.booksla.com/xero-price-increase/)). An Australian trainer calls it the sixth year in a row of increases ([EzyLearn, Sep 2026](https://ezylearn.com.au/2026/09/xero-raises-prices-again-six-years-in-a-row-are-the-new-features-worth-it/)); headline only, not fetched.
- **Who buys:** Owners of 1–50 person service firms (agencies, consultants, trades, clinics, nonprofits), usually on the advice of their outside bookkeeper or CPA.
- **US market size:** Estimate, not verified this pass. There are about 6M US employer firms and tens of millions of non-employer firms (SBA background). QBO is the default for most. Serviceable market: 1M+ businesses paying $30–$140/mo.
- **Urgency trigger (why they'd switch NOW):**
  - The Aug 1, 2026 QBO renewal hike and the Oct 1, 2026 Xero hike.
  - Clean-cutover windows: **Jan 1, 2027** (new fiscal year) and the Desktop Plus renewal cycle for stranded Desktop users.
- **Fastest-selling states/metros:** Estimate. States with the most small businesses: CA, TX, FL, NY, GA, IL. Plus metros with dense bookkeeper networks (Phoenix, Dallas, Atlanta, Tampa).

## Pain points (evidence)
- **[Price]** QBO Plus went from $90 (Aug 2023) to $140 (Aug 2026) and Advanced from $200 to $340 ([NerdWallet](https://www.nerdwallet.com/article/small-business/quickbooks-pricing); [SWK](https://www.swktech.com/2026-quickbooks-price-increases-what-they-mean-for-your-renewal/)).
- **[Price]** One guide calls the Aug 2026 hike "the third time in two years," and notes that payroll, payments, Bill Pay ACH and 1099 e-filing are all billed on top ([Beancount.io](https://beancount.io/blog/2026/08/25/quickbooks-online-price-hike-advanced-70-percent-guide); competitor-adjacent blog).
- **[Lock-in / forced migration]** Desktop Pro Plus and Premier Plus were pulled from new sale (Sep 30, 2024), then raised about 15% for renewers on Feb 1, 2026 ([SWK](https://www.swktech.com/2026-quickbooks-price-increases-what-they-mean-for-your-renewal/)).
- **[Forced migration]** A user moved from QuickBooks Self-Employed to QBO without proper notice ended up with about 70 missing invoices and unresolved support tickets (Aug 20, 2026) ([Trustpilot](https://www.trustpilot.com/review/quickbooks.intuit.com)).
- **[Billing]** A long-term customer waited 10+ months for a refund of duplicate charges across multiple billing names, with emails ignored and callbacks missed (Sep 2, 2026) ([Trustpilot](https://www.trustpilot.com/review/quickbooks.intuit.com)).
- **[Billing / cancellation]** A user couldn't reach support to cancel and disputed charges after asking to cancel (Sep 19, 2026) ([Trustpilot](https://www.trustpilot.com/review/quickbooks.intuit.com)).
- **[Billing]** A 60-day money-back guarantee was measured in a way that produced only a partial refund on an annual plan (Aug 21, 2026) ([Trustpilot](https://www.trustpilot.com/review/quickbooks.intuit.com)).
- **[Complexity/UX]** A user calls QBO "expensive, complicated, difficult to use," with repeated login and verification failures blocking access (Sep 21, 2026) ([Trustpilot](https://www.trustpilot.com/review/quickbooks.intuit.com)).
- **[Reliability]** An Aug 2026 update broke the Shopify connector. One merchant now manually reviews 400+ orders a month (Aug 31 and Sep 23, 2026) ([Trustpilot](https://www.trustpilot.com/review/quickbooks.intuit.com)).
- **Balance note:**
  - The Trustpilot profile has 16,928 reviews at 3.7/5 and appears to mix UK and US reviewers, so treat individual reviews as directional.
  - Xero's hike is modest and comes with sweeteners, so Xero users are a weaker target than QBO Plus/Advanced users.

## What we build (the better version)
1. **MVP:** **One-click QBO import** (OAuth + QBO API): chart of accounts, customers, vendors, items, open invoices/bills and a transaction history snapshot. Plus Xero and QB Desktop (IIF/Excel) import.
2. **MVP:** A double-entry GL with bank feeds (Plaid) and **AI categorization** that learns from the imported history and explains each suggestion. Bank reconciliation, then month-end close checklist.
3. **MVP:** Invoices, estimates and recurring invoices with card/ACH through the customer's own Stripe account (no markup), plus automated reminders.
4. **MVP:** Bills and AP with receipt capture by email or photo (AI extraction) and 1099 vendor tracking (1099-NEC/MISC export to a filing partner).
5. **MVP:** Standard reports: P&L, balance sheet, cash flow, AR/AP aging, and P&L by class/project (a QBO Plus feature we include for everyone).
6. **MVP:** **Free accountant seats** and a multi-client bookkeeper dashboard (the ProAdvisor-style hub).
7. **V2:** Sales tax (via a Stripe Tax/TaxJar-style API), inventory lite, and budgets vs. actuals.
8. **V2:** Payroll through an embedded payroll partner (see G04) and bill pay ACH at cost.
9. **V2:** Industry packs: agencies (project profitability), trades (job costing, retainage), nonprofits (fund accounting lite).
10. **V2:** An AI "close assistant" that drafts the monthly close memo, flags anomalies and prepares tax-ready trial balance exports for Drake, UltraTax and ProConnect.

## Pricing to win
- **Plans:** Core $29/mo (unlimited users, invoices, bank feeds). Pro $59/mo (classes/projects, multi-currency, budgets, API).
- **Terms:** Accountants free. Month-to-month. Free migration.
- **Example:** A service firm on QBO Plus pays $140 × 12 = **$1,680/yr**. PlainLedger Pro costs $708/yr, saving **$972/yr**. A firm on QBO Advanced ($4,080/yr) saves about $3,370/yr.

## Go-to-market (first 100 customers)
- **Bookkeepers first:** r/Bookkeeping, r/Accounting, r/smallbusiness, bookkeeper Facebook groups, AIPB (American Institute of Professional Bookkeepers), NACPB, and state CPA societies (e.g., TXCPA, FICPA, CalCPA tech conferences).
  - Offer wholesale pricing: $19/client/mo, which they can mark up.
- **SEO pages:**
  - "QuickBooks price increase August 2026"
  - "QuickBooks Plus $140 alternative"
  - "QuickBooks Desktop Pro Plus renewal alternative"
  - "Xero price increase October 2026 US"
- **Launch timing:** A "Start fresh Jan 1, 2027" campaign (Oct–Dec 2026), with free opening-balance setup.
- **Marketplaces:** Stripe App Marketplace, Shopify App Store (target the broken-QBO-connector crowd), and Gusto/Check integrations.

## Risks and incumbent moats
- **Accountant ecosystem and familiarity:** QBO is the lingua franca for CPAs. Mitigation: free accountant seats, clean trial-balance exports into the major tax packages, and a bookkeeper wholesale program.
- **Bank-feed reliability:** Plaid costs and outages. Mitigation: CSV/OFX fallback and budgeting for Plaid costs in the $29 tier.
- **App ecosystem** (hundreds of QBO integrations). Mitigation: API plus Zapier, and focus on the 15 integrations that matter.
- **Accuracy liability:** Mitigation: AI suggestions require confirmation, full audit trail, locked periods.
- **Build ease is moderate, not easy:** A GL, reconciliation and reporting that CPAs trust takes longer than a CRUD app. Expect a 6–8 week MVP.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 2 | 3 | 5 | **18** |

## Sources
- [2026 QuickBooks Price Increases – What They Mean for Your Renewal (SWK Technologies, Sep 14, 2026)](https://www.swktech.com/2026-quickbooks-price-increases-what-they-mean-for-your-renewal/)
- [QuickBooks Online Just Raised Advanced to $340 a Month (Beancount.io, Aug 25, 2026)](https://beancount.io/blog/2026/08/25/quickbooks-online-price-hike-advanced-70-percent-guide)
- [QuickBooks Pricing 2026 (NerdWallet, updated Mar 2026)](https://www.nerdwallet.com/article/small-business/quickbooks-pricing)
- [QuickBooks Online pricing changes (Intuit)](https://quickbooks.intuit.com/r/product-update/quickbooks-price-changes/)
- [Xero US pricing (fetched Sep 24, 2026)](https://www.xero.com/us/pricing-plans/)
- [Xero Price Increase: What Changes October 1, 2026 (Booksla, Aug 2026)](https://www.booksla.com/xero-price-increase/)
- [Xero Raises Prices Again — Six Years in a Row (EzyLearn, Sep 2026)](https://ezylearn.com.au/2026/09/xero-raises-prices-again-six-years-in-a-row-are-the-new-features-worth-it/)
- [Intuit QuickBooks reviews (Trustpilot)](https://www.trustpilot.com/review/quickbooks.intuit.com)
