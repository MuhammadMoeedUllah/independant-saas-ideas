# ReadyTutor LA: a cheaper, better Wyzant / Varsity Tutors / Outschool for Louisiana reading tutors paid by Steve Carter vouchers and LA GATOR

**One-liner:** A flat-price practice kit for Louisiana reading tutors and small tutoring centers. It turns state money (the $1,500 Steve Carter tutoring vouchers and the LA GATOR ESA on Odyssey) and families facing the Act 422 third-grade retention rule into booked, documented, science-of-reading-aligned sessions, with no marketplace cut.

## Snapshot
- **Replaces** (pricing as documented in P04, 2026):
  - **Wyzant:** the tutor keeps 75%, and a separate 9% service fee applies to all lessons ([Wyzant fee structure](https://support.wyzant.com/tutors/tutor-payments/what-is-the-fee-structure-for-tutors-listed-on-wyzant/)).
  - **Outschool:** keeps 30% of the class price, with payouts 7–13 days later (policy dated Mar 4 2026) ([Outschool earnings policy](https://support.outschool.com/en/articles/2382129-teacher-earnings-and-payments-policy)).
  - **Preply:** 33% commission that falls to 18% at 400+ hours, and it keeps 100% of each new student's first lesson ([MyEngineeringBuddy, Jul 2026](https://www.myengineeringbuddy.com/blog/preply-reviews-features-pricing-alternatives/)).
  - **Varsity Tutors (Nerdy):** tutor pay is set by the company ([Nerdy 10-Q via StockTitan, Aug 6 2026](https://www.stocktitan.net/sec-filings/NRDY/10-q-nerdy-inc-quarterly-earnings-report-7ae2fdff5381.html)).
  - **DIY stack:** Google Sheets session logs, Zoom, paper sign-in sheets and Odyssey invoices typed by hand.
- **Recent price hikes / changes (switching windows):**
  - **Voucher raised and widened:** HB 244 (2024 RS) raised the Steve Carter voucher from **$1,000 to $1,500**, added math, and extended eligibility to K–12 students below mastery. That makes **369,033 students eligible** ([Legislative Fiscal Office note](https://www.legis.la.gov/Legis/ViewDocument.aspx?d=1380593)).
  - **Funding doubled for 2025–26:** LDOE matched the state's $5M for 2025–26, for **$10M in total** ([LDOE newsroom, Aug 27 2025](https://doe.louisiana.gov/about/news-releases/louisiana-tutoring-initiative)).
  - **Retention in force:** Act 422 (HB 12, 2023) has made third-grade promotion depend on the reading score since **2024–25**. Retained students get evidence-based tutoring, and parents sign an at-home reading contract ([KTAL](https://www.ktalnews.com/news/education/edwards-signs-louisiana-education-bill-to-retain-3rd-graders-who-fail-to-meet-reading-standard/)).
  - **Misuse penalties:** HB 186 (2026) adds criminal penalties for deliberate misuse of LA GATOR funds ([FutureEd, Jul 13 2026](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)). Providers now want spotless records.
  - **Marketplace retreat:** Nerdy is winding down Varsity Tutors for Schools from **Jul 31 2026** (10-Q above), which displaces tutors and school clients.
- **Who buys:**
  - Certified and retired teachers who tutor reading in Louisiana, dyslexia therapists, small tutoring centers (2–10 tutors), and micro-schools serving GATOR families.
  - The owner-tutor pays by card.
- **US market size:**
  - **Louisiana only at launch.** 369,033 students are eligible for Steve Carter vouchers (fiscal note).
  - **Voucher pool:** the $10M 2025–26 budget covers up to about **6,667 vouchers at $1,500** (estimate: $10M ÷ $1,500, ignoring admin costs). The fiscal note assumed only 0.8% participation, or about 2,952 students.
  - **GATOR:** tutoring spend is unknown, but awards run $5,243–$15,253 per student and can pay for tutoring ([LDOE LA GATOR](https://doe.louisiana.gov/topic-pages/louisiana-school-choice/la-gator)).
  - **Tutor count:** Louisiana has no confirmed count. Estimate: low thousands.
  - The TAM (total addressable market) is small. This is a state wedge that shares a codebase with P01, P04 and F07.
- **Urgency trigger (why they'd switch NOW):**
  - **Screener windows:** Bulletin 741 requires K–3 screeners in the first 30 days, in December and in April ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/louisiana/)). Each window produces a fresh list of eligible students.
  - **Retest windows:** spring and summer retest attempts under Act 422.
  - **Next GATOR application window:** about Mar 2027 (verify).
  - **Federal credits:** tax-credit scholarships start Jan 1 2027, and Louisiana opted in on Dec 17 2025 ([Ballotpedia](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)). Whether that money can fund tutoring depends on each scholarship-granting organization's (SGO's) rules (verify).
- **Fastest-selling states/metros:**
  - Baton Rouge, New Orleans/Jefferson, Lafayette, Shreveport-Bossier and Lake Charles (estimate).
  - **Expansion (verify each program):** P01/P04 states where public money pays tutors, such as Texas TEFA on the same Odyssey rails and Missouri MOScholars (tutoring is an allowed expense).

## Pain points (evidence)
No Louisiana-specific tutor reviews were found this pass. The bullets combine documented marketplace complaints (from P04) with the structural friction written into Louisiana's own program rules.
- **[Price]** Outschool keeps 30% of every payment ([Outschool policy](https://support.outschool.com/en/articles/2382129-teacher-earnings-and-payments-policy)). A teacher reviewer says the cut rose from 17% to 30% (Indeed, Apr 20 2026; reviewer claim) ([Indeed](https://www.indeed.com/cmp/Outschool/reviews)).
- **[Price]** Wyzant takes 25% plus a separate 9% service fee, even on students the tutor brought in ([Wyzant](https://support.wyzant.com/tutors/tutor-payments/what-is-the-fee-structure-for-tutors-listed-on-wyzant/)).
- **[Price]** Varsity Tutors tutors report "very low pay and no bargaining power" (Apr 10 2026), and pay and benefits are rated 2.8/5 ([Indeed](https://www.indeed.com/cmp/Varsity-Tutors/reviews?fjobtitle=Tutor&ftopic=paybenefits)).
- **[Reliability]** Varsity student opportunities are "very inconsistent" (Aug 27 2026). Nerdy is winding down Varsity Tutors for Schools from Jul 31 2026 ([Indeed](https://www.indeed.com/cmp/Varsity-Tutors/reviews?fjobtitle=Tutor&ftopic=paybenefits); [Nerdy 10-Q](https://www.stocktitan.net/sec-filings/NRDY/10-q-nerdy-inc-quarterly-earnings-report-7ae2fdff5381.html)).
- **[Low take-up]** The state's own fiscal note assumed only **0.8%** of 369,033 eligible students would use the expanded voucher. The money exists, but families and tutors are not being matched ([fiscal note](https://www.legis.la.gov/Legis/ViewDocument.aspx?d=1380593)).
- **[Complexity]** Steve Carter tutors must be certified teachers or hold a relevant degree. Families register with the school-assigned student ID, and voucher funds are deducted as sessions are scheduled. Tutors have to keep their own calendars in sync with the state platform ([LDOE FAQ](https://doe.louisiana.gov/docs/default-source/literacy/steve-carter-literacy-program-faq.pdf?sfvrsn=23166318_5)).
- **[Complexity]** LA GATOR does not reimburse families: every purchase goes through Odyssey, so tutors must invoice there as vendors ([LDOE LA GATOR](https://doe.louisiana.gov/topic-pages/louisiana-school-choice/la-gator)).
- **[Compliance]** Act 517 (2022) bars instructional materials that use three-cueing or visual memory as the main basis for word recognition. Many off-the-shelf tutor worksheets don't meet that bar ([Reading League Compass](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/louisiana/)).
- **[Parent burden]** Act 422 requires parents to sign an at-home reading contract. Retained students must receive evidence-based tutoring, but nothing helps parents keep up their side ([KTAL](https://www.ktalnews.com/news/education/edwards-signs-louisiana-education-bill-to-retain-3rd-graders-who-fail-to-meet-reading-standard/)).
- **[Documentation]** HB 186 (2026) criminalizes deliberate misuse of GATOR funds, so providers need session-level proof of what was delivered ([FutureEd](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)).

## What we build (the better version)
1. **MVP** **Tutor profile and credential binder:** upload a teaching certificate or degree and record background-check dates. A public "Steve Carter- and GATOR-ready" page links to the tutor's booking calendar.
2. **MVP** **Scheduling and session log:** sessions, attendance, minutes, skill focus and notes. One-click exports in the fields the voucher platform and Odyssey invoices need. Uploads are manual; no API is assumed.
3. **MVP** **Screener-to-plan:** the tutor enters beginning-, middle- and end-of-year screener results. AI drafts a skills plan covering phonemic awareness, phonics, fluency, vocabulary and comprehension, using only decodable, non-cueing activities. It shares the passage library with P01 and R08.
4. **MVP** **Act 422 home-reading helper:** a printable or SMS nightly routine for the parent contract, a quick log of home reading, and a progress snapshot before each retest.
5. **MVP** **One ledger per student across funding sources:** $1,500 voucher balance, GATOR invoices, and private pay through Stripe (the tutor is the merchant). Itemized receipts can be reused for 529 or tax purposes (P07).
6. **V2** **Consent-based progress report to the school's reading teacher or literacy coach**, with minimal personal data.
7. **V2** **Parish tutor directory** ("find a voucher-ready reading tutor near you"). It replaces the discovery tutors lose when they leave marketplaces.
8. **V2** **Center mode:** multiple tutors, room scheduling and payroll export.
9. **V2** **Math module** for the HB 244 math expansion.

## Pricing to win
- **Solo tutor:** $19/mo. **Center:** $59/mo for up to 10 tutors. No commission, month-to-month, with free roster import.
- **Example (estimate):** a tutor with 12 private-pay or GATOR students at $50/hr, 2 hours a week for 30 weeks, bills $36,000 a year.
  - On a 25% marketplace cut, that tutor would give up **$9,000**. ReadyTutor costs **$228/yr**.
  - For Steve Carter students, the state pays the tutor through its own platform. We charge nothing extra and never touch voucher funds.

## Go-to-market (first 100 customers)
- **Timing:**
  - Launch around the fall screener results (Sep–Oct).
  - Push again after the December screener.
  - Push before spring LEAP and the Act 422 retest windows.
  - Run a summer-retest campaign.
- **Channels:**
  - Parish literacy coaches and LDOE tutoring-initiative contacts. Check whether the approved-provider list is public (verify).
  - The Louisiana Retired Teachers Association and local teacher-union chapters (verify names).
  - The IDA Louisiana branch, for dyslexia therapists who receive Act 266 screening referrals (verify).
  - CHEF of Louisiana and LA GATOR parent Facebook groups (verify names).
  - The Louisiana Library Association and public libraries hosting "tutor nights" (verify).
- **SEO pages:**
  - "How to use a Steve Carter tutoring voucher"
  - "LA GATOR tutoring provider: invoicing on Odyssey"
  - "3rd grade LEAP retest: what parents can do"
  - "Switch from Wyzant/Varsity: keep 100%"
- **Partners:**
  - Micro-schools and private schools on GATOR (cross-sell with F06 ESA Desk).
  - Reading-intervention publishers whose materials meet Act 517.

## Risks and incumbent moats
- **The voucher platform is state-run and closed.** Tutors must still list there.
  - Mitigation: position ReadyTutor as the tutor's back office, not a rival marketplace, and export clean session data.
- **Appropriation risk.** The $5M state line is annual, and the LDOE match may not recur (verify 2026–27).
  - Mitigation: the multi-funding ledger (GATOR, private pay, federal credit scholarships) so tutors don't depend on one source.
- **Small, single-state market.**
  - Mitigation: build as a module of the P01/P04/F07 codebase, and expand to other states where public money pays tutors (TX TEFA, MO MOScholars; verify).
- **Student data.** FERPA applies when schools share records, and Louisiana student-privacy rules apply (verify).
  - Mitigation: parent-owned profiles, first name plus grade only, and school sharing only with consent.
- **Content compliance.**
  - Mitigation: a curated, decodable, non-cueing activity library, with a checklist aligned to Act 517.
- **Low take-up may come from families, not tutors.**
  - Mitigation: the parish directory and plain-language parent explainers make demand visible.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 3 | 2 | **15** |

## Sources
- [LDOE: Steve Carter Literacy Tutoring Program FAQ (PDF)](https://doe.louisiana.gov/docs/default-source/literacy/steve-carter-literacy-program-faq.pdf?sfvrsn=23166318_5)
- [LDOE newsroom: Louisiana Tutoring Initiative ($5M match for 2025–26, Aug 27 2025)](https://doe.louisiana.gov/about/news-releases/louisiana-tutoring-initiative)
- [Legislative Fiscal Office: HB 244 (2024 RS) fiscal note](https://www.legis.la.gov/Legis/ViewDocument.aspx?d=1380593)
- [KTAL: Act 422 / HB 12 third-grade retention law](https://www.ktalnews.com/news/education/edwards-signs-louisiana-education-bill-to-retain-3rd-graders-who-fail-to-meet-reading-standard/)
- [The Reading League Compass: Louisiana (Act 517, Bulletin 741, Acts 108/438/448/266)](https://compass.thereadingleague.org/paths/policymakers-and-state-education-agencies/louisiana/)
- [LDOE: LA GATOR Scholarship Program](https://doe.louisiana.gov/topic-pages/louisiana-school-choice/la-gator)
- [FutureEd: 2026 private school choice bill tracker (Jul 13 2026)](https://www.future-ed.org/legislative-tracker-2026-state-private-school-choice-bills/)
- [Ballotpedia: Federal K-12 tax credit scholarship participation](https://ballotpedia.org/State_participation_in_the_federal_K-12_education_tax_credit_program)
- [Outschool: Teacher earnings and payments policy](https://support.outschool.com/en/articles/2382129-teacher-earnings-and-payments-policy) (via P04)
- [Wyzant: Fee structure for tutors](https://support.wyzant.com/tutors/tutor-payments/what-is-the-fee-structure-for-tutors-listed-on-wyzant/) (via P04)
- [MyEngineeringBuddy: Preply review and pricing (Jul 2026)](https://www.myengineeringbuddy.com/blog/preply-reviews-features-pricing-alternatives/) (via P04)
- [Indeed: Outschool reviews](https://www.indeed.com/cmp/Outschool/reviews) and [Indeed: Varsity Tutors pay reviews](https://www.indeed.com/cmp/Varsity-Tutors/reviews?fjobtitle=Tutor&ftopic=paybenefits) (via P04)
- [Nerdy 10-Q via StockTitan (Aug 6 2026)](https://www.stocktitan.net/sec-filings/NRDY/10-q-nerdy-inc-quarterly-earnings-report-7ae2fdff5381.html) (via P04)
- louisianatutoringinitiative.com did not load in this pass, so the platform vendor, provider count and voucher expiry rules are unconfirmed (verify).
- Internal: ../states/LA-louisiana.md; ../ideas/P01, P02, P04, F06, F07, R08
