# FirstCall: an owned lead-capture and follow-up system so home-service pros spend less on Angi, Thumbtack and Google LSA

**One-liner:** Every call, form, text and marketplace lead lands in one inbox and gets an instant AI text-back. The tool shows the true cost per booked job for each lead source, so a contractor can cut the paid sources that don't pay off.

## Snapshot
- **Replaces / reduces spend on:**
  - **Angi (incl. HomeAdvisor)**, 2026 ([LeadTruffle](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)):
    - Membership about $300/yr.
    - Per-lead cost by trade: roofing $50–$120+, HVAC $45–$100+, plumbing $40–$85, electrical $35–$80, landscaping $25–$55.
    - 1-year contracts that auto-renew unless cancelled 60+ days ahead, with an early-termination fee of 35% of contract value.
    - Per-lead prices can change month to month as Angi tests prices by area ([Stingleads](https://stingleads.com/resources/angi-vs-homeadvisor-vs-stingleads)).
  - **Google Local Services Ads**, Feb 2026 benchmark covering $6.72M of spend across 888 contractors ([Valley Marketing Group](https://thevalleymarketinggroup.com/blog/google-local-services-ads-cost-per-lead-2026/)):
    - Average $53/lead.
    - Plumbing $35–$65, HVAC $30–$70, electrical $40–$75, roofing $55–$90.
  - Thumbtack, Yelp Ads and Houzz Pro: in scope. Current 2026 prices were **not verified in this pass**.
- **Recent price hikes / changes:**
  - **Angi:**
    - FTC order of Jan 2023 (final Apr 2023): HomeAdvisor to pay up to $7.2M and stop deceptively marketing lead quality ([FTC](https://www.ftc.gov/news-events/news/press-releases/2023/01/ftc-order-requires-homeadvisor-pay-72-million-stop-deceptively-marketing-its-leads-home-improvement)).
    - Over $3M returned to contractors, Nov 2023 ([Stingleads](https://stingleads.com/resources/angi-vs-homeadvisor-vs-stingleads)).
    - **Vermont AG settlement, Oct 2025:** Angi agreed to stop using "Angi Certified Pro," pay $100,000, and point users to Vermont's contractor registry ([Stingleads](https://stingleads.com/resources/angi-vs-homeadvisor-vs-stingleads)).
    - Angi spun off from IAC as an independent public company on Apr 1, 2025. Since Jan 13, 2025, homeowners choose which pros to match with ([LeadTruffle](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)).
    - A long-running contractor class action, *Airquip v. HomeAdvisor* (D. Colo. 1:16-cv-01849), exists ([CourtListener](https://www.courtlistener.com/docket/6077289/airquip-inc-v-homeadvisor-inc/)). Its current status was not checked.
  - **Google LSA** ([Footbridge Media](https://www.footbridgemedia.com/marketing-tips/5-changes-google-local-service-ads-contractors-should-know)):
    - Jul 2024: manual lead disputes replaced with automated credits.
    - Early 2025: Google stopped crediting "job type not serviced" and "geo not serviced" leads.
    - Jan 6, 2025: the LSA mobile app was retired.
    - Oct 20, 2025: badges merged into "Google Verified."
    - **Nov 7, 2025: the $2,000 Google Guarantee money-back protection was eliminated.**
- **Who buys:** Owner-operators of HVAC, plumbing, electrical, roofing, remodeling, garage-door, landscaping, pest-control, cleaning and handyman businesses (1–20 trucks). The owner or office manager decides, often on a phone, with a credit card.
- **US market size:** Estimate, not verified this pass. Several hundred thousand to 1M+ US specialty-trade and home-service firms. Angi's own contractor complaint volume (2,281 BBB complaints in 3 years, [LeadTruffle](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)) suggests a large paying base. Spend pool is large: a contractor buying 20 leads/mo at $50–$100 spends $12k–$24k/yr on leads (**estimate**).
- **Urgency trigger (why they'd switch NOW):**
  - Google's disputes and the Guarantee are gone (Jul 2024, early 2025, Nov 2025). Footbridge estimates $10k+/yr in lost credits for a contractor spending $5k/mo on LSA (15–25% of leads fall in formerly credit-eligible categories); smaller spenders lose proportionally less.
  - Angi auto-renewals, early-termination fees and shared leads persist.
  - The fall/winter HVAC and plumbing season (Oct–Feb) is when missed calls cost the most.
- **Fastest-selling states/metros:**
  - Vermont: AG action against Angi (Oct 2025) is a PR hook.
  - Colorado: *Airquip* venue; Angi is headquartered in Denver.
  - Big-metro lead costs run 20–25% higher ([LeadTruffle](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)), so high-cost metros (NYC, LA, Chicago, Dallas, Houston, Atlanta, Phoenix) feel it most. The metro list is an estimate.

## Pain points (evidence)
- **[Price]** Angi leads are shared with 3–8 contractors, and roofers report the same lead sold to as many as 16 competitors, each paying full price ([LeadTruffle, 2026](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)).
- **[Lead quality]** Contractors' top complaints are fake or unreachable leads (disconnected numbers, no response) and price shoppers with no intent to hire. Angi's Trustpilot score is 1.4/5 across 37,000+ reviews ([LeadTruffle](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)).
- **[Lock-in/Contracts]** Angi uses 1-year auto-renewing contracts with a 35% early-termination fee. Contractors cite bills over budget and hard cancellations ([LeadTruffle](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)).
- **[Price/Transparency]** Per-lead charges can change month to month as Angi tests prices in your area ([Stingleads](https://stingleads.com/resources/angi-vs-homeadvisor-vs-stingleads)).
- **[Deceptive practices]** The FTC found HomeAdvisor made false or unsubstantiated claims about lead quality and source, and ordered up to $7.2M ([FTC, Jan 2023](https://www.ftc.gov/news-events/news/press-releases/2023/01/ftc-order-requires-homeadvisor-pay-72-million-stop-deceptively-marketing-its-leads-home-improvement)). Vermont's AG forced Angi to drop the "Angi Certified Pro" label (Oct 2025) ([Stingleads](https://stingleads.com/resources/angi-vs-homeadvisor-vs-stingleads)).
- **[Price]** Since early 2025, contractors pay for LSA leads outside their service area or for services they don't offer, because Google removed those credit categories. Footbridge estimates 15–25% of monthly leads are no longer credited ([Footbridge Media](https://www.footbridgemedia.com/marketing-tips/5-changes-google-local-service-ads-contractors-should-know)).
- **[Support/Disputes]** In Google LSA, "you no longer get to argue." Disputes became an algorithmic "Very dissatisfied" rating (Jul 2024) ([Footbridge Media](https://www.footbridgemedia.com/marketing-tips/5-changes-google-local-service-ads-contractors-should-know)). Even where credits exist, not every invalid lead gets credited automatically ([Valley Marketing Group, 2026](https://thevalleymarketinggroup.com/blog/google-local-services-ads-cost-per-lead-2026/)).
- **[Lock-in]** An electrician who left Thumbtack lost 40+ five-star reviews built over 3 years. The same poster said lead fees had roughly tripled, from $2–5 to about $20 per job, with no refunds. This is an older post (Oct 2020) but shows the review lock-in dynamic ([Mike Holt Forum](https://forums.mikeholt.com/threads/marketing-and-leads.2556807/)).
- **[Lead quality]** Another electrician said about 90% of paid-platform leads were "how much, just wondering" inquiries that each cost money (Oct 2020) ([Mike Holt Forum](https://forums.mikeholt.com/threads/marketing-and-leads.2556807/)).
- **[Speed]** 35–50% of jobs go to the first contractor to respond ([LeadTruffle](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)). Shared leads therefore reward whoever texts back in seconds, which most one-truck owners can't do from a ladder.

## What we build (the better version)
1. **MVP:** A business phone number or call-forwarding layer with **missed-call text-back in 5 seconds**: "Sorry we missed you, what do you need help with? Reply with a photo."
2. **MVP:** A unified lead inbox. Calls, texts, website form, Google Business Profile messages and forwarded Angi/Thumbtack/LSA lead emails are parsed into one card per job: name, phone, address, job type, source.
3. **MVP:** An AI qualifier that texts every new lead within 60 seconds. It asks job type, zip, urgency and photos, then scores the lead: spam, out-of-area, price-shopper or real.
4. **MVP:** A lead-source ROI board showing, per source: leads, booked jobs, revenue entered, cost per lead and cost per booked job. "Angi cost you $1,340 for 2 jobs this month."
5. **MVP:** A **dispute helper** that flags out-of-area, spam or duplicate LSA/Angi leads and generates the dispute or feedback text with timestamps.
6. **MVP:** An embeddable "Get a quote" widget for the website and Google Business Profile link, with photo upload and instant booking into a calendar.
7. **MVP:** An automatic review request after a job is marked done, sent to Google. **Reviews you own**, not marketplace reviews you lose when you leave.
8. **V2:** An AI voice receptionist for after-hours calls that books estimates and takes emergency details.
9. **V2:** Follow-up sequences for unsold estimates (day 2, 7, 21) and seasonal maintenance reminders to past customers, turning repeat work into free leads.
10. **V2:** Jobber, Housecall Pro and ServiceTitan sync to pull invoiced revenue into the ROI board.
11. **V2:** A per-state contractor license-number display and registry link on the quote widget, a trust signal that fits the Vermont AG theme.

## Pricing to win
- **Plans:** Solo $49/mo (1 number, 1 user). Crew $99/mo (3 numbers, 5 users, AI qualifier). Pro $199/mo (AI voice receptionist, unlimited users).
- **Terms:** Texts and minutes at cost + 10%. Month-to-month. No setup fee.
- **Example (estimate):** An HVAC owner buying 20 Angi leads/mo at about $70 spends $1,400/mo ([cost range source](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)). FirstCall at $99/mo aims to cut 30% of that spend (**estimate**) by dropping the worst source and converting more organic and repeat leads. That's a projected saving of $420/mo against $99/mo. Say it plainly: we reduce marketplace spend, we don't replace demand.

## Go-to-market (first 100 customers)
- **Reddit:** r/HVAC, r/Plumbing, r/electricians, r/Roofing, r/Contractor, r/sweatystartup, r/smallbusiness, r/lawncare, r/CleaningBusiness. Search "Angi," "Thumbtack," "LSA disputes."
- **Facebook groups:** HVAC business-owner groups, plumbing business-owner groups, roofing contractor groups, "Lawn Care Business Owners," cleaning-business owner groups.
- **Associations:** ACCA (HVAC), PHCC (plumbing), NRCA (roofing), NARI (remodeling), state contractor associations.
- **Events:** AHR Expo and state trade shows.
- **"Switch from X" SEO pages:**
  - "Angi early termination fee"
  - "Cancel Angi leads contract"
  - "Google LSA disputes removed"
  - "Google Guarantee removed November 2025"
  - "Thumbtack lead cost too high"
  - "HomeAdvisor FTC refund"
- **Partners:**
  - Jobber and Housecall Pro app marketplaces.
  - Suppliers' counter staff (Ferguson, Johnstone).
  - Bookkeepers for trades.
- **Cold outreach:** Scrape Angi/LSA-listed pros per metro and text them the "your missed calls cost you" calculator.

## Risks and incumbent moats
- **Demand dependency:** Marketplaces supply demand we can't replace. Mitigation: position as "cut waste and own your customers," and keep them buying the sources that work.
- **SMS/voice compliance (10DLC, TCPA, state mini-TCPAs):** Mitigation: established CPaaS, consent capture on the widget, conversational texts only (responding to inbound inquiries).
- **Crowded space:** GoHighLevel agencies, Podium, Jobber and LeadTruffle-type tools already compete here. Mitigation: the cheaper flat price, the ROI and dispute helper, and no agency middleman.
- **Parsing marketplace emails:** Formats change. Mitigation: AI extraction with fallbacks, and forwarding rules.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 5 | 4 | 4 | 5 | 5 | **23** |

## Sources
- [FTC Order Requires HomeAdvisor to Pay Up To $7.2 Million (FTC, Jan 2023)](https://www.ftc.gov/news-events/news/press-releases/2023/01/ftc-order-requires-homeadvisor-pay-72-million-stop-deceptively-marketing-its-leads-home-improvement)
- [FTC Approves Final Order against HomeAdvisor (FTC, Apr 2023)](https://www.ftc.gov/news-events/news/press-releases/2023/04/ftc-approves-final-order-against-homeadvisor-inc-deceptively-marketing-its-leads-home-improvement)
- [HomeAdvisor vs Angi (2026): What Contractors Actually Pay (Stingleads)](https://stingleads.com/resources/angi-vs-homeadvisor-vs-stingleads)
- [The Complete Guide to Angi Leads for Home Service Contractors in 2026 (LeadTruffle)](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/)
- [The Rules of Google Local Service Ads Just Changed (Footbridge Media)](https://www.footbridgemedia.com/marketing-tips/5-changes-google-local-service-ads-contractors-should-know)
- [Google LSA Cost Per Lead 2026 (Valley Marketing Group)](https://thevalleymarketinggroup.com/blog/google-local-services-ads-cost-per-lead-2026/)
- [Marketing and leads (Mike Holt Forum, 2020)](https://forums.mikeholt.com/threads/marketing-and-leads.2556807/)
- [Airquip, Inc. v. HomeAdvisor, Inc. docket (CourtListener)](https://www.courtlistener.com/docket/6077289/airquip-inc-v-homeadvisor-inc/)

## Verification (Sep 24 2026)
- ✅ Google LSA: manual disputes removed Jul 2024; "job type/geo not serviced" credits ended early 2025; app retired Jan 6 2025; badges merged Oct 20 2025; Guarantee eliminated Nov 7 2025 — source states each date verbatim ([source](https://www.footbridgemedia.com/marketing-tips/5-changes-google-local-service-ads-contractors-should-know))
- ⚠️ "$10k+/yr lost credits per contractor" — source says this applies to a contractor spending $5,000/mo on LSA (15–25% of leads, $750–1,250/mo); text narrowed ([source](https://www.footbridgemedia.com/marketing-tips/5-changes-google-local-service-ads-contractors-should-know))
- ✅ Angi ~$300/yr membership, per-lead ranges by trade, 1-year contract with 35% early-termination fee — confirmed; source adds auto-renew unless cancelled 60+ days ahead, IAC spin-off Apr 1 2025, homeowner choice from Jan 13 2025 (added) ([source](https://www.leadtruffle.co/blog/complete-guide-angi-leads-home-service-contractors-2026/))
- ✅ LSA average $53/lead, $6.72M spend, 888 contractors, Feb 2026, per-trade ranges — confirmed exactly ([source](https://thevalleymarketinggroup.com/blog/google-local-services-ads-cost-per-lead-2026/))
- Not re-checked: Vermont AG Oct 2025 settlement (Stingleads). Scores unchanged.
