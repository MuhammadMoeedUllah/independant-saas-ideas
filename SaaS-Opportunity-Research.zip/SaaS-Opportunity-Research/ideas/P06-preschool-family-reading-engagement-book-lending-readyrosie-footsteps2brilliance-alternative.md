# StoryNest: a cheaper, simpler ReadyRosie / Footsteps2Brilliance for preschools, Head Start, home daycares and Imagination Library affiliates

**One-liner:** Weekly "read, talk, play" activities sent to families by text in their language. It includes a classroom book-lending log and funder-ready engagement reports. It's priced per site so a home daycare can buy with a card and a Head Start grantee can buy under small-purchase rules instead of a district contract.

## Snapshot
- **Replaces** (accessed Sep 2026):
  - **ReadyRosie:** the Texas instructional-materials review (IMRA) lists **Teaching Strategies** as publisher. Sold as a "Paid Subscription or License" that needs **district or campus setup**. Covers PreK–3, English/Spanish plus Vietnamese and Arabic support, with modeled-moment videos ([TEA IMRA](https://im.tea.texas.gov/learning-resources/readyrosie-0)). Price not published.
  - **Footsteps2Brilliance:** district "Model Innovation City" partnerships, price not published ([F2B](https://www.footsteps2brilliance.com/personalized-partnerships-2/district-partnerships)). The MyF2B Android app has **3.9★** from 15 reviews and 5,000+ downloads ([Google Play](https://play.google.com/store/apps/details?id=com.myf2b.myf2b)).
  - **Waterford Upstart:** free to qualifying families, paid for by **state contracts and partners**. Availability depends on the region ([Waterford](https://www.waterford.org/upstart/)).
  - **Free alternatives:** Vroom, Khan Academy Kids, and **Dolly Parton's Imagination Library** (free monthly books; local–state cost sharing).
  - **Consumer apps:** Lingokids (paid; 4.7★ on Trustpilot from 165 reviews) ([Trustpilot](https://www.trustpilot.com/review/lingokids.com)).
  - **Status quo:** Brightwheel/ClassDojo messages plus paper book bags. Operations tools are covered in F05.
- **Recent price hikes / changes (switching windows):**
  - **Imagination Library state cuts:**
    - **Washington:** **$0** of a $7M 2025–27 request (budget Apr 26 2025). **121,000** children and 46 local partners affected ([Imagination Library of WA](https://www.imaginationlibrarywashington.org/state_budget_shuts_out_funding_for_dolly_parton_s_imagination_library_of_washington)).
    - **Indiana:** direct state funding eliminated for 2025–26 (was $2M in 2023–24 and $4M in 2024–25). The program went statewide on Apr 2 2026 through private fundraising ([Chalkbeat](https://www.chalkbeat.org/indiana/2026/04/02/dolly-parton-imagination-library-in-all-92-counties/)).
    - **Missouri:** cut from **$6M to $2M**, with **170,000+** children enrolled (May 20 2026) ([Fulton Sun](https://www.fultonsun.com/news/2026/may/20/missouri-slashes-budget-for-dolly-parton/)).
    - Local affiliates now have to **prove impact to raise money locally**.
  - **Head Start turmoil:**
    - A preliminary FY2026 budget draft proposed eliminating Head Start (about 800k children, 17,000+ centers). About $1B in grants had reportedly been withheld ([K-12 Dive, Apr 17 2025](https://www.k12dive.com/news/head-start-eliminated-hhs-draft-budget-child-care-preschool/745721/)).
    - During the fall 2025 shutdown, programs in **40+ states missed Nov 1 funding**, affecting 65,000+ children ([FFYF, Nov 18 2025](https://www.ffyf.org/2025/11/18/state-of-play-shutdown/)).
    - An **Aug 6 2026** proposed rule (comments close **Oct 6 2026**) rolls back wage and benefit mandates but **keeps most family-engagement requirements** ([FFYF](https://www.ffyf.org/2026/08/06/state-of-play-nprm/)).
    - Programs must do more with less and still document family engagement.
- **Who buys:**
  1. Head Start / Early Head Start family-services and education managers (grant-funded).
  2. State and district pre-K sites.
  3. Private preschools and childcare centers (owner, card).
  4. Licensed home daycares (card).
  5. Imagination Library local affiliates, libraries and United Ways (impact reporting).
- **US market size:**
  - Head Start: about **800k children** and **15,000–17,000 centers** ([K-12 Dive](https://www.k12dive.com/news/head-start-eliminated-hhs-draft-budget-child-care-preschool/745721/); [FFYF](https://www.ffyf.org/policy-priorities/2026-early-head-start-head-start/)).
  - Imagination Library: hundreds of thousands of enrolled children in WA and MO alone.
  - Childcare centers and home daycares: see F05 (not re-counted).
  - Estimate: tens of thousands of buyer sites.
- **Urgency trigger (why they'd switch NOW):**
  - Head Start budget pressure favors cheaper per-site tools over district-scale licenses.
  - Imagination Library affiliates need outcome data after state cuts (WA, IN, MO).
  - Fall enrollment and family-engagement goal-setting (Sep–Oct).
  - K–2 screening laws (e.g. CA AB 1454) push "kindergarten readiness" literacy down to pre-K.
- **Fastest-selling states/metros:**
  - **Imagination Library cut states:** WA, IN, MO.
  - **TX:** ReadyRosie is listed in IMRA, which proves demand.
  - **CA:** K–2 screening from AB 1454.
  - **Head Start-dense states** (estimate: TX, CA, MS, FL, NY).

## Pain points (evidence)
- **[Bugs/UX]** ReadyRosie app reviews report crashes and blank screens, missing sound on videos, login errors, and a play button "hidden behind the top bar" (2.9★; JustUseApp aggregate of App Store reviews, 2026) ([JustUseApp](https://justuseapp.com/en/app/1019768274/readyrosie/reviews)).
- **[Complexity]** ReadyRosie needs a paid license plus district or campus setup, so there's no self-serve option for a single home daycare or small center ([TEA IMRA](https://im.tea.texas.gov/learning-resources/readyrosie-0)).
- **[Access]** Waterford Upstart only exists where a funder pays. Families must fill out a form to learn whether it's offered in their area ([Waterford](https://www.waterford.org/upstart/)).
- **[Funding]** Washington's statewide Imagination Library got $0 of its $7M request, putting books for 121,000 children at risk ([Imagination Library of WA, Apr 2025](https://www.imaginationlibrarywashington.org/state_budget_shuts_out_funding_for_dolly_parton_s_imagination_library_of_washington)).
- **[Funding]** Missouri's cut left roughly four months of runway. The Dollywood Foundation says the state "has not fulfilled its commitment" ([Fulton Sun, May 20 2026](https://www.fultonsun.com/news/2026/may/20/missouri-slashes-budget-for-dolly-parton/)).
- **[Funding]** Indiana removed direct state funding in 2025–26, and the First Lady had to fundraise to keep the program statewide ([Chalkbeat, Apr 2 2026](https://www.chalkbeat.org/indiana/2026/04/02/dolly-parton-imagination-library-in-all-92-counties/)).
- **[Budget shock]** Head Start programs that missed funding cut transportation, staff and hours, or took loans ([FFYF, Nov 2025](https://www.ffyf.org/2025/11/18/state-of-play-shutdown/)).
- **[Engagement]** Lingokids parents say games get repetitive, children lose interest and a paid subscription is required ([Trustpilot](https://www.trustpilot.com/review/lingokids.com)).
- **[Existential risk]** Head Start was "zeroed out" in the preliminary FY2026 draft. NHSA called it "catastrophic" ([K-12 Dive](https://www.k12dive.com/news/head-start-eliminated-hhs-draft-budget-child-care-preschool/745721/)).

## What we build (the better version)
1. **MVP** **52-week activity library** for ages 0–5. Each activity has a 60-second modeled video, a printable card and a "read, talk, sing, play" routine. Top 5 languages are human-reviewed; 20+ more are AI-translated.
2. **MVP** **Text-first delivery** with no app download. Parents tap "we did it" and can attach a photo or voice note. Nudges go out at the times families pick.
3. **MVP** **Classroom book lending:** QR label on each book, check-out to a family, return reminders and lost-book tracking. An **Imagination Library sign-up helper** links to the local affiliate.
4. **MVP** **Reports:**
   - Family engagement by classroom and language, and minutes read.
   - Exports for Head Start family-engagement (PFCE) goals and monitoring, state pre-K reports and funders (Imagination Library affiliates, United Way).
5. **MVP** **Teacher one-click weekly send**, matched to the classroom theme (map to Creative Curriculum or Frog Street units by *theme*; no copied content).
6. **V2** Family workshop kit (slides, sign-in, attendance) for Head Start parent meetings.
7. **V2** Kindergarten-readiness skill checks (letter names and sounds, rhyming, phonological awareness) and a kindergarten transition report, linking to P01 and P02.
8. **V2** Imports from ChildPlus, Brightwheel and Procare (CSV first).
9. **V2** Imagination Library affiliate mode: enrollment-drive landing pages and a donor impact page.

## Pricing to win
- **Home daycare: $9/mo. Center: $39/mo per site** (unlimited families). **Head Start / pre-K grantee: $1,500/yr for up to 10 sites. Affiliate or library: $29/mo.** Free for up to 10 families.
- **Comparison:** ReadyRosie and Footsteps2Brilliance prices aren't published, so no verified savings figure. We need quotes in the state pass. The pitch is self-serve, text-first and under small-purchase thresholds.

## Go-to-market (first 100 customers)
- **Associations:** National Head Start Association and state Head Start associations (conference exhibits), and state Child Care Resource & Referral agencies.
- **Home daycare:** NAFCC and state family child-care associations, plus home-daycare Facebook groups.
- **Imagination Library:** local affiliates in WA, IN and MO (United Ways, Rotary, libraries). Offer a free impact dashboard for 6 months.
- **SEO:** "Head Start family engagement activities", "PFCE outcomes report template", "preschool book lending system".
- **Cross-sell** with F05 (childcare operations) customers.

## Risks and incumbent moats
- **Free substitutes** (Vroom, Khan Kids, Imagination Library). We're the delivery, tracking and reporting layer and link out to free content.
- **Grant procurement:** Head Start follows federal procurement rules. Keep the grantee price under the micro-purchase threshold (commonly $10,000; verify grantee policies).
- **Funding volatility:** diversify buyers (private centers, home daycares, affiliates).
- **Privacy:**
  - **Head Start** has its own child-records privacy rules (45 CFR 1303, Subpart C). Sign a data agreement that honors them.
  - **FERPA** applies to district pre-K.
  - **COPPA:** we're parent-facing with no child accounts. Photos and voice notes uploaded by parents stay private to the class, are never public, auto-delete after 12 months and carry no ad trackers.
- **Video content cost:** use short, cheap-to-film modeled videos (phone-shot with local educators) and grow the library over time.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 2 | 3 | **15** |

## Sources
- [ReadyRosie – Texas IMRA](https://im.tea.texas.gov/learning-resources/readyrosie-0)
- [ReadyRosie reviews – JustUseApp](https://justuseapp.com/en/app/1019768274/readyrosie/reviews)
- [MyF2B – Google Play](https://play.google.com/store/apps/details?id=com.myf2b.myf2b) · [Footsteps2Brilliance district partnerships](https://www.footsteps2brilliance.com/personalized-partnerships-2/district-partnerships)
- [Waterford Upstart](https://www.waterford.org/upstart/)
- [Lingokids – Trustpilot](https://www.trustpilot.com/review/lingokids.com)
- [State budget shuts out Imagination Library of Washington, Apr 2025](https://www.imaginationlibrarywashington.org/state_budget_shuts_out_funding_for_dolly_parton_s_imagination_library_of_washington)
- [Missouri slashes Imagination Library budget – Fulton Sun, May 20 2026](https://www.fultonsun.com/news/2026/may/20/missouri-slashes-budget-for-dolly-parton/)
- [Imagination Library in all 92 Indiana counties – Chalkbeat, Apr 2 2026](https://www.chalkbeat.org/indiana/2026/04/02/dolly-parton-imagination-library-in-all-92-counties/)
- [Imagination Library USA](https://imaginationlibrary.com/usa/)
- [Head Start zeroed out in preliminary budget – K-12 Dive, Apr 17 2025](https://www.k12dive.com/news/head-start-eliminated-hhs-draft-budget-child-care-preschool/745721/)
- [State of Play: Federal Shutdown – FFYF, Nov 18 2025](https://www.ffyf.org/2025/11/18/state-of-play-shutdown/)
- [State of Play: Head Start NPRMs – FFYF, Aug 6 2026](https://www.ffyf.org/2026/08/06/state-of-play-nprm/)
- [2026 Early Head Start and Head Start – FFYF](https://www.ffyf.org/policy-priorities/2026-early-head-start-head-start/)
- [Governor signs literacy bill (AB 1454) – EdSource](https://edsource.org/2025/governor-newsom-signs-literacy-bill/742396)
