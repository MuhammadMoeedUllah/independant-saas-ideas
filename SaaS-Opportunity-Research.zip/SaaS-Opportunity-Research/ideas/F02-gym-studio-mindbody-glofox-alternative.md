# OpenStudio: a cheaper, better Mindbody / ABC Glofox / Zen Planner for boutique gyms, yoga, pilates and CrossFit boxes

**One-liner:** Class booking, memberships, autopay and a member app for a flat monthly price, with no contracts, no marketplace or "discovery" fees, no processing surcharge and free migration off Mindbody.

## Snapshot
- **Replaces:**
  - **Mindbody:** stopped publishing tier prices (as of Jun 2026). Operators report base plans of **$139–$599/mo** that often land above **$1,000/mo** after add-ons, marketplace commissions and processing (effective processing about 3.5% reported). Contracts of **12–24 months that auto-renew** ([Vibefam, 2026](https://vibefam.com/mindbody-reviews-reddit-2026/)).
  - **ABC Glofox:** "Plans starting at $99/mo", with tiers hidden behind a sales call. Operators report Essential about $110–150, Boost about $160–250, Elite about $250–400+ and Enterprise about $500–600+. There is a **platform surcharge of 2.9% + $0.30 on top of Stripe's 2.9% + $0.30** (about 5.9% + $0.60 effective). Quarterly prepay; annual terms on higher tiers ([Vibefam, 2026](https://vibefam.com/glofox-pricing-2026/)).
  - **Zen Planner** (pricing page, accessed Sep 24 2026): Studio **from $99/mo**, Essentials **from $198**, Ultimate **from $348**, New Business Bundle from $199. Priced by active members. Add-ons: Website from $99/mo, **Engage (marketing) from $249/mo**, Branded App $39/mo, card readers $39/mo. Month-to-month ([Zen Planner](https://zenplanner.com/pricing/)).
  - Others: Wodify, PushPress, Arketa, Momence (not re-priced in this pass).
- **Recent price hikes / changes:**
  - Mindbody added a **"new client discovery fee"** ([r/mindbody](https://www.reddit.com/r/mindbody/comments/1pde1yv/did_you_know_about_the_new_new_client_discovery/)), hid its public pricing in 2026, and made its dedicated account manager (TAM) a paid add-on ([Vibefam](https://vibefam.com/mindbody-reviews-reddit-2026/)).
  - A G2 reviewer (Dec 4 2024) says Glofox "abruptly increased pricing 70 percent". The source does not tie this to the ABC acquisition; that link is our inference (unverified). A Trustpilot reviewer says some customers were charged "300 percent" of the agreed price ([Vibefam](https://vibefam.com/glofox-pricing-2026/)). Both are individual reviews, not a published price change.
- **Who buys:** Owner-operators of boutique studios (yoga, pilates, barre, cycling, HIIT), CrossFit and functional-fitness boxes, personal-training studios and small independent gyms (50–800 members).
- **US market size:** Estimate only: tens of thousands of US fitness facilities. Industry reports (HFA, formerly IHRSA) commonly cite about 55k US health and fitness clubs; not re-verified this pass. Add thousands of CrossFit affiliates and independent yoga/pilates studios on top.
- **Urgency trigger (why they'd switch NOW):** Mindbody discovery fees and hidden pricing (2025–26). Individual Glofox reviewers report a 70% hike and being billed 300% of the agreed price (anecdotal, not an announced change). Auto-renewing contracts give each studio a known **renewal date to target**.
- **Fastest-selling states/metros:** High boutique-studio density: NYC, LA, San Diego, Austin, Denver, Miami, Chicago, Seattle, Scottsdale. Estimate.

## Pain points (evidence)
- **[Price]** Owners say Mindbody's $139–$599 base price regularly ends up at $1,000+/mo once fees are added (r/gymowner, ["MindBody gym software rips you off"](https://www.reddit.com/r/gymowner/comments/1pkqls9/mindbody_gym_software_rips_you_off_heres_how/)).
- **[Price]** Yoga studio owners fed up with Mindbody fees are asking what else to use (r/yoga, ["Fed up with Mindbody fees"](https://www.reddit.com/r/yoga/comments/1ndfjxe/what_scheduling_software_do_you_actually_use_fed/)).
- **[Price]** Owner shock at hidden processing markups and per-acquisition charges (r/mindbody, ["In disbelief"](https://www.reddit.com/r/mindbody/comments/1s86gub/in_disbelief/)).
- **[Price]** Mindbody's new-client discovery fee surprised operators (r/mindbody, [thread](https://www.reddit.com/r/mindbody/comments/1pde1yv/did_you_know_about_the_new_new_client_discovery/)).
- **[Lock-in/Contracts]** A trainer reports that Mindbody refused to cancel: written cancellations were ignored and monthly charges continued (r/personaltraining, ["Mindbody refuses to cancel"](https://www.reddit.com/r/personaltraining/comments/1l68ato/mindbody_refuses_to_cancel/)).
- **[Lock-in]** Studios describe a painful migration off Mindbody (r/mindbody, ["Migration migraine"](https://www.reddit.com/r/mindbody/comments/1rlq89o/migration_migraine/)).
- **[Support]** AI-routed first-line support loops without escalating (r/mindbody, ["Mindbody is horrible"](https://www.reddit.com/r/mindbody/comments/1p1ok9f/mindbody_is_horrible/); ["Anyone else feeling done with Mindbody?"](https://www.reddit.com/r/mindbody/comments/1mne9pf/anyone_else_feeling_done_with_mindbody/)).
- **[Price]** Glofox "abruptly increased pricing 70 percent for subpar software and service" (G2, Dec 4 2024, via [Vibefam](https://vibefam.com/glofox-pricing-2026/)).
- **[Lock-in/Contracts]** A gym seller was billed by Glofox for 8 months after selling the gym, including 3 unannounced charges of $1,239 (Capterra, Oct 2023, via [Vibefam](https://vibefam.com/glofox-pricing-2026/)).
- **[Price]** Glofox's platform surcharge sits on top of Stripe fees, for an effective about 5.9% + $0.60 per card payment ([Vibefam](https://vibefam.com/glofox-pricing-2026/)).

## What we build (the better version)
1. **MVP** Class schedule, capacity, waitlists with auto-promote, and appointments (PT and privates). Embeddable widget plus hosted page.
2. **MVP** Memberships, class packs, intro offers, family and child add-ons, freezes, and failed-payment dunning with SMS and email card-update links.
3. **MVP** Stripe Connect billing at Stripe's cost (no platform surcharge), card and ACH, with a "bring your own Stripe" option.
4. **MVP** **Mindbody/Glofox/Zen Planner migration kit:** member and visit history import, plus a PCI card-data transfer request so autopay continues without members re-entering cards. We also generate a "contract end date" reminder.
5. **MVP** PWA member app (book, cancel, buy, digital waiver). Branded native app is V2.
6. **MVP** Digital waivers and e-sign, check-in kiosk on an iPad, attendance reports.
7. **MVP** Built-in email/SMS automations (intro-offer nurture, win-back after 14 days without a visit), included rather than a $249/mo "Engage" add-on.
8. **V2** WOD/programming and leaderboard for CrossFit boxes. Workout logging.
9. **V2** Instructor payroll (per class, per head), substitutes, and a sub-request board.
10. **V2** ClassPass/Gympass/Wellhub inbound sync and Google Reserve.
11. **V2** AI front desk: answers DMs and texts about schedule and pricing, books trials.

## Pricing to win
- **$79/mo flat up to 300 members, $129/mo unlimited**, all features, month-to-month, free migration, processing at Stripe cost (or a disclosed +0.25%).
- **Example:** a pilates studio on Mindbody paying about $400/mo base plus add-ons, reported by owners as often $1,000+/mo, moves to OpenStudio at $129. That saves **$3,300–$10,400/yr**. A Glofox Boost box doing $30k/mo in card volume pays about $870/mo in surcharge alone (2.9% + $0.30 on top of Stripe, an estimate) and saves most of it.

## Go-to-market (first 100 customers)
- **Reddit:** r/gymowner, r/mindbody (owners venting), r/yogateachers, r/pilates, r/crossfit, r/personaltraining. Post an honest "Mindbody contract exit checklist".
- **Facebook groups:** "Boutique Fitness Studio Owners", pilates and yoga studio owner groups, CrossFit affiliate owner groups.
- **Events:** Health & Fitness Association (HFA, formerly IHRSA) Show, IDEA World, CrossFit affiliate gatherings, Club Industry.
- **Renewal-window outbound:** ask prospects for their Mindbody or Glofox renewal date, set a reminder 60 days before, and offer a "we'll buy out your last month" credit.
- **Partners:** gym business coaches (Two-Brain Business, pilates and yoga teacher-training programs) with a 20% recurring referral.
- **SEO:** "cancel Mindbody contract", "Mindbody discovery fee", "Glofox pricing", "Zen Planner alternative".

## Risks and incumbent moats
- **Card-token migration:** without a token transfer, members must re-enter cards and some churn. We get around this with Stripe's PCI data-import process and a guided "update card" campaign with a small incentive.
- **Auto-renewing contracts:** we can't break them. We time outreach to renewal dates.
- **Mindbody consumer marketplace:** it brings some drop-ins. We integrate ClassPass/Wellhub and Google Reserve instead.
- **Crowded challengers** (PushPress free tier, Arketa, Momence, Gymdesk): we differentiate on flat price, zero surcharge and done-for-you migration.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 5 | 5 | 3 | 4 | 3 | **20** |

## Sources
- [Mindbody reviews on Reddit – Vibefam (2026)](https://vibefam.com/mindbody-reviews-reddit-2026/)
- [r/gymowner – MindBody gym software rips you off](https://www.reddit.com/r/gymowner/comments/1pkqls9/mindbody_gym_software_rips_you_off_heres_how/)
- [r/yoga – Fed up with Mindbody fees](https://www.reddit.com/r/yoga/comments/1ndfjxe/what_scheduling_software_do_you_actually_use_fed/)
- [r/mindbody – In disbelief](https://www.reddit.com/r/mindbody/comments/1s86gub/in_disbelief/)
- [r/mindbody – new client discovery fee](https://www.reddit.com/r/mindbody/comments/1pde1yv/did_you_know_about_the_new_new_client_discovery/)
- [r/mindbody – Mindbody is horrible](https://www.reddit.com/r/mindbody/comments/1p1ok9f/mindbody_is_horrible/)
- [r/mindbody – Anyone else feeling done with Mindbody?](https://www.reddit.com/r/mindbody/comments/1mne9pf/anyone_else_feeling_done_with_mindbody/)
- [r/personaltraining – Mindbody refuses to cancel](https://www.reddit.com/r/personaltraining/comments/1l68ato/mindbody_refuses_to_cancel/)
- [r/mindbody – Migration migraine](https://www.reddit.com/r/mindbody/comments/1rlq89o/migration_migraine/)
- [Glofox pricing in 2026 – Vibefam](https://vibefam.com/glofox-pricing-2026/)
- [Zen Planner pricing page (accessed Sep 24 2026)](https://zenplanner.com/pricing/)
- [ABC Glofox plans page](https://www.glofox.com/plans/)

## Verification (Sep 24 2026)
- ✅ Mindbody no longer publishes tiers; base $139–$599/mo, often $1,000+ all-in; ~3.5% effective processing; 12–24 month auto-renewing contracts; discovery fee; paid TAM add-on — confirmed ([source](https://vibefam.com/mindbody-reviews-reddit-2026/))
- ✅ Glofox "starting at $99/mo", operator-reported tiers, 2.9% + $0.30 surcharge on top of Stripe (~5.9% + $0.60), $1,239 charges after the gym was sold — confirmed ([source](https://vibefam.com/glofox-pricing-2026/))
- ⚠️ "Glofox post-acquisition hikes of 70–300%" — the source quotes one G2 review (70%) and one Trustpilot complaint (charged 300% of the agreed price) and does not link them to the ABC acquisition. Softened in the text and marked as anecdotal ([source](https://vibefam.com/glofox-pricing-2026/))
- ✅ Zen Planner Studio $99, Essentials $198, Ultimate $348, Bundle $199, priced by active members; Website $99, Engage $249, App $39, readers $39; month-to-month — confirmed ([source](https://zenplanner.com/pricing/))
- Scores unchanged (the Mindbody trigger, which is confirmed, carries the urgency).
