# RecitalReady: a cheaper, better Jackrabbit / iClassPro / Spark Membership for dance, gymnastics, swim and martial-arts schools

**One-liner:** Family-based tuition billing, class enrollment, recitals, costumes and skills tracking for kids' activity studios. Flat price instead of per-student tiers, and a modern parent app.

## Snapshot
- **Replaces:**
  - **Jackrabbit Class** (pricing page, accessed Sep 24 2026): **from $49/mo, tiered by total students at month end**. Jackrabbit Plus with branded app **from $93/mo + $169 setup + app-store fees**. Enterprise **$245/mo** flat (Enterprise + app $331/mo) ([Jackrabbit Class pricing](https://www.jackrabbitclass.com/pricing/)).
  - **Jackrabbit Dance:** "$59+/mo plus per-student pricing that scales hard past a couple hundred students" ([Presently comparison, 2026](https://usepresently.com/blog/best-dance-studio-software)).
  - **DanceStudio-Pro:** $59–$179/mo, which the same (competitor) source says has been "climbing without matching feature improvements" ([Presently, 2026](https://usepresently.com/blog/best-dance-studio-software)).
  - **iClassPro:** quote-based. Described as the priciest option, with implementation "a real project" ([Presently](https://usepresently.com/blog/best-dance-studio-software)).
  - **Spark Membership** (martial arts): Basic **$99/mo**, Pro **$149/mo**, Enterprise custom, plus setup and processing fees and **typically a 12-month commitment** (as of Nov 6 2025) ([Gymdesk](https://gymdesk.com/blog/spark-membership-software-honest-reviews-and-top-complaints)).
  - Kicksite: not re-priced in this pass.
- **Recent price hikes / changes:** We found no confirmed 2025–26 list-price hike for Jackrabbit. The pain is that **per-student tier pricing climbs as a studio grows** and the platforms look dated. Note: a competitor blog claimed Akada was "shutting down in 2026", but Akada's own Dec 2025 post shows it still operating and shipping features ([Akada](https://akadasoftware.com/wrapping-up-2025-a-look-into-the-new-year/)). **Do not use that as a trigger.**
- **Who buys:** Owners and office managers of dance studios, gymnastics and cheer gyms, swim schools, martial-arts dojos, and kids' music/art/STEM enrichment centers (100–1,500 students).
- **US market size:** Estimate only: tens of thousands of US youth activity studios, with dance studios alone commonly estimated in the tens of thousands. Needs Census NAICS 611610 (fine arts schools) and 611620 (sports and recreation instruction) counts in the state pass.
- **Urgency trigger (why they'd switch NOW):** Season-start windows. Studios switch **June–August**, before fall registration, and in **January**. Recital season (Apr–Jun) exposes the gaps in costume and recital modules. Per-student tiers also raise the bill as enrollment grows.
- **Fastest-selling states/metros:** Suburban family-heavy metros: Texas (DFW, Houston, Austin), Utah, Georgia, Florida, the Carolinas, Ohio, suburban Chicago. Estimate.

## Pain points (evidence)
- **[Price]** An owner says the monthly rate changes with student counts, so staff constantly archive inactive students to keep the bill down (Jackrabbit Gymnastics, Capterra, Mar 2024) ([Capterra](https://www.capterra.com/p/172591/Jackrabbit-Gymnastics/reviews/?page=7)).
- **[Price]** An owner finds transaction costs and program cost "a bit high" for what it does (Jackrabbit Dance, Capterra, Dec 3 2024) ([Capterra](https://www.capterra.com/p/93349/Jackrabbit-Dance/reviews/?page=3)).
- **[Complexity/UX]** Tuition can't be batch-processed for all students in one pass, so each family must be posted and processed one by one (Jackrabbit Dance, Dec 3 2024) ([Capterra](https://www.capterra.com/p/93349/Jackrabbit-Dance/reviews/?page=3)).
- **[Missing features]** The recital module doesn't track participation status cleanly and rosters don't refresh (Jackrabbit Dance, Dec 17 2024) ([Capterra](https://www.capterra.com/p/93349/Jackrabbit-Dance/reviews/?page=3)).
- **[Missing features]** The costume module only handles ordering, with no checkout or inventory workflow (Jackrabbit Dance, Dec 7 2024) ([Capterra](https://www.capterra.com/p/93349/Jackrabbit-Dance/reviews/?page=3)).
- **[Complexity/UX]** Simple reports take too many steps (Jackrabbit Dance, Dec 17 2024) ([Capterra](https://www.capterra.com/p/93349/Jackrabbit-Dance/reviews/?page=3)).
- **[Complexity/UX]** The platform "lacks modern technology" compared with competitors (Jackrabbit Dance, Dec 12 2024) ([Capterra](https://www.capterra.com/p/93349/Jackrabbit-Dance/reviews/?page=3)).
- **[Missing features]** There is no mobile version of the admin side (Jackrabbit Gymnastics, Mar 2024) ([Capterra](https://www.capterra.com/p/172591/Jackrabbit-Gymnastics/reviews/?page=7)).
- **[Missing features]** The events module is so clunky that the gym runs birthday parties in a separate system (Jackrabbit Gymnastics, Dec 2022) ([Capterra](https://www.capterra.com/p/172591/Jackrabbit-Gymnastics/reviews/?page=7)).
- **[Complexity/UX]** The site goes unresponsive at peak times "once or twice a month" (Jackrabbit Gymnastics, Mar 2024) ([Capterra](https://www.capterra.com/p/172591/Jackrabbit-Gymnastics/reviews/?page=7)).
- **[Support / Lock-in]** Spark Membership users report waiting several days for fixes, a steep learning curve and a typical 12-month commitment ([Gymdesk](https://gymdesk.com/blog/spark-membership-software-honest-reviews-and-top-complaints)).

## What we build (the better version)
1. **MVP** **Family accounts:** siblings, multiple guardians, sibling and multi-class discounts, and registration fees.
2. **MVP** **One-click monthly tuition run** for all families (card and ACH autopay), with proration, late fees and failed-payment retry.
3. **MVP** Online registration with class age and level rules, capacity, waitlists, trial classes and e-sign waivers and policies.
4. **MVP** Parent app (PWA): schedule, absences, makeup-class booking, announcements, payments.
5. **MVP** Attendance on a teacher's phone, plus two-way SMS and email to a class, level or whole studio (included, no caps).
6. **MVP** Free import from Jackrabbit, iClassPro and DanceStudio-Pro exports.
7. **V2** **Recital and costume center:** per-dancer costume sizes, fees billed to family ledgers, a checkout and return inventory, and recital rosters with a quick-change conflict checker (flags dancers in back-to-back numbers).
8. **V2** Skills and belt/level tracking with parent-visible progress cards (gymnastics levels, swim levels, martial-arts belts, with testing fees).
9. **V2** Birthday party and camp booking with deposits.
10. **V2** Competition-team billing (travel, entry fees, installment plans).
11. **V2** AI assistant that drafts class placement ("which Level 2 class fits Emma's schedule?") and answers parent FAQs.

## Pricing to win
- **$59/mo flat up to 250 students, $99/mo unlimited.** Not per-student. Branded-app setup free. Month-to-month. Processing at Stripe cost plus a disclosed small margin.
- **Example:** a 400-student dance studio on per-student Jackrabbit tiers plus a branded app ($169 setup) switches to $99/mo flat. Savings depend on the tier; ask prospects for their current invoice in the sales process. A Spark Membership Pro dojo ($149/mo, 12-month term) saves $600/yr and gets month-to-month terms.

## Go-to-market (first 100 customers)
- **Facebook groups:** "Dance Studio Owners" groups, the "Dance Studio Owners Association" community, gymnastics and cheer gym owners groups, "Swim School Owners", martial-arts school owners groups.
- **Trade events:** Dance Teacher Summit, DanceLife Retreat, the USA Gymnastics Congress, the US Swim School Association annual conference, Martial Arts SuperShow.
- **Timing:** a push in May–July ("switch before fall registration") with free white-glove migration.
- **Partners:** costume vendors and recital-video companies (referral fee), and studio business coaches.
- **SEO:** "Jackrabbit alternative", "dance studio software flat price", "recital costume tracking software".

## Risks and incumbent moats
- **Mid-season switching is painful:** we sell into the summer window and offer a parallel-run month.
- **Autopay card migration:** the same token-transfer issue as F02. Use Stripe's PCI import or a card re-collect at registration, which parents are doing anyway.
- **Jackrabbit brand trust** in the dance/gym world: we win with the recital and costume workflow and flat pricing, backed by studio-owner testimonials.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 4 | 3 | **17** |

## Sources
- [Jackrabbit Class pricing (accessed Sep 24 2026)](https://www.jackrabbitclass.com/pricing/)
- [The best dance studio software in 2026 – Presently](https://usepresently.com/blog/best-dance-studio-software)
- [Jackrabbit Dance reviews p.3 – Capterra](https://www.capterra.com/p/93349/Jackrabbit-Dance/reviews/?page=3)
- [Jackrabbit Gymnastics reviews p.7 – Capterra](https://www.capterra.com/p/172591/Jackrabbit-Gymnastics/reviews/?page=7)
- [Spark Membership honest reviews and complaints – Gymdesk (Nov 2025)](https://gymdesk.com/blog/spark-membership-software-honest-reviews-and-top-complaints)
- [Akada: Wrapping up 2025 (confirms not shutting down)](https://akadasoftware.com/wrapping-up-2025-a-look-into-the-new-year/)
- [iClassPro vs Jackrabbit – Software Advice](https://www.softwareadvice.com/class-registration/iclasspro-profile/vs/jackrabbit/)
