# ShiftTip: a cheaper, better 7shifts / Homebase for hourly restaurant, bar and café teams

**One-liner:** Scheduling, a GPS/photo time clock, tip pooling and tip reporting (including federal "no tax on tips" reporting) for hourly hospitality teams. One flat per-location price covers everything, with no feature gating.

## Snapshot
- **Replaces:**
  - **7shifts** (per Turnozo, updated July 23, 2026), per location per month: Comp free (up to 15 employees, 1 location), Essentials $44.99 ($39.99 annual), Pro $89.99 ($79.99), Premium $149.99 ($134.99) ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
  - **Homebase**, per location per month: Basic free (1 location, 10 employees, 90-day timesheets), Essentials $30 ($24 annual), Plus $70 ($56), All-in-One $120 ($96) ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
  - **When I Work, Deputy, Sling:** also in the category. Pricing was not verified in this pass.
- **Recent price hikes / changes:**
  - **July 2, 2025:** 7shifts put "go-forward changes to 7shifts pricing plans" into effect ([7shifts changelog](https://developers.7shifts.com/changelog/changes-to-7shifts-pricing-plans)). Plan names were restructured to Comp, Essentials, Pro and Premium ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
  - **Jan 2024:** 7shifts cut about 19% of staff (Turnozo, citing BetaKit).
  - **Homebase feature gating:** PTO controls, departments and AI scheduling need Plus ($70). Labor-cost tools, overtime alerts and HR need All-in-One ($120) ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
  - **Federal "no tax on tips" deduction:** Created by the July 2025 federal budget law (One Big Beautiful Bill Act) for tax years 2025-2028. Employers must report qualified tips and tipped occupations separately. *Not re-verified via web in this pass; confirm the IRS W-2 reporting details and dates before using this in marketing.*
- **Who buys:** Owners and GMs of restaurants, bars, cafés, bakeries and QSR franchisees with 10-60 hourly staff per location. Buyer pain peaks at payroll and tip-out time.
- **US market size:** Estimate: most of the approximately 1 million US foodservice locations employ hourly staff (NRA figure commonly cited; not re-verified). The scheduling category also spans retail, salons and hospitality.
- **Urgency trigger (why they'd switch NOW):** 7shifts plan changes (July 2025). Homebase gating and glitch complaints (Sept 2026). New federal tip-reporting obligations for 2026 W-2s. State and city tip-credit phase-outs and tip-pool rules (see state leads).
- **Fastest-selling states/metros:** States with complex tip and wage rules: California, Washington, Oregon, Nevada and Minnesota (no tip credit). New York (tip-credit rules by region). Chicago (tip-credit phase-out). Washington DC (Initiative 82 changes; verify). Massachusetts and Michigan (tip-credit policy fights). All of these need verification in the per-state pass.

## Pain points (evidence)
- **[Complexity/UX]** A Homebase user (Sept 21, 2026) said employee clock-in was malfunctioning even with geofencing disabled ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Complexity/UX]** A reviewer (Sept 16, 2026) said the app had been extremely glitchy for almost two weeks ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Price]** A reviewer (Sept 15, 2026) said mobile time clock costs were higher than expected despite online claims of free access ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Missing features / reliability]** A reviewer (Sept 8, 2026) reported phantom shifts, gaps in timesheets and remote staff unable to log in ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Complexity/UX]** A reviewer (Sept 6, 2026) got repeated clock-in prompts interrupting work whenever Clover Dining opened ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Price]** A small non-profit (July 15, 2026) felt it was paying for many features it does not use ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Trust]** A reviewer (June 18, 2026) raised concerns about newly added AI hiring features ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Lock-in/Billing]** Reddit users report difficulty cancelling Homebase and charges after cancellation. This is secondhand, via Turnozo, and the original threads were not pulled ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
- **[Price]** Homebase gates overtime alerts and labor-cost tools behind the $120/mo All-in-One tier ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
- **[Vendor risk]** The Jan 2024 layoffs at 7shifts raise concerns about long-term commitment (Turnozo, citing BetaKit).
- Overall: Homebase has 3.8/5 on 319 Trustpilot reviews, with 25% one-star, a polarized base ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).

## What we build (the better version)
1. **MVP: Drag-and-drop weekly scheduler.** Includes templates, availability, time-off requests and shift swaps with manager approval.
2. **MVP: AI schedule draft.** Built from last year's sales by hour (CSV or Square/Clover API) plus labor-percent targets.
3. **MVP: Time clock** on a shared tablet (PIN plus photo) or phone (geofence). Break and meal-period prompts are configured by state rules.
4. **MVP: Tip pooling and tip-out calculator.** Rules by role, points, hours or sales. Card-tip import from POS CSV. An auditable tip ledger per shift, and tip statements employees can see.
5. **MVP: "No tax on tips" report pack.** Qualified-tip totals per employee with an occupation code field, exportable for payroll providers and W-2 prep. The rule details must be verified before launch.
6. **MVP: Overtime and labor-cost alerts** and payroll export (Gusto, ADP, QuickBooks, Paychex CSV). Included in every plan.
7. **MVP: Team messaging and shift reminders** by SMS and push.
8. **V2: State compliance packs**, starting with California meal/rest breaks, Oregon, Seattle, NYC and Chicago predictive scheduling, split-shift and spread-of-hours rules.
9. **V2: Two-way POS integrations** (Square, Clover, Toast) for automatic tip import and sales-per-labor-hour.
10. **V2: Instant tip payouts** to debit cards through a payouts partner.

## Pricing to win
- **ShiftTip:** Free for 1 location with up to 10 staff (scheduling plus time clock). **$39/mo per location, all features** (tip pooling, labor alerts, overtime, PTO, payroll export, compliance packs), with unlimited staff. No per-user fees and no annual lock-in.
- **Savings:** A 30-person restaurant needing labor-cost and overtime alerts pays $120/mo on Homebase All-in-One or $89.99-$149.99 on 7shifts Pro/Premium. ShiftTip's $39 saves $50-$110/mo per location, or about $600-$1,300/yr. For a 5-location group that is $3k-$6.5k/yr.

## Go-to-market (first 100 customers)
- **Tip-season content engine:** A "no tax on tips" employer checklist and a free tip-pool calculator (web tool, no signup) as the SEO and lead magnet. Pages for "Homebase alternative" and "7shifts alternative."
- **Reddit:** r/restaurateur, r/KitchenConfidential, r/Serverlife, r/BarOwners, r/smallbusiness. Servers complaining about tip-outs are a bottom-up channel ("send this to your manager").
- **State restaurant associations:** co-host "tip law update" webinars in CA, NY, IL, MA, MI and DC.
- **Payroll partners:** Restaurant-focused bookkeepers and CPAs get a revenue share, since they field the tip questions.
- **POS app marketplaces:** Square App Marketplace and Clover App Market listings for fast, card-paying installs.
- **NRA Show** plus state association trade shows.

## Risks and incumbent moats
- **Cheap and free incumbents** (Homebase free tier, Sling, 7shifts Comp) mean the price gap is modest. We win on tip compliance, no gating and reliability.
- **Payroll bundling:** Homebase and 7shifts upsell payroll. Mitigation: integrate with payroll rather than compete. Consider a Gusto-embedded partnership in V2.
- **Wage-and-hour liability:** Tip-pool and break-rule mistakes create legal exposure. Mitigation: rules engine with conservative defaults and "not legal advice" disclosures, reviewed by an employment lawyer before launch.
- **POS data access:** Toast's API is gated. Start with Square and Clover (open APIs) plus CSV import.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 2 | 4 | 4 | 5 | **18** |

## Sources
- [7shifts vs Homebase pricing and hidden costs – Turnozo (updated July 23, 2026)](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)
- [Changes to 7shifts Pricing Plans – 7shifts developer changelog (July 2, 2025)](https://developers.7shifts.com/changelog/changes-to-7shifts-pricing-plans)
- [Homebase reviews – Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)
- [7shifts review 2026 – OnTheClock](https://www.ontheclock.com/blog/7shifts-review)
- [Homebase vs 7shifts – Shifton](https://shifton.com/comparison/homebase-vs-7shifts/)
