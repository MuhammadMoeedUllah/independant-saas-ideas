# FlatRate: a cheaper, better ServiceTitan / Housecall Pro / Jobber for owner-run HVAC, plumbing, and electrical shops

**One-liner:** Scheduling, dispatch, a good-better-best pricebook, invoicing, and maintenance-plan billing for 1–25-tech trade shops. One flat monthly price, no contract, and free data export whenever you want it.

## Snapshot
- **Replaces:**
  - **ServiceTitan** does not publish prices. Third-party estimates put it at about $245–$300 per tech per month (Starter), $300–$400 (Essentials) and $400–$500 (The Works). Onboarding runs about $5k–$15k for small shops, contracts are at least 12 months with early-cancellation penalties, and add-ons such as Marketing Pro run about $2,000+/mo ([Projul analysis, Feb 12 2026, a competitor's estimates](https://projul.com/blog/servicetitan-pricing-analysis-2026/)).
  - **Housecall Pro** (list prices checked Sep 24 2026): Basic $79/mo monthly or $59/mo annual, 1 user. Essentials $189 or $149, 5 users. Max $329 or $299, 8 users, plus $35 per extra user. Payments at 2.59%. AI CSR, payroll, voice, GPS and websites are sold as extra add-ons ([HCP pricing](https://www.housecallpro.com/pricing/)).
  - **Jobber** (list prices checked Sep 24 2026), all month-to-month with no commitment: Core $49/mo (1 user), Connect $139–$399, Grow $199–$499, Plus $499–$699. Extra users are $29 each. Add-ons: Pipeline $49/mo, Receptionist $29/mo, Marketing Suite $99/mo. Card fees are 2.9% + 30¢. The 1-year-commitment prices are introductory: they run for 3 months and then step up (for example, Core goes from $24 to $39) ([Jobber pricing](https://www.getjobber.com/pricing/)).
  - FieldEdge and Workiz were not priced in this pass.
- **Recent price hikes / changes:**
  - A Housecall Pro customer (an HVAC company) says its monthly bill went from $351 to $681 with no advance notice (Trustpilot, Sep 15 2026).
  - A long-time Jobber user complains of "persistent price hikes" (Trustpilot, Aug 25 2026).
  - ServiceTitan has been public since its Dec 2024 IPO (NASDAQ: TTAN). It is pushing paid "Pro" add-ons, and reviewers describe early-exit bills of about $22k and $37k (see below).
  - Jobber is running a "save up to 40%" promo for sign-ups before Sep 30 2026, which suggests churn pressure.
- **Who buys:** The owner or office manager of a residential HVAC, plumbing or electrical company with 1–25 techs. This is usually the owner's own card purchase.
- **US market size:** A rough estimate, not verified in this pass, is about 150k–200k employer establishments across NAICS 238220 (plumbing/HVAC) and 238210 (electrical), plus many sole proprietors. Confirm with Census County Business Patterns.
- **Urgency trigger (why they'd switch NOW):**
  - ServiceTitan contracts come up for renewal, and customers are angry about auto-renewals.
  - HCP and Jobber bills are rising on renewal and through add-on creep.
  - The Sept–Oct shoulder season, before the heating rush, is the window when shops have time to switch.
- **Fastest-selling states/metros:** An inference, not measured. Start with Sun Belt HVAC-heavy metros with long cooling seasons and many small shops: TX (DFW, Houston, San Antonio), FL (Tampa, Orlando, Miami), AZ (Phoenix) and GA (Atlanta). Then NC and TN.

## Pain points (evidence)
- **[Lock-in/Contracts]** A ServiceTitan customer says the sales rep promised flexibility to exit early. When they tried to leave, the company denied that conversation happened and demanded about a $22,000 cancellation fee ([Trustpilot, Jul 13 2026](https://ca.trustpilot.com/review/servicetitan.com)).
- **[Lock-in/Price]** A small shop says ServiceTitan needed extra staff just to run it, carried hidden phone charges of $80–100/mo, and billed them $37,000 after they left following one month ([Trustpilot, Jun 15 2026](https://ca.trustpilot.com/review/servicetitan.com)).
- **[Price]** A reviewer says ServiceTitan "nickel and dimes" for add-ons and auto-renews contracts without sending cancellation notices ([Trustpilot, Jul 29 2026](https://ca.trustpilot.com/review/servicetitan.com)).
- **[Support]** A ServiceTitan user describes very poor training and scripted support, and says they could not reach management to get problems fixed ([Trustpilot, Jul 29 2026](https://ca.trustpilot.com/review/servicetitan.com)).
- **[Complexity]** G2 reviewers, as summarized by Projul, report ServiceTitan implementations that took about 8 months and cost about $25k ([Projul, 2026](https://projul.com/blog/servicetitan-pricing-analysis-2026/)).
- **[Price]** An HCP customer's bill went from $351 to $681 per month without notice, which wiped out their price advantage over competitors ([Trustpilot, Sep 15 2026](https://www.trustpilot.com/review/housecallpro.com)).
- **[Payments]** An HCP ACH payment sat pending for 8 days after the client approved it, which disrupted the shop's payroll ([Trustpilot, Sep 10 2026](https://www.trustpilot.com/review/housecallpro.com)).
- **[Lock-in]** An HCP customer spent a month trying to cancel, got only automated replies, and had to book a call just to leave ([Trustpilot, Sep 6 2026](https://www.trustpilot.com/review/housecallpro.com)).
- **[Billing]** A sewer contractor says duplicate HCP accounts were charged for five straight months and billing staff denied responsibility ([Trustpilot, May 1 2026](https://www.trustpilot.com/review/housecallpro.com)). HCP's overall Trustpilot score is 2.4/5 on 642 reviews.
- **[Price/Lock-in]** A long-time Jobber user says reporting is "extremely limited," prices keep rising, and they feel trapped by their data ([Trustpilot, Aug 25 2026](https://www.trustpilot.com/review/getjobber.com)).
- **[Support/Bugs]** A 12-year Jobber customer says the API duplicates line items on quotes, manual deletion throws errors, and support does not respond ([Trustpilot, Aug 28 2026](https://www.trustpilot.com/review/getjobber.com)).

## What we build (the better version)
1. **MVP:** Import from ServiceTitan, HCP or Jobber by CSV or export: customers, locations, equipment, open jobs and memberships. We do the import for you for free.
2. **MVP:** A drag-and-drop dispatch board with SMS "tech on the way" texts and a live ETA link.
3. **MVP:** A mobile tech app that works offline: checklists, photos, signatures, and a good/better/best option presenter built from a flat-rate pricebook.
4. **MVP:** AI pricebook builder. Upload a supply-house invoice or a price list, set a markup, and it generates flat-rate tasks with labor hours.
5. **MVP:** Invoicing and payments through Stripe, passed through at cost plus a published margin. Tap to pay, ACH, and card-on-file for maintenance plans.
6. **MVP:** Maintenance agreements (memberships) with auto-billing, recurring visit generation and renewal reminders.
7. **MVP:** Two-way QuickBooks Online sync covering customers, invoices and payments.
8. **MVP:** One-click full data export in CSV and JSON. "Leave anytime" is a feature.
9. **V2:** AI call answering and booking, sold at cost-plus rather than as a $29–$99/mo add-on.
10. **V2:** Equipment/warranty tracking by serial number, with refrigerant-log fields for EPA 608 record-keeping.
11. **V2:** Financing hand-off to lenders such as GreenSky, Service Finance and Wisetack through partner links.
12. **V2:** Tech performance dashboard (revenue per tech, close rate, callbacks) and a commission calculator.

## Pricing to win
- **Our prices:** Solo $49/mo. Shop $149/mo for up to 10 users. Pro $299/mo with unlimited users. Month-to-month, no setup fee, free migration.
- **Card processing:** Passed through at cost plus about 0.3%, published openly.
- **Example savings:** A 6-tech HVAC shop on ServiceTitan's low estimate ($245/tech) pays about $1,470/mo plus onboarding. On FlatRate Shop it pays $149/mo, saving about $15.8k a year before add-ons. Against HCP Max for 8 users ($329 monthly), we save about $180/mo.

## Go-to-market (first 100 customers)
- **Reddit:** "Price hike / contract trap" posts in r/HVAC, r/Plumbing, r/electricians and r/sweatystartup, offering a free migration concierge. Owners already swap ServiceTitan contract horror stories there.
- **SEO pages:** "ServiceTitan cancellation fee", "Housecall Pro price increase", "Jobber alternative no per-user fee", plus a public "true cost calculator".
- **Associations:** ACCA (Air Conditioning Contractors of America), PHCC (Plumbing-Heating-Cooling Contractors) and state chapters. Offer member pricing and sponsor chapter meetings.
- **Trade shows:** AHR Expo, plus regional supply-house counter days.
- **Supply-house partnerships:** Johnstone Supply, Ferguson, Winsupply and local distributors. Import their price files into the AI pricebook as a co-marketing hook.
- **Consultants:** Partner with flat-rate pricing consultants and HVAC coaching groups who help shops leave ServiceTitan. Pay a 20% recurring referral fee.
- **Outbound:** Cold email to shops that show ServiceTitan or HCP booking widgets on their websites (detectable from site tech), timed to contract anniversaries.

## Risks and incumbent moats
- **Crowded category.** FieldEdge, Workiz and many cheap FSMs already exist. We differentiate on no contract, flat price, instant export and AI pricebook setup, and sell against ServiceTitan's contract anger rather than on features.
- **Payments.** Incumbents earn heavily on processing. We use Stripe Connect and earn a thin transparent margin.
- **Data lock-in.** Exports can be incomplete (for example, pricebook images). We build importers and offer a concierge service.
- **Integrations.** Financing, distributor pricing and marketing attribution are ServiceTitan strengths. We defer them to V2 partners.
- **Compliance.** PCI is covered through Stripe. SOC 2 comes later, since it is not needed for owner-operators.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 5 | 4 | 2 | 3 | 5 | **19** |

## Sources
- [Jobber pricing page (checked Sep 24 2026)](https://www.getjobber.com/pricing/)
- [Housecall Pro pricing page (checked Sep 24 2026)](https://www.housecallpro.com/pricing/)
- [Projul: ServiceTitan Pricing 2026 (Feb 12 2026; competitor estimates)](https://projul.com/blog/servicetitan-pricing-analysis-2026/)
- [Trustpilot: ServiceTitan reviews (3.9/5, 411)](https://ca.trustpilot.com/review/servicetitan.com)
- [Trustpilot: Housecall Pro reviews (2.4/5, 642)](https://www.trustpilot.com/review/housecallpro.com)
- [Trustpilot: Jobber reviews (4.2/5, 230)](https://www.trustpilot.com/review/getjobber.com)
