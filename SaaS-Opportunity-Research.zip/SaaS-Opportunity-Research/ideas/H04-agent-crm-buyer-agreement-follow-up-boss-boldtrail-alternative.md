# AgentPact: a cheaper, better Follow Up Boss / BoldTrail (kvCORE) for solo agents and small teams, with the post-NAR-settlement buyer-agreement workflow built in

**One-liner:** A flat-priced real estate CRM with lead routing, texting and calling, and smart plans. It adds a **"no tour without a signed buyer agreement"** workflow: compensation disclosure, state-form checklists, an e-sign and showing log, and a broker compliance dashboard. It is independent of any portal (not owned by Zillow).

## Snapshot
- **Replaces:**
  - **Follow Up Boss (Zillow-owned):**
    - **Grow:** $69/user/mo monthly or $58 annual. The calling add-on is **$39/user/mo** ($33 annual).
    - **Pro:** $499/mo for 10 users, then $49/user.
    - **Platform:** $1,000/mo for 30 users, then $20/user.
    - No contract ([FUB pricing, Sept 2026](https://www.followupboss.com/pricing)).
  - **BoldTrail (kvCORE, Inside Real Estate):** Quote-based, and often bought by the brokerage. One reviewer said they were billed **$409.75** after asking to deactivate ([G2, May 2026](https://www.g2.com/products/boldtrail/reviews)).
  - Lofty, Sierra Interactive and CINC: pricing not verified in this pass.
- **Recent price hikes / changes:**
  - **NAR settlement practice changes took effect Aug 17, 2024.** MLS participants need a **written buyer agreement before touring** (virtual tours included). It must state compensation as an objective amount or rate, cap compensation from all sources at that amount, and say that commissions are fully negotiable. Offers of compensation are banned from the MLS ([NAR](https://www.nar.realtor/the-facts/what-the-nar-settlement-means-for-home-buyers-and-sellers)).
  - Brokers now carry the compliance risk for every tour.
  - No dated 2024-2026 Follow Up Boss list-price increase was verified in this pass. Current list prices are above.
- **Who buys:** Solo agents (card buyers), small teams of 2-15 agents (team lead), and independent brokerages of 5-50 agents (broker-owner). Franchise brokerages often mandate BoldTrail or Lofty, and agents then pay for their own FUB anyway.
- **US market size:** Estimate: about 1.4-1.5 million NAR members plus non-member licensees, and tens of thousands of independent brokerages. Verify with NAR membership data. Agent count has been falling since 2022, so budgets are tight.
- **Urgency trigger (why they'd switch NOW):**
  - Buyer-agreement compliance is a daily workflow problem that generic CRMs don't enforce.
  - Agents want to avoid feeding lead data to Zillow.
  - Agents are cutting costs as transaction volume and agent counts fall.
  - January is when teams reset their tech stack.
- **Fastest-selling states/metros:** Large-agent states: California, Florida, Texas, New York, Arizona, Georgia and North Carolina. The large state REALTOR associations issue their own buyer-agreement forms, which makes state-specific checklists valuable. Estimate.

## Pain points (evidence)
- **[Price]** A REALTOR (July 2025) said Follow Up Boss could be cheaper, especially for new users, or offer a longer trial ([G2](https://www.g2.com/products/follow-up-boss/reviews)).
- **[Lock-in/Trust]** A small-business reviewer (Nov 2023) worried that Zillow's data practices threaten FUB's independence after the acquisition ([G2](https://www.g2.com/products/follow-up-boss/reviews)).
- **[Support]** One FUB reviewer (Jan 2024) found live support hard to reach. Another (Sept 2024) said support slowed as the company grew ([G2](https://www.g2.com/products/follow-up-boss/reviews)).
- **[Integrations]** A reviewer (July 2025) has asked repeatedly for FUB's BoldTrail BackOffice integration to be updated, with no result ([G2](https://www.g2.com/products/follow-up-boss/reviews)).
- **[Lock-in/Contracts]** A REALTOR (Feb 2026) said BoldTrail won't let you test the software yourself before signing ([G2](https://www.g2.com/products/boldtrail/reviews)).
- **[Price/Billing]** A BoldTrail user (May 2026) said the company kept charging $409.75 after they asked for deactivation and didn't get full onboarding ([G2](https://www.g2.com/products/boldtrail/reviews)).
- **[Price/Missing features]** A BoldTrail product educator (June 2026) found international numbers weren't supported. This came out only after five months and $7,500 spent ([G2](https://www.g2.com/products/boldtrail/reviews)).
- **[Complexity/UX]** A CEO (July 2026) said BoldTrail was unnecessarily complex, and key features were missing or didn't work as expected ([G2](https://www.g2.com/products/boldtrail/reviews)).
- **[Misleading sales]** A reviewer (Sept 2026) was promised about 30 leads a month and got 4-5. A second reviewer (July 2026), who switched from CINC, got only a fraction of their previous leads ([G2](https://www.g2.com/products/boldtrail/reviews)).
- **[UX]** A FUB scheduling coordinator (Nov 2025) said the mobile app is sometimes slow ([G2](https://www.g2.com/products/follow-up-boss/reviews)).

## What we build (the better version)
1. **MVP: Lead inbox and routing.** Email parsing from Zillow, Realtor.com, Homes.com, website forms and open-house sign-ins. Round-robin, ponds and speed-to-lead alerts.
2. **MVP: Texting and calling at cost** (Twilio) with a click-to-call power list. No $39/user dialer add-on.
3. **MVP: Buyer-agreement workflow.** Before a showing can be scheduled, the buyer needs a signed agreement on file. Agreements are uploaded or generated from the **broker's own** state association form, with e-sign. Compensation fields are validated (objective amount, "negotiable" notice present, term dates), plus renewal and expiry alerts.
4. **MVP: Showing log** tied to agreements, as audit evidence for the broker. Tours without an agreement are flagged.
5. **MVP: Smart plans.** AI-drafted follow-up sequences (text and email) that the agent approves, with a past-client nurture calendar (home anniversaries, market updates).
6. **MVP: Broker compliance dashboard.** Percentage of active buyers with a valid agreement, expiring agreements, and missing disclosures by agent.
7. **MVP: One-click import** from FUB, BoldTrail, Lofty and CSV.
8. **V2: State disclosure checklist engine.** Required seller and buyer disclosures and agency forms by state, with timing reminders across the transaction.
9. **V2: IDX website and property alerts** (needs MVP-level MLS/IDX approvals per MLS).
10. **V2: Commission and deal pipeline** with a basic back-office export (splits, caps).

## Pricing to win
- **AgentPact:** **Solo $29/mo** (calling and texting at cost). **Team $149/mo for up to 10 users**, then $12/user. **Brokerage compliance** $3/agent/mo on top of any CRM (sold standalone to brokers). No contract; free import.
- **Savings example:** A solo agent on FUB Grow monthly with calling pays $69 + $39 = **$108/mo**. AgentPact is $29 plus about $10 of usage, a saving of about **$830/yr**. A 10-person team on FUB Pro pays $499/mo against our $149/mo, a saving of **$4,200/yr**.

## Go-to-market (first 100 customers)
- **State REALTOR associations** (e.g., Texas REALTORS, California Association of REALTORS, Florida REALTORS): member-benefit vendor programs and tech expos. Pitch the buyer-agreement compliance checklist tied to their own forms.
- **Local boards and MLS tech days** and broker-owner roundtables. Brokers buy the compliance dashboard, and their agents adopt the CRM.
- **Communities:** r/realtors and agent Facebook groups (large national agent communities). Share a free "buyer agreement compliance audit" template.
- **SEO:** "Follow Up Boss alternative," "CRM not owned by Zillow," "kvCORE alternative," "buyer agreement tracking software."
- **Partners:** real estate coaches and team-building consultants (referral fees), and transaction coordinators.

## Risks and incumbent moats
- **Crowded category** (Wise Agent, Real Geeks, Lofty, LionDesk-type tools). Mitigation: lead with compliance and the broker dashboard, not the "CRM."
- **Brokerage-mandated platforms** (BoldTrail through franchise deals). Mitigation: import and sync, and sell the compliance layer that sits alongside them.
- **State forms are copyrighted by associations.** Mitigation: never redistribute forms. Use checklists and the broker-uploaded forms.
- **Portal lead integrations** depend on email parsing. The Zillow API favors FUB.
- **TCPA and texting compliance.** Mitigation: consent capture and 10DLC registration built in.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 2 | 3 | 4 | 4 | **16** |

## Sources
- [Follow Up Boss Pricing (Sept 2026)](https://www.followupboss.com/pricing)
- [Follow Up Boss Reviews – G2](https://www.g2.com/products/follow-up-boss/reviews)
- [BoldTrail Reviews – G2](https://www.g2.com/products/boldtrail/reviews)
- [What the NAR Settlement Means for Home Buyers and Sellers – NAR](https://www.nar.realtor/the-facts/what-the-nar-settlement-means-for-home-buyers-and-sellers)
