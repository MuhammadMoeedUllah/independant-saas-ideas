# LicenseLedger: a cheaper, better CE Broker / Harbor Compliance / LegalZoom compliance bundle for licensed professionals and small practices

**One-liner:** One app that holds every professional license you or your staff carry across states, tracks continuing-education (CE) hours against each board's rules using AI read from certificates, and keeps your LLC's annual reports and franchise-tax dates on a calendar. It is flat-priced, with no paywall on your own transcript.

## Snapshot
- **Replaces:**
  - **CE Broker** is the CE tracking and reporting system that several state boards use (notably Florida; list to verify in the per-state pass).
    - It has a free basic tier with paid upgrades. Reviewers say basic information such as CE transcripts requires an upgrade.
    - Paid tier prices were **not verified in this pass** (cebroker.com/pricing returned 404 on Sep 24 2026).
  - **Harbor Compliance** (license and entity management) is quote-based. Not verified.
  - **Registered-agent and compliance subscriptions** from LegalZoom, Northwest and CT Corporation:
    - Commonly advertised at about $125/yr (Northwest) up to about $299/yr (LegalZoom registered agent), plus "compliance" bundles.
    - Figures are from background knowledge and **not verified in this pass**.
- **Recent price hikes / changes:**
  - **BOI reporting is gone for domestic companies.** FinCEN's interim final rule of **Mar 26 2025** limited "reporting company" to foreign entities. On **Aug 11 2026** FinCEN finalized the rule (effective Aug 14 2026): "U.S. companies are exempt," and US persons with FinCEN IDs need not update ([FinCEN BOI](https://www.fincen.gov/boi)).
    - Any "BOI filing" or compliance upsell sold to domestic LLCs is now dead weight, which opens a window to re-sell "what you actually still owe": state annual reports and franchise tax.
  - CE Broker upsell complaints dominate 2026 reviews (below).
- **Who buys:**
  - Individual licensees: nurses (especially travel and compact nurses), therapists, pharmacists, real estate agents, contractors, CPAs, cosmetologists, insurance producers.
  - Practice and agency managers tracking staff licenses (home health, staffing agencies, clinics).
  - Solo LLC owners who formed through LegalZoom-type services.
- **US market size:**
  - Estimate: tens of millions of occupational licensees in the US (most commonly cited figure is about 1 in 5 workers licensed; not re-verified), and tens of millions of LLCs and corporations filing annual reports.
  - Individual willingness to pay is low ($20–$60/yr). Practices and agencies pay more.
- **Urgency trigger (why they'd switch NOW):**
  - **License renewal deadlines**, which are staggered by board. Many boards renew biennially on birth month or fixed dates.
  - Examples of entity dates (well-known, verify in the per-state pass): the **Delaware LLC annual tax is due June 1** and the **California $800 minimum franchise tax** is due annually.
  - **The Aug 11 2026 FinCEN final rule** is a "stop paying for BOI" moment.
  - CE Broker transcript paywall frustration shortly before renewal.
- **Fastest-selling states/metros:**
  - **Florida**, where CE Broker is embedded in license renewal for many professions. Verify the profession list.
  - Multistate-license states for nurses (Nurse Licensure Compact members) and travel-nurse hubs (TX, AZ, FL, NC, TN).
  - Delaware and California for entity-tax reminders.

## Pain points (evidence)
- **[Overall]** CE Broker averages **1.5/5 on 37 reviews (Sep 24 2026), 94% of them 1-star** ([Trustpilot, 2026](https://www.trustpilot.com/review/cebroker.com)).
- **[Price/Upsell]** Upselling feels "coercive" despite a free tier, and users say they are forced to upgrade just to see their own CE transcript ([Trustpilot, 2026](https://www.trustpilot.com/review/cebroker.com)).
- **[Billing]** A cancellation took 8 days to process, and the refund was then denied because the 30-day window had lapsed by one day ([Trustpilot, 2026](https://www.trustpilot.com/review/cebroker.com)).
- **[Accuracy]** Completed CME credits show as "Not completed" after being entered, and courses are miscategorized or vanish from transcripts ([Trustpilot, 2026](https://www.trustpilot.com/review/cebroker.com)).
- **[Accuracy]** License information syncs incorrectly from state boards ([Trustpilot, 2026](https://www.trustpilot.com/review/cebroker.com)).
- **[Support]** Holds of 30+ minutes end in disconnection, email replies read as AI-generated and don't help, tickets take 8+ days, and one reviewer says "customer service is nonexistent" ([Trustpilot, 2026](https://www.trustpilot.com/review/cebroker.com)).
- **[Risk]** Professionals say unresolved CE Broker problems put their license renewals at risk ([Trustpilot, 2026](https://www.trustpilot.com/review/cebroker.com)).
- **[Billing/Lock-in]** A LegalZoom customer says recurring fees for business management and registered-agent services "kept piling on without clear opt-in transparency," cancelling through the portal was "unnecessarily difficult," and the billing seemed "designed to catch users off guard" ([Trustpilot, Sep 2026](https://www.trustpilot.com/review/legalzoom.com)). LegalZoom is otherwise rated 4.6/5 on 33k+ reviews, so this is a minority complaint.
- **[Regulatory churn]** BOI filing went from mandatory, to paused, to domestic companies exempt (Mar 2025), to exempt permanently (Aug 2026), leaving owners unsure what they owe ([FinCEN](https://www.fincen.gov/boi)).

## What we build (the better version)
1. **MVP: a license wallet.** Add each license by state, board and number. We look up status and expiry from public board lookups where they are available (Nursys for nurses, V2) and store photos of the cards.
2. **MVP: a CE rules engine** for the top 10 professions in the top 15 states: hours per cycle, mandatory topics (for example ethics, laws and rules, human trafficking, implicit bias), live vs. home-study limits, and carry-over.
3. **MVP: AI certificate capture.** Snap or forward a certificate by email and we extract the provider, course, hours, category, date and approval number, then map them to every license the course counts toward. That matters for multi-state licensees.
4. **MVP: a "Am I done?" dashboard** showing hours remaining by license, with a renewal countdown and reminders at 120/60/30/7 days by email and SMS.
5. **MVP: a free, unlimited audit-ready transcript export** (PDF plus the certificate bundle). This is the anti-CE-Broker feature.
6. **MVP: an entity calendar.** Enter your LLC or corporation and state(s) and get annual report and franchise-tax due dates, fees, direct links to the state portal, and a note that BOI is no longer required for US companies (dated source).
7. **V2: a team plan** for clinics, agencies and brokerages: staff license and CE monitoring, alerts to the manager, and primary-source verification logs.
8. **V2: CE Broker hand-off.** Push course completions where the board requires CE Broker reporting (via provider or partner API if available), or produce a pre-filled checklist.
9. **V2: done-for-you annual report filing** at $49 plus the state fee, and a partner registered-agent service at about $99/yr (below common market rates, estimate).
10. **V2: a CE course marketplace** with affiliate revenue from providers, which lets us keep the individual price low.

## Pricing to win
- **Our plans:**
  - **Individual:** $29/yr for unlimited licenses and states, with a free transcript export always.
  - **Team:** $4 per licensed staff member per month.
  - **Entity calendar:** free. Filing service $49 per filing (V2).
- **Comparison:**
  - CE Broker's paid tiers (price unverified) put the transcript behind a paywall; ours never does.
  - Against LegalZoom/Northwest compliance bundles (about $125–$299/yr, unverified), a solo LLC owner who only needs reminders pays $0 with us, and $49 when they want filing done.

## Go-to-market (first 100 customers)
- **Nurses first** (largest licensee group, multi-state, CE heavy): r/nursing, r/TravelNursing, travel-nurse Facebook groups, and nursing-school alumni groups. Pitch: "your transcript, free, forever."
- **Florida push:** SEO for "CE Broker alternative," "CE Broker transcript without upgrade" and "Florida license renewal CE requirements [profession]."
- **Staffing agencies and home-health agencies** (team plan): cold email to compliance coordinators. Overlaps with the E07 buyer list.
- **Real estate brokerages and insurance agencies** track agents' CE. Go through brokerage owners and state REALTOR associations.
- **Entity side:** SEO for "Do I still need to file BOI? (No, Aug 2026 rule)" and "[State] LLC annual report due date." Bookkeepers and accountants get a free multi-client view.

## Risks and incumbent moats
- **Boards that mandate CE Broker.** In those states we complement it rather than replace it: we track, remind and export, and the licensee still reports in CE Broker. Our pitch is multi-state convenience and a free transcript.
- **Rules accuracy** across 50 states × dozens of professions is a big content job. We start narrow (top 10 professions × 15 states), show citations and use AI-assisted monitoring of board rule changes.
- **Registered-agent service** needs physical addresses in every state. We partner rather than build.
- **Low individual willingness to pay.** Offset with team plans and CE-course affiliate revenue.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 4 | 4 | 5 | **20** |

## Sources
- [Trustpilot: CE Broker reviews (1.5/5, 37 reviews)](https://www.trustpilot.com/review/cebroker.com)
- [Trustpilot: LegalZoom reviews](https://www.trustpilot.com/review/legalzoom.com)
- [FinCEN: Beneficial Ownership Information (interim final rule Mar 26 2025; final rule Aug 11 2026)](https://www.fincen.gov/boi)

## Corrections from the state pass (Sep 2026)
- **Delaware LLC/LP annual tax is now $400** (was $300), due Jun 1; corporate franchise tax and annual report due Mar 1. See ideas/S2-01 and states/DE-delaware.md.
- **Florida:** Sunbiz administratively dissolves entities that missed the annual report on the fourth Friday of September (Sep 25 2026 this year), a recurring urgency hook. See states/FL-florida.md.

## Verification (Sep 24 2026)
- ✅ FinCEN: interim final rule Mar 26 2025 limited reporting to foreign entities; final rule issued Aug 11 2026 (effective Aug 14 2026, added): "U.S. companies are exempt", and US persons with FinCEN IDs need not update ([source](https://www.fincen.gov/boi))
- ✅ CE Broker Trustpilot 1.5/5 with 94% 1-star — confirmed; the review count is now 37 (was 36), updated ([source](https://www.trustpilot.com/review/cebroker.com))
- ✅ Transcript upsell ("forcing healthcare workers to upgrade to see basic CEU summary"), 8-day cancellation then refund denied, credits showing "Not completed", 30+ minute holds — confirmed ([source](https://www.trustpilot.com/review/cebroker.com))
- ⚠️ CE Broker paid-tier prices are still unverified; the vendor pricing page (cebroker.com/pricing) returned 404 (source not reachable Sep 2026).
- Scores unchanged.
