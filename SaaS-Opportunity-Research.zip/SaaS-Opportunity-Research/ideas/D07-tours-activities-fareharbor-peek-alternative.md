# BookTrail: a cheaper, better FareHarbor / Peek Pro / Xola for independent tour, activity and attraction operators

**One-liner:** A booking system for tours, rentals, charters, classes and small attractions with **no booking fee on the guest**. It has a transparent flat subscription, all-in pricing that complies with junk-fee law, waivers, capacity and resource scheduling, and direct Stripe payouts.

## Snapshot
- **Replaces:**
  - **FareHarbor (Booking Holdings):** a **6% booking fee in North America, added to the customer's checkout price**. A $100 tour becomes $106. No monthly fee and no setup fee, but FareHarbor **does not publish its rates**, so operators learn them on sales calls (per Roverd, July 10, 2026) ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/), [CaptainBook](https://www.captainbook.io/blog/fareharbor-pricing-fees-explained), [Bokun](https://www.bokun.io/fareharbor-pricing)).
  - **Peek Pro:** the fee is charged to the customer, with no monthly base fee. **Rezdy:** from $99/mo, OTA-focused. **Roverd:** 5% per booking; the operator chooses whether to absorb or pass it on ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/)). **Xola:** pricing not verified this pass.
- **Recent price hikes / changes:**
  - **2026:** FareHarbor rolled out a new operator platform called "Desk." An operator review (Apr 2026) called it "HORRIBLE" ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
  - **FTC junk-fee rule (effective May 12, 2025)** covers live-event tickets and short-term lodging ([FTC](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)). Whether tours and attractions count as "live events" needs a legal check. **California SB 478** (effective July 1, 2024) requires advertised prices to include all mandatory fees for California consumers, so fee-on-top models create compliance work (verify how FareHarbor handles CA).
  - Reviewers report a "drop in support quality since the Booking Holdings acquisition" ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/)).
- **Who buys:** Owner-operators of walking and food tours, boat charters and fishing guides, kayak, bike and e-bike rentals, zip lines, escape rooms, cooking classes, ghost tours, and small museums or attractions. Buyer is the owner, card-paying and seasonal.
- **US market size:** Estimate: tens of thousands of US tour and activity operators. Unverified; check Arival and US Census NAICS 5615 / 7139 counts in the next pass. The dollar pool is large because fees scale with gross bookings.
- **Urgency trigger (why they'd switch NOW):** Junk-fee scrutiny (FTC rule May 2025, CA SB 478, and new state laws in MN, CO, VA and MA per the state-lead list; verify). The disruptive migration to FareHarbor "Desk." Off-season (Oct-Mar for summer operators) is the switching window.
- **Fastest-selling states/metros:** Tourism clusters: Florida (Orlando, Keys, Gulf Coast), Hawaii, California (SF, San Diego, LA, Monterey), Nevada (Las Vegas), New York City, Tennessee (Smoky Mountains, Nashville), South Carolina (Charleston, Myrtle Beach), Colorado mountain towns, Alaska cruise ports, New Orleans, Savannah.

## Pain points (evidence)
- **[Price]** FareHarbor's 6% fee is added to the guest's checkout price, which inflates the operator's advertised price at the last step ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/), [Hamza Liaqat, "The 6% Fee Math"](https://hamzaliaqat.com/blog/fareharbor-pricing-2026)).
- **[Price/Transparency]** FareHarbor doesn't publish rates, which operators flag as friction during research ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/)).
- **[Complexity/UX]** An operator (Apr 2026) called the new "Desk" platform "HORRIBLE" and not user-friendly ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Support]** An operator (Mar 2026) said training lasts 7 days with a trainer, "then you are left" ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Support]** An operator (Jun 2026) said onboarding was "quick and easy for them," and then they were left hanging ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Support/Lost revenue]** An operator (Mar 2026) described 20 days of delays implementing pricing, with the product closed to bookings in the meantime ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Support]** An operator (Jul 2026) said a website project had dragged on for over a year with little communication ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Missing features]** An operator (Mar 2026) said promised advertising was never delivered and inventory display was broken ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Guest experience]** A guest (May 2026) said a booking couldn't be honored and getting a refund was unnecessarily difficult ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Billing]** A reviewer (Aug 2026) said charges continued for months after cancellation ([Trustpilot](https://www.trustpilot.com/review/fareharbor.com)).
- **[Complexity/UX]** A competitor reports a 14-second checkout load delay and a 25% drop in completed bookings. This is a competitor claim to treat cautiously ([Roverd](https://www.roverd.com/fareharbor-review-alternatives/)).
- Overall: FareHarbor has 3.8/5 on 183 Trustpilot reviews.

## What we build (the better version)
1. **MVP: Product and availability builder.** Tours with time slots, rentals by hour or day, private charters and multi-day trips. Capacity by guide, vehicle or boat seats.
2. **MVP: Fast, mobile-first checkout** embedded on the operator's site (one script tag) with Apple Pay and Google Pay. **All-in price shown from the first screen.**
3. **MVP: Stripe Connect direct payouts** with deposits, balance-due autopay, and gift cards.
4. **MVP: Digital waivers** with a minor/guardian flow, signed in the booking flow or by QR on arrival and stored per booking.
5. **MVP: Guide and resource scheduling.** Manifests, check-in by QR, and weather cancellations with one-tap bulk rebook or refund texts.
6. **MVP: Automated reminders and review requests** (SMS and email) to Google and Tripadvisor.
7. **MVP: Import tool** for FareHarbor, Peek and Xola bookings and customer lists (CSV plus AI mapping).
8. **V2: OTA distribution** through channel managers (Viator/Tripadvisor, GetYourGuide, Expedia Local Expert) and Google Things to Do.
9. **V2: Reseller and hotel-concierge portal** with commission tracking.
10. **V2: Dynamic pricing** by demand and weather, plus an AI phone and chat booking agent.

## Pricing to win
- **BookTrail:** **$0 guest booking fee.** $79/mo flat (single location, unlimited products and bookings) or $149/mo (multi-location, OTA channel, reseller portal). Processing at Stripe cost plus a disclosed markup. No contract, free migration.
- **Savings example:** An operator doing $400k/yr in online bookings on FareHarbor adds $24k/yr in 6% fees to guests' bills. BookTrail costs $948-$1,788/yr. The operator can either lower the all-in price guests see by about 5% (more conversions) or raise the base price 3% and keep about $10k extra a year.
- **Honest note:** FareHarbor is "free" to operators, so the pitch must be about guest conversion, all-in pricing compliance and control, not the operator's bill.

## Go-to-market (first 100 customers)
- **Arival** (the in-destination experiences industry community) events and webinars. Also Tripadvisor and Viator operator communities.
- **Destination marketing organizations and CVBs, and state tourism offices:** vendor partnerships and "tourism business summit" sponsorships in FL, TN, SC and HI.
- **Vertical clusters first:** fishing charters and boat tours (marina docks in FL Keys and the Gulf Coast), e-bike rentals, escape rooms and ghost tours. Each has Facebook owner groups and word of mouth.
- **"FareHarbor alternative," "no booking fee tour software," "FareHarbor Desk problems"** SEO pages plus a fee calculator.
- **Reddit:** r/smallbusiness, r/Entrepreneur, r/touroperators if active, r/escaperooms.
- **Partner referrals:** Web designers who build tour-operator sites get a revenue share.

## Risks and incumbent moats
- **OTA distribution:** FareHarbor and Peek have deep Viator, GetYourGuide and Google connections. Mitigation: plug into existing connectivity hubs in V2 and focus on direct-booking operators first.
- **"Free to operator" framing:** It's hard to sell a subscription against $0. Mitigation: an optional **1.5% operator-paid** plan with no subscription, never on the guest.
- **Waiver and liability standards** vary by state. Use templates, not legal advice.
- **Payments:** Stripe Connect handles PCI and KYC. Weather refunds need good tooling.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 4 | 4 | 3 | **19** |

## Sources
- [FareHarbor Review 2026: Pros, Cons & Best Alternatives – Roverd (July 10, 2026; competitor)](https://www.roverd.com/fareharbor-review-alternatives/)
- [FareHarbor Pricing – Roverd](https://www.roverd.com/fareharbor-pricing/)
- [FareHarbor Pricing & Fees Explained 2026 – CaptainBook](https://www.captainbook.io/blog/fareharbor-pricing-fees-explained)
- [FareHarbor Pricing Guide 2026 – Bokun](https://www.bokun.io/fareharbor-pricing)
- [FareHarbor Pricing 2026: The 6% Fee Math – Hamza Liaqat](https://hamzaliaqat.com/blog/fareharbor-pricing-2026)
- [FareHarbor Pricing 2026 – Automate.travel](https://automate.travel/blog/fareharbor-pricing-guide-2026/)
- [FareHarbor vs Peek Pro – EquipDash](https://equipdash.com/blog/fareharbor-vs-peek-pro)
- [FareHarbor reviews – Trustpilot](https://www.trustpilot.com/review/fareharbor.com)
- [FTC Rule on Unfair or Deceptive Fees to Take Effect May 12, 2025 – FTC](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)
