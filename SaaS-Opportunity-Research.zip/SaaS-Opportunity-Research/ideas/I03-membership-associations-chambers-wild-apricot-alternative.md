# DuesDesk: a cheaper, better WildApricot / MemberClicks / GrowthZone for clubs, small associations and chambers

**One-liner:** Member database, dues renewals, event registration, a member directory and a simple website for volunteer-run clubs, alumni groups, small associations and chambers of commerce. Flat pricing, any payment processor with no surcharge, and a one-click WildApricot import.

## Snapshot
- **Replaces:**
  - **WildApricot (Personify)** (official pricing page, "last updated Feb 7 2026"):
    - **100 contacts: $66/mo monthly**, $59.40/mo on a 1-year prepay, $56.10/mo on a 2-year prepay.
    - Higher tiers go up to 50,000 contacts, with prices not shown in our fetch ([WildApricot pricing](https://www.wildapricot.com/pricing)).
    - A competitor reports April 2026 annual prices of **$886 (250 contacts), $1,663 (500) and $5,238 (5,000)** ([Groupable, competitor](https://www.groupable.com/blog/wild-apricot-pricing-hidden-fees)).
  - **WildApricot payment surcharge.** WildApricot's own page says alternative payment systems cost "an additional fee". A competitor describes it as a **20% surcharge on the entire annual subscription** if you use a processor other than WildApricot/Personify Payments ([WildApricot pricing](https://www.wildapricot.com/pricing); [Groupable](https://www.groupable.com/blog/wild-apricot-pricing-hidden-fees)).
  - **GrowthZone AMS:** "starting at **$3,900/yr**", custom quotes, with modules, payments, websites and implementation extra. **ChamberMaster** (same company) publishes no rate ([ChamberHive, May 2026, competitor](https://www.chamberhive.com/blog/growthzone-alternatives-comparison)).
  - MemberClicks and YourMembership: quote-based, not re-priced in this pass.
- **Recent price hikes / changes (switching windows):**
  - **WildApricot price history** (competitor-reported): **+20% in 2021, +25% in 2023, another rise in 2025, and ~5% in early 2026** ([Groupable](https://www.groupable.com/blog/wild-apricot-pricing-hidden-fees)). One Trustpilot reviewer saw a **27% renewal jump, from $640 to $810**, for the same tier (Nov 2023) ([Trustpilot](https://www.trustpilot.com/review/wildapricot.com)).
  - **PE consolidation.** **Momentive Software (owned by TA Associates) acquired Personify on Jan 6 2026.** That puts MemberClicks, A2Z Events and Personify products under the same roof as YourMembership, Nimble AMS and NetForum. Analysts warn of "product rationalization and pricing optimization within 18–36 months". This is MemberClicks customers' third owner in five years ([SmartThoughts, Jan 20 2026](https://www.smartthoughts.net/post/momentive-personify-acquisition-association-impact)). WildApricot is marketed as "WildApricot by Personify" ([WildApricot pricing](https://www.wildapricot.com/pricing)).
- **Who buys:** Volunteer presidents and treasurers of clubs (running, pickleball, garden, car, rotary-style service clubs), alumni associations, PTAs and boosters. Also executive directors of small trade and professional associations (1–5 staff) and chamber presidents/CEOs. Clubs buy with a card; chambers decide with a board but move quickly at renewal.
- **US market size:** Estimate: tens of thousands of small associations and several thousand local chambers of commerce, plus hundreds of thousands of informal clubs, alumni chapters and boosters. Verify via IRS 501(c)(6) and 501(c)(7) counts in the state pass.
- **Urgency trigger (why they'd switch NOW):** WildApricot renewal notices after the early-2026 increase. Momentive/Personify consolidation uncertainty for MemberClicks and YourMembership customers. **Jan 1 dues-renewal season** (switch in Oct–Nov to run renewals on the new system).
- **Fastest-selling states/metros:** Everywhere clubs exist. Associations cluster in DC/VA/MD, Chicago and state capitals (Austin, Sacramento, Columbus, Harrisburg). Chambers are densest in TX, CA, FL, OH, PA and IL (estimate).

## Pain points (evidence)
- **[Price]** A webmaster for two nonprofits saw the annual subscription rise **27% ($640 to $810) for the same service** (Trustpilot, Nov 12 2023) ([Trustpilot](https://www.trustpilot.com/review/wildapricot.com)).
- **[Price/Lock-in]** A competitor says organizations discover the **20% surcharge** on their next invoice, after they've already enabled dues collection and onboarded members ([Groupable](https://www.groupable.com/blog/wild-apricot-pricing-hidden-fees)).
- **[Support]** A nonprofit reviewer had no live support, sales promises went unmet, and they couldn't launch for **9 months**. Support also cancelled callback sessions (Trustpilot, Feb 11 2026) ([Trustpilot](https://www.trustpilot.com/review/wildapricot.com)).
- **[Missing features / reliability]** A member organization says newsletters lose emails and delivery tracking is inconsistent, at "premium" USD prices (Trustpilot, May 29 2026) ([Trustpilot](https://www.trustpilot.com/review/wildapricot.com)).
- **[Complexity/UX]** A reviewer calls the design early-2000s, and says the problems only show up in real use after the trial (Trustpilot, May 28 2026) ([Trustpilot](https://www.trustpilot.com/review/wildapricot.com)).
- **[Complexity/UX]** The email editor has fixed margins, an unclear cursor position and unpredictable bullets (Trustpilot, Aug 12 2026) ([Trustpilot](https://www.trustpilot.com/review/wildapricot.com)).
- **[Complexity/UX]** The site builder keeps breaking, and basic tasks like linking emails take too many steps (Trustpilot, Aug 29 2026) ([Trustpilot](https://www.trustpilot.com/review/wildapricot.com)).
- **[Overall]** WildApricot's Trustpilot rating is **1.3/5 across 159 reviews** (accessed Sep 24 2026) ([Trustpilot](https://www.trustpilot.com/review/wildapricot.com)).
- **[Price/Missing]** WildApricot users have long asked for a low-cost plan (e.g. ~$25/mo) on WildApricot's own wishlist forum ([WildApricot forums](https://forums.wildapricot.com/forums/308932-wishlist/suggestions/13335057-low-level-pricing-plans-e-g-25)).
- **[Price transparency]** GrowthZone's full price depends on modules, payments, websites and seats; a competitor warns that its starting price "does not tell you" the real total ([ChamberHive](https://www.chamberhive.com/blog/growthzone-alternatives-comparison)).

## What we build (the better version)
1. **MVP** Member database with membership levels, households and companies (for chambers), custom fields, and a **one-click WildApricot import** (contacts, levels, renewal dates, event history).
2. **MVP** **Automated dues renewals:** reminder sequences, grace periods, autopay, prorated join dates, and a lapsed-member win-back.
3. **MVP** **Bring any processor with no surcharge:** Stripe, Square or PayPal, plus offline check/cash marking.
4. **MVP** Event registration with member vs non-member pricing, waitlists, QR check-in and all-in ticket pricing display.
5. **MVP** Public member directory and business directory (chambers), with member self-service profiles.
6. **MVP** Email newsletters with a modern block editor, deliverability tracking and SMS blasts.
7. **MVP** Simple website builder (templates for clubs, alumni groups and chambers) on a custom domain.
8. **V2** **Chamber pack:** tiered sponsorships, ribbon-cutting and event calendars, a member-to-member deals board, and a "hot deals" newsletter, plus a GrowthZone/ChamberMaster import.
9. **V2** Multi-chapter/federation mode (national with chapters, dues split).
10. **V2** AI board helper: drafts renewal emails, summarizes meeting minutes, and builds a treasurer's report from payments.

## Pricing to win
- **$19/mo** up to 250 members. **$39/mo** up to 1,000. **$79/mo** up to 5,000. **$149/mo** unlimited (chambers). Month-to-month, no processor surcharge, free import.
- **Example:** a 500-contact club paying WildApricot about $1,663/yr (April 2026, competitor-reported) moves to $468/yr and saves **~$1,200/yr (72%)**. If it was paying the 20% surcharge for its own processor, it saves more.

## Go-to-market (first 100 customers)
- **ACCE** (Association of Chamber of Commerce Executives) and **state chamber executives associations** (e.g. Texas Chamber of Commerce Executives, the Western Association of Chamber Executives): conference booths and "chamber software cost" webinars.
- **State societies of association executives** (e.g. TSAE in Texas, CalSAE) for 1–5 staff associations.
- **Club verticals:** pickleball, running and cycling club directors (Facebook groups), alumni-relations offices (chapter tools), PTA and booster networks.
- **WildApricot user forums** and **Reddit** (r/nonprofit, r/association): the "WildApricot price increase" query.
- **SEO:** "WildApricot alternative", "WildApricot 20% surcharge", "MemberClicks alternative after Momentive", "ChamberMaster alternative".
- **Timing:** Oct–Nov before Jan 1 renewals; July for fiscal-year associations.

## Risks and incumbent moats
- **Websites:** many orgs run their public site on WildApricot, so the import must include pages and menus.
- **Autopay tokens:** re-collect cards at the first renewal on our system (renewal emails double as re-enrollment).
- **Cheap competitors** (MembershipWorks, Groupable, Memberplanet): we differentiate with import quality, no surcharge and a chamber pack.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 4 | 4 | 3 | **19** |

## Sources
- [WildApricot pricing (last updated Feb 7 2026; accessed Sep 24 2026)](https://www.wildapricot.com/pricing)
- [WildApricot price increase 2026: hidden fees – Groupable (competitor)](https://www.groupable.com/blog/wild-apricot-pricing-hidden-fees)
- [WildApricot reviews – Trustpilot](https://www.trustpilot.com/review/wildapricot.com)
- [WildApricot wishlist: low-level pricing plans](https://forums.wildapricot.com/forums/308932-wishlist/suggestions/13335057-low-level-pricing-plans-e-g-25)
- [Momentive Software acquires Personify – SmartThoughts (Jan 20 2026)](https://www.smartthoughts.net/post/momentive-personify-acquisition-association-impact)
- [Personify acquires MemberClicks](https://personifycorp.com/blog/personify-acquires-memberclicks/)
- [GrowthZone alternatives – ChamberHive (May 2026, competitor)](https://www.chamberhive.com/blog/growthzone-alternatives-comparison)
