# Clipboardless: a cheaper, contract-free Tebra / Phreesia / NexHealth front-office layer for small clinics

**One-liner:** A flat-priced front-office layer for any small outpatient clinic (1–10 providers): smart intake forms, online booking, reminders, QR check-in, card-on-file and copay collection, Good Faith Estimates and review requests. It sits alongside the clinic's existing EHR with no multi-year contract.

## Snapshot
- **Replaces:**
  - **Tebra** (Kareo + PatientPop): **no public prices**. Pricing page tiers: Practice Automation, EHR+, Patient Experience + Marketing, EHR Starter, Billing Starter. Priced per clinical provider with unlimited non-clinical staff. Published extras: EPCS setup about $75/provider one-time; PDMP integration $500 one-time per facility + about $50/user/yr (pricing page, fetched 2026-09-24).
  - **IntakeQ** (pricing page, fetched 2026-09-24):
    - Forms Only $54.90/mo + $20 per additional practitioner.
    - Practice Management $84.90/mo + $30 per additional practitioner.
    - Low-volume plans: Forms $29.90 (10 submissions/mo) and PM $59.90 (25 appointments + 25 forms per practitioner per 30 days).
    - BAA included.
  - **Phreesia, NexHealth**: quote-based; pricing **not verified in this pass**.
- **Recent price hikes / changes:**
  - Tebra's **pricing policy (updated effective Jul 1, 2026)** allows increases of **up to 4.9% once per 12 months** with 30 days' notice (60 days on month-to-month for all fees). Contracts **auto-renew unless written non-renewal is given at least 60 days before term end**. "All fees are nonrefundable and non-cancellable", and deactivated providers may owe an **early termination fee for the rest of the term**.
  - Capterra reviewers report an annual service fee added for unused services (Jun 2026) and monthly charges jumping from **$300 to $1,700** from undisclosed ERA transaction fees during an account transition (Nov 2025).
- **Who buys:** Owners and practice managers of small independent practices (primary care, specialists, behavioral health, chiro/PT, med spa) on legacy or bundled PM/EHR systems. They pay by card.
- **US market size:** Our estimate is 200k+ small US outpatient practices across physician, behavioral, dental and allied health (not verified in this pass). This layer is horizontal, so it can be cross-sold into every segment E01–E07.
- **Urgency trigger (why they'd switch NOW):** Tebra renewals and the **60-day non-renewal window**, the annual 4.9% increase allowance, fee surprises (ERA and service fees), and No Surprises Act Good Faith Estimate obligations for self-pay patients.
- **Fastest-selling states/metros:** Estimate: states with many independent practices and self-pay volume (TX, FL, CA, NY, NJ, GA, AZ). This is a horizontal product, so lead with metros where our vertical products (E01–E07) sell.

## Pain points (evidence)
- **[Price]** A director says Tebra added an annual service fee for services they didn't use, and it took a lot of back-and-forth to fix (Capterra, Jun 2026) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).
- **[Price / Lock-in]** An administrator with 10+ years on Kareo/Tebra says monthly charges rose from $300 to $1,700 because of undisclosed ERA transaction fees during an account transition (Capterra, Nov 2025) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).
- **[Support / Lock-in]** The same administrator was "bounced around" between reps with no clear offboarding path (Capterra, Nov 2025) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).
- **[Lock-in/Contracts]** The policy requires written non-renewal 60+ days before term end, says fees are non-cancellable and nonrefundable, and allows ETFs for deactivated providers (Tebra pricing policy, effective Jul 1, 2026) ([Tebra](https://www.tebra.com/tebra-pricing-policy)).
- **[Complexity/UX]** An office manager and biller finds billing features and reports confusing and insurance take-backs complicated (Capterra, Mar 2026) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).
- **[Support]** A CEO describes a repeated pattern of unresolved issues, unstable workflows and no leadership accountability (Capterra, May 2026) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).
- **[Missing features]** Mobile and web schedules don't sync, and cancellations sometimes don't show up (Capterra, Aug 2025) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).
- **[Missing features]** There's no HIPAA-compliant direct messaging; the workaround is sending portal invites (Capterra, Oct 2025) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).
- **[Missing features]** Template dropdowns can't be customized to show only frequently used options (Capterra, Jun 2026) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).
- **[Price]** Tebra's overall rating of 3.9/5 across 1,384 Capterra reviews is low for the category (fetched 2026-09-24) ([Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)).

## What we build (the better version)
1. **MVP:** **Smart intake forms**: conditional logic, English and Spanish, insurance card and ID photo capture with OCR, consents with e-signature, and medical/behavioral history templates by specialty.
2. **MVP:** **Universal EHR hand-off**: a PDF packet plus structured JSON/CSV, delivered by secure download, e-fax or upload to the EHR's document inbox. It works with any EHR on day one.
3. **MVP:** **Online booking widget** (website, Google, Instagram), reminders with two-way confirmation, and waitlist auto-fill.
4. **MVP:** **QR/kiosk check-in** on the patient's own phone, so no tablet rental.
5. **MVP:** **Payments**: card on file, copay at check-in, text-to-pay, payment plans, and a **Good Faith Estimate** generator for self-pay patients.
6. **MVP:** **Google review requests** and a simple NPS survey.
7. **MVP+:** Real-time **insurance eligibility** (270/271) through a clearinghouse API, charged at cost.
8. **V2:** Bidirectional EHR integrations through vendor marketplaces and APIs (appointment and demographics write-back).
9. **V2:** An AI phone and text receptionist (answers FAQs, books, reschedules) and a patient-responsibility cost estimator.
10. **V2:** A front-office analytics dashboard (no-show rate, collections at time of service, form completion).

## Pricing to win
- **$49/mo per location with unlimited providers and staff.** Unlimited forms and email reminders, SMS at cost above a large bundle, card processing at Stripe's standard rate. Month-to-month, no ETFs, cancel in app.
- **Savings:**
  - A 3-practitioner clinic on IntakeQ Practice Management pays $84.90 + 2×$30 = $144.90/mo. Clipboardless **saves about $1,150/yr**.
  - A 5-practitioner clinic on IntakeQ PM pays $204.90/mo. Clipboardless **saves about $1,870/yr**.
  - Against Tebra, Phreesia and NexHealth, we lead with **no contract and no ETF**. Savings depend on quotes, so collect them on calls before making claims.
- **Honest note:** IntakeQ is already inexpensive for solo providers. Our edge is flat multi-provider pricing, payments and GFE, and contract freedom.

## Go-to-market (first 100 customers)
- **A "Tebra non-renewal deadline calculator" SEO page** (enter your renewal date, get your 60-day notice date and a notice letter template), plus "Tebra alternative", "Phreesia alternative for small practice", "NexHealth pricing", and "IntakeQ alternative for group practice".
- **Practice-manager channels:** MGMA state chapters, AAPC local chapters (coders and billers influence front-office tooling), and practice-manager Facebook and LinkedIn groups.
- **Partners:** Medical billing companies and IT/MSP firms serving small clinics (reseller margin). Also cross-sell to customers of E01–E07.
- **Directories:** Capterra and G2 listings with a free tier to seed reviews, and EHR app marketplaces where available (verify listing costs).
- **Local:** Chamber health-care councils and specialty societies' state meetings, bundled with E-series vertical booths.

## Risks and incumbent moats
- **Commodity category:** Many HIPAA form builders exist (IntakeQ, Jotform HIPAA, and others). We differentiate through bundling (payments + GFE + booking), flat pricing and vertical templates.
- **EHR write-back:** Incumbents such as Phreesia and NexHealth have deep integrations. We start universal (PDF/fax/JSON) and add integrations where the most customers are.
- **Payments dependency and PCI:** Stripe Elements or Checkout keeps us at SAQ-A scope.
- **HIPAA/BAA on a small-team budget:** We are a business associate.
  - Sign customer BAAs and use AWS HIPAA-eligible services under its self-serve BAA (RDS/S3 with KMS, SES, Textract for insurance card OCR).
  - SMS carries links only, with no PHI.
  - Stripe for payments, relying on HIPAA's payment-processing exemption, with no diagnosis or service detail in metadata.
  - E-fax through a vendor that signs a BAA.
  - A free HHS SRA Tool risk assessment, MFA, audit logs, and a breach runbook.
  - **Cost estimate:** A few hundred dollars a month plus a few thousand dollars a year for a pen test and cyber insurance. Add SOC 2 when multi-location groups ask.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 4 | 4 | **18** |

## Sources
- [Tebra Pricing Policy (effective Jul 1, 2026)](https://www.tebra.com/tebra-pricing-policy)
- [Tebra pricing page](https://www.tebra.com/pricing) (fetched 2026-09-24)
- [Tebra reviews, Capterra](https://www.capterra.com/p/129169/Tebra/reviews/)
- [IntakeQ pricing](https://intakeq.com/pricing) (fetched 2026-09-24)
- [Tebra (previously Kareo + PatientPop) Pricing, G2](https://www.g2.com/products/tebra-previously-kareo-patientpop/pricing)
