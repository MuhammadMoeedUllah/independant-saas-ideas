# Part500 Kit: a cheaper, better Vanta / Drata / consultant retainer for NY DFS-licensed small agencies and brokers

**One-liner:** A flat-priced, self-serve compliance kit that walks small NY DFS licensees (insurance agencies, individual agents and brokers, mortgage brokers) through 23 NYCRR Part 500. It covers the exemption decision, policies, MFA and asset-inventory evidence, risk assessment and training, and ends with the **April 15** annual certification, filed with a stored receipt.

## Snapshot
- **Replaces:**
  - **Vanta** has four tiers (Essentials, Plus, Professional, Enterprise). It is **quote-only** and doesn't list 23 NYCRR 500 among its featured frameworks ([Vanta pricing, fetched 2026-09-24](https://www.vanta.com/pricing)).
  - **Drata** is quote-only, via "Contact Sales," and its featured frameworks don't include 23 NYCRR 500 ([Drata pricing, fetched 2026-09-24](https://drata.com/pricing)).
  - The usual small-agency alternative is an IT/MSP or compliance-consultant engagement priced per project (estimate, not verified this pass), or doing it by hand from DFS PDFs.
- **Recent price hikes / changes:**
  - The amended Part 500 phased in through Nov 2025, with MFA and asset inventory as the last pieces (verify exact phase dates).
  - DFS keeps settling cybersecurity cases, for example **Delta Dental (consent order Apr 30 2026; $2.25M amount, verify)** and **Order Express (Aug 2026, verify; not listed on the DFS page)** ([DFS Cybersecurity Resource Center](https://www.dfs.ny.gov/industry_guidance/cybersecurity)).
  - Individual insurance brokers and agents must file an annual compliance notification unless fully exempt ([DFS FAQ](https://www.dfs.ny.gov/cybersecurity/faqs)).
- **Who buys:** Principals of 1–20-person independent insurance agencies, individual producers, mortgage brokers and small DFS-licensed lenders. The buyer is the owner or office manager, who is also the "senior officer" signing the certification.
- **US market size:**
  - DFS supervises 1,900+ insurers and 1,300+ banks and financial institutions ([DFS About](https://www.dfs.ny.gov/about_us)).
  - DFS does not publish the number of individual agents, brokers and mortgage licensees. Our estimate is tens of thousands of NY-resident agencies and individual licensees, plus non-resident licensees who also fall under DFS.
  - This is a NY-only product at launch. V2 extends it to the NAIC Insurance Data Security Model Law states and to the FTC Safeguards Rule for tax preparers and auto dealers (verify state list).
- **Urgency trigger (why they'd switch NOW):**
  - **April 15 each year:** a Certification of Material Compliance or an Acknowledgment of Noncompliance, signed by the highest-ranking executive and the CISO or senior officer.
  - A **72-hour** incident notice and a **24-hour** extortion-payment notice.
  - DFS says the emailed receipt is the only confirmation of the filing and "you may need the receipt number to renew your license" ([DFS Submissions](https://www.dfs.ny.gov/cybersecurity/submissions)).
- **Fastest-selling states/metros:** NY only. Long Island (Nassau and Suffolk agency density), NYC boroughs, Westchester and Hudson Valley, Buffalo, Rochester, Albany (estimate).

## Pain points (evidence)
This is a regulatory-burden product, so most of the evidence comes from DFS's own documents. Review-site complaint threads were not collected this pass, because web search wasn't available.
- **[Complexity]** Small entities with the 500.19(a) limited exemption (<20 staff, <$7.5M revenue, or <$15M assets) still must maintain a cybersecurity program and written policies. They also need access-privilege limits, a written password policy, risk assessments, third-party service-provider policies, MFA, an asset inventory with data-retention limits, and annual training including social engineering ([DFS Small Business](https://www.dfs.ny.gov/cybersecurity/small-business-resources)).
- **[Complexity]** There are seven exemption paths (500.19(a)–(g)). Some require a Notice of Exemption within 30 days, and some need none. When eligibility ends, the entity has 180 days to reach full compliance ([DFS Exemptions](https://www.dfs.ny.gov/cybersecurity/exemptions)). Owners can't easily tell which applies to them.
- **[Deadline]** The annual certification or acknowledgment is due April 15 and needs two signatures, the top executive and the CISO or senior officer. That's hard in a 3-person agency with no CISO ([DFS Submissions](https://www.dfs.ny.gov/cybersecurity/submissions)).
- **[Deadline]** Incident notice is due within 72 hours, including incidents at third-party service providers such as an AMS vendor or rater. Extortion payments need notice within 24 hours plus a 30-day follow-up ([DFS Submissions](https://www.dfs.ny.gov/cybersecurity/submissions)).
- **[Lock-in / licensing]** DFS says the emailed receipt "is the only confirmation of the submission" and "you may need the receipt number to renew your license," so a missed filing can become a licensing problem ([DFS Submissions](https://www.dfs.ny.gov/cybersecurity/submissions)).
- **[Individual agents]** Individual insurance brokers and agents must file unless fully exempt ([DFS FAQ](https://www.dfs.ny.gov/cybersecurity/faqs)). Many sole producers don't know they are a covered entity (inference).
- **[Price / fit]** The two best-known compliance-automation platforms are quote-only and built around SOC 2, ISO and HIPAA, and neither lists 23 NYCRR 500 as a featured framework ([Vanta](https://www.vanta.com/pricing), [Drata](https://drata.com/pricing)). That's overkill for a 4-person agency.
- **[Enforcement fear]** DFS keeps publicizing cybersecurity settlements (Delta Dental consent order Apr 30 2026, $2.25M (verify amount); Order Express, Aug 2026 (verify)) ([DFS](https://www.dfs.ny.gov/industry_guidance/cybersecurity)).

## What we build (the better version)
1. **Exemption and scope wizard (MVP).** Answer about 10 questions (headcount incl. contractors, revenue for 3 years, assets, systems, NPI held, parent coverage). You get the exact 500.19 category, the sections that still apply, and whether and when to file a Notice of Exemption.
2. **Policy pack generator (MVP).** AI drafts plain-English policies from the wizard answers: the 500.3 cybersecurity policy, the 500.7(b) password policy, the 500.11 third-party provider policy, the incident response plan and the data-retention schedule. Staff e-sign acknowledgments and the policies are versioned.
3. **Asset inventory (MVP).** Import from Google Workspace or Microsoft 365 device lists, or from CSV, or use a guided "walk the office" checklist for laptops, phones, printers and the AMS, rater and carrier portals. Each asset gets an owner, location, data held and retention date (500.13).
4. **MFA evidence locker (MVP).** A checklist of every login (email, AMS, carrier portals, bank, remote access) with a screenshot or attestation upload. The gaps are flagged in red (500.12).
5. **Risk assessment builder (MVP).** A questionnaire plus an AI-drafted report and remediation list, re-run each year (500.9).
6. **Annual training (MVP).** A 20-minute social-engineering and phishing module with a quiz and completion certificates per person (500.14).
7. **April 15 filing assistant (MVP).** An evidence binder PDF, the signature workflow for both signers, reminders from January, a step-by-step DFS portal walkthrough (DFS ID plus authenticator app), and storage for the receipt number used at license renewal.
8. **Incident clock (MVP).** A "we think we were hacked" button that starts the 72-hour and 24-hour timers, prefills the DFS notice fields, and logs vendor-side incidents.
9. **Vendor (TPSP) tracker (V2).** List the AMS, raters, IT provider and cloud storage, send security questionnaires, and store attestations.
10. **Cluster and MSP console (V2).** One login for an agency network, aggregator or MSP to run 20–200 agencies, with bulk exemption filings (DFS supports bulk submission for 50+ individuals).
11. **Multi-framework expansion (V2).** The FTC Safeguards Rule (tax preparers and auto dealers), the MA 201 CMR 17 WISP, and NAIC model-law states, all reusing the same evidence.
12. **Phishing simulation and tabletop exercise (V2).**

## Pricing to win
- **Solo producer:** $19/mo or $179/yr, covering the wizard, policies, training for 1 person and the filing assistant.
- **Agency (up to 20 people):** $59/mo or $590/yr, adding the asset inventory, MFA locker, risk assessment and incident clock.
- **Done-with-you April 15 package:** a $299 one-time add-on. We review the binder before you certify.
- **Cluster/MSP:** $15/agency/mo, 10-agency minimum.
- **Versus alternatives:** Vanta and Drata need a sales call and are built for SOC 2. A consultant or MSP project is priced per engagement (estimate, not verified). A typical 5-person agency pays $590/yr with us, has no contract, and can export everything as PDFs.

## Go-to-market (first 100 customers)
- **Associations:** IIABNY (Big I New York) and PIANY (Professional Insurance Agents of NY). Offer a free "Part 500 in 30 minutes" webinar, and try to get it approved for CE credit (verify).
- **Agency clusters and aggregators:** NY-based networks (for example SIAA master agencies, Iroquois Group, verify) buy for members.
- **Mortgage side:** the NY Association of Mortgage Brokers (verify name).
- **Seasonality:** Q4 2026 "get ready" content, then Jan–Apr 15 hard selling. Send reminder emails to the DFS licensee lists that associations already reach.
- **SEO:** "23 NYCRR 500 small business checklist," "DFS cybersecurity certification April 15," "500.19(a) limited exemption requirements," "Notice of Exemption DFS how to file."
- **Partners:** MSPs serving insurance agencies (white-label), E&O insurers (a premium credit for completed kits, to negotiate), AMS vendors' marketplaces (integration listing).
- **Communities:** r/Insurance, r/InsuranceAgent, and Facebook groups for independent insurance agents in NY (search by name).

## Risks and incumbent moats
- **"We just tick the box."** Many small licensees may certify without doing the work. The counter is DFS enforcement publicity plus E&O and cyber-insurance applications that ask for MFA and asset evidence.
- **Legal-advice liability.** Position the product as a templates-and-workflow tool, not legal advice. Add an optional attorney or consultant review marketplace.
- **Associations giving away free templates.** Partner with them instead of competing, since they want a tool for members.
- **AMS vendors bundling a module.** Applied and Vertafore could add one. We win on simplicity, price and non-AMS evidence (email, devices, banking).
- **Rule changes.** DFS amends Part 500 periodically, and a single-state product carries concentration risk. Mitigate with the multi-framework V2.
- **Low moat.** The content is replicable. The moat is the evidence history (year-over-year binder) and the cluster/MSP distribution.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 5 | 4 | 3 | **19** |

## Sources
- [NY DFS Cybersecurity Resource Center](https://www.dfs.ny.gov/industry_guidance/cybersecurity)
- [NY DFS Small Business Compliance Resources](https://www.dfs.ny.gov/cybersecurity/small-business-resources)
- [NY DFS Cybersecurity Exemptions](https://www.dfs.ny.gov/cybersecurity/exemptions)
- [NY DFS Cybersecurity Submissions](https://www.dfs.ny.gov/cybersecurity/submissions)
- [NY DFS Cybersecurity FAQs](https://www.dfs.ny.gov/cybersecurity/faqs)
- [NY DFS About Us](https://www.dfs.ny.gov/about_us)
- [Vanta pricing (fetched 2026-09-24)](https://www.vanta.com/pricing)
- [Drata pricing (fetched 2026-09-24)](https://drata.com/pricing)

## Verification (Sep 24 2026)
- ✅ The April 15 annual notice covers the previous calendar year, is signed by the highest-ranking executive and the CISO or senior officer, and is filed in the DFS Portal with DFS ID plus MFA ([DFS Submissions](https://www.dfs.ny.gov/cybersecurity/submissions))
- ✅ Incident notice within 72 hours; extortion-payment notice within 24 hours plus a written explanation within 30 days ([DFS Submissions](https://www.dfs.ny.gov/cybersecurity/submissions))
- ❌ DFS never says the receipt is "critical for license renewal". Its words are that the email receipt "is the only confirmation of the submission" and "you may need the receipt number to renew your license". Both places that used the misquote were fixed ([DFS Submissions](https://www.dfs.ny.gov/cybersecurity/submissions))
- ✅ 500.19(a) limited exemption: fewer than 20 employees and contractors, OR <$7.5M revenue in each of the last 3 years, OR <$15M year-end assets. The duties that still apply are the program and policies, access limits, password policy, risk assessment, third-party provider (TPSP) policy, MFA, asset inventory, training and annual notice ([DFS Small Business](https://www.dfs.ny.gov/cybersecurity/small-business-resources))
- ✅ Bulk submissions are supported for entities with 50+ covered individuals who share the same exemption ([DFS Submissions](https://www.dfs.ny.gov/cybersecurity/submissions))
- ⚠️ Enforcement: the Delta Dental consent order is dated Apr 30 2026, but the page shows no dollar amount. **Order Express (Aug 2026) is not listed** on the resource center. The page confirms the amendment took effect Nov 1 2023 with phased dates, but not the Nov 2025 final phase. All three are now tagged (verify) ([DFS Cybersecurity](https://www.dfs.ny.gov/industry_guidance/cybersecurity))
