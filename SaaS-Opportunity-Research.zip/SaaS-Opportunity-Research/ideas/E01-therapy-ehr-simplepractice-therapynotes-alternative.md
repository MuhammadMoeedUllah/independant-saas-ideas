# Hearth EHR: a cheaper, better SimplePractice / TherapyNotes for solo and small-group therapists

**One-liner:** A flat-priced, all-included EHR for private-practice therapists (notes with AI scribe, telehealth, scheduling, payments, superbills, light insurance) with a "leave Headway/Alma" kit for clinicians going direct after platform rate cuts.

## Snapshot
- **Replaces:**
  - **SimplePractice** (pricing page, fetched 2026-09-24): Starter $49/mo, Essential $79/mo, Plus $99/mo (solo). Group Plus: $99/mo first clinician + $74/mo each additional; 6+ clinicians custom. Add-ons: Care Aide AI bundle $59/mo (account owner) + $49/mo per additional clinician; standalone Note Taker $35/mo; ePrescribe $49/mo + $89 setup; "Insurance Navigator" $1.79/claim (listed as coming soon). 50%-off-for-3-months promo shown.
  - **TherapyNotes** (support article, fetched 2026-09-24): Solo $69/mo; Group $79/mo first clinician + $50/mo each additional; TherapyFuel AI $40/clinician/mo; Premium Telehealth $15/clinician/mo; ePrescribe $65/prescriber/mo; e-claims 14c each, paper claims $1, eligibility checks 14c, text/voice reminders 14c each; cards 3.1% + 30c; storage $9/mo first user + $3/additional.
  - **Headway / Alma** (insurance-credentialing platforms, not classic subscriptions): therapists accept platform-negotiated payer rates, which the platforms and payers have cut (see below).
  - TherapyAppointment: pricing not verified in this pass.
- **Recent price hikes / changes:**
  - SimplePractice Starter reportedly went from $29 to $49/mo in March 2025 (+69%), per a competitor's blog; not confirmed against a SimplePractice primary source ([SteadyPractice](https://www.steadypractice.app/blog/simplepractice-price-increase-2025-what-to-do.html)). Capterra reviewers in 2025–2026 describe "constant" increases with little notice.
  - AI is sold as an add-on. A solo SimplePractice Plus user with Care Aide pays $99 + $59 = **$158/mo**. A TherapyNotes solo user with TherapyFuel pays $69 + $40 = **$109/mo**, before per-claim and per-reminder fees.
  - **Headway/Alma rate cuts:** in Nov 2024, UnitedHealth/Optum cut rates for therapists on two digital platforms, and therapists were angry about it ([ClearHealthCosts](https://clearhealthcosts.com/blog/2024/11/2-digital-mental-health-platforms-cut-pay-rates-for-therapists-with-unitedhealths-optum-stirring-anger/)). **Effective July 15, 2026**, Aetna "flattened" rates for Alma-contracted therapists: 53+ minute sessions now pay the same as 37–52 minute sessions, highly complex evaluations pay the same as moderate ones, and doctoral-level rates fell to master's level. Alma said publicly that it disagrees ([Behavioral Health Business, May 2026](https://bhbusiness.com/2026/05/21/aetna-cuts-rates-with-alma-contracted-therapists/)). One practice-consulting blog puts the platform cuts at up to 30% ([Mental Wealth Solutions](https://mentalwealthsolutions.org/blog/headway-alma-therapist-pay-cuts-marketplace-platforms)).
- **Who buys:** Solo LPCs, LMFTs, LCSWs and psychologists, plus group practices of 2–10 clinicians. The buyer is the owner-clinician, who pays by card.
- **US market size:** Our estimate is roughly 150k–250k US clinicians in private practice, derived from BLS counts for counselors, MFTs, social workers and psychologists. We did not verify this in this pass. SimplePractice alone has 2,827 Capterra reviews, which points to a very large installed base.
- **Urgency trigger (why they'd switch NOW):** (1) Aetna/Alma rate flattening took effect July 15, 2026. Clinicians leaving platforms for direct contracts or private pay need their own EHR, billing and superbills. (2) SimplePractice and TherapyNotes keep adding paid AI add-ons. (3) Annual SimplePractice renewals.
- **Fastest-selling states/metros:** Large private-pay and out-of-network metros: NYC, SF Bay Area/LA (CA has the largest MFT base via CAMFT), Chicago, Austin/Dallas, Denver, Seattle. Rate cuts from Aetna and Optum hit nationally, so every state is in play.

## Pain points (evidence)
- **[Price]** An owner-therapist says prices go up constantly with very little notice (Capterra, Mar 2026) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Price]** A director of operations at a 2–10 person practice calls $99/mo expensive given the repeated rate hikes (Capterra, Dec 2024) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Price]** An owner-therapist is annoyed at extra charges for basics such as CPT-code use and premium pricing for calendar sync (Capterra, May 2025) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Price / Lock-in]** An owner-therapist says SimplePractice bought competitors and then shut them down, and that a "special deal" rate came out higher than regular pricing (Capterra, Jan 2025) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Support]** Reviewers describe customer support as nonexistent, with bots that can't solve problems (Capterra, Dec 2024 and Jul 2025) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Complexity/UX]** A reviewer reports connection or system problems 4–6 times a week (Capterra, Dec 2024) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Complexity/UX]** Telehealth links fail and have to be re-sent by hand (Capterra, Mar 2025) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Missing features]** There is no autosave, so progress-note text is lost unless you keep clicking save (Capterra, May 2025) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Missing features]** Clients can't self-manage new appointment times (Capterra, Mar 2026) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Missing features]** A group practice's care coordinator says the product didn't fit their workflow and billing processing had problems (Capterra, Jan 2025) ([Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)).
- **[Price / platform]** Therapists on Headway and Alma have seen payer rates cut by Optum (Nov 2024) and flattened by Aetna (Jul 2026), which pushes them to reconsider platform dependence ([ClearHealthCosts](https://clearhealthcosts.com/blog/2024/11/unitedhealth-optum-pay-cut-makes-clinicians-reassess-value-of-tech-mental-health-platforms/), [BHB](https://bhbusiness.com/2026/05/21/aetna-cuts-rates-with-alma-contracted-therapists/)).

## What we build (the better version)
1. **MVP:** One-click migration from SimplePractice and TherapyNotes exports: clients, appointments and documents as PDFs, done for free by us.
2. **MVP:** A calendar with client self-booking and self-rescheduling, recurring sessions, waitlist, and unlimited email reminders. SMS reminders are included and carry no PHI.
3. **MVP:** Notes with **autosave** and SOAP/DAP/BIRP/treatment-plan templates. A **built-in AI scribe is included in the base price**, and recordings and transcripts are deleted by default after the note is signed.
4. **MVP:** Intake packets, consents and e-signatures, plus an automatic **Good Faith Estimate** for self-pay clients (No Surprises Act).
5. **MVP:** 1:1 telehealth with a stable per-client room link and a phone dial-in fallback.
6. **MVP:** Card on file, auto-charge after the session, packages and sliding scale. A **superbill generator** helps out-of-network clients get reimbursed.
7. **MVP:** A client portal for messages, documents and payments. PHQ-9 and GAD-7 are sent and scored automatically.
8. **MVP+ (weeks 4–6):** Eligibility checks and 837P claims through a developer clearinghouse API, charged at cost.
9. **V2:** A **"Go-direct kit"** for Headway/Alma leavers: a CAQH/NPI/payer-application checklist tracker, a payer-rate comparison (what the platform paid versus a direct contract), and client-transition letters.
10. **V2:** ERA auto-posting, denial worklist, and payer rate tracking per CPT (90834 vs 90837).
11. **V2:** Group-practice payroll splits per session, supervisor co-sign for associates, and multi-location.
12. **V2:** ePrescribe through a partner, Psychology Today/directory profile sync, and an AI treatment-plan drafter.

## Pricing to win
- **Hearth Solo: $39/mo, all-in.** It includes the AI scribe, telehealth, reminders and superbills. Month-to-month, with free migration.
- **Hearth Group:** $39 + $29 per additional clinician. Admin staff are free.
- Claims and eligibility checks pass through at cost. Card processing is Stripe's standard rate with no markup at launch.
- **Savings examples:**
  - SimplePractice Plus + Care Aide costs $158/mo ($1,896/yr). Hearth costs $468/yr, a **saving of about $1,428/yr**.
  - TherapyNotes Solo + TherapyFuel costs $109/mo. Hearth **saves about $840/yr**.
  - A 5-clinician group on SimplePractice Plus + Care Aide pays about $650/mo ($99 + 4×$74 + $59 + 4×$49). Hearth costs $155/mo, a **saving of about $5,900/yr**.

## Go-to-market (first 100 customers)
- **Reddit:** r/therapists and r/psychotherapy. Answer recurring "leaving SimplePractice" and "Headway rate cut" threads helpfully and disclose that we're the vendor.
- **Facebook groups:** Large private-practice therapist groups built around practice-building communities. Verify group names, sizes and rules before posting. Offer a free "Going Direct After Alma/Headway" webinar.
- **State associations:** CAMFT (California), NASW state chapters, state counseling associations (e.g., Texas Counseling Association), state psychological associations. Sponsor newsletters, offer member discounts, and pursue endorsed-vendor slots.
- **CE events:** ACA Conference & Expo, CAMFT annual conference, Psychotherapy Networker Symposium. Offer a free 1-hour CE-style webinar on the No Surprises Act GFE and superbills.
- **Partners:** Credentialing consultants, therapy billing services and private-practice coaches (20% recurring affiliate).
- **SEO:** "SimplePractice alternative", "SimplePractice price increase", "TherapyNotes vs SimplePractice", "leaving Headway/Alma", and "Aetna 90837 rate cut".

## Risks and incumbent moats
- **Crowded category:** Many low-cost EHRs already exist. We differentiate on all-in pricing (AI included), a stable UX, and the go-direct kit that creates the switching moment.
- **Lock-in:** Data export quality varies, and saved cards may not transfer, so clients have to re-enter cards through a one-link card-update flow. SimplePractice also has its own client directory as a demand-side moat.
- **Insurance billing depth:** Launch private-pay-first and add claims through a clearinghouse API.
- **HIPAA/BAA on a small-team budget:** Therapists who never bill insurance electronically may not technically be HIPAA covered entities, but the market expects HIPAA regardless. We act as a business associate:
  - We sign a BAA with every customer and get BAAs from every subprocessor that touches PHI.
  - **Infrastructure:** AWS with its self-serve BAA (AWS Artifact), using only HIPAA-eligible services (RDS/S3 with KMS encryption, SES, Transcribe/Bedrock for the AI scribe), or the GCP equivalent.
  - **SMS:** No PHI in texts ("You have an update, tap to view securely"), or use a vendor that signs a BAA (verify the tier).
  - **Payments:** Stripe, since HIPAA's payment-processing exemption generally covers pure payment transactions. Keep diagnosis and service detail out of Stripe metadata.
  - **Video:** A vendor that signs a BAA.
  - **Paperwork:** A free HHS SRA Tool risk assessment, written policies, MFA, audit logs, encryption, and a breach runbook. No official "HIPAA certification" exists.
  - **Cost estimate:** A few hundred dollars a month in infrastructure plus a few thousand dollars a year for a pen test and cyber insurance. Add SOC 2 only when groups ask.
  - HHS proposed a Security Rule update in Jan 2025 that would make MFA and encryption explicit. Its status was not verified in this pass, so build to it anyway.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 3 | 4 | 4 | **18** |

## Sources
- [SimplePractice pricing](https://www.simplepractice.com/pricing/) (fetched 2026-09-24)
- [TherapyNotes Pricing and Subscription Options (support article)](https://support.therapynotes.com/hc/en-us/articles/30661380110747-TherapyNotes-Pricing-and-Subscription-Options) (fetched 2026-09-24)
- [SimplePractice reviews, Capterra](https://capterra.com/p/130710/SimplePractice/reviews/)
- [SimplePractice Price Increase 2025, SteadyPractice (competitor blog)](https://www.steadypractice.app/blog/simplepractice-price-increase-2025-what-to-do.html)
- [Aetna Cuts Rates with Alma-Contracted Therapists, Behavioral Health Business (May 21, 2026)](https://bhbusiness.com/2026/05/21/aetna-cuts-rates-with-alma-contracted-therapists/)
- [2 digital mental health platforms cut pay rates for therapists with Optum, ClearHealthCosts (Nov 2024)](https://clearhealthcosts.com/blog/2024/11/2-digital-mental-health-platforms-cut-pay-rates-for-therapists-with-unitedhealths-optum-stirring-anger/)
- [UnitedHealth-Optum pay cut makes clinicians reassess platforms, ClearHealthCosts](https://clearhealthcosts.com/blog/2024/11/unitedhealth-optum-pay-cut-makes-clinicians-reassess-value-of-tech-mental-health-platforms/)
- [Headway and Alma Therapist Pay Cuts of Up to 30%, Mental Wealth Solutions](https://mentalwealthsolutions.org/blog/headway-alma-therapist-pay-cuts-marketplace-platforms)
