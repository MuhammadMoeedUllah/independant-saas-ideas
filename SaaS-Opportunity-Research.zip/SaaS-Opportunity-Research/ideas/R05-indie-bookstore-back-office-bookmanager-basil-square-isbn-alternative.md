# SpineDesk: a cheaper, better Basil / BookManager / "Square + ISBN workaround" for independent bookstores

**One-liner:** A bookseller back office that sits on top of the Square, Shopify or Clover POS a store already uses. Scan an ISBN to shelve a book, import distributor invoices, and run special orders, preorders, local-author consignment, ticketed events, book-club subscriptions, used-book buying and school/library invoices from one flat-priced app.

## Snapshot
- **Replaces:**
  - **Basil** (pricing page, fetched Sept 2026):
    - Standard: $250 setup, then **from $245/mo**, plus **1% of gross sales** for automated marketplace management.
    - Basil Lite: $70/machine/mo, plus $50/mo for online selling.
    - Basil + Square (inventory only, one machine): $30/mo plus 1% of sales.
    - ([Basil pricing](https://basilsoftware.com/pricing))
  - **BookManager:** **$6,000 one-time** software, **$1,330/yr** data, $500/yr webstore, **$400 per extra station**. Updates and support require the yearly subscription, and it is not cloud-based (FitSmallBusiness, July 6, 2026) ([FitSmallBusiness](https://fitsmallbusiness.com/bookstore-pos/)).
  - **Anthology:** no public pricing. A third party *estimates* $5k–$20k to implement and $79–$125/user/mo ([ITQlick](https://www.itqlick.com/visual-anthology)). Estimate, not vendor-confirmed.
  - **Booklog:** no public pricing. Says it has run for 40 years, serves 2,100+ bookstores, and works with Square, Clover, QuickBooks, IndieCommerce, Ingram, Edelweiss, PubNet and PubEasy ([Booklog](https://www.booklog.com/booklog_qb.html)).
  - **IBID/IBIDIE, WordStock, Prism, Ratex:** listed as bookseller POS vendors by the Midwest Independent Booksellers Association. Pricing not public and not verified this pass ([MIBA](https://www.midwestbooksellers.org/industry-resources-for-booksellers)).
  - **Square** (July 2026): Free / $49 Plus / $149 Premium, 2.6% + 15¢ in person ([FitSmallBusiness](https://fitsmallbusiness.com/bookstore-pos/)). Square does **not** fill in book data from an ISBN scan (Square Community, Mar 2025).
  - **Shopify POS:** Lite $5, Pro $89/location/mo. ISBN import needs a third-party app ([FitSmallBusiness](https://fitsmallbusiness.com/bookstore-pos/); [ISBNExpress](https://apps.shopify.com/isbn-express-book-importer)).
  - **book by book** (a Square add-on and a direct cheap competitor): **$29/mo or $299/yr**. It imports orders from Ingram, Edelweiss, PubEasy and CataList, fills in descriptions and covers, and supports used books. It lists no consignment or events features ([book by book](https://bookbybook.app/)). Bookflow is another Square add-on for bookshops ([Square Community](https://community.squareup.com/t5/Payments-Troubleshooting/Can-I-scan-ISBN-s-from-books-to-build-my-inventory/td-p/783261)).
  - **IndieCommerce (ABA's e-commerce platform):** $175/mo (IndieLite $50/mo), plus **1% of the store's own e-commerce sales, capped at $500/mo**. The 1% has applied since Aug 1, 2020 ([ABA mailing](https://www.bookweb.org/civicrm/mailing/view?id=4662&reset=1)).
  - **Bookshop.org:** free affiliate storefront. Stores get 30% of cover price on their own storefront sales, and it has sold ebooks since Jan 2025 ([Wikipedia](https://en.wikipedia.org/wiki/Bookshop_(company))).
  - **Edelweiss / Above the Treeline:** Edelweiss catalogs are free. Above the Treeline analytics has a monthly fee; ABA members get the setup fee waived and 10% off ([GLIBA](https://www.gliba.org/tools-of-the-trade.html)).
- **Recent price hikes / changes:**
  - **IndieCommerce 2.0 fee increase effective Jan 1, 2026.** Announced Nov 12, 2025 as the "first increase in monthly platform fees in over ten years." ABA said the 1% commission "no longer covers" hosting, PCI and anti-bot/CDN costs. The announcement gave no new dollar amounts ([IndieCommerce](https://indiecommerce.com/Pricing_Update)).
  - **QuickBooks POS support ended.** Booklog markets itself directly to displaced QuickBooks POS bookstores ([Booklog](https://www.booklog.com/booklog_qb.html)).
  - **New-store boom:**
    - 323 bookstore businesses opened in 2024: 247 storefronts, 55 pop-ups, 12 mobile, 9 online ([ABA 2024 Annual Report](https://www.bookweb.org/sites/default/files/diy/ABA-AnnualReport-2024-final.pdf)).
    - ABA reported **19% membership growth** and **600+ stores added in 2025**, many romance/romantasy (Jane Friedman, June 3, 2026) ([Jane Friedman](https://janefriedman.com/american-bookseller-association-reports-19-percent-membership-growth/)).
    - Every new store picks its software at opening.
- **Who buys:** owners and GMs of independent new and used bookstores, usually 1–3 locations. Includes romance-only shops, bookstore-bars and cafés, pop-ups and mobile shops. The owner decides and pays by card.
- **US market size:**
  - ABA had **2,844 member companies in 2024** (+18% YoY) ([ABA 2024 report](https://www.bookweb.org/sites/default/files/diy/ABA-AnnualReport-2024-final.pdf)).
  - Straight Arrow News (SAN) cites **3,218 independent bookstores in 2025**, a 70% rise since 2020 ([SAN](https://san.com/cc/beyond-the-page-behind-the-local-bookstore-boom-across-the-us/)).
  - *Estimate:* 3,500–4,500 US bookstores once used-only shops outside ABA are added.
  - Dollar pool *estimate*: about $4–10M ARR at $1,000–$2,500 per store per year. This is a small, focused niche.
- **Urgency trigger (why they'd switch NOW):**
  - The IndieCommerce fee increase took effect Jan 1, 2026.
  - 600+ new stores in 2025 are choosing systems now.
  - The holiday preorder and special-order crunch runs Oct–Dec.
  - The ABA Winter Institute (Feb) is when budgets get set.
- **Fastest-selling states/metros:**
  - **Texas:** 21 new stores in 2024, and 13 of the first 100 new stores in 2025 ([SAN](https://san.com/cc/beyond-the-page-behind-the-local-bookstore-boom-across-the-us/)).
  - **Romance-specialty stores nationwide:** 157 romance-specific ABA members, 43 of them opened in the prior 18 months ([SAN](https://san.com/cc/beyond-the-page-behind-the-local-bookstore-boom-across-the-us/)).
  - Beyond that: dense indie metros (Brooklyn, Portland, Minneapolis–St. Paul, Denver/Boulder, Bay Area, Asheville) — *estimate*.

## Pain points (evidence)
- **[Missing features]** A children's second-hand bookshop owner (Mar 13, 2025) asked whether Square could scan an ISBN and fill in book details. The answer was no. The options were manual setup or a third-party add-on ([Square Community](https://community.squareup.com/t5/Payments-Troubleshooting/Can-I-scan-ISBN-s-from-books-to-build-my-inventory/td-p/783261)).
- **[Complexity/UX]** The Violet Fox Bookshop told Square's product manager that staff enter "every single book that walks in the door" by hand, thousands of them. ISBN lookup would be a "huge game changer." Square offered a GTIN field and spreadsheet import, with no timeline (Sept 3, 2021) ([Square Community](https://community.squareup.com/t5/Event-Discussions/Square-Inventory-amp-Item-Management-Ask-our-Product-Manager/m-p/300614)).
- **[Price]** BookManager costs $6,000 upfront, $1,330/yr for data and $400 per extra station. The review lists a "steep price point" and no cloud version as cons (July 2026) ([FitSmallBusiness](https://fitsmallbusiness.com/bookstore-pos/)).
- **[Price]** Basil is rated "expensive; high setup fee," with no low-stock alerts and no offline mode (July 2026) ([FitSmallBusiness](https://fitsmallbusiness.com/bookstore-pos/)). On top of the monthly fee it takes 1% of gross sales for marketplace management ([Basil](https://basilsoftware.com/pricing)).
- **[Support]** Basil users describe the system as "broken and bug riddled," say their emails were "ignored every single time," and report that inventory cannot go negative, which breaks reconciliation. These reviews are *older (2017–2019)*; a Nov 2023 review was positive ([WebRetailer](https://www.webretailer.com/reviews/basil-bookseller-software/)).
- **[Price/Lock-in]** IndieCommerce is raising monthly platform fees from Jan 2026 on top of its 1% commission. Stores had no dollar figures at announcement time (Nov 12, 2025) ([IndieCommerce](https://indiecommerce.com/Pricing_Update)).
- **[Price opacity]** Anthology publishes no pricing, and third-party reviewers flag "lack of transparent pricing" and high customization and implementation costs ([ITQlick](https://www.itqlick.com/visual-anthology)).
- **[Missing features]** A brick-and-mortar Shopify POS user (June 5, 2025) said inventory management "was a challenge without a robust, 3rd party application." Another (Jan 24, 2026) said add-ons and upgrades "feel expensive, especially for small businesses" ([Capterra](https://www.capterra.com/p/205337/Shopify-POS/reviews/?page=2)).
- **[Reliability]** A Shopify POS user (June 17, 2025): receipt printer and barcode scanners "disconnect daily" ([Capterra](https://www.capterra.com/p/205337/Shopify-POS/reviews/?page=2)).
- **[Complexity/UX]** A bookshop using a Shopify ISBN importer (edited Jan 11, 2026) complained that cost and quantity have to be entered item by item. They asked for spreadsheet-style bulk editing ([Shopify App Store](https://apps.shopify.com/isbn-express-book-importer/reviews)).
- **[Economics]** A new Texas bookstore-bar owner needs to sell about 1,389 books a month to hit targets and averaged 500 in her first five months. Owners say indies "have had to diversify with coffee shops, bars, gift items, workshops," which multiplies systems ([SAN](https://san.com/cc/beyond-the-page-behind-the-local-bookstore-boom-across-the-us/)).
- **[Lock-in]** On general retail POS, a Lightspeed retailer got a $930 invoice for declining Lightspeed's card processing (see D09) ([Capterra](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)).

## What we build (the better version)
1. **MVP: Scan-to-shelf.** Phone camera or USB scanner reads the ISBN and fills in title, author, cover, list price, BISAC category and format, then pushes the item to the Square, Shopify or Clover catalog. Used-book mode adds condition, a suggested price and a "last copy" flag.
2. **MVP: Distributor invoice and PO import.** Upload Ingram, Edelweiss, PubEasy or publisher order and invoice files to receive stock, record cost and COGS, and split new titles from replenishment. It matches book by book's core feature, and staff never retype a book.
3. **MVP: Special orders and preorders.**
   - Take the order at the counter or online, with an optional deposit.
   - Automatic text or email when the book arrives.
   - Aging report and "unclaimed after 14 days" nudges.
   - Frontlist preorder campaigns with a signed-copy option.
4. **MVP: Events and ticketing.**
   - Ticket plus book bundles, where the ticket includes the book, and signed-preorder lists for customers who can't attend.
   - QR check-in and per-event sales reports for publisher co-op recaps.
   - Paid through the store's own Stripe or Square, with no per-ticket fee from us.
5. **MVP: Local-author consignment.**
   - Online intake and application form with an e-signed agreement and any intake fee.
   - Per-author stock tracking, automated quarterly sales statements and payouts.
   - End-of-term pickup reminders.
   - Today stores run this on paper or spreadsheets.
6. **MVP: Book clubs and subscription boxes.** Recurring monthly "staff pick" or genre subscriptions, pick lists, shipping labels, and pickup lists for in-store club members with a discount.
7. **MVP: Used-book buying desk.** Scan a customer's books to see a cash or trade-credit offer from the store's own rules. Includes a store-credit ledger tied to the customer.
8. **V2: School and library B2B.** Quotes, POs, tax-exempt certificate storage, net-30 invoices, bulk ISBN list import for classroom sets, and book-fair consignment (pairs with R04 OpenBookFair). Includes the Texas SB 13 need for school buyers to publish proposed purchase lists (see R07).
9. **V2: Online storefront** with preorder, pickup and Bookshop.org / IndieCommerce link-out, for stores leaving IndieCommerce over the fee increase.
10. **V2: AI buyer assistant.** Reorder suggestions from sales velocity, "you sold 3, 0 on hand" alerts, a drafted weekly "new arrivals" newsletter, and staff-pick shelf-talker printing.
11. **V2: Stand-alone POS mode.** Processor-agnostic, for stores leaving BookManager or Basil entirely, with multi-location transfers.

## Pricing to win
- **Starter $39/mo:** 1 location, scan-to-shelf, invoice import, special orders, sync to one POS.
- **Pro $79/mo:** adds events and ticketing, consignment, subscriptions, used-book desk and B2B invoices.
- No setup fee, no % of sales, month-to-month. We import the existing catalog and customer list free.
- **Savings vs Basil Standard:** $250 + ($245 × 12) = $3,190 in year one, *plus* 1% of gross sales (about $5k/yr on $500k revenue, if the 1% applies to all sales rather than only marketplace sales; the pricing page is ambiguous). SpineDesk Pro costs $948/yr, so an estimated **$2.2k–$7k/yr** saved.
- **Savings vs BookManager:** $6,000 upfront plus $1,830/yr, against $948/yr.
- **vs book by book ($29/mo):** we cost $10–$50 more but cover special orders, consignment, events, subscriptions and B2B, which it does not advertise.

## Go-to-market (first 100 customers)
- **Regional bookseller association fall shows** (exhibit or sponsor), then the **ABA Winter Institute** (Feb):
  - NAIBA, SIBA, MPIBA, PNBA, NCIBA/SCIBA (the California associations), GLIBA, NEIBA, MIBA.
  - Get onto the associations' "industry resources" vendor lists; MIBA already lists POS vendors ([MIBA](https://www.midwestbooksellers.org/industry-resources-for-booksellers)).
- **New-store pipeline:** partner with bookstore-opening trainers and consultants, and with ABA's new-member onboarding. Offer "open your store on SpineDesk + Square" bundles for the 600+/yr new openings.
- **Romance-bookstore owners** (157 ABA members): event and preorder features for signing events and special editions.
- **Marketplaces:** Square App Marketplace and Shopify App Store listings, with SEO pages such as "ISBN lookup for Square," "BookManager alternative," "Basil alternative" and "consignment for local authors."
- **Cold list:** public ABA store finder and regional member directories. Lead with a free "consignment program in a box": local authors apply through the store's SpineDesk form, which spreads the product from store to store.
- **Communities:** r/bookstores and r/booksellers (read-only research; Reddit could not be fetched this pass), Bookstagram, and ABA's Bookselling This Week advertising.

## Risks and incumbent moats
- **Tiny market.** About 3.5–4.5k stores caps this near a few million in ARR (*estimate*). Mitigation: expand to comic and game shops, museum and gift shops that sell books, and Canada/UK indies.
- **Book metadata licensing.** Covers, descriptions and prices come from licensed feeds such as Bowker, Ingram iPage, Edelweiss and BookNet. Mitigation: start from the distributor files stores already receive, plus Open Library and commercial ISBN APIs, used within their terms.
- **EDI/ordering integrations.** PubNet/PubEasy EDI and Ingram ordering are long-standing moats for BookManager, IBID and Booklog. MVP imports files instead of sending EDI; V2 pursues certification.
- **Payments dependency.** Staying on Square, Shopify or Clover keeps us out of PCI scope and avoids asking stores to change processors.
- **Cheap direct competitors.** book by book ($29/mo) and Bookflow already fix the ISBN problem on Square. We differentiate on special orders, consignment, events, subscriptions and B2B.
- **Relationship loyalty.** Long-time BookManager and IBID stores stick with vendors they know. We target new stores and stores in a switching moment (IndieCommerce fee increase, QuickBooks POS shutdown).

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 3 | 4 | 2 | **15** |

## Sources
- [Basil Bookseller Software pricing](https://basilsoftware.com/pricing)
- [FitSmallBusiness: 6 Best Bookstore POS Systems for 2026 (July 6, 2026)](https://fitsmallbusiness.com/bookstore-pos/)
- [ITQlick: Anthology POS review](https://www.itqlick.com/visual-anthology)
- [Booklog POS for independent bookstores](https://www.booklog.com/booklog_qb.html)
- [MIBA: Industry resources for booksellers](https://www.midwestbooksellers.org/industry-resources-for-booksellers)
- [GLIBA: Tools of the Trade](https://www.gliba.org/tools-of-the-trade.html)
- [IndieCommerce pricing update (Nov 12, 2025)](https://indiecommerce.com/Pricing_Update)
- [ABA: IndieCommerce and IndieLite fee changes (2020)](https://www.bookweb.org/civicrm/mailing/view?id=4662&reset=1)
- [ABA 2024 Annual Report](https://www.bookweb.org/sites/default/files/diy/ABA-AnnualReport-2024-final.pdf)
- [Jane Friedman: ABA reports 19% membership growth (June 3, 2026)](https://janefriedman.com/american-bookseller-association-reports-19-percent-membership-growth/)
- [SAN: Behind the local bookstore boom](https://san.com/cc/beyond-the-page-behind-the-local-bookstore-boom-across-the-us/)
- [Square Community: Can I scan ISBNs to build my inventory? (Mar 2025)](https://community.squareup.com/t5/Payments-Troubleshooting/Can-I-scan-ISBN-s-from-books-to-build-my-inventory/td-p/783261)
- [Square Community: Inventory & Item Management PM Q&A (Sept 2021)](https://community.squareup.com/t5/Event-Discussions/Square-Inventory-amp-Item-Management-Ask-our-Product-Manager/m-p/300614)
- [Square Community: Upload inventory by ISBN barcode](https://community.squareup.com/t5/Square-for-Retail/Can-I-upload-my-inventory-through-barcodes-book-ISBN-for-example/m-p/248712)
- [book by book: the bookstore app Square never built](https://bookbybook.app/)
- [ISBNExpress Shopify app reviews](https://apps.shopify.com/isbn-express-book-importer/reviews)
- [Capterra: Shopify POS reviews p.2](https://www.capterra.com/p/205337/Shopify-POS/reviews/?page=2)
- [Capterra: Lightspeed Retail reviews](https://www.capterra.com/p/120491/Lightspeed-Retail/reviews/)
- [WebRetailer: Basil reviews](https://www.webretailer.com/reviews/basil-bookseller-software/)
- [Wikipedia: Bookshop (company)](https://en.wikipedia.org/wiki/Bookshop_(company))
