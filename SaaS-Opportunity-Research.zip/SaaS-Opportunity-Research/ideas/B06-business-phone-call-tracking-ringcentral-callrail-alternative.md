# RingFlat: a cheaper, better RingCentral / CallRail for local businesses

**One-liner:** A month-to-month business phone system with call tracking built in. Flat per-location pricing, free number port-out, and AI call summaries, with no annual contract or early-termination fee.

## Snapshot
- **Replaces:**
  - **CallRail**, Aug 8, 2026 ([Call Tracker](https://calltracker.io/blog/2026-08-08-callrail-pricing/)):
    - Lead Tracking $50/mo, Lead Tracking Complete $95/mo, Lead Conversion $150/mo, Lead Conversion Complete $195/mo.
    - **Every** tier includes only 5 local numbers, 250 local minutes and 25 texts.
    - Overages: $3/extra number, $0.05/minute, toll-free $5/number and $0.08/minute, $0.03/text.
  - **Quo (formerly OpenPhone)**, 2025–2026, per user per month ([CallRail blog](https://www.callrail.com/blog/quo-review)):
    - Starter $19 monthly / $15 annual. Business $33 / $23. Scale $47 / $35.
    - Extra numbers $5/mo. AI credits from $25/mo (4,000) to $199/mo (60,000).
  - **RingCentral:** per-user annual contracts. 2026 list prices **not verified this pass**.
  - **GoHighLevel phone:** 5% markup on all phone charges ([Apexure](https://www.apexure.com/blog/gohighlevel-pricing)).
  - Grasshopper and Dialpad: **not verified this pass**.
- **Recent price hikes / changes:**
  - OpenPhone rebranded as Quo and added metered AI credits ([CallRail blog](https://www.callrail.com/blog/quo-review)). The rebrand date was not confirmed.
  - CallRail's tiers add features but not usage: "climbing the tiers buys you features, not more usage" ([Call Tracker](https://calltracker.io/blog/2026-08-08-callrail-pricing/)).
  - RingCentral has 541 BBB complaints in 3 years (137 closed in the last 12 months), many in Jul–Aug 2026 about contracts and post-cancellation billing ([BBB](https://www.bbb.org/us/ca/belmont/profile/telecommunications/ringcentral-inc-1116-65952/complaints)).
- **Who buys:** Owner-operators and office managers at 1–25 person local businesses (home services, clinics, law firms, agencies, real estate). Marketing agencies buy call tracking for clients.
- **US market size:** Estimate, not verified this pass. Nearly every SMB needs a business line. Serviceable market for cloud phone plus call tracking: 1M+ US businesses at $20–$300/mo.
- **Urgency trigger (why they'd switch NOW):**
  - RingCentral contract anniversaries and post-cancellation billing disputes (a cluster of BBB complaints in Jul–Aug 2026).
  - CallRail overages as ad campaigns add tracking numbers.
  - Business closures and downsizing, where RingCentral contracts keep billing.
- **Fastest-selling states/metros:** California. The state's automatic-renewal law and its enforcement are relevant (background knowledge; verify in the per-state pass, including a CA Assembly consumer-protection committee document that surfaced in search, [apcp.assembly.ca.gov](https://apcp.assembly.ca.gov/media/889)). Otherwise national. Home-service-heavy Sun Belt metros for call tracking (estimate).

## Pain points (evidence)
- **[Lock-in/Contracts]** A customer said a sales rep promised a 30-day trial and the option to reduce licenses, but they ended up locked into a 12-month, 12-license contract with $3,400+ termination exposure (Aug 15, 2026) ([BBB](https://www.bbb.org/us/ca/belmont/profile/telecommunications/ringcentral-inc-1116-65952/complaints)).
- **[Lock-in]** A business that closed says RingCentral refused to change the contract and kept charging monthly (Jul 29, 2026) ([BBB](https://www.bbb.org/us/ca/belmont/profile/telecommunications/ringcentral-inc-1116-65952/complaints)).
- **[Billing]** RingCentral approved a cancellation with credits back to Feb 2026 but kept billing. The customer demanded $13,120.15 in credits after six months of promises (Jul 29, 2026) ([BBB](https://www.bbb.org/us/ca/belmont/profile/telecommunications/ringcentral-inc-1116-65952/complaints)).
- **[Billing]** After a Mar 29, 2026 termination, a customer was charged for four more months, including through an automatic card-updater on a replacement card (Jul 16, 2026) ([BBB](https://www.bbb.org/us/ca/belmont/profile/telecommunications/ringcentral-inc-1116-65952/complaints)).
- **[Billing]** A customer who cancelled on Mar 20, 2026, before renewal, was charged $337.45 anyway (Jul 15, 2026) ([BBB](https://www.bbb.org/us/ca/belmont/profile/telecommunications/ringcentral-inc-1116-65952/complaints)).
- **[Support/Porting]** A customer's service was interrupted for days while they tried to port the number away. They waited over an hour for a supervisor (Jul 27, 2026) ([BBB](https://www.bbb.org/us/ca/belmont/profile/telecommunications/ringcentral-inc-1116-65952/complaints)).
- **[Price]** CallRail's higher tiers add no numbers or minutes. Extra tracking numbers ($3 each) and minutes drive cost as campaigns grow ([Call Tracker, Aug 2026](https://calltracker.io/blog/2026-08-08-callrail-pricing/)).
- **[Price]** Quo's per-user costs "increase significantly as teams scale," and its AI is sold as separate credit packs ([CallRail blog](https://www.callrail.com/blog/quo-review)).
- **[Support]** Quo's support response times are inconsistent at peak hours, and call quality suffers in weak-signal areas ([CallRail blog](https://www.callrail.com/blog/quo-review)).
- **[Hidden fees]** GoHighLevel adds a 5% markup to phone charges, disclosed in help docs rather than on the pricing page ([Apexure](https://www.apexure.com/blog/gohighlevel-pricing)).

## What we build (the better version)
1. **MVP:** Local and toll-free numbers, port-in help, and **guaranteed free port-out**. Mobile, desktop and web apps via WebRTC on a CPaaS (Telnyx or Twilio class).
2. **MVP:** Call routing: business hours, ring groups, voicemail-to-text, and missed-call text-back.
3. **MVP:** Built-in call tracking. Dynamic number insertion on the website, plus per-campaign numbers (Google Ads, Google Business Profile, Yelp, truck wrap, mailers). No separate CallRail bill.
4. **MVP:** AI call summaries and tags on every call ("new lead, water heater, wants quote Thursday"), with lead or not-lead scoring and a missed-opportunity report.
5. **MVP:** Shared SMS inbox for the team, with 10DLC registration handled for the customer.
6. **MVP:** A plain billing page with no annual contract, cancel in-app, and a usage meter with alerts.
7. **V2:** An AI receptionist for after-hours and overflow that books appointments into Google or Outlook calendars.
8. **V2:** Google Ads and GA4 conversion upload from calls. HubSpot, Jobber and our B02/B04 CRM sync.
9. **V2:** Call recording with state-aware consent announcements (two-party consent states).
10. **V2:** Agency sub-accounts for call tracking resale, where the client owns the numbers.

## Pricing to win
- **Plans:** Essentials $25/mo per location (3 users, 3 numbers, 1,000 minutes, 500 texts). Growth $59/mo (10 users, 10 tracking numbers, 3,000 minutes, AI summaries). Extra usage at cost + 15%.
- **Terms:** Month-to-month.
- **Example (estimate, from the Aug 2026 CallRail rates):** A home-service business on CallRail Lead Conversion ($150/mo) with 10 tracking numbers (+$15) and 600 minutes (+$17.50) pays about $182/mo for tracking alone, plus a separate phone system. RingFlat Growth covers both for $59/mo, saving about **$1,480+/yr** before the phone bill.

## Go-to-market (first 100 customers)
- **Reddit:** r/smallbusiness, r/VOIP, r/sysadmin (the small-office crowd), r/PPC, r/HVAC, r/Plumbing, r/LawFirm.
- **Facebook groups:** PPC and local-agency groups (for call tracking), law-firm marketing groups, home-service owner groups.
- **"Switch from X" SEO pages:**
  - "RingCentral early termination fee"
  - "Cancel RingCentral contract business closed"
  - "Port number out of RingCentral"
  - "CallRail overage charges"
  - "CallRail alternative flat price"
  - "Quo AI credits cost"
- **Partners:**
  - PPC freelancers and local agencies (call tracking is a must-have for proving ROI).
  - IT managed-service providers for small offices.
- **Bundle:** Sell as the phone layer of FirstCall (B04). Cross-sell to its users.

## Risks and incumbent moats
- **Telecom complexity:** E911, CNAM, porting, STIR/SHAKEN, 10DLC, call quality and uptime. Mitigation: build entirely on a mature CPaaS and keep scope to SMB features.
- **Reliability expectations:** Phones are mission-critical. Mitigation: status page, carrier redundancy (V2), and 24/7 support for outages only.
- **Low-price competitors:** Quo, Google Voice and Grasshopper already exist. Mitigation: win on bundled call tracking plus AI plus no contracts, not on bare seat price.
- **Recording consent laws:** State two-party consent rules apply. Mitigation: automatic announcement by caller and callee state.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 2 | 4 | 5 | **18** |

## Sources
- [RingCentral, Inc. BBB complaints](https://www.bbb.org/us/ca/belmont/profile/telecommunications/ringcentral-inc-1116-65952/complaints)
- [CallRail Pricing in 2026: Plans, Overages, and What You Actually Pay (Call Tracker, Aug 8, 2026)](https://calltracker.io/blog/2026-08-08-callrail-pricing/)
- [Quo (formerly OpenPhone) Review: Pros, Cons, and Pricing (CallRail)](https://www.callrail.com/blog/quo-review)
- [GoHighLevel Pricing in 2026 (Apexure)](https://www.apexure.com/blog/gohighlevel-pricing)
