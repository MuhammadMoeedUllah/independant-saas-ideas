# Harbor: a self-hostable wiki + issue tracker for regulated SMBs leaving Jira / Confluence Data Center

**One-liner:** A single-binary (or Docker/VM appliance) wiki and tracker that runs air-gapped or on-prem. It has a **high-fidelity Jira and Confluence importer**, a flat per-server license, and a local AI assistant that never leaves the network.

## Snapshot
- **Replaces:**
  - **Jira Software / Confluence / Jira Service Management Data Center.** List prices were not captured in this pass, and Atlassian sells DC in user tiers through partners.
    - **About 15% DC price increase effective Feb 17, 2026** (ONES, Jun 17, 2026; partner notices from OnPoint and Corptec).
    - **No new DC licenses for new customers after Mar 30, 2026.**
  - **Atlassian Cloud:**
    - Standard **+5%**, Premium **+7.5%**, Enterprise **+7.5–10%**, all effective **Oct 15, 2025** (Atlassian FY26 Cloud Pricing Notice).
    - Government Cloud (FedRAMP) +7.5–10%. Bitbucket +10%.
  - **Existing alternatives:** open-source tools (OpenProject, Redmine, XWiki, BookStack, Wiki.js, GitLab issues, Gitea/Forgejo), commercial self-hosted tools (YouTrack, ONES), and Microsoft SharePoint and Planner.
- **Recent price hikes / changes (the switching window):**
  - **Sept 2025:** Atlassian announced Data Center end-of-life (The Register, Sept 9, 2025).
  - **Dec 2025:** no new DC Marketplace apps (The Jira Guy, Sept 8, 2025).
  - **Feb 17, 2026:** about 15% DC price increase.
  - **Mar 30, 2026:** end of new DC subscriptions.
  - **Mar 30, 2028:** last renewals and user-tier expansions.
  - **Mar 28, 2029:** DC becomes **read-only**.
- **Who buys:** IT and engineering managers at **50–1,000-person organizations** that cannot or will not go to Atlassian Cloud:
  - defense contractors in air-gapped labs;
  - state and local government;
  - healthcare, finance and legal teams with data-residency rules;
  - manufacturers with OT and isolated networks;
  - customers contractually barred from cloud.
  This is **not** a card-swipe buyer. Expect IT approval plus security review, but still far faster than enterprise RFPs for sub-500-seat deals.
- **US market size:** Atlassian does not publish DC customer counts. The regulated or on-prem-bound, sub-1,000-user slice is likely in the **low thousands of US organizations** (estimate). Deal sizes are larger ($5k–50k/yr, estimate), so the dollar pool is meaningful but the count is small.
- **Urgency trigger (why they'd switch NOW):** a fixed countdown. Renewals end in Mar 2028 and the product is read-only on **Mar 28, 2029**. Every DC renewal from now on is a decision point, and 2026–27 budgets are being set now.
- **Fastest-selling states/metros:** defense and aerospace clusters (NoVA/DC/MD, Huntsville AL, San Diego, Colorado Springs, Dayton OH, the Dallas–Fort Worth area), state capitals, and healthcare and finance hubs (Boston, Charlotte, Minneapolis).

## Pain points (evidence)
- **[Lock-in/Contracts]** A customer says deep integrations with legacy systems make cloud migration impossible, and they will leave Atlassian entirely if forced (The Register, Sept 9, 2025) ([source](https://www.theregister.com/2025/09/09/atlassian_will_go_cloudonly_customers/))
- **[Price]** An independent consultant estimates typical DC-to-Cloud moves cost about **28% more**, contradicting Atlassian's savings claims (The Register, Sept 9, 2025) ([source](https://www.theregister.com/2025/09/09/atlassian_will_go_cloudonly_customers/))
- **[Price]** Reaching feature parity usually means Cloud Premium, which drives the roughly 28% increase for most migrating organizations (The Jira Guy, Sept 8, 2025) ([source](https://thejiraguy.com/2025/09/08/so-long-data-center/))
- **[Missing features]** A commenter runs 10+ DC instances and 20+ **air-gapped lab environments** under government contracts that can't move to any cloud, FedRAMP or not (The Jira Guy, Sept 8, 2025) ([source](https://thejiraguy.com/2025/09/08/so-long-data-center/))
- **[Lock-in/Contracts]** Some organizations are **contractually prohibited** from cloud migration (The Jira Guy, Sept 8, 2025) ([source](https://thejiraguy.com/2025/09/08/so-long-data-center/))
- **[Missing features]** Government users needing FedRAMP face incomplete support, and customers must negotiate unspecified "unique circumstances" exemptions (The Register, Sept 9, 2025) ([source](https://www.theregister.com/2025/09/09/atlassian_will_go_cloudonly_customers/))
- **[Complexity/UX]** Admins are frustrated by an abrupt EOL for people who had only just migrated from Server to DC (The Register, Sept 9, 2025) ([source](https://www.theregister.com/2025/09/09/atlassian_will_go_cloudonly_customers/))
- **[Missing features]** Business-critical Marketplace apps lack cloud parity, and a commenter says cloud pricing "doesn't feel profitable" once re-platforming effort is counted (Atlassian Community, 2026) ([source](https://community.atlassian.com/forums/App-Central-articles/What-happens-to-your-Jira-amp-Confluence-after-2029-and-are-you/ba-p/3200945))
- **[Price]** DC prices rose about 15% on Feb 17, 2026, even as the product heads to end-of-life (ONES, Jun 17, 2026) ([source](https://ones.com/blog/atlassian-data-center-pricing-increase-2026/))
- **[Support]** After Mar 28, 2029, workflows freeze and security patches stop, which is an unacceptable risk for regulated environments (Atlassian Community, 2026) ([source](https://community.atlassian.com/forums/App-Central-articles/What-happens-to-your-Jira-amp-Confluence-after-2029-and-are-you/ba-p/3200945))

**Honest read:** the pain is severe and dated, but this is **not a fast card-swipe SMB sale**, and fidelity demands are high: Jira workflows, custom fields, JQL, Confluence macros and permissions. Big incumbents (GitLab, YouTrack, OpenProject) and consultancies will fight for these migrations. The sharp wedge is **"read-only archive + lightweight live replacement"** for smaller DC shops, sold with migration services.

## What we build (the better version)
1. **Confluence archive-and-edit.** Import a Confluence space export (XML/HTML) into Markdown pages with attachments, page tree, labels, comments, and **the most common macros rendered** (code, info panels, tables, page includes, TOC). Unsupported macros are flagged in a report. **MVP**
2. **Jira project import.** Issues, statuses, custom fields (text, select, user, date, number), comments, attachments, links, sprints and history, taken from a Jira XML/CSV export or the DC REST API. **MVP** (core fields and comments). **V2** (workflow conditions and validators mapped to simple rules)
3. **Tracker:** kanban and list views, a simple workflow editor, a JQL-like filter language (a subset, with AI "write my query"), saved filters and dashboards. **MVP**
4. **Permissions and audit:** LDAP/AD and SAML/OIDC, space and project permissions, a full audit log, and retention policies. **MVP** (LDAP/OIDC, audit). **V2** (SAML, SCIM)
5. **Air-gapped deployment:** a single Docker image or OVA, offline license file, offline update bundles, PostgreSQL, and no telemetry. **MVP**
6. **Link redirector.** Old `/browse/ABC-123` and `/display/SPACE/Page` URLs redirect to the new locations, so bookmarks and links in code keep working. **MVP**
7. **Local AI assistant:** search and Q&A across wiki and issues using a locally hosted open-weights model (optional GPU), with nothing leaving the network. **V2**
8. **Service-desk lite:** an email-to-ticket portal to replace simple JSM use cases. **V2**
9. **Compliance pack:** mappings to NIST 800-171 and CMMC control families for the tool itself, plus a hardening guide. **V2** (verify current CMMC rollout dates before marketing)

## Pricing to win
| Plan | Harbor | Context |
|---|---|---|
| Archive **$1,500/yr per server** | Read-only Confluence and Jira archive with search and link redirects, unlimited users | For shops that just need history after Mar 2029 |
| Team **$6,000/yr per server** | Full wiki + tracker, up to 250 users | DC renewals rose ~15% in Feb 2026; Cloud Premium is ~28% more than DC for many (estimates) |
| Org **$15,000/yr per server** | Up to 1,000 users, SAML/SCIM, priority support | Versus multi-product DC renewals |
| Migration service | Fixed fee $5k–25k (estimate), depending on spaces, projects and apps | Sold directly or through Atlassian-alumni consultants |

Flat per-server pricing with unlimited users in tier, perpetual archive rights, and no forced cloud.

## Go-to-market (first 100 customers)
- **Communities:** r/jira, r/atlassian, r/sysadmin, r/devops, Atlassian Community Data Center forums, The Jira Guy readership, and Atlassian User Groups (ACE) in defense-heavy metros.
- **"Switch from X" SEO:**
  - "Confluence Data Center end of life alternative"
  - "Jira self-hosted alternative air-gapped"
  - "Confluence archive read-only 2029"
  - "Jira Data Center 2029 read only what to do"
- **Channels:** former Atlassian Solution Partners and independent Jira admins as a paid migration channel (30% of the first-year license). Defense-contractor MSPs and CMMC consultants. GovCon events (AFCEA chapters).
- **Offer:** a free "DC exit assessment": upload a Confluence and Jira export summary and get a fidelity report plus a quote.

## Risks and incumbent moats
- **Import fidelity** for workflows, macros and apps like ScriptRunner and Tempo. Answer: be honest in the fidelity report, archive what can't be converted, and prioritize the 20 most common macros and field types.
- **Buyer security reviews.** Answer: an SBOM, signed images, a hardening guide, a pen-test report, and later SOC 2 (company level).
- **Open-source "free" alternatives.** Answer: the migration tooling, link redirects and support contract are what they pay for.
- **Atlassian concessions** (exemptions, extended DC for "unique circumstances"). Answer: target sub-1,000-user shops, which are the least likely to get exemptions.
- **Slow sales cycle** (weeks to months). Answer: sell the Archive tier first. It's a low-risk purchase that seeds the upgrade.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 2 | 2 | 2 | **13** |

## Sources
- [Atlassian Data Center EOL: Timeline, 2026 New Pricing – ONES](https://ones.com/blog/atlassian-data-center-pricing-increase-2026/) (Jun 17, 2026; vendor source)
- [Atlassian's move to cloud-only means customers face integration issues and more – The Register](https://www.theregister.com/2025/09/09/atlassian_will_go_cloudonly_customers/) (Sept 9, 2025)
- [So Long, Data Center – The Jira Guy](https://thejiraguy.com/2025/09/08/so-long-data-center/) (Sept 8, 2025)
- [What happens to your Jira & Confluence after 2029 – Atlassian Community](https://community.atlassian.com/forums/App-Central-articles/What-happens-to-your-Jira-amp-Confluence-after-2029-and-are-you/ba-p/3200945) (2026)
- [Atlassian Fiscal 2026 Cloud Pricing Notice (PDF)](https://s206.q4cdn.com/270053503/files/doc_downloads/2025/09/Fiscal-2026-Cloud-Pricing-notice.pdf) (effective Oct 15, 2025)
- [Atlassian Data Center price changes effective February 2026 – OnPoint](https://www.onpointserv.com/post/atlassian-data-center-price-changes-effective-february-2026-what-you-need-to-know) (partner notice; headline only)
