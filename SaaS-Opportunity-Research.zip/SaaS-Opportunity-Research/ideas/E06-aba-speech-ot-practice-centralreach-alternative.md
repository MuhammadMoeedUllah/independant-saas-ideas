# SkillTrack: a cheaper, simpler CentralReach for small ABA agencies (and private speech/OT practices)

**One-liner:** An offline-first session app for RBTs and therapists (trial data, auto-graphs, AI session notes) with authorization-unit tracking, supervision compliance, and claims-ready billing. Priced per active client with unlimited staff and no auto-renew traps.

## Snapshot
- **Replaces:**
  - **CentralReach:** quote-based, per-user or per-therapist pricing, not published on Capterra. CentralReach also sells a small-practice product ("CR Essentials") that appears in Capterra comparisons.
  - **Rethink, Motivity, TheraNest** (TheraNest is used by counseling and SLP/OT practices): pricing not verified in this pass.
- **Recent price hikes / changes:**
  - A practice manager reports that CentralReach **auto-renewed an annual contract a month early without notice and refused a refund despite 45+ days' cancellation notice** (Capterra, Aug 2024).
  - Reviewers cite add-on pricing with no bundle discounts (May 2024) and costs per therapist that add up when each client has two therapists (Feb 2025).
  - Payer-side pressure on ABA (Medicaid rate changes and HHS-OIG audits of state ABA Medicaid payments) is a known theme. Specifics were **not verified in this pass** and are flagged for the per-state pass.
- **Who buys:** Owner-BCBAs of small ABA agencies (1–5 BCBAs, 5–40 RBTs) and owners of private pediatric SLP/OT practices. The owner or clinical director signs.
- **US market size:** Our estimate is several thousand small ABA agencies plus tens of thousands of private SLP/OT practitioners (not verified in this pass; use BACB certificant counts and ASHA/AOTA private-practice data in the next pass).
- **Urgency trigger (why they'd switch NOW):** Annual renewals (including the early auto-renew risk), per-user cost growth as agencies hire RBTs, and payer audits that punish weak session documentation.
- **Fastest-selling states/metros:** Estimate: states with large ABA Medicaid and commercial-mandate markets and many small agencies (CA, TX, FL, NJ, NY, MA, IL, NC, GA). Verify in the per-state pass.

## Pain points (evidence)
- **[Price]** An RBT says CentralReach's per-therapist cost adds up quickly when each client has two therapists (Capterra, Feb 2025) ([Capterra](https://capterra.com/p/140743/CentralReach/reviews/)).
- **[Lock-in/Contracts]** The annual contract auto-renewed a month early without notice, and the refund was refused despite 45+ days' notice (Capterra, Aug 2024) ([Capterra](https://capterra.com/p/140743/CentralReach/reviews/)).
- **[Price]** A CEO says added functionality costs more with no bundling discounts (Capterra, May 2024) ([Capterra](https://capterra.com/p/140743/CentralReach/reviews/)).
- **[Lock-in]** Leaving means a 4-step process to download each patient's records one at a time (Capterra, Aug 2024) ([Capterra](https://capterra.com/p/140743/CentralReach/reviews/)).
- **[Complexity/UX]** A BCBA says setting up data collection takes a huge amount of effort compared with competitors and the procedures feel disjointed (Capterra, Nov 2021) ([Capterra](https://capterra.com/p/140743/CentralReach/reviews/)).
- **[Complexity/UX]** RBTs report frequent forced re-logins during sessions and slow performance on mobile devices (Capterra, Oct 2019) ([Capterra](https://capterra.com/p/140743/CentralReach/reviews/)).
- **[Support]** A VP says the system was down more than it worked for weeks (Capterra, Jan 2022) ([Capterra](https://capterra.com/p/140743/CentralReach/reviews/)).
- **[Support]** The same VP says there's barely any customer service and no way to get immediate help (Capterra, Jan 2022) ([Capterra](https://capterra.com/p/140743/CentralReach/reviews/)).
- Note: several complaints above are 2019–2022. The 2024–2025 complaints center on pricing, contracts and exports, which are our wedge.

## What we build (the better version)
1. **MVP:** An **offline-first RBT session app** for trial-by-trial DTT, task analysis, frequency/duration, interval and ABC data. Big touch targets, works on cheap Android tablets, no forced re-logins mid-session (device PIN with a session lock).
2. **MVP:** **Automatic session notes.** Structured data plus an AI summary draft, parent/caregiver signature, and time/GPS stamps for session verification.
3. **MVP:** A programs and targets library, mastery criteria, and **auto-graphs** with phase-change lines. BCBAs update programs remotely.
4. **MVP:** An **authorization tracker**: units by CPT (97151, 97153, 97155, 97156) per auth period, burn-down alerts, and warnings before overuse.
5. **MVP:** A **supervision compliance tracker** that checks RBT supervision against BACB minimums (e.g., the monthly supervision percentage) and logs BCBA overlap sessions.
6. **MVP:** Scheduling with credential and auth checks.
7. **MVP:** A **claims-ready export** (CSV or 837P file for a billing company).
8. **MVP:** A **one-click full export** of every client's data.
9. **MVP:** A **parent portal** with session summaries, consents and messages.
10. **V2:** Direct clearinghouse claims, ERA posting and a denial worklist, with payer-specific modifier rules.
11. **V2:** Payroll export (e.g., Gusto) with drive time, BCBA-trainee fieldwork hour tracking, and EVV capture in states that apply EVV to these services (verify per state).
12. **V2:** An SLP/OT mode (goal banks, SOAP, school/IEP-style progress reports) and an AI treatment-plan drafter from assessment summaries. Do not reproduce copyrighted assessment protocols.

## Pricing to win
- **$12 per active client per month with unlimited staff, minimum $99/mo.** Month-to-month, no auto-renew, free migration, full export anytime.
- **Example:** A 30-client agency pays $360/mo. CentralReach pricing is quote-based and per user, so we offer to **beat any written CentralReach quote by 40%** and publish our price (claim to be validated on sales calls).
- An SLP/OT solo plan costs $39/mo.

## Go-to-market (first 100 customers)
- **Reddit:** r/ABA, r/BCBA, r/slp, r/OccupationalTherapy. Offer an auth-tracker spreadsheet-to-app template as a lead magnet.
- **State ABA associations:** CalABA, TxABA, FABA (Florida), NYSABA, MassABA, and others. Buy exhibitor booths and offer free CEUs on "audit-proof session notes" (become a BACB ACE provider or partner with one).
- **Conferences:** The ABAI Annual Convention, the Council of Autism Service Providers (CASP) conference, the ASHA Convention, and AOTA INSPIRE.
- **Facebook:** Large BCBA and ABA-business-owner groups and SLP private practice groups (verify rules).
- **Partners:** ABA billing companies, which will recommend a data tool that exports clean claims. Revenue share.
- **SEO:** "CentralReach alternative for small ABA", "CentralReach cancel contract", "ABA authorization tracking".

## Risks and incumbent moats
- **Payer billing complexity:** Modifiers, units and state Medicaid rules vary. Start with export-to-biller, then build direct claims per payer.
- **Offline sync correctness:** We prioritize conflict resolution tests before launch.
- **Incumbent moats:** CentralReach's all-in-one breadth (clinical, billing, HR, LMS) and RCM services. We win on price transparency, RBT UX and contract fairness.
- **PE consolidation of ABA agencies:** Acquired agencies move to corporate systems. Target independents.
- **HIPAA/BAA on a small-team budget:** ABA and SLP/OT practices that bill insurance are covered entities, and we are their business associate.
  - Sign customer BAAs and use AWS HIPAA-eligible services under AWS's self-serve BAA.
  - Offline devices must use **encrypted local storage**, with remote wipe and device PIN.
  - No PHI in SMS or push notification text. Stripe only for subscription billing.
  - A free HHS SRA Tool risk assessment, MFA, audit logs, and a breach runbook.
  - **Cost estimate:** A few hundred dollars a month plus a few thousand dollars a year for a pen test and cyber insurance. Minors' data makes a mature parent-access and consent model essential.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 2 | 3 | 3 | **15** |

## Sources
- [CentralReach reviews, Capterra](https://capterra.com/p/140743/CentralReach/reviews/)
- [CentralReach pricing and alternatives, Capterra](https://capterra.com/p/140743/CentralReach/)
- [Compare CentralReach vs CR Essentials, Capterra](https://capterra.com/compare/140743-210165/CentralReach-vs-Behaviorsoft)
- [5 Best ABA Billing Software Solutions of 2026, Theralytics (competitor source)](https://www.theralytics.net/blogs/best-aba-billing-software)
