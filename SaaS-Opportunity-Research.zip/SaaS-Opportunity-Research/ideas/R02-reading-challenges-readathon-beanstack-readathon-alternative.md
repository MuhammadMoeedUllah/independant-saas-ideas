# ReadRally: a cheaper, better Beanstack / READsquared plus a no-cut read-a-thon for libraries, schools and PTAs

**One-liner:** One app runs reading challenges and logs (summer reading, 1,000 Books Before Kindergarten, classroom logs) and turns any challenge into a pledge-per-minute read-a-thon. Libraries pay a small flat fee. Schools keep about 97% of what's raised (card processing only), not the 75–80% typical of read-a-thon platforms.

## Snapshot
- **Replaces:**
  - **Beanstack (Zoobean).** Pricing is quote-only: schools are priced by number of schools, and libraries by population served and the add-ons chosen ([Beanstack pricing](https://www.beanstack.com/pricing)).
    - Real contract: Dubuque County Library District (IA) approved **$1,430/yr on a 3-year subscription** (board minutes, Sep 17 2025) ([DCLD](https://www.dubcolib.org/wp-content/uploads/2025/11/Board-Minutes-September-2025-Approved.pdf)).
    - Beanstack accepts **Scholastic Dollars** and Title I funds, and pitches "reading fundraisers to offset costs" ([Beanstack pricing](https://www.beanstack.com/pricing)).
  - **READsquared:** **$595 per library** if contracted individually, or about $559 under Montana State Library's group contract (Jun 2023–May 2024) ([MSL memo, Feb 2023](https://ftpaspen.msl.mt.gov/EventResources/20230130130911_22348.pdf)).
  - **Read-A-Thon (read-a-thon.com / readathon.org):** says schools keep **"75–80% of every donation"**, with donors optionally covering platform fees (unverified; the cited page does not mention it) (vendor page, 2026) ([Read-A-Thon](https://www.read-a-thon.com/solutions/book-fair-alternatives)). That implies a 20–25% total cut.
  - **99Pledges:** 0% platform fee, but card processing of **3.49% + $0.49** per transaction (competitor comparison, Jul 2026) ([PledgeAthon](https://www.pledgeathon.io/vs/99pledges)).
  - **PledgeStar:** a free plan funded by donor tips, or a **7% fee capped at $1,195 per campaign** ([PledgeStar FAQ](https://pledgestar.com/faqs.html)).
  - Wandoo Reader, Reading Rewards and ReaderZone were not priced in this pass. Paper logs and Google Forms remain the free default.
- **Recent price hikes / changes (switching windows):**
  - **Federal library money shock.** The Mar 14 2025 executive order targeted IMLS. The Grants to States program had paid out more than **$180M in FY24** and funds summer reading, databases and ILS for small libraries (Library Journal, Oct 2025) ([LJ](https://www.libraryjournal.com/story/concerned-but-committed-small-and-rural-libraries-feeling-the-impact-of-a-defunded-imls)).
    - Courts blocked the order and LSTA is at **$212.5M**, but the **FY27 budget proposes zero** for IMLS (LJ, Apr 2026) ([LJ](https://www.libraryjournal.com/story/one-year-after-the-executive-order)).
    - Montana's READsquared cost is LSTA-subsidized. That group contract had already shrunk **from 40 libraries (2020) to 6 (2023)** ([MSL](https://ftpaspen.msl.mt.gov/EventResources/20230130130911_22348.pdf)).
  - **Read-a-thon fee pressure.** New entrants are attacking percentage-fee incumbents: PledgeAthon (0% platform fee), PagePledge (flat $1,000–$1,800 CAD per campaign), and PledgeStar (capped at $1,195) ([PagePledge](https://pagepledge.com/pricing), [PledgeStar](https://pledgestar.com/faqs.html)).
- **Who buys:**
  - Public library youth services managers and directors, for summer, winter and year-round challenges.
  - School librarians and literacy coaches.
  - **PTA/PTO fundraising chairs**, for read-a-thons. They buy with a card or nonprofit account and decide within a meeting.
- **US market size:**
  - About 9,000+ public library systems. Estimate: essentially all run summer reading. Small libraries are 77% of US public libraries (ARSL via LJ, FY2022) ([LJ](https://www.libraryjournal.com/story/concerned-but-committed-small-and-rural-libraries-feeling-the-impact-of-a-defunded-imls)).
  - Estimate: about 99k public plus about 30k private K-12 schools (NCES, commonly cited; verify).
  - Tens of thousands of PTAs and PTOs (estimate; National PTA reports about 20k+ units, verify).
  - Read-a-thons are one of the standard spring fundraisers.
- **Urgency trigger (why they'd switch NOW):**
  - Summer reading contracts renew Jan–Apr and library FY budgets reset Jul 1. IMLS/LSTA uncertainty is cutting state subsidies.
  - Spring read-a-thon planning happens Oct–Feb, and PTAs are angry about losing 20%+ of their raise.
- **Fastest-selling states/metros:** States where state-library LSTA subsidies of summer reading platforms are at risk (MT, AK, ME: LJ reports Maine and Alaska cuts). High-PTA-fundraising suburbs in CA, TX, NJ, VA and WA.

## Pain points (evidence)
- **[Price]** Schools lose **20–25%** of every read-a-thon donation on Read-A-Thon's own "keep 75–80%" claim ([Read-A-Thon](https://www.read-a-thon.com/solutions/book-fair-alternatives)).
  - A competitor's worked example: a school raising **$15,000** keeps **$12,000** on a 20%-fee platform versus about **$14,400** on flat pricing (PagePledge) ([PagePledge](https://pagepledge.com/pricing)).
- **[Price]** 99Pledges' **3.49% + $0.49** card fees cost about $195 more than Stripe-standard fees on a $25k campaign (competitor analysis, Jul 2026) ([PledgeAthon](https://www.pledgeathon.io/vs/99pledges)).
- **[Price]** Small libraries depend on subsidies to afford these tools. Montana's statewide READsquared group fell from 40 to 6 libraries, and the remaining ones pay $150 each with LSTA funds covering the rest ([MSL](https://ftpaspen.msl.mt.gov/EventResources/20230130130911_22348.pdf)).
- **[Price]** A small Iowa library district bought Beanstack at $1,430/yr specifically to cut the **cost of printing paper reading logs**, and used a state grant (Enrich Iowa) to pay for it ([DCLD](https://www.dubcolib.org/wp-content/uploads/2025/11/Board-Minutes-September-2025-Approved.pdf)). Without grants, paper wins.
- **[Complexity/UX]** Beanstack Tracker reviewers report:
  - past reading **logs to the wrong day**, so charts show wrong data;
  - late-evening reading counts as the next day, and the last day of a challenge doesn't count;
  - the timer **logs to the wrong child's profile**.

  ([JustUseApp review aggregation](https://justuseapp.com/en/app/1360324277/beanstack-tracker/reviews))
- **[Complexity/UX]** Parents can't log several books at once ("logging each one individually is DUMB"), must assign a start date to every book, and call the new UI "horrible" ([JustUseApp](https://justuseapp.com/en/app/1360324277/beanstack-tracker/reviews)).
- **[Support/Bugs]** Reviewers say the app spins forever with no developer response, an update broke streak tracking, logged reading doesn't award the badge, and old completed challenges can't be removed ([JustUseApp](https://justuseapp.com/en/app/1360324277/beanstack-tracker/reviews)).
- **[Missing features]** Beanstack's pricing page is contact-sales only, with separate "products" such as Reading Motivation Index and Comics Plus sold as bundles ([Beanstack pricing](https://www.beanstack.com/pricing)). Small libraries can't self-serve.
- **[Counter-evidence]** The Beanstack Tracker app holds **4.8★ from about 98K ratings** ([App Store](https://apps.apple.com/us/app/beanstack-tracker/id1360324277?see-all=reviews&platform=iphone)). Families like it. The pain is **price and fundraising fees for the buyer**, not reader UX. Score accordingly.
- *Evidence gap:* Reddit (r/Librarians, r/PTA, r/Teachers) is blocked from this environment. Collect read-a-thon fee threads manually.

## What we build (the better version)
1. **MVP: Challenge builder.** Templates for summer reading, 1,000 Books Before Kindergarten, winter reading, "Read 20 minutes a day" and classroom logs. Goals can be minutes, books, pages or activities (bingo boards). Badges and prize tiers with inventory counts for prize-desk pickup.
2. **MVP: Family-first logging.**
   - One account with many kids.
   - **Bulk log** ("we read 6 picture books today") and correct time zones and dates.
   - A timer that stays tied to the chosen child.
   - ISBN scan and offline mode.
   - SMS/QR logging for families without the app.
   - Paper-log photo upload that AI transcribes into entries, for libraries that keep paper.
3. **MVP: Pledge-a-thon toggle.** Any school or PTA challenge becomes a read-a-thon:
   - per-student donation pages;
   - flat or per-minute pledges;
   - Stripe checkout (the school's own Stripe account, so funds go straight to the PTA);
   - automatic "your reader hit 300 minutes" updates to donors;
   - class leaderboards and printable certificates.
4. **MVP: Staff dashboard.** Registrations, active readers, minutes by branch, school or grade, prize fulfilment, and a one-click **state library summer reading report** export.
5. **MVP: Multilingual.** Spanish at launch, others by auto-translation.
6. **V2: ILS lookups** for "read a book from our catalog" and holds links (Koha, Evergreen, Apollo, Polaris, Destiny APIs where available). **Clever/ClassLink** rostering for schools.
7. **V2: District or statewide consortium mode**, so one state library can sponsor all small libraries. This replaces the MSL-style group contract.
8. **V2: Partner-funded prizes and sponsor badges** (local businesses), and teacher wish lists tied to R04 book fairs.
9. **V2: Reading-motivation surveys and AI book recommendations** by age and interest. Recommendations draw only on the library's own catalog.

## Pricing to win
- **Public libraries:** flat, by population served. **$0 up to 5k, $299/yr to 25k, $699/yr to 100k, $1,499/yr above.**
  - Versus Beanstack at $1,430/yr for one small Iowa district (2025) and READsquared at $595/yr (2023).
  - A small library saves **$300–$1,400/yr**.
- **Schools:** teacher classroom logs free. School-wide challenges **$299/school/yr**.
- **Read-a-thons: 0% platform fee.** The school pays only Stripe (about 2.9% + 30¢), and donors may add an optional tip.
  - A PTA raising **$15,000 keeps about $14,500 instead of $11,250–$12,000** on a platform where schools keep 75–80%: **+$2,500 to +$3,250**.
  - Or the PTA picks a **flat $199 per campaign** option with no tip prompt.
- No annual lock-in, export anytime, and free import of last year's participants.

## Go-to-market (first 100 customers)
- **Libraries:**
  - CSLP (Collaborative Summer Library Program) member states: its annual theme drives summer reading, so offer ready-made CSLP-theme challenge templates.
  - State library youth-services consultants and state library association conferences (fall season).
  - The ARSL (Association for Rural & Small Libraries) conference and webinars.
  - A "free for libraries under 5k population" land-grab.
- **PTAs:**
  - PTO Today (its forums, the PTO Today Expo and newsletter ads).
  - State PTA conventions.
  - Facebook PTA/PTO leader groups.
  - "Switch from Read-A-Thon" and "readathon fees" SEO pages, plus a fee calculator ("see how much your school loses").
  - Referral: $100 to the PTA treasury for each school referred.
- **Schools:** school librarian associations in the R01 deadline states, bundled with ClearShelf.
- **Timing:** Library outreach Nov–Mar, before summer reading purchasing. PTA outreach Sep–Jan, before spring read-a-thons.

## Risks and incumbent moats
- **Beanstack's brand and app network.** It has a 98K-rating app and statewide sponsorships. *Mitigation:* go cheaper, and bundle a 0%-fee fundraiser. Beanstack's pricing page suggests "reading fundraisers" as a way to offset its cost ([pricing page](https://www.beanstack.com/pricing)); we did not check whether it has a built-in pledge feature. Win small and rural libraries first.
- **Payments and nonprofit compliance.**
  - Donations flow through the PTA's own Stripe Connect account; we never hold funds.
  - Tip prompts must be clearly optional. FTC and state AG scrutiny of "tip" dark patterns is a live risk.
  - State charitable-solicitation rules apply to PTAs, so we provide receipts with the EIN.
- **Children's privacy.** COPPA (under-13 accounts are parent-managed), FERPA for school deployments, and state student-privacy DPAs. *Mitigation:* parent-owned accounts, minimal data, SDPC DPAs.
- **Low switching urgency on the library side.** Readers are happy. *Mitigation:* lead with price and the loss of IMLS subsidies, and with PTA fundraising dollars.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 5 | 4 | 3 | **19** |

## Sources
- [Beanstack pricing page](https://www.beanstack.com/pricing)
- [Beanstack vs alternatives](https://www.beanstack.com/resources/beanstack-vs-alternatives)
- [Dubuque County Library District board minutes, Sep 2025 (Beanstack $1,430/yr)](https://www.dubcolib.org/wp-content/uploads/2025/11/Board-Minutes-September-2025-Approved.pdf)
- [Montana State Library FY2024 funding memo (READsquared contract), Feb 2023](https://ftpaspen.msl.mt.gov/EventResources/20230130130911_22348.pdf)
- [Read-A-Thon: book fair alternatives (keep 75–80%)](https://www.read-a-thon.com/solutions/book-fair-alternatives)
- [Read-A-Thon: school fundraising platforms comparison 2026](https://www.read-a-thon.com/solutions/school-fundraising-platforms)
- [PledgeAthon vs 99Pledges fees (Jul 2026)](https://www.pledgeathon.io/vs/99pledges)
- [PagePledge pricing](https://pagepledge.com/pricing)
- [PledgeStar FAQ (7% capped at $1,195)](https://pledgestar.com/faqs.html)
- [Walnut Creek Education Foundation read-a-thon FAQ](https://www.wcefk12.org/readathon-faq.html)
- [Beanstack Tracker App Store reviews](https://apps.apple.com/us/app/beanstack-tracker/id1360324277?see-all=reviews&platform=iphone)
- [Beanstack Tracker review aggregation (JustUseApp)](https://justuseapp.com/en/app/1360324277/beanstack-tracker/reviews)
- [Small and rural libraries feel IMLS defunding (Library Journal, Oct 2025)](https://www.libraryjournal.com/story/concerned-but-committed-small-and-rural-libraries-feeling-the-impact-of-a-defunded-imls)
- [One year after the executive order (Library Journal, Apr 2026)](https://www.libraryjournal.com/story/one-year-after-the-executive-order)

## Verification (Sep 25 2026)
- ✅ Beanstack $1,430/yr — Dubuque County Library District minutes for Sep 17, 2025 approve $1,430/yr on a 3-year subscription, paid from FY26 Enrich Iowa funds, "to help lower the cost of printing reading logs" ([source](https://www.dubcolib.org/wp-content/uploads/2025/11/Board-Minutes-September-2025-Approved.pdf))
- ✅ READsquared $595 individual / ~$559 group — the MSL memo gives $595 per library, or a $3,352 group contract (~$559 each) for Jun 1, 2023–May 30, 2024. Participation fell from 40 libraries (2020) to 6; each pays $150 and LSTA covers $2,452 ([source](https://ftpaspen.msl.mt.gov/EventResources/20230130130911_22348.pdf))
- ⚠️ Read-A-Thon "keep 75–80%" — the page repeats "Schools keep 75-80% of every donation". The claim that donors can cover platform fees is not on the page and is marked unverified ([source](https://www.read-a-thon.com/solutions/book-fair-alternatives))
- ✅ LSTA $212.5M and FY27 zero for IMLS — LJ (Apr 7, 2026): LSTA "currently funded at $212.5 million", the EO was blocked in court (the administration withdrew its appeal Apr 6), and the FY27 budget eliminates IMLS and IAL ([source](https://www.libraryjournal.com/story/one-year-after-the-executive-order))
