# GiftLedger: a cheaper, better Raiser's Edge NXT / Bloomerang / Givebutter for small nonprofits

**One-liner:** Donor CRM, donation forms, receipts and year-end statements for nonprofits under ~$3M revenue. One flat monthly price, unlimited records and users, no donor "tip" dark patterns, month-to-month terms, and free migration off Blackbaud.

## Snapshot
- **Replaces:**
  - **Blackbaud Raiser's Edge NXT:** Blackbaud publishes no prices. A competitor's estimate from nonprofit reports puts it at **$4,000–$15,000/yr**, plus **$5,000–$25,000 implementation** and **$2,000–$5,000 training**. eTapestry is estimated at **$100–$150/mo** (AlignMint, published Jul 29 2025, updated May 27 2026; estimates, not official) ([AlignMint](https://www.getalignmint.org/blog/blackbaud-pricing)).
  - **Bloomerang** (official pricing page, accessed Sep 24 2026):
    - CRM **from $125/mo**; Fundraising **from $40/mo**, which must be bundled with the CRM; Volunteer **from $119/mo**; all-in "Giving Platform" **from $242/mo**.
    - **Every price is shown "billed annually"** (no monthly option listed). Priced by number of records. **Every plan includes unlimited users**, so "unlimited users" is not a differentiator against Bloomerang ([Bloomerang pricing](https://bloomerang.com/pricing/)).
    - So the minimum CRM plus fundraising bundle is about **$1,980/yr** before processing. A competitor reports processing of **2.2% + $0.30 (card)** and **1% + $0.30 (ACH)** ([Zeffy, Mar 23 2026](https://www.zeffy.com/blog/bloomerang-reviews)).
  - **Givebutter:** "free" to the nonprofit, funded by donor tips. TINA.org says the donation form adds a **15% tip by default**, plus processing fees ([TINA.org, Jun 1 2026](https://truthinadvertising.org/articles/givebutters-hidden-fees/)).
  - DonorPerfect, Neon One, Little Green Light and GoFundMe Pro (Classy): not re-priced in this pass.
- **Recent price hikes / changes (switching windows):**
  - **Blackbaud breach fallout.** The 2020 ransomware breach led to a **$49.5M multistate AG settlement (Oct 2023)** ([Utah AG](https://attorneygeneral.utah.gov/2023/10/06/ag-reyes-and-the-utah-division-of-consumer-protection-announce-49-5-million-multistate-settlement-with-blackbaud-after-data-breach-impacts-nonprofits-and-consumers)). A **final FTC order (May 2024)** requires Blackbaud to delete data it doesn't need and to strengthen its security ([FTC, Feb 2024](https://www.ftc.gov/news-events/news/press-releases/2024/02/ftc-order-will-require-blackbaud-delete-unnecessary-data-boost-safeguards-settle-charges-its-lax); [FTC final, May 2024](https://ftc.gov/news-events/news/press-releases/2024/05/ftc-finalizes-order-blackbaud-related-allegations-firms-security-failures-led-data-breach)).
  - **Blackbaud renewal escalators.** A competitor says "most Blackbaud contracts include annual escalation clauses, typically 5–15% per year" on multi-year terms (competitor claim; verify against a real contract) ([AlignMint](https://www.getalignmint.org/blog/blackbaud-pricing)).
  - **Givebutter class action (filed April 2026).** It alleges tips and fees were added without affirmative consent. TINA.org also flags the FTC fees rule for Givebutter's ticket sales ([TINA.org](https://truthinadvertising.org/articles/givebutters-hidden-fees/)).
  - **Bloomerang's per-record tiers:** reviewers say each tier jump adds "several hundred dollars a year" (see pain points).
- **Who buys:** Executive directors, development directors and board treasurers at nonprofits with $100k–$3M revenue and 0–5 fundraising staff. The ED usually signs, and often pays with a card.
- **US market size:** Estimate: about 1.5M+ IRS-recognized 501(c)(3) organizations. Most are small; well over half report under $500k revenue (IRS EO Business Master File; verify exact count in the state pass).
- **Urgency trigger (why they'd switch NOW):** Blackbaud contract anniversaries and escalators, often at the **Jul 1 / Jan 1 fiscal-year renewals**. The Givebutter lawsuit makes boards nervous about donor-tip forms. **Year-end giving (Oct–Dec)** forces a decision: switch before Giving Tuesday (Dec 1 2026) or wait until January.
- **Fastest-selling states/metros:** States with the most nonprofits: CA, NY, TX, FL, PA, IL, OH (estimate). Also states with heavy charitable-solicitation registration burdens (NY, CA, PA, FL, IL), where our registration tracker is a selling point.

## Pain points (evidence)
- **[Price]** A development director says Raiser's Edge NXT is a "significant investment", especially for smaller nonprofits (Capterra, Jul 2025) ([Capterra](https://capterra.com/p/247647/Blackbaud-Raiser-s-Edge-NXT/reviews/)).
- **[Price]** The CEO of a 2–10 person nonprofit says RE NXT was "very expensive", so they switched when the contract ended (Capterra, Mar 2026) ([Capterra](https://capterra.com/p/247647/Blackbaud-Raiser-s-Edge-NXT/reviews/)).
- **[Lock-in/Contracts]** A grants director describes aggressive re-subscription tactics and disputed contract terms that ended in a Better Business Bureau complaint (Capterra, Feb 2024) ([Capterra](https://capterra.com/p/247647/Blackbaud-Raiser-s-Edge-NXT/reviews/)).
- **[Price]** A reviewer was charged extra fees for going over the constituent limit (Capterra, Jul 2020) ([Capterra](https://capterra.com/p/247647/Blackbaud-Raiser-s-Edge-NXT/reviews/)).
- **[Complexity/UX]** A donor engagement officer reports a steep learning curve, and says switching between the web and database views feels disjointed (Capterra, Apr 2026) ([Capterra](https://capterra.com/p/247647/Blackbaud-Raiser-s-Edge-NXT/reviews/)).
- **[Support]** A reviewer says support moved from real help to a self-service knowledge base, with "little-to-no support" (Capterra, Feb 2024) ([Capterra](https://capterra.com/p/247647/Blackbaud-Raiser-s-Edge-NXT/reviews/)).
- **[Price]** Bloomerang users on G2 say cost rises "significantly as your contact list grows". One limited how many contacts they added because each tier jump added several hundred dollars a year (G2 quotes compiled by Zeffy, a competitor, Mar 2026) ([Zeffy](https://www.zeffy.com/blog/bloomerang-reviews)).
- **[Price]** A Bloomerang user says the price is "very high for what you get" for a small or mid-size organization (G2, via Zeffy) ([Zeffy](https://www.zeffy.com/blog/bloomerang-reviews)).
- **[Support]** A Bloomerang user says support wait times have grown over the past year (G2, via Zeffy) ([Zeffy](https://www.zeffy.com/blog/bloomerang-reviews)).
- **[Trust/Fees]** Givebutter donors report surprise charges, with a default 15% tip and fees they found only after entering card details. Complaints appear on Reddit, BBB and Trustpilot, and a class action was filed in April 2026 ([TINA.org, Jun 2026](https://truthinadvertising.org/articles/givebutters-hidden-fees/)).

## What we build (the better version)
1. **MVP** Donor CRM: households, relationships, giving history, soft credits, tags, and moves-management stages. **Unlimited records and users** (no per-record tiers).
2. **MVP** **One-click Blackbaud / Bloomerang / LGL / Givebutter import:** maps RE NXT exports (constituents, gifts, funds, campaigns, appeals) with AI field-matching and a dedupe preview.
3. **MVP** Donation forms, recurring giving and simple event tickets. **No default tip.** A plain opt-in "cover the fee" checkbox that shows the exact dollar amount, compliant with the FTC fees rule for tickets.
4. **MVP** Automatic IRS-compliant acknowledgment receipts (quid-pro-quo disclosure over $75) and **one-click year-end giving statements**.
5. **MVP** Email appeals and segments (lapsed donors, LYBUNT/SYBUNT, major-donor prospects) with a built-in sender (no Mailchimp needed).
6. **MVP** Board-ready dashboards: retention rate, revenue by fund and campaign, pledge balances, and a QuickBooks export by fund/class.
7. **V2** **Charitable solicitation registration tracker:** which states you solicit in, renewal due dates per state, and document checklists (Form 990, audit threshold). Sold as a compliance add-on.
8. **V2** AI "donor brief" before each call or meeting (giving history, notes, next ask amount), plus AI-drafted thank-you letters in the ED's voice.
9. **V2** Peer-to-peer and auction pages, volunteer hours, and grant pipeline tracking.
10. **V2** Security posture as a selling point: SOC 2 Type I roadmap, field-level encryption for bank data, and a data-minimization setting (the opposite of what the FTC found at Blackbaud).

## Pricing to win
- **Free** up to 500 records (forms plus CRM). **$49/mo** up to 5,000 records. **$99/mo unlimited.** Unlimited users on every plan, month-to-month, free migration.
- Processing at Stripe cost (Stripe's discounted nonprofit rate where eligible). No platform percentage. Any optional donor fee-cover goes 100% to the nonprofit.
- **Example (estimate):** a $1M nonprofit on RE NXT at ~$6,000/yr (mid-range of the AlignMint estimate) moves to $1,188/yr and saves about **$4,800/yr**, plus it avoids the 5–15% escalator. A Bloomerang customer at the ~$1,980/yr minimum saves about $800/yr and never pays another tier jump.

## Go-to-market (first 100 customers)
- **State nonprofit associations** (National Council of Nonprofits network, e.g. CalNonprofits, Nonprofit New York, Florida Nonprofit Alliance, PANO in PA, Minnesota Council of Nonprofits): member discount plus webinars on "Blackbaud renewal: what to negotiate or how to leave".
- **Reddit:** r/nonprofit and r/fundraising. Answer "Raiser's Edge renewal" and "Givebutter tips" threads with a free migration offer.
- **AFP (Association of Fundraising Professionals) local chapters** and the NTEN community; partner with fractional development directors and nonprofit CPAs (referral fee).
- **"Switch from X" SEO pages:** "Raiser's Edge alternative for small nonprofits", "Bloomerang price per record", "Givebutter without tips".
- **Timing:** push Oct–Nov (before year-end statements) and May–June (before Jul 1 renewals).

## Risks and incumbent moats
- **Data migration from RE NXT is messy** (custom fields, gift splits). Offer a white-glove import and a parallel-run month.
- **Free competitors** (Zeffy, Givebutter) set a "$0" anchor. We win on trust (no tips), a real CRM and year-end statements.
- **Payments dependency** on Stripe: plan for nonprofit-verification friction.
- **Security expectations** after Blackbaud: SOC 2 will be asked for early.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 4 | 3 | 5 | **20** |

## Sources
- [FTC: Order requires Blackbaud to delete unnecessary data (Feb 2024)](https://www.ftc.gov/news-events/news/press-releases/2024/02/ftc-order-will-require-blackbaud-delete-unnecessary-data-boost-safeguards-settle-charges-its-lax)
- [FTC finalizes Blackbaud order (May 2024)](https://ftc.gov/news-events/news/press-releases/2024/05/ftc-finalizes-order-blackbaud-related-allegations-firms-security-failures-led-data-breach)
- [Utah AG: $49.5M multistate Blackbaud settlement (Oct 2023)](https://attorneygeneral.utah.gov/2023/10/06/ag-reyes-and-the-utah-division-of-consumer-protection-announce-49-5-million-multistate-settlement-with-blackbaud-after-data-breach-impacts-nonprofits-and-consumers)
- [Raiser's Edge NXT reviews – Capterra](https://capterra.com/p/247647/Blackbaud-Raiser-s-Edge-NXT/reviews/)
- [Blackbaud pricing in 2026 – AlignMint (competitor estimates)](https://www.getalignmint.org/blog/blackbaud-pricing)
- [Bloomerang pricing (accessed Sep 24 2026)](https://bloomerang.com/pricing/)
- [Bloomerang reviews and fees – Zeffy (competitor, Mar 2026)](https://www.zeffy.com/blog/bloomerang-reviews)
- [Givebutter's hidden fees – TINA.org (Jun 1 2026)](https://truthinadvertising.org/articles/givebutters-hidden-fees/)
- [Givebutter pricing page](https://givebutter.com/pricing)

## Verification (Sep 24 2026)
- ✅ Bloomerang CRM $125, Fundraising $40 (must be bundled with CRM), Volunteer $119, Giving Platform $242, all "billed annually", priced by records — confirmed. The page also says "Every plan comes with unlimited users" (note added: not a differentiator for us). "Annual only" softened to "no monthly option listed" ([source](https://bloomerang.com/pricing/))
- ✅ Givebutter default 15% tip; class action filed in April alleging tips and fees added without affirmative consent; FTC fees-rule angle (article dated Jun 1 2026; the year of filing is implied, not stated) ([source](https://truthinadvertising.org/articles/givebutters-hidden-fees/))
- ✅ RE NXT $4k–15k/yr, $5k–25k implementation, $2k–5k training, eTapestry $100–150/mo, "5-15% per year" escalators — confirmed as AlignMint's competitor estimates (Jul 29 2025, modified May 27 2026) ([source](https://www.getalignmint.org/blog/blackbaud-pricing))
- Not re-checked: Blackbaud $49.5M AG settlement and FTC order (official sources, low risk). Scores unchanged.
