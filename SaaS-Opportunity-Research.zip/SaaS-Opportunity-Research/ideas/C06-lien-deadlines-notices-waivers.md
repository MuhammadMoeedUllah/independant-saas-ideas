# LienClock: a cheaper, clearer Levelset (Procore Pay) for subcontractors and suppliers who need to protect lien rights

**One-liner:** A 50-state lien-deadline calendar built from the jobs you already invoice. It creates the correct statutory notice or waiver form for each state, mails it certified at cost, and warns you before any lien right expires.

## Snapshot
- **Replaces:**
  - **Levelset**, owned by Procore since November 2021. Its pricing page lists SendNotice at $59 per recipient and SendDemand at $59 per recipient, and says filing a lien needs a subscription (call for a price) ([Levelset pricing, checked Sep 24 2026](https://www.levelset.com/pricing/)). A competitor comparison lists preliminary notices at $19 per send after 3 free, Notices of Intent at $49 per send after 3 free, mechanic's lien filing at $349, and lien cancellation at $149. It also cites third-party figures of about $149 per user per month for subscriptions (unverified) ([Siteline, updated Jul 28 2026](https://www.siteline.com/compare/levelset)).
  - **Procore Pay** bundles lien waivers into GC payment flows. Pricing was not verified.
  - Also used: spreadsheets, and lien attorneys or notice-service bureaus.
- **Recent price hikes / changes:**
  - Since the Procore acquisition (Nov 2021), reviewers say GC payment-history vetting tools were removed and phone support was replaced by email-only support (see below).
  - **Law changes create demand.** Texas's HB 2237, effective Jan 1 2022, overhauled notices and forms. Texas SB 929 (signed May 21 2025) now pushes deadlines that land on a weekend or holiday to the next business day. Other 2025 Texas bills touched trust funds (SB 841), venue (HB 2960) and public-project payment delays (HB 3005) ([Texas Easy Lien, Feb 26 2026](https://www.texaseasylien.com/blog/texas-lien-law-2026-what-every-contractor-needs-to-know-now/)).
- **Who buys:** The owner, office manager or credit manager at a specialty subcontractor (electrical, plumbing, HVAC, drywall, concrete, roofing) or at a material supplier or equipment-rental firm. Often a 1–50-person company.
- **US market size:** A rough estimate, not verified, is about 450k+ specialty-trade-contractor employer establishments (NAICS 238), plus building-material dealers and rental yards. Confirm with Census CBP. Most have unpaid receivables at some point.
- **Urgency trigger (why they'd switch NOW):**
  - Deadlines run for every job, every month. Missing one loses the lien right on that job.
  - New state rules (Texas 2022 and 2025) push firms to automate.
  - The trigger event is an unpaid invoice from a GC.
- **Fastest-selling states/metros:** Start with states that have short, strict, monthly or early notice requirements:
  - **Texas:** monthly notices on the 15th of the 2nd month (residential) or 3rd month (commercial).
  - **California:** 20-day preliminary notice.
  - **Arizona:** 20-day preliminary notice.
  - **Colorado:** a notice of intent at least 10 days before filing the lien, which must be filed within 4 months. Enforcement is 6 months from the last work.
  - **Florida:** 45-day Notice to Owner.
  - **Washington:** 60-day notice.
  - Georgia requires no preliminary notice, so it is lower priority.

**Notable state rules for subs and suppliers** (from [Forms-Legal, Jun 2026](https://forms-legal.com/blog/mechanics-lien-us-deadlines-preliminary-notices-costs-by-state) and [Texas Easy Lien](https://www.texaseasylien.com/blog/texas-lien-law-2026-what-every-contractor-needs-to-know-now/). Have an attorney verify before building rules.)

| State | Preliminary notice | Lien filing window | Enforce by |
|---|---|---|---|
| TX | Monthly: 15th of 2nd month (residential) / 3rd month (commercial) after the work | 15th of 3rd month (residential) / 4th month (commercial) | 1 year after the last day to file the lien affidavit, for both residential and commercial work. It can be extended to 2 years by a recorded written agreement with the owner (Prop. Code 53.158, as amended by HB 2237) |
| CA | 20 days | 90 days from last furnishing | 90 days after filing |
| FL | 45 days | 90 days | 1 year |
| AZ | 20 days | 120 days | 6 months |
| CO | No start-of-work notice is required. A **notice of intent** must be served on the owner (personal delivery or certified mail) at least 10 days before filing the lien statement (C.R.S. 38-22-109(3)) | 4 months after last work or materials (2 months for day laborers) | Suit must be filed within 6 months after the last work or materials or completion, **not** 6 months after filing (C.R.S. 38-22-110) |
| WA | 60 days | 90 days | 8 months |
| NY | None required on private improvements (Lien Law §10 has no preliminary-notice step) | 8 months (4 months single-family), measured from completion or final furnishing | 1 year from filing (Lien Law §17; verify) |
| GA | None required | 90 days | 1 year |

## Pain points (evidence)
Levelset is rated fairly well overall (4.3/5 on 3,839 Trustpilot reviews), so pain is moderate and mostly about fees and support.
- **[Price]** A customer was charged $67 for "preparing" a notice they wrote themselves and called it a "total scam" ([Trustpilot, Jan 15 2026](https://www.trustpilot.com/review/levelset.com)).
- **[Missing features]** Tools that let contractors check a GC's payment history were removed after the Procore acquisition, taking away a protection users relied on ([Trustpilot, Jan 6 2026](https://www.trustpilot.com/review/levelset.com)).
- **[Support]** Levelset support was "extremely disappointing," with no or slow replies when help was needed ([Trustpilot, Jan 30 2026](https://www.trustpilot.com/review/levelset.com)).
- **[Support]** Phone support was discontinued and callers are pushed to email for complex lien questions ([Trustpilot, Dec 12 2024](https://www.trustpilot.com/review/levelset.com)).
- **[Complexity/Price]** The software is confusing and glitchy, and the "high price" doesn't justify the problems ([Trustpilot, Oct 14 2025](https://www.trustpilot.com/review/levelset.com)).
- **[Accuracy]** A recipient got a false lien demand for a debt already paid, and could not reach support to fix it ([Trustpilot, Oct 11 2025](https://www.trustpilot.com/review/levelset.com)).
- **[Price]** Fees are charged per document ($19–$59 per notice or recipient, $349 per lien), so costs scale with every job and every recipient ([Levelset pricing](https://www.levelset.com/pricing/); [Siteline](https://www.siteline.com/compare/levelset)).
- **[Missing features]** Subs say they want billing (pay applications) and lien tracking in one place, with deadline visibility across all jobs tied to receivables. Levelset keeps these separate. This is a competitor's framing ([Siteline](https://www.siteline.com/compare/levelset)).
- **[Risk]** In Texas, "one missed deadline or improper notice can invalidate your entire claim" ([Texas Easy Lien](https://www.texaseasylien.com/blog/texas-lien-law-2026-what-every-contractor-needs-to-know-now/)).

## What we build (the better version)
1. **MVP:** Job intake: address, owner, GC, role (sub, sub-sub or supplier), residential or commercial, public or private, and first-furnishing date. AI fills in the property owner and legal description from county records where available.
2. **MVP:** **50-state deadline engine.** Computes preliminary notice, notice of intent, lien and enforcement dates for each job. Starts with the TX, CA, FL, AZ, CO, WA, NY and GA rules and adds more states. Includes Texas month-by-month notices and SB 929 weekend/holiday rolling.
3. **MVP:** Deadline calendar with SMS and email alerts at 14, 7 and 2 days, and an "at-risk $" dashboard linked to unpaid invoices.
4. **MVP:** Statutory form generator (preliminary notice, notice of intent, lien waivers conditional and unconditional, progress and final) using state-mandated forms. Free to generate yourself.
5. **MVP:** Certified-mail sending through a print-and-mail API, charged at postage cost plus a small flat fee, with proof of mailing stored.
6. **MVP:** QuickBooks sync. Unpaid invoices on a job start the notice-of-intent workflow automatically.
7. **V2:** Waiver exchange portal. GCs request conditional or unconditional waivers, and subs sign and track them. Free for GCs, which spreads the product.
8. **V2:** Lien filing through attorney-partner networks at a flat price (no in-house legal practice).
9. **V2:** GC payment-reputation data built from our users' anonymized payment timing. This restores the vetting feature Levelset users say was removed.

## Pricing to win
- **Our prices:** $49/mo per company with unlimited jobs, users and self-generated forms. Certified mailing at postage cost plus $3. Partner-attorney lien filing at a flat price published per state.
- **Example savings:** An electrical sub sending 20 preliminary notices a month (1 recipient each) pays about $380/mo at Levelset's $19 rate after the free sends, or about $1,180/mo at $59 per recipient. With us it pays $49/mo plus postage at cost (about $10–$11 each for certified mail with return receipt, an estimate).

## Go-to-market (first 100 customers)
- **Associations:** ASA (American Subcontractors Association) and state chapters; NACM (National Association of Credit Management) for supplier credit managers; NLBMDA and state lumber/building-material dealer associations; trade associations from C01–C02 (ACCA, PHCC, NRCA).
- **State-by-state SEO:** A "[State] mechanics lien deadline calculator" page for all 50 states. This is a free tool that captures leads, and the deadline engine does double duty.
- **Partners:** Construction attorneys and CPAs as referral partners. They get a free dashboard to watch client deadlines.
- **Reddit:** r/Construction, r/Contractor, r/electricians, r/Plumbing. Post "the GC hasn't paid, what now?" explainers.
- **Distribution:** A free waiver exchange for GCs pulls in their subs, and each sub invites its own GCs.

## Risks and incumbent moats
- **Legal accuracy.** Wrong deadlines create liability. Mitigate with attorney-reviewed rules per state, versioned updates, clear disclaimers, and E&O insurance. Launch in 8 states with deep coverage rather than 50 shallow ones.
- **Unauthorized practice of law.** We provide forms and calculations, and a licensed attorney handles filings.
- **Procore's network effects.** GCs push subs into Procore Pay. We counter with the free waiver portal and QuickBooks-first flow for subs who never touch Procore.
- **Mailing costs** are real, so we pass them through transparently.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 3 | 4 | 4 | **18** |

## Sources
- [Levelset pricing page (checked Sep 24 2026)](https://www.levelset.com/pricing/)
- [Siteline vs. Levelset (updated Jul 28 2026)](https://www.siteline.com/compare/levelset)
- [Trustpilot: Levelset (4.3/5, 3,839)](https://www.trustpilot.com/review/levelset.com)
- [Forms-Legal: Mechanic's lien deadlines by state (updated Jun 2026)](https://forms-legal.com/blog/mechanics-lien-us-deadlines-preliminary-notices-costs-by-state)
- [Texas Easy Lien: Texas Lien Law 2026 (Feb 26 2026)](https://www.texaseasylien.com/blog/texas-lien-law-2026-what-every-contractor-needs-to-know-now/)

## Verification (Sep 24 2026)
- ✅ TX SB 929 was signed May 21 2025 and took effect immediately. It amends Prop. Code 53.003(e) so a deadline that lands on a Saturday, Sunday or legal holiday moves to the next day that is none of those ([LegiScan](https://legiscan.com/TX/bill/SB929/2025); [enrolled text](https://capitol.texas.gov/tlodocs/89R/billtext/pdf/SB00929F.pdf))
- ❌ TX enforcement is not "2 years". Suit must be brought "not later than the first anniversary of the last day a claimant may file the lien affidavit", with no residential/commercial split, and it can be extended to 2 years only by a recorded written agreement. HB 2237 changed this effective Jan 1 2022. The table is fixed ([Prop. Code 53.158](https://texas.public.law/statutes/tex._prop._code_section_53.158))
- ❌ NY preliminary notice: Lien Law §10 has no preliminary-notice requirement, so the "all claimants required" claim was wrong and is fixed ([NY Lien Law §10](https://www.nysenate.gov/legislation/laws/LIE/10))
- ✅ NY lien window: 8 months after completion or final furnishing, 4 months for a single-family dwelling. The 1-year duration (§17) was not checked and stays (verify) ([NY Lien Law §10](https://www.nysenate.gov/legislation/laws/LIE/10))
- ❌ CO notice: there is no notice due "10 days after work begins". A notice of intent must be served "at least ten days before the time of filing the lien statement". The table and the market bullet are fixed ([C.R.S. 38-22-109](https://codes.findlaw.com/co/title-38-property-real-and-personal/co-rev-st-sect-38-22-109/))
- ✅ CO lien window: 4 months after the last labor or materials, 2 months for day laborers ([C.R.S. 38-22-109](https://codes.findlaw.com/co/title-38-property-real-and-personal/co-rev-st-sect-38-22-109/))
- ❌ CO enforcement is not "6 months after filing". A lien holds for no more than "six months after the last work or labor is performed, or ... materials are furnished" (or completion) unless suit is filed and notice recorded in that time. Fixed ([C.R.S. 38-22-110](https://codes.findlaw.com/co/title-38-property-real-and-personal/co-rev-st-sect-38-22-110/))
- ✅ AZ preliminary notice: "not later than twenty days after the claimant has first furnished". A late notice covers only work from 20 days before it was served ([A.R.S. 33-992.01](https://www.azleg.gov/ars/33/00992-01.htm))
- ⚠️ The FL, CA, WA and GA rows and the TX month counts were not re-checked against statutes this pass
