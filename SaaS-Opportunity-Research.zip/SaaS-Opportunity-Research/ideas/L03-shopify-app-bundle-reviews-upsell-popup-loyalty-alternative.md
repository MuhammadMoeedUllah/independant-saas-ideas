# StackSaver: one flat-price Shopify app that replaces 5–8 stacked subscriptions (reviews, upsells, pop-ups, loyalty, SEO) for small merchants

**One-liner:** One lightweight Shopify app with reviews, upsell and bundle offers, email-capture pop-ups, points loyalty, trust badges and SEO fixes. Each module can be switched on or off, and the whole thing costs one flat monthly fee with no order-volume tiers. AI imports your old apps' data and settings in one click.

## Snapshot
- **Replaces** (prices per PandaCodeGen, verified Aug 2, 2026, unless noted):
  - **Reviews:** Judge.me $15/mo; Loox $49.99/mo (300 orders included, then $50 per extra 300); Yotpo from $15/mo (Starter). A Yotpo reviewer in Jul 2026 says the useful paid tiers start at **$129**.
  - **Loyalty:** Smile.io Essential $15/mo (up to 500 monthly orders). A Smile reviewer in May 2026 reports being "forced to pay **$199/mo**" on a higher plan.
  - **Subscriptions:** Recharge $99/mo + 1.49% + $0.19 per transaction; Bold Subscriptions $24.99/mo. Out of scope for the MVP.
  - **Page building:** PageFly $24/mo. **Helpdesk:** Gorgias from $10/mo. **Email/SMS:** Klaviyo from $20/mo. Email/SMS is out of scope because B01 covers it.
  - **Existing all-in-one rivals:** Vitals and similar "40+ apps in one" bundles already exist. Verify their current price and reviews before building.
- **Recent price hikes / changes:**
  - **Yotpo** moved imported reviews' "Verified Buyer" badge off the Pro plan and behind Premium/Enterprise (1-star review, Aug 20, 2026).
  - A 7-year Yotpo customer alleges being overcharged about **$7,000/yr** on a contract while a $329/mo package existed, and found Okendo at $299/mo (Dec 10, 2025).
  - App vendors keep gating features by order volume or tier. The effect compounds because merchants stack many apps. AppStoreResearch (Apr 24, 2026) notes that stores past $500K revenue often run **"dozens of apps."**
- **Who buys:** owner-operated Shopify stores doing about **$5K–$150K/mo** in revenue (estimate band), run by the founder or a 1–5-person team, on Basic, Grow or Advanced plans. They install and pay through the Shopify App Store with no procurement.
- **US market size:** third-party store trackers (StoreLeads, BuiltWith) put live US Shopify storefronts in the low millions (estimate; verify). The paying-app segment is a fraction of that, likely hundreds of thousands of stores (estimate).
- **Urgency trigger (why they'd switch NOW):**
  - An app bill audit in Q4 prep (Sept–Oct, ahead of BFCM).
  - A feature moved to a higher tier (Yotpo, Aug 2026).
  - Order-volume tier bumps after a good month.
  - Page-speed and Core Web Vitals drops from stacked app scripts.
- **Fastest-selling states/metros:** DTC founder clusters in LA/Orange County, NYC/Brooklyn, Austin, Miami, Salt Lake City/Utah County, Denver and Nashville. Marketing is fully online, so geography matters less than community.

## Pain points (evidence)
- **[Price]** A small-business owner says Yotpo's paid tiers start at $129 with no cheaper useful option, and calls the limits "scammy" (Shopify App Store, Jul 6, 2026) ([source](https://apps.shopify.com/yotpo-social-reviews/reviews?ratings%5B%5D=1))
- **[Price]** A long-time Yotpo customer alleges about $7,000/yr in overcharges versus an undisclosed $329/mo package, and switched to Okendo at $299/mo (Shopify App Store, Dec 10, 2025) ([source](https://apps.shopify.com/yotpo-social-reviews/reviews?ratings%5B%5D=1))
- **[Lock-in/Contracts]** On Smile.io: "Once you sign up you will be forced to pay $199/mo FOREVER or cancel," with no flexible downgrade (Shopify App Store, May 2, 2026) ([source](https://apps.shopify.com/smile-io/reviews?ratings%5B%5D=1))
- **[Price]** A merchant chose Smile's free plan but was charged $79, and the refund request went unresolved (Shopify App Store, Apr 7, 2026) ([source](https://apps.shopify.com/smile-io/reviews?ratings%5B%5D=1))
- **[Missing features]** Yotpo moved imported reviews' "Verified Buyer" badge from Pro to Premium/Enterprise, taking away a feature the merchant already had (Shopify App Store, Aug 20, 2026) ([source](https://apps.shopify.com/yotpo-social-reviews/reviews?ratings%5B%5D=1))
- **[Missing features]** Yotpo's CSV export repeatedly came back empty during testing (Shopify App Store, Feb 7, 2026) ([source](https://apps.shopify.com/yotpo-social-reviews/reviews?ratings%5B%5D=1))
- **[Missing features]** A 3-year Yotpo user went from several hundred new reviews a month to 7 and switched platforms (Shopify App Store, Jun 3, 2026) ([source](https://apps.shopify.com/yotpo-social-reviews/reviews?ratings%5B%5D=1))
- **[Complexity/UX]** A Smile.io bug hurt conversion rates, and the merchant says the revenue lost exceeded the subscription cost (Shopify App Store, Jul 7, 2026) ([source](https://apps.shopify.com/smile-io/reviews?ratings%5B%5D=1))
- **[Support]** Yotpo's AI chatbot promised a 4–6-hour follow-up and no human replied for two days (Shopify App Store, Jul 16, 2026). Another reviewer says support is "only AI" (Feb 7, 2026) ([source](https://apps.shopify.com/yotpo-social-reviews/reviews?ratings%5B%5D=1))
- **[Support]** A paying Smile.io merchant reports slow support and inadequate fixes (Shopify App Store, May 7, 2026) ([source](https://apps.shopify.com/smile-io/reviews?ratings%5B%5D=1))
- **[Complexity/UX]** App bills grow as a stack, not from one expensive app: "I have apps for reviews, upsells, email capture, currency conversion, and more" (merchant quoted by PandaCodeGen, Mar 19, 2026) ([source](https://www.pandacodegen.com/blog/shopify-app-costs-real-monthly-bill))

**Honest read:** all-in-one Shopify bundles already exist, so "bundle" alone is not new. The wedges are:
- **(a) No order-volume tiers.** A flat price removes the "you had a good month, now pay more" trap that hits reviews and loyalty apps.
- **(b) One script and fast pages,** proven with a before/after speed report.
- **(c) One-click AI migration** of reviews, loyalty balances and pop-up settings from Judge.me, Yotpo, Loox, Smile and Privy.
- **(d) An "app bill audit" onboarding** that shows the exact savings.

## What we build (the better version)
1. **App-bill audit on install.** Reads the installed apps and their public price tiers and shows "you pay ~$X/mo for features StackSaver includes." **MVP**
2. **Reviews module:** photo and video reviews, post-purchase request emails, star ratings on product and collection pages, Google Shopping review feed, CSV import (Judge.me, Yotpo, Loox, Okendo formats), and **Verified Buyer badges on every plan**. **MVP**
3. **Upsell and bundles:** frequently-bought-together, cart drawer upsell, post-purchase one-click offer (Shopify checkout extensions), volume discounts, and AI offer suggestions from order history. **MVP** (FBT, cart upsell, volume discounts). **V2** (post-purchase)
4. **Pop-ups and email capture:** spin or discount pop-ups, exit intent, a teaser, and sync to Shopify customers, Klaviyo or Mailchimp. **MVP**
5. **Loyalty:** points for orders, reviews and referrals, a VIP tier, a rewards widget, and a **balance import from Smile.io CSV**. **MVP** (points and referrals). **V2** (VIP tiers, POS)
6. **Trust and conversion widgets:** free-shipping bar, trust badges, countdown, size chart and stock alerts. **MVP**
7. **SEO and speed:** AI alt text and meta descriptions in bulk, JSON-LD product and review schema, broken-link finder, image compression, and one deferred script bundle for all modules. **MVP** (alt text, schema, one script). **V2** (image compression pipeline)
8. **Unified dashboard:** revenue influenced per module, reviews collected, loyalty liability, and a speed score before and after. **MVP**
9. **AI store assistant:** "Why did conversion drop last week?" answered from store data. **V2**
10. **Wholesale and B2B price lists** and a subscriptions module. **V2** (possibly never; Recharge is sticky)

## Pricing to win
| Plan | StackSaver | What it replaces (examples, Aug 2026 list prices) |
|---|---|---|
| Starter **$19/mo** | All modules, up to 300 orders/mo | Judge.me $15 + Smile $15 + a pop-up app + an upsell app |
| Growth **$49/mo** | All modules, **unlimited orders**, remove branding, priority support | Loox $49.99 + Smile $199 + Yotpo $129 tiers |
| Scale **$99/mo** | Growth + multi-store + API | Yotpo $299–329 contracts |

Billing runs through the Shopify Billing API, month-to-month, with free migration.

**Savings example (estimate):** a store paying Loox $49.99 + Smile $199 + an upsell app (~$30) + a pop-up app (~$20) ≈ $299/mo moves to StackSaver Growth at $49, saving **≈$3,000/yr**.

## Go-to-market (first 100 customers)
- **Shopify App Store:** the main channel. Rank for "reviews," "loyalty," "bundle," "all in one" and "app bundle." A free tier for fewer than 50 orders/mo gets reviews flowing early.
- **Communities:** r/shopify, r/ecommerce, r/dropship, r/smallbusiness, Shopify Community forums, and Facebook groups (Shopify Entrepreneurs, eCommerce Growth Hackers, DTC founders).
- **"Switch from X" SEO:**
  - "Yotpo alternative cheaper"
  - "Smile.io alternative flat price"
  - "Loox alternative"
  - "reduce Shopify app costs"
  - "Shopify app audit"
  - "Judge.me vs Yotpo"
- **Agency and Shopify-expert partners:** a 30% rev share for Shopify Partners who move client stores, plus white-label reports.
- **Timing:** launch the "BFCM app-bill audit" campaign in Sept–Oct each year.

## Risks and incumbent moats
- **Shopify App Store ranking and review-count moat** held by Judge.me, Klaviyo and Yotpo. Answer: a free tier plus a review-migration tool. Launch in a niche first ("all-in-one for stores under 300 orders").
- **Existing bundles (Vitals and others).** Answer: compete on speed, no order tiers, and migration quality. Validate their weaknesses before building.
- **Shopify platform risk:** checkout extensibility changes, Billing API rules, and a revenue share above Shopify's developer threshold (verify current terms). Answer: build on theme app extensions and checkout UI extensions only, with no theme code injection.
- **Breadth versus depth.** Each module must match the core of a specialist app. Answer: ship 5 modules well and add more later.
- **Loyalty liability data.** Points balances must migrate exactly. Answer: reconciliation reports and a merchant sign-off step.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 3 | 5 | 4 | **20** |

## Sources
- [Shopify App Costs in 2026: Audit the Real Bill – PandaCodeGen](https://www.pandacodegen.com/blog/shopify-app-costs-real-monthly-bill) (Mar 19, 2026; prices verified Aug 2, 2026)
- [Reduce Shopify App Costs: A Founder's Playbook for 2026 – AppStoreResearch](https://appstoreresearch.com/blog/reduce-shopify-app-costs) (Apr 24, 2026)
- [Yotpo Product Reviews – 1-star reviews, Shopify App Store](https://apps.shopify.com/yotpo-social-reviews/reviews?ratings%5B%5D=1) (Dec 2025–Aug 2026)
- [Smile: Loyalty & Rewards – 1-star reviews, Shopify App Store](https://apps.shopify.com/smile-io/reviews?ratings%5B%5D=1) (Jan 2025–Jul 2026)

## Verification (Sep 24 2026)
- ✅ Prices verified Aug 2 2026: Judge.me $15, Loox $49.99, Yotpo Starter $15, Smile Essential $15, Recharge $99 + 1.49% + 19¢, Bold $24.99, PageFly $24, Gorgias $10 — confirmed. Order caps added (Loox 300 orders, Smile 500), which support the "no order-volume tiers" wedge ([source](https://www.pandacodegen.com/blog/shopify-app-costs-real-monthly-bill))
- ✅ Yotpo: "no cheaper option than $129" (Jul 6 2026); Verified Buyer badge for imported reviews moved from Pro to Premium/Enterprise (Aug 20 2026); ~$7,000/yr contract vs a $329/mo package, Okendo $299/mo (Dec 10 2025); "only AI" support (Feb 7 2026) — confirmed ([source](https://apps.shopify.com/yotpo-social-reviews/reviews?ratings%5B%5D=1))
- ✅ Smile.io: "forced to pay $199/mo FOREVER or Cancel" (May 2 2026); $79 charge on the free plan (Apr 7 2026); CVR-dropping bugs (Jul 7 2026) — confirmed ([source](https://apps.shopify.com/smile-io/reviews?ratings%5B%5D=1))
- Scores unchanged.
