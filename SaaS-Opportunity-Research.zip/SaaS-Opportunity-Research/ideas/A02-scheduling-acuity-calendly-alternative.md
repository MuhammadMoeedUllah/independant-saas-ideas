# BookFlat: a cheaper, better Acuity / Calendly / Setmore for solo and small-team appointment businesses

**One-liner:** Booking pages with SMS reminders, deposits, no-show fees and intake forms included at one flat price, on your own domain, with no per-seat creep. Best sold as a module bundled with A01 (forms) and A03 (texting) rather than on its own.

## Snapshot
- **Replaces:**
  - **Calendly** (UseCarly guide, Aug 22, 2026), per seat:
    - Free
    - Standard $10 annual / $12 monthly
    - **Standard Plus $18/$24** (new)
    - Teams $16/$20
    - **Teams Plus $24/$32** (new)
    - Enterprise from about $15k/yr with a 50-seat minimum
    Round-robin and lead routing stay locked to Teams and above.
  - **Acuity Scheduling** (Squarespace), per GlossGenius (Apr 1, 2026). Acuity has **no built-in payment processing** (it connects to Stripe, Square or PayPal).
    - Starter $20/mo monthly or $16 annual: 1 calendar, **email reminders only**
    - Standard $34/$27: 6 calendars, SMS reminders
    - Premium $61/$49: 36 calendars, **HIPAA only here or on Enterprise**
  - **Setmore** (Trafft, verified Jul 30, 2026): Free (4 users, 200 appointments/mo). Pro $5/user/mo annual or about $9–12 monthly. **No custom domain on any tier.** SMS and two-way sync are Pro only.
  - **SimplyBook.me**: tiered plans with add-ons (not re-verified in this pass).
- **Recent price hikes / changes:**
  - Calendly added two **AI-bundle tiers on Aug 19, 2026**, which pushes an $8/seat upsell (Notetaker, the "Callie" assistant).
  - Calendly's monthly billing costs 20–33% more than annual.
  - Acuity's parent Squarespace was **taken private by PE firm Permira (about $7.2B, 2024)**. Users report login and identity problems and more bugs since the Squarespace integration.
  - Acuity renamed its tiers (Starter/Standard/Premium) and keeps SMS reminders off the cheapest plan.
- **Who buys:** solo and small-team appointment businesses not locked into a vertical suite: coaches, tutors, music teachers, photographers, consultants, therapists and counselors, trainers, pet groomers, mobile detailers. The buyer is the owner, paying with a card.
- **US market size:** estimate. Several million US sole proprietors and small service firms book by appointment. The Squarespace/Acuity install base alone is large but not published.
- **Urgency trigger (why they'd switch NOW):** Acuity's annual renewal dates combined with bugs and outages since the Squarespace integration. Calendly's new AI-tier upsell (Aug 2026). No-show losses that SMS reminders plus deposits fix right away.
- **Fastest-selling states/metros:** no state-law driver. Target dense solo-service metros (LA, NYC, Miami, Austin, Denver, Atlanta) and Canada/US border time-zone users hurt by DST bugs.

## Pain points (evidence)
- **[Lock-in/Contracts]** An Acuity customer says the "cancel anytime" marketing didn't match the actual 14-day refund window on annual plans (Trustpilot, Sept 23, 2026) ([source](https://www.trustpilot.com/review/acuityscheduling.com))
- **[Missing features]** A British Columbia user says appointments showed at the wrong time after a daylight-saving change, risking double-bookings (Trustpilot, Sept 19, 2026) ([source](https://www.trustpilot.com/review/acuityscheduling.com))
- **[Support]** A long-time Acuity user got stuck with two conflicting logins after the Squarespace acquisition, and support couldn't fix it after many contacts (Trustpilot, May 16, 2026) ([source](https://www.trustpilot.com/review/acuityscheduling.com))
- **[Support]** Growing bugs and outages kept clients from booking, so the reviewer moved to a competitor (Trustpilot, Sept 10, 2026) ([source](https://www.trustpilot.com/review/acuityscheduling.com))
- **[Support]** Acuity support replied with generic "we're working on it" messages and no workaround while bookings were disrupted (Trustpilot, Sept 19, 2026) ([source](https://www.trustpilot.com/review/acuityscheduling.com))
- **[Complexity/UX]** Clients find Acuity's booking flow "clunky", with too many account requirements that put people off booking (Trustpilot, Sept 8, 2026) ([source](https://www.trustpilot.com/review/acuityscheduling.com))
- **[Price]** Acuity's SMS reminders need the $34/mo Standard plan, and the $20 Starter is email-only (Fractal Apps, Jul 29, 2026) ([source](https://www.fractalapps.dev/blog/acuity-scheduling-alternatives-for-sms-reminders/))
- **[Missing features]** Setmore: Google Calendar sync failures are the top recurring complaint across years of reviews. There is no custom domain on any tier, and SMS and two-way sync sit behind Pro (Trafft summary of Capterra/G2, Jul 2026) ([source](https://trafft.com/setmore-reviews/))
- **[Support]** A Calendly support agent closed a chat after a long wait without resolving the issue (Trustpilot, Sept 18, 2026) ([source](https://www.trustpilot.com/review/calendly.com))
- **[Price]** On Calendly, round-robin and routing need Teams ($16–20/seat), and the new Plus tiers add $8/seat for AI (UseCarly, Aug 22, 2026) ([source](https://www.usecarly.com/blog/calendly-standard-plus-pricing/))

**Honest read:** complaint volume is moderate (Calendly is 4.1/5 on Trustpilot, Acuity 3.7/5), and the low end is already cheap (Setmore at $5/user, free Google Calendar booking pages, Cal.com). Vertical suites (GlossGenius, Vagaro, Square Appointments) own salons and spas. A standalone scheduler is a weak business. **As a bundled module** (booking, intake form, deposit and SMS reminders in one link), it strengthens A01 and A03.

## What we build (the better version)
1. **Booking page on your own domain** (`book.yourbiz.com`) with services, durations, buffers, and multiple staff and locations. **MVP**
2. **Two-way Google and Microsoft calendar sync** with conflict checks and a DST-safe time-zone engine plus tests. **MVP**
3. **SMS and email reminders on every plan** (at-cost SMS), with confirm/reschedule by reply ("C to confirm"). **MVP**
4. **Deposits, prepayment and no-show fees** through the business's own Stripe or Square. **MVP**
5. **Intake forms attached to service types**, reusing A01. HIPAA mode in **V2**.
6. **No client account required.** Clients book in 3 taps, and Apple and Google wallet passes are **V2**.
7. **Group classes, packages and memberships** (e.g., 10-session pack). **V2**
8. **Round-robin, routing forms and team pages at no extra per-seat charge.** **MVP** for round-robin, **V2** for routing.
9. **Waitlist auto-fill.** When a slot opens, the next person on the waitlist gets an SMS. **V2**
10. **AI booking over SMS/webchat** ("Do you have Thursday after 5?"), shared with A03. **V2**
11. **One-click import** of services, availability and future appointments from Acuity and Calendly exports. **MVP** (CSV or ICS)

## Pricing to win
- **Solo $9/mo:** 1 calendar, SMS reminders at cost, deposits, custom domain.
- **Team $29/mo flat:** up to 10 staff and 3 locations.
- **Bundle:** included free with FormFlare Pro (A01) or the A03 texting plan.
- **Comparisons:**
  - Acuity Standard is $34 monthly, just to get SMS.
  - Calendly Teams for 5 people is $80–100/mo.
- **Typical savings:** a 5-staff studio on Calendly Teams ($100/mo monthly) moving to $29 saves **about $850/yr**. A solo on Acuity Standard ($34) moving to $9 saves **$300/yr**.

## Go-to-market (first 100 customers)
- Bundle with A01 and A03 customers first. It's the easiest upsell.
- **Communities:** r/smallbusiness, r/Entrepreneur, r/photography and r/WeddingPhotography, r/personaltraining, r/tutor, r/musicteachers, and Squarespace designer communities.
- **SEO:**
  - "Acuity alternative with SMS reminders"
  - "Acuity Squarespace login problem"
  - "Calendly alternative no per-seat"
  - "booking page custom domain free"
  - "Setmore custom domain"
- **Partners:** Squarespace/Wix web designers (resell with the site), and coach-training programs.
- **Directories:** Capterra/G2 listings with a free tier, plus Product Hunt.

## Risks and incumbent moats
- **Commodity market** with free tiers everywhere. Mitigate by bundling rather than selling standalone.
- **Calendar sync reliability** is table stakes, so invest in sync tests and a DST test suite.
- **Payments** stay in the customer's own Stripe or Square account, which avoids money-transmission issues.
- **Vertical suites** (salon/spa, medical) have deep workflows, so avoid those verticals.
- **Squarespace bundling:** Acuity comes inside website plans. Win with better SMS and deposits, plus designer partnerships.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 2 | 2 | 4 | 4 | 4 | **16** |

## Sources
- [Calendly Standard Plus and Teams Plus Pricing Explained – UseCarly](https://www.usecarly.com/blog/calendly-standard-plus-pricing/) (Aug 22, 2026)
- [Acuity Scheduling pricing – GlossGenius](https://glossgenius.com/blog/acuity-scheduling-price) (Apr 1, 2026)
- [Acuity Scheduling Alternatives for SMS Reminders – Fractal Apps](https://www.fractalapps.dev/blog/acuity-scheduling-alternatives-for-sms-reminders/) (Jul 29, 2026)
- [Setmore Reviews: The Good, the Bad, and the Ugly – Trafft](https://trafft.com/setmore-reviews/) (verified Jul 30, 2026)
- [Acuity Scheduling on Trustpilot](https://www.trustpilot.com/review/acuityscheduling.com) (3.7/5, 643 reviews)
- [Calendly on Trustpilot](https://www.trustpilot.com/review/calendly.com) (4.1/5, 675 reviews)
- [Squarespace acquired by Permira for $7.2 billion – For Fairness Sake](https://forfairnesssake.substack.com/p/for-fairness-sake-squarespace-acquired)
- [SimplyBook.me Pricing](https://simplybook.me/en/pricing)
