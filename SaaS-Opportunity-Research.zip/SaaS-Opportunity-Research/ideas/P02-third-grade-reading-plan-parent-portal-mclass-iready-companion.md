# ReadingPlan Home: a cheaper, better parent-facing layer than mCLASS Home Connect, i-Ready family reports and Word-template reading plans, for K–3 schools under third-grade reading laws

**One-liner:** Turns a screener flag from any vendor (mCLASS/DIBELS, Acadience, i-Ready, NWEA MAP) into a state-compliant individual reading plan. It adds a plain-language parent notice in the family's language, weekly 10-minute at-home activities, and a shared progress and contact log that holds up in a retention or good-cause review.

## Snapshot
- **Replaces / sits beside:**
  - **Amplify mCLASS (DIBELS 8):** North Carolina's statewide K–5 assessment for Read to Achieve and reading-camp eligibility. The family side is a "Home Connect" site plus parent letters in **English and Spanish**. Pricing is by sales quote only ([Amplify NC](https://amplify.com/northcarolina/), accessed Sep 2026).
  - **Acadience, i-Ready (Curriculum Associates), NWEA MAP (HMH):** district contracts, not re-priced. None is sold as a standalone reading-plan and parent portal.
  - **Status quo:** locally built Word/PDF templates. Nebraska's guidance says districts "develop templates locally" ([NDE IRIP guidance, updated Aug 1 2025](https://www.education.ne.gov/wp-content/uploads/2025/08/Individual-Reading-Improvement-Plans-Guidance-Document2023.pdf)). Ohio publishes a PDF RIMP (Reading Improvement and Monitoring Plan) decision tool ([Ohio DEW](https://education.ohio.gov/getattachment/Topics/Learning-in-Ohio/Literacy/Third-Grade-Reading-Guarantee/RIMP-Decision-Tool-Revised-1.pdf.aspx?lang=en-US)).
  - **Adjacent parent-paid tool:** Reading Pacer fluency scans, free tier plus a **$19 one-time quarter** ([Reading Pacer](https://readingpacer.com/)).
- **Recent price hikes / changes (switching windows):**
  - **Indiana (SEA 1, 2024), first retention year (2024–25)** ([Chalkbeat, Nov 5 2025](https://www.chalkbeat.org/indiana/2025/11/05/how-many-students-held-back-under-retention-law/)):
    - About **3,040** third-graders retained.
    - **87.3%** passed IREAD-3; **10,663** failed.
    - **6,950** good-cause exemptions.
    - About **673** students left the state or became homeschooled.
  - **New or strengthened laws phasing in** ([Reading Pacer law tracker, Jun 2026](https://readingpacer.com/reading-laws/); secondary source, verify against statutes):
    - WV: 2026–27.
    - MD: 2027–28 (with parent consent).
    - OK: 2027–28.
    - WI: Sep 1 2027.
    - NV: Jul 1 2028.
    - UT: phase-in through 2030.
  - **Counts:**
    - 18 states have some form of third-grade retention. Ohio weakened its law in 2023 and Michigan dropped retention ([The 74, May 12 2026](https://www.the74million.org/article/3rd-grade-retention-isnt-really-about-kids-its-about-adults-who-teach-them/)).
    - K-12 Dive counts 14 states with test-based retention in effect plus 4 more coming ([K-12 Dive, 2025](https://www.k12dive.com/news/3rd-graders-flagged-retention-small-meaningful-improvement/753214/)).
  - **Evidence behind the pitch:**
    - NBER's Michigan study: children flagged for retention gained 0.045 standard deviations whether or not they were held back. The gains come from the adult actions the flag triggers: parent involvement, tutoring and teacher support ([K-12 Dive](https://www.k12dive.com/news/3rd-graders-flagged-retention-small-meaningful-improvement/753214/)).
    - Mississippi's model pairs **individual reading plans, parent notification and "Read at Home" lessons** ([The 74](https://www.the74million.org/article/3rd-grade-retention-isnt-really-about-kids-its-about-adults-who-teach-them/)).
  - **Federal:** H.R. 7890 (House, Sep 17 2026) ties the $194M in literacy grants to the science of reading ([EdWeek](https://www.edweek.org/teaching-learning/federal-science-of-reading-legislation-passes-the-house/2026/09)).
- **Who buys:**
  1. The **principal, assistant principal or K–3 literacy coach** at a single elementary school, with building or Title I funds, kept small enough to fall under local purchasing thresholds (these vary).
  2. **Charter and private schools** (single-site decisions).
  3. **Parents directly**, through a freemium "home plan" once a letter arrives.
  4. **Tutoring centers** serving flagged children.
  - Honest note: **district-wide deals are slow** (DPA, board approval, often 3–9 months). Land with teachers and schools first.
- **US market size:**
  - Indiana alone tests **84,000+** third-graders a year, and 10,663 failed in 2025 ([Chalkbeat](https://www.chalkbeat.org/indiana/2025/11/05/how-many-students-held-back-under-retention-law/)).
  - Estimate: flagged K–3 students run to hundreds of thousands a year across the roughly 20+ states that require plans and notices.
  - Buyer count: tens of thousands of US public elementary schools (NCES; not re-checked).
- **Urgency trigger (why they'd switch NOW):**
  - **Screening windows:** beginning of year (Aug–Oct), middle of year (Jan), end of year (Apr–May).
  - **Hard deadlines:** e.g. Nebraska requires the plan within **30 days** of identification and a written parent notice within **15 working days** ([NDE](https://www.education.ne.gov/wp-content/uploads/2025/08/Individual-Reading-Improvement-Plans-Guidance-Document2023.pdf)).
  - **IREAD-3 and state tests in spring**, then summer reading camps.
- **Fastest-selling states/metros:**
  - **Mandatory-retention states:** AL, AZ, AR, FL, IN, LA, MS, NC, SC, TN.
  - **West Virginia** (new in 2026–27).
  - **Plan and notice states:** NE, OH, AK.
  - **Charter-dense metros:** Indianapolis, Phoenix, Charlotte, Florida metros.

## Pain points (evidence)
- **[Stress]** Indiana educators call IREAD-3 a "pressure cooker". One teacher says she feels it's her fault if children don't pass, and a mother says her high-achieving daughter is "terrified" of the test ([IPM, Sep 12 2025](https://www.ipm.org/news/2025-09-12/retention-law-puts-high-stakes-on-third-grade-reading-test)).
- **[Equity]** IREAD-3 pass rates are 76.1% for Black and Hispanic students versus 92.3% for White students ([Purdue College of Education, Mar 2 2026](https://education.purdue.edu/news/2026/03/02/high-stakes-literacy-testing-indianas-iread-3/)).
- **[Unfunded remediation]** Summer school is "unfunded" and ranges from a 2-week online session to 6+ weeks ([Purdue](https://education.purdue.edu/news/2026/03/02/high-stakes-literacy-testing-indianas-iread-3/)).
- **[Rigid]** A single test decides, with no credit for classroom or progress-monitoring data, and no read-aloud accommodations for dyslexic students ([Purdue](https://education.purdue.edu/news/2026/03/02/high-stakes-literacy-testing-indianas-iread-3/)).
- **[Families leave]** About 673 Indiana students left the state or switched to homeschool in the first retention year ([Chalkbeat](https://www.chalkbeat.org/indiana/2025/11/05/how-many-students-held-back-under-retention-law/)).
- **[Paperwork]** Nebraska's plans must include screening and diagnostic data, interventions, progress monitoring, a **home support plan** (including parent-guided home reading) and **dated documentation of every parent contact**. Each district builds its own template ([NDE](https://www.education.ne.gov/wp-content/uploads/2025/08/Individual-Reading-Improvement-Plans-Guidance-Document2023.pdf)).
- **[Parent trust]** Ohio's Statewide Family Engagement Center publishes guidance on turning the legally required RIMP letter into a "foundation for a partnership", which suggests today's letters don't build trust ([OSU, Mar 2025](https://ohiofamiliesengage.osu.edu/resources/build-trust-with-families-through-the-reading-improvement-and-monitoring-plan-rimp-letter/)).
- **[Incumbent gap]** mCLASS family materials are a Home Connect site and English/Spanish letters. There is no two-way plan, activity check-off or contact log ([Amplify NC](https://amplify.com/northcarolina/)).
- **[Parent confusion]** Understood tells parents to get a copy of the state law, ask the school to explain it and call their state's Parent Training and Information Center, because the rules vary so much ([Understood](https://www.understood.org/en/articles/third-grade-retention-laws-what-you-need-to-know)).

## What we build (the better version)
1. **MVP** **State rulebook** for 12 launch states (IN, NC, OH, TN, FL, MS, SC, AL, AZ, AR, NE, WV): plan-field requirements, deadlines, good-cause exemption lists and parent-notice templates, each with a "last verified" date and statute link.
2. **MVP** **Screener import by CSV** from the mCLASS, Acadience, i-Ready and MAP exports teachers already download. No API partnership is needed. The flag list is built automatically.
3. **MVP** **Plan builder:** prefilled from subscores (phonemic awareness, decoding, fluency, comprehension). It sets intervention, minutes per week, progress-monitoring schedule and home-support plan, with parent e-signature.
4. **MVP** **Parent notice generator:** plain language at a 6th-grade reading level, with human-reviewed translations for the top 10 languages and AI translation beyond that. Sent by SMS, email or print, with read receipts and an automatic **contact log**.
5. **MVP** **At-home activity cards** matched to the gap. Ten minutes, no device needed, with a "we did it" tap for parents.
6. **MVP** **Shared progress chart**, and a one-click PDF "retention/good-cause file" for the committee.
7. **V2** Portfolio builder for states that allow a portfolio or alternative-assessment exemption.
8. **V2** Summer reading-camp roster, attendance and end-of-camp retest tracking.
9. **V2** Clever/ClassLink/OneRoster rostering and SSO. Multi-school district dashboard.
10. **V2** Parent-paid "Home Coach" ($6/mo): daily decodables and fluency checks from the P01 engine.

## Pricing to win
- **Free for one teacher** (up to 10 students). **School: $1,200/yr flat**, unlimited K–3 plans. **District: $1/K–3 student/yr** with a signed DPA. **Parent Home Coach: $6/mo.**
- **Comparison:** no incumbent sells this standalone. The real cost is staff time. Estimate: 45–60 minutes per plan, notice and contact log × 60 flagged students is about **45–60 staff hours per school per window**. At a teacher's hourly cost, $1,200 pays back in the first window.

## Go-to-market (first 100 customers)
- **Teacher-led freemium:** K–3 and literacy-coach Facebook groups, r/Teachers and **The Reading League** state chapters, with a free "IREAD-3 / Read to Achieve parent letter" generator as the lead magnet.
- **State networks:** Indiana literacy coaches (IDOE-funded coach cohorts), NC DPI regional literacy teams, Ohio's Statewide Family Engagement Center (content partner) and state principals' associations.
- **Parent side:** state Parent Training and Information Centers, Decoding Dyslexia chapters and PTO cross-sell (P05).
- **SEO:** "what is a RIMP", "IREAD-3 practice at home", "Read to Achieve reading camp", "good cause exemption [state]".
- **Charter networks** in IN, AZ, FL and NC: one decision-maker for several schools.

## Risks and incumbent moats
- **Procurement speed** (biggest risk). Mitigate with freemium, a school-level price under local thresholds and a pre-signed SDPC National Data Privacy Agreement.
- **Screener vendors add parent modules.** Amplify and Curriculum Associates could build this. Our moat is multi-screener support, the state rulebook and the parent contact log that compliance reviewers want.
- **FERPA:** we act as a "school official" under district control. No re-disclosure, no advertising, and deletion at contract end.
- **State student-privacy laws:** NY Ed Law 2-d (with the parents' bill of rights), IL SOPPA (published contracts and breach notice), CA SOPIPA and AB 1584.
- **COPPA:** there are no student logins. School use relies on school authorization for under-13s, and parent accounts are adults.
- **Cheap compliance stack:** data minimization (name, grade, local student ID, scores; no SSN or birthdate), US hosting, encryption, audit logs. A SOC 2 readiness tool once revenue exceeds about $100k.
- **Translation liability:** templates reviewed by human translators, with the AI flagging uncertain passages.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 2 | 4 | **16** |

## Sources
- [How many Indiana students were held back – Chalkbeat, Nov 5 2025](https://www.chalkbeat.org/indiana/2025/11/05/how-many-students-held-back-under-retention-law/)
- [Retention law puts high stakes on third-grade reading test – IPM, Sep 12 2025](https://www.ipm.org/news/2025-09-12/retention-law-puts-high-stakes-on-third-grade-reading-test)
- [High Stakes Literacy Testing: Indiana's IREAD-3 – Purdue, Mar 2 2026](https://education.purdue.edu/news/2026/03/02/high-stakes-literacy-testing-indianas-iread-3/)
- [3rd-Grade Retention Isn't Really About Kids – The 74, May 12 2026](https://www.the74million.org/article/3rd-grade-retention-isnt-really-about-kids-its-about-adults-who-teach-them/)
- [3rd graders flagged for retention make small gains – K-12 Dive, 2025](https://www.k12dive.com/news/3rd-graders-flagged-retention-small-meaningful-improvement/753214/)
- [Third-Grade Reading Laws by State (2026) – Reading Pacer](https://readingpacer.com/reading-laws/)
- [Individual Reading Improvement Plans guidance – Nebraska DOE, Aug 2025](https://www.education.ne.gov/wp-content/uploads/2025/08/Individual-Reading-Improvement-Plans-Guidance-Document2023.pdf)
- [Build Trust Through the RIMP Letter – Ohio Statewide Family Engagement Center, Mar 2025](https://ohiofamiliesengage.osu.edu/resources/build-trust-with-families-through-the-reading-improvement-and-monitoring-plan-rimp-letter/)
- [RIMP Decision Tool 2025 – Ohio DEW](https://education.ohio.gov/getattachment/Topics/Learning-in-Ohio/Literacy/Third-Grade-Reading-Guarantee/RIMP-Decision-Tool-Revised-1.pdf.aspx?lang=en-US)
- [Amplify mCLASS North Carolina](https://amplify.com/northcarolina/)
- [Third-grade retention laws – Understood](https://www.understood.org/en/articles/third-grade-retention-laws-what-you-need-to-know)
- [Federal Science of Reading bill passes House – EdWeek, Sep 2026](https://www.edweek.org/teaching-learning/federal-science-of-reading-legislation-passes-the-house/2026/09)
- [Reading Pacer](https://readingpacer.com/)
