# SiteLoop: a cheaper, better Campspot / Newbook / Staylist for independent campgrounds, RV parks, glamping and small marinas

**One-liner:** A flat-fee reservation and park management system for independent campgrounds and RV parks, with no guest-paid booking fees. It handles interactive site maps, seasonal and monthly billing, metered utility billing and a camp-store POS, in the park's own brand.

## Snapshot
- **Replaces:**
  - **Campspot:** a subscription plus a **guest-paid booking fee on online reservations**. The pricing page gives no amounts and requires a demo. Campspot says "many of our customers add a surcharge to customer orders to offset the Campspot reservation fee." It states no setup fees and no long-term contracts, and gives Growth Package parks preferred Marketplace exposure ([Campspot pricing, viewed Sept 2026](https://software.campspot.com/pricing/)).
  - **Newbook, Staylist, Firefly (campground), Dockwa (marinas):** competitors. Pricing was not verified in this pass.
- **Recent price hikes / changes:**
  - Campspot's model pushes fees onto campers at checkout, which clashes with all-in-price rules. The **FTC junk-fee rule for short-term lodging took effect May 12, 2025** ([FTC](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)). Whether campsites and RV sites count as "short-term lodging" should be confirmed against the [FTC FAQ](https://www.ftc.gov/business-guidance/resources/rule-unfair-or-deceptive-fees-frequently-asked-questions). California's all-in pricing law (SB 478, effective July 1, 2024) applies to consumer prices generally (verify).
  - No dated 2024-2026 list-price increase was found for Campspot in this pass. Newbook's comparison lists "unpredictable pricing" as a Campspot con ([Newbook, Oct 27, 2025](https://www.newbook.cloud/campspot-reviews-features-support-and-why-operators-look-for-alternatives/)).
- **Who buys:** Owner-operators of private campgrounds, RV parks, RV resorts, glamping sites, mobile-home/RV long-term parks and small marinas, typically 20-300 sites. Often family-owned. Buyer is the owner or office manager.
- **US market size:** Estimate: low tens of thousands of privately owned campgrounds and RV parks, plus several thousand marinas. Unverified; ARVC and marina association figures to be checked. The segment has seen heavy PE roll-up of larger parks, so independents are the target.
- **Urgency trigger (why they'd switch NOW):** Off-season (Oct-Mar in most states) is the migration window before the next season. Junk-fee rules make guest-paid platform fees awkward. Support delays hurt most in peak season, so owners decide to switch in fall.
- **Fastest-selling states/metros:** High campground-count and RV-snowbird states: Texas, Florida, Arizona, California, Michigan, Pennsylvania, New York, Wisconsin, North Carolina and Tennessee. Snowbird winter-park clusters in AZ (Yuma, Mesa), FL and South Texas (Rio Grande Valley) buy in summer and fall. State list is an estimate to verify with ARVC data.

## Pain points (evidence)
- **[Price/Guest experience]** Campspot charges campers a booking fee for online reservations, and parks often add their own surcharge to offset Campspot's reservation fee ([Campspot pricing](https://software.campspot.com/pricing/)).
- **[Support]** A campground owner (Jan 2026) reported 5-7 day response times, with incomplete answers that forced repeated follow-ups ([Capterra](https://www.capterra.com/p/176517/Campspot/reviews/)).
- **[Reliability]** A manager (July 2025) said recurring bugs show up every couple of months and support gives the same repetitive fixes ([Capterra](https://www.capterra.com/p/176517/Campspot/reviews/)).
- **[Support]** An owner (Apr 2023) said no one answers the phone and callbacks take days or weeks ([Capterra](https://www.capterra.com/p/176517/Campspot/reviews/)).
- **[Missing features]** A manager (Sept 2024) could not check out departing guests, which stopped them re-renting the site right away ([Capterra](https://www.capterra.com/p/176517/Campspot/reviews/)).
- **[Complexity/UX]** A GM (Oct 2023) said updating rates by CSV is cumbersome and sometimes takes several attempts ([Capterra](https://www.capterra.com/p/176517/Campspot/reviews/)).
- **[Missing features]** An owner (Oct 2023) had limited control over refunds and was forced to apply credits instead ([Capterra](https://www.capterra.com/p/176517/Campspot/reviews/)).
- **[Complexity/UX]** A GM said long-term camper billing confuses customers and needs manual edits. This review is older (2020) ([Capterra](https://www.capterra.com/p/176517/Campspot/reviews/)).
- **[Lock-in/Branding]** Operators switch because the booking engine carries the software provider's branding, plus limited integrations and automation ([Newbook, Oct 2025](https://www.newbook.cloud/campspot-reviews-features-support-and-why-operators-look-for-alternatives/)).
- **[Support]** Support is limited to email and phone during business hours, and feedback ranges from fast to "frustrating delays during busy times" ([Newbook](https://www.newbook.cloud/campspot-reviews-features-support-and-why-operators-look-for-alternatives/)).
- *Note:* Campspot still rates 4.5/5 on 90 Capterra reviews, so the pain is real but not universal. Newbook is a competitor source.

## What we build (the better version)
1. **MVP: Interactive site map booking.** Upload a park map image, then draw site pins with AI assistance. Filters for rig length, amperage (30/50A), pull-through and pet-friendly.
2. **MVP: Branded booking engine with all-in pricing.** No platform fee charged to campers. Park-set add-ons such as firewood, golf carts and early check-in.
3. **MVP: Nightly, weekly, monthly and seasonal rate rules**, edited in a spreadsheet-like grid (no CSV round-trips). Minimum stays for holidays.
4. **MVP: Long-term and seasonal camper billing.** Recurring invoices, autopay, and **metered electric billing** by entering meter readings on a phone (photo plus OCR).
5. **MVP: Front-desk check-in/out.** Instant site release for re-rental, waitlist for sold-out dates, and gate-code texts.
6. **MVP: Payments through Stripe** with deposits, full or partial refunds under the owner's control, and next-day payouts.
7. **MVP: Camp store POS** (Tap to Pay) for ice, firewood and propane, with simple inventory.
8. **V2: Marina module.** Slip maps, transient and seasonal slips, boat length and beam, fuel-dock sales (Dockwa alternative).
9. **V2: Distribution.** Listings on Hipcamp, Good Sam and RVshare-type marketplaces through an API or iCal where available, and Google "Things to do" and free booking links.
10. **V2: Glamping and cabin housekeeping boards**, digital waivers, and activity booking (shares the D07 engine).

## Pricing to win
- **SiteLoop:** $99/mo for up to 75 sites, $179/mo for 76-200 sites, $249/mo for 201-300 sites. **$0 camper booking fees.** Processing at Stripe cost plus a disclosed markup. No contract, free migration in off-season.
- **Savings framing:** Campspot's guest fee amount isn't public. For a park doing 3,000 online bookings a year, every $1 of guest fee is $3,000/yr of friction added to the camper's price. Parks can keep that margin themselves or show a lower all-in price. *Get actual Campspot guest-fee amounts from a checkout test in the next pass.*

## Go-to-market (first 100 customers)
- **ARVC** (National Association of RV Parks & Campgrounds): vendor listing plus exhibiting at its annual Outdoor Hospitality Conference & Expo.
- **State campground associations** (most states have one, for example in TX, FL, MI, PA, NY and CA; verify names and vendor programs): fall and winter conventions are the buying season.
- **KOA:** KOA franchisees are locked into KOA's system, so target **independent** parks that left KOA or never joined. Good Sam-rated parks are a list source.
- **Reddit and forums:** r/RVLiving and r/GoRVing reach campers (demand-side stories about booking fees). Owner Facebook groups for RV park and campground owners are the buyer channel.
- **"Campspot alternative," "campground software no booking fees" SEO pages** and a free all-in-pricing compliance check.
- **Referral:** Campground brokers and consultants, since new owners often re-platform after an acquisition.

## Risks and incumbent moats
- **Campspot Marketplace demand:** Parks get bookings from Campspot's consumer marketplace, which is a network effect. Mitigation: parks keep marketplace listings where contracts allow, and we push Google, Hipcamp and direct.
- **Seasonal timing:** Nobody switches mid-season. Sales cycles are tied to the Oct-Mar window.
- **Utility billing and state landlord-tenant rules** for long-term RV residents vary by state. Mitigation: flexible billing, not legal logic.
- **Payments:** Stripe handles PCI.
- **Rural connectivity:** Parks often have bad internet. Offline-tolerant PWA with sync (V2).

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 3 | 4 | 2 | **16** |

## Sources
- [Campspot Pricing – Campspot Software](https://software.campspot.com/pricing/)
- [Campspot Reviews – Capterra](https://www.capterra.com/p/176517/Campspot/reviews/)
- [Campspot Reviews: Features, Support, Pricing – Newbook (Oct 27, 2025; competitor)](https://www.newbook.cloud/campspot-reviews-features-support-and-why-operators-look-for-alternatives/)
- [Campground Booking Software Comparison 2026 – CamperWatch](https://www.camperwatch.org/campground-booking-software)
- [Best Campground Management Software 2026 – Software Advice](https://www.softwareadvice.com/campground-management/)
- [FTC Rule on Unfair or Deceptive Fees to Take Effect May 12, 2025 – FTC](https://www.ftc.gov/news-events/news/press-releases/2025/05/ftc-rule-unfair-or-deceptive-fees-take-effect-may-12-2025)
- [Rule on Unfair or Deceptive Fees FAQ – FTC](https://www.ftc.gov/business-guidance/resources/rule-unfair-or-deceptive-fees-frequently-asked-questions)
