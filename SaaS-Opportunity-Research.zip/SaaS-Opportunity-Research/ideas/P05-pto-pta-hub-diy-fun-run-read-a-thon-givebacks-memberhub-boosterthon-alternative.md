# PTOHub: a cheaper, better Givebacks (MemberHub) / Konstella / MoneyMinder + Boosterthon / Apex for independent PTOs and parent groups

**One-liner:** One flat-fee hub for a school parent group, covering website, directory, volunteer sign-ups, store and tickets, a treasurer ledger and **DIY fun-run and read-a-thon pledge pages**. The school keeps the roughly 40–50% that fun-run companies have historically been reported to take.

## Snapshot
- **Replaces** (prices accessed Sep 2026 unless noted):
  - **Givebacks** (MemberHub is folded in; memberhub.com now redirects to givebacks.com) ([Givebacks pricing](https://www.givebacks.com/resources/pricing)):
    - **Plans:** Pro **$499/yr**, Premium **$599/yr**, Partner custom.
    - **Store and POS:** **1.05% + $0.65** platform fee plus Stripe **2.9% + 30¢**.
    - **Fundraisers:** a 0% "tip" model, or **7.5%** under the "percent" model.
    - **Direct donations:** 0% platform fee plus 1.99% + 49¢.
  - **Givebacks for state PTA units:** the software is free, but card payments cost **3.95% + $0.59** and processing is WePay only.
    - Massachusetts PTA says units "must" use it to manage members, officers and good standing ([MA PTA FAQ, rev. Feb 12 2026](https://www.massachusettspta.org/membership-2/faq-for-memberhub/)).
    - Washington State PTA made it the primary database from **Jul 1 2024** ([WSPTA](https://www.wastatepta.org/givebacks/)).
  - **MoneyMinder** (treasurer software): **$299/yr**. Includes a Cheddar Up Team edition and 990-N/990-EZ e-filing; the 8868 extension is +$25 ([MoneyMinder pricing](https://www.moneyminder.com/pricing)).
  - **Cheddar Up** ([Cheddar Up pricing](https://www.cheddarup.com/pricing)):
    - Free plan: 3.95% + 95¢ per card payment.
    - Pro: **$15/mo** billed annually.
    - Team: **$35/mo** billed annually, 3.59% + 59¢ per card payment.
  - **Konstella:** pricing not published; claims 5,000+ schools and 500,000+ families ([Konstella](https://www.konstella.com/)).
  - **Fun-run companies:**
    - **Booster (Boosterthon):** "charges a percentage based on the level of support" (not published). Its MyBooster online platform says schools keep 95% "on average" ([Booster FAQ](https://boosterthon.com/fundraising-faqs/)).
    - **Apex Leadership Co.:** quote only. Claims 5,000+ partner schools and $400M+ "profit for school communities" ([Apex](https://www.apexleadershipco.com/fun-run-fundraising)).
    - **Historical fee reports (old, verify current):** Boosterthon charged 48–60% (PTO Today message boards, ~2010) ([PTO Today](https://classic.ptotoday.com/boards/17-fundraising/149053-boosterthon-fun-run?start=18)), and 49% in a 2021 parent blog ([Frog Trouble Times](https://frogtroubletimes.substack.com/p/havent-they-gone-far-enough)).
  - **DIY pledge tool 99Pledges:** 0% platform fee, **3.49% + 49¢** processing, donor tips ([99Pledges](https://www.99pledges.com/pricing)).
- **Recent price hikes / changes (switching windows):**
  - MemberHub was absorbed into Givebacks, and several state PTAs made it mandatory: WA switched from MemberPlanet on Jul 1 2024 ([WSPTA](https://www.wastatepta.org/givebacks/)), and MA revised its FAQ in Feb 2026.
  - Givebacks' flat plans ($499–599/yr) replace the "free" framing for groups outside PTA partnerships.
  - A Givebacks reviewer says support now pushes users to AI tools (Feb 2026).
  - National PTA membership is about **2.5M**, down from 12.1M in 1962 ([PTO Today, 2026](https://www.ptotoday.com/pto-today-articles/pto-vs-pta-whats-the-difference)). Groups are drifting to independent PTOs that choose their own tools.
- **Who buys:**
  - **Primary:** presidents and treasurers of **independent PTOs**. Volunteer boards that decide in May–August and pay by card or check.
  - **Secondary:** PTA units for fun-run pledges and treasury only, since their state PTA locks membership into Givebacks.
- **US market size:**
  - About **23,000** National PTA local units ([Wikipedia](https://en.wikipedia.org/wiki/Parent%E2%80%93teacher_association)).
  - PTO Today says independent PTOs likely number "more than double" PTA units. Estimate: 45k–60k PTOs, or **70k–80k parent groups** in total.
  - Fun-run companies alone claim **$1B+ raised** (Booster, [site](https://boosterthon.com/)) and **$400M+** in school profit (Apex). That is a large pool being taxed.
- **Urgency trigger (why they'd switch NOW):**
  - **Board handoff** May–August.
  - **Fall fun-run season** Sep–Oct; spring read-a-thons Feb–Mar.
  - **990-N due on the 15th day of the 5th month** after fiscal year-end (Nov 15 for a June 30 fiscal year).
  - **Givebacks mandates** at state-PTA level push some units to disaffiliate and become PTOs.
- **Fastest-selling states/metros:**
  - **Sun Belt suburbs** where fun runs are standard (GA, SC, NC, FL, TX; Booster is based in Georgia). Estimate.
  - **Large suburban districts** with active PTOs.
  - **States whose PTAs mandate Givebacks** (MA confirmed; WA uses it as the statewide membership database, but the "mandate" wording is unverified; others listed on state PTA sites are unverified, e.g. [VA](https://vapta.org/memberhub/), [FL](https://www.floridapta.org/memberhub-givebacks/), [TN](https://tnpta.org/index.php/memberhub/)). Target their fun-run and treasury needs.

## Pain points (evidence)
- **[Price]** A Givebacks user says donations carry about 10% in charges. A $200 donation incurred a **$21.73** fee (Trustpilot, May 2024) ([Trustpilot](https://www.trustpilot.com/review/givebacks.com)).
- **[Support]** Givebacks representatives redirect questions to AI tools, and one was "snarky and obnoxious" (Trustpilot, Feb 2026) ([Trustpilot](https://www.trustpilot.com/review/givebacks.com)).
- **[Reliability]** In a school fundraiser, only part of the donations showed up in the account even though donors got confirmation emails (Trustpilot, Oct 2023) ([Trustpilot](https://www.trustpilot.com/review/givebacks.com)).
- **[Complexity/UX]** On MemberHub, a PTSA president couldn't remove a former account owner, emails arrived two weeks late and changing the bank account took over a month (Capterra, Sep 2021) ([Capterra](https://www.capterra.com/p/115300/MemberHub/reviews/)).
- **[Support]** MemberHub's unsubscribe failed after 20+ tries, and support never answered (Capterra, Dec 2022) ([Capterra](https://www.capterra.com/p/115300/MemberHub/reviews/)).
- **[Price/bugs]** A MoneyMinder treasurer paid extra for bank feeds that hadn't worked for at least a month. Another says the cost is "getting high" (Capterra, Sep 2025) ([Capterra](https://www.capterra.com/p/147716/MoneyMinder/reviews/?page=2)).
- **[Accuracy]** One PTA's MoneyMinder books showed more money than the bank at year-end ("way less money than the software said"). Another found reports cut off in March when pulling a July–June year (Capterra, Sep 2025 and Sep 2024) ([Capterra](https://www.capterra.com/p/147716/MoneyMinder/reviews/?page=2)).
- **[Price, fun runs]** Parents say Boosterthon charged "48%+" without clear disclosure. One school estimated the company got about $28k while the school netted about $18k (PTO Today boards, old, ~2010) ([PTO Today](https://classic.ptotoday.com/boards/17-fundraising/149053-boosterthon-fun-run?start=18)).
- **[Price/instruction time]** A 2021 parent post says the company kept 49% and that roughly two weeks of specials were replaced with company-led assemblies ([Frog Trouble Times, Oct 2021](https://frogtroubletimes.substack.com/p/havent-they-gone-far-enough)).
- **[Lock-in]** PTA units must use Givebacks for membership and good standing, with WePay the only processor (MA PTA FAQ, Feb 2026) ([MA PTA](https://www.massachusettspta.org/membership-2/faq-for-memberhub/)).

## What we build (the better version)
1. **MVP** **Group site and opt-in directory** (families control what's shown), memberships and dues with a **state-PTA remittance export**, and volunteer sign-ups with reminders.
2. **MVP** **Store and tickets** (spirit wear, carnival, auction), **Tap to Pay** at events and a payer-covers-fees toggle.
3. **MVP** **DIY fun-run and read-a-thon pledge pages:**
   - Parents create their own child's page (first name + last initial, no photo by default).
   - Flat or per-lap/per-minute pledges.
   - Volunteers enter laps or minutes from a phone.
   - Automatic post-event invoices to pledgers.
   - Class leaderboards and a prize-budget calculator.
   - Templates for no-prize and book-prize events, plus an event-day playbook (music, T-shirt vendors, timing).
4. **MVP** **Treasurer ledger:**
   - Budget vs. actual, bank CSV import, receipt capture.
   - **Two-signer reimbursement approval.**
   - Fiscal-year reports that don't truncate, a year-end audit packet and **990-N reminders**.
5. **MVP** Email newsletters with one-click unsubscribe that actually works, plus auto-translation.
6. **V2** Bank feeds (Plaid), 1099-NEC and a 990-EZ helper.
7. **V2** Sponsor and business-ad pages, and employer matching-gift prompts.
8. **V2** Multi-school council view and a board-handoff kit (passwords, bank signers, calendar).

## Pricing to win
- **$199/yr flat per school**, unlimited admins. **0% platform fee.** Card processing at cost (about 2.9% + 30¢), with payers covering fees optionally.
- **Examples:**
  - vs Givebacks Pro ($499/yr): saves **$300/yr** plus the 1.05% + $0.65 store fee.
  - vs MoneyMinder ($299/yr, which already bundles Cheddar Up Team Edition, a "$576 value"): saves **about $100/yr**. A group paying for Cheddar Up Team separately ($420/yr) saves about $220/yr.
  - **Fun run:** a 500-student school raising **$40,000**. Estimate:
    - If a company keeps 40–50% (historical reports), the school gives up $16k–20k.
    - DIY with PTOHub: about $1.2k processing + $199 + $3k–5k for shirts and prizes.
    - The school keeps about **$34k** instead of about $20k–24k.

## Go-to-market (first 100 customers)
- **Events:** **PTO Today Expo** (regional shows) and state PTO and principal conferences.
- **Communities:** PTO Today message boards, r/PTA, r/Parenting, and Facebook groups for PTO presidents and treasurers.
- **Lead magnet:** a free "DIY Fun Run kit" (pledge page, volunteer lap app, T-shirt order form) and a "Boosterthon/Apex vs DIY net-proceeds calculator".
- **SEO:** "Boosterthon alternative", "Apex fun run percentage", "DIY read-a-thon pledge page", "PTO treasurer software", "MemberHub alternative".
- **Timing:** email campaigns to incoming presidents in May–July. Principal referrals (principals hate losing specials time to assemblies).

## Risks and incumbent moats
- **State PTA mandates for Givebacks:** don't fight them. Target PTOs first. Sell PTA units only fun-run and treasury modules, with an export for Givebacks dues.
- **Fun-run companies bring people:** they supply staff, assemblies and prizes, and we can't. Our answer is playbooks, local vendor lists and a "hire a local DJ/MC" checklist.
- **Volunteer churn:** the annual handoff kit and board-transfer workflow keep the account alive year to year.
- **Payments and fraud:** Stripe Connect with the group as merchant of record; payout holds for new accounts.
- **Student privacy:**
  - Pledge pages are created by parents, not imported from the school's student information system, which avoids FERPA disclosure questions.
  - No child accounts, so COPPA isn't triggered.
  - If a school shares a roster, it's used only under the school's directory-information policy.
- **Charitable solicitation:** most small PTOs are exempt or registered locally. Give a state-by-state checklist (verify per state).

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 3 | 4 | **17** |

*Price gap lowered 4 → 3 after verification: MoneyMinder's $299 already includes Cheddar Up Team, so the treasurer-stack saving is about $100/yr, not $520. Booster also now says schools keep 95% on average on MyBooster, and the 40–50% fun-run figures are only historical.*

## Sources
- [Givebacks pricing](https://www.givebacks.com/resources/pricing)
- [FAQ for Givebacks (formerly MemberHub) – Massachusetts PTA, Feb 2026](https://www.massachusettspta.org/membership-2/faq-for-memberhub/)
- [All About Givebacks – WSPTA](https://www.wastatepta.org/givebacks/)
- [Givebacks – Virginia PTA](https://vapta.org/memberhub/) · [Florida PTA](https://www.floridapta.org/memberhub-givebacks/) · [Tennessee PTA](https://tnpta.org/index.php/memberhub/)
- [givebacks.com reviews – Trustpilot](https://www.trustpilot.com/review/givebacks.com)
- [MemberHub reviews – Capterra](https://www.capterra.com/p/115300/MemberHub/reviews/)
- [MoneyMinder reviews – Capterra](https://www.capterra.com/p/147716/MoneyMinder/reviews/?page=2) · [MoneyMinder pricing](https://www.moneyminder.com/pricing)
- [Cheddar Up pricing](https://www.cheddarup.com/pricing)
- [Konstella](https://www.konstella.com/)
- [Booster FAQs](https://boosterthon.com/fundraising-faqs/) · [Booster home](https://boosterthon.com/)
- [Apex Fun Run](https://www.apexleadershipco.com/fun-run-fundraising) · [NYS PTA – Apex Leadership Co](https://nyspta.org/apex-leadership-co/)
- [Boosterthon Fun Run – PTO Today message boards](https://classic.ptotoday.com/boards/17-fundraising/149053-boosterthon-fun-run?start=18)
- [Haven't they gone far enough – Frog Trouble Times, Oct 2021](https://frogtroubletimes.substack.com/p/havent-they-gone-far-enough)
- [99Pledges pricing](https://www.99pledges.com/pricing)
- [PTO vs. PTA: What's the difference – PTO Today](https://www.ptotoday.com/pto-today-articles/pto-vs-pta-whats-the-difference)
- [Parent–teacher association – Wikipedia](https://en.wikipedia.org/wiki/Parent%E2%80%93teacher_association)

## Verification (Sep 25 2026)
- ✅ Givebacks pricing — Pro $499/yr, Premium $599/yr, Partner custom. Store/POS carries a 1.05% + $0.65 platform fee plus 2.9% + $0.30 processing. Fundraisers are 0% (tip model) or 7.5% (percent model). Direct donations are 0% platform + 1.99% + $0.49 ([source](https://www.givebacks.com/resources/pricing))
- ✅ MA PTA mandate — units must "use Givebacks to manage your PTA members, officers and good-standing requirements". The software is free to units, card fees are 3.95% + $0.59, and WePay is the only processor (last revised 02/12/2026) ([source](https://www.massachusettspta.org/membership-2/faq-for-memberhub/))
- ⚠️ WA PTA — "July 1, 2024 – Givebacks takes over as our primary database", replacing memberplanet. The page does not state explicitly that units must use it; the VA, FL and TN pages were not checked ([source](https://www.wastatepta.org/givebacks/))
- ❌ MoneyMinder + Cheddar Up saving — MoneyMinder is $299/yr, but it includes "Cheddar Up Team Edition ($576 value)" plus 990-N/990-EZ e-filing (8868 +$25). The "$299 + $420 → save $520" example double-counted Cheddar Up. Corrected to about $100/yr, and Price gap lowered 4 → 3 ([source](https://www.moneyminder.com/pricing); [Cheddar Up Team $35/mo billed annually](https://www.cheddarup.com/pricing))
- ⚠️ Fun-run 40–50% take — Booster "charges a percentage based on the level of support your school selects", and on MyBooster "On average, schools keep 95% of the funds". The 40–50% figures come only from 2010 and 2021 reports ([source](https://boosterthon.com/fundraising-faqs/))
