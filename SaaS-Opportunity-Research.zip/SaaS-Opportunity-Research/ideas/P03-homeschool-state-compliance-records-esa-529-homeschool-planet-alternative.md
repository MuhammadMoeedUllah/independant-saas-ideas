# HomeRoll: a cheaper, better Homeschool Planet / Homeschool Manager / Homeschool-life for families who must prove compliance and spend ESA or 529 money

**One-liner:** A homeschool log that knows your state's law and your legal option. It tracks notice deadlines, required subjects, days and hours, New York's instruction plan and quarterly reports, Pennsylvania's portfolio and evaluator packet, and testing. Daily 30-second entries become the exact filing, and a receipt vault covers ESA, 529 and scholarship money.

## Snapshot
- **Replaces** (prices accessed Sep 2026 unless noted):
  - **Homeschool Planet:** **$9.95/mo or $84.95/yr**, 30-day trial ([Homeschool Planet](https://homeschoolplanet.com/)). Curriculum schedules cost extra (**$6–10+** each) ([Homeschool Planning, 2025](https://homeschool-planning.com/homeschool-planners-digital/)).
  - **Homeschool Manager:** **$5.99/mo or $49/yr** ([Homeschool Manager](https://homeschoolmanager.com/pricing/)).
  - **Other planners** (2025 list prices, [Homeschool Planning](https://homeschool-planning.com/homeschool-planners-digital/)):
    - Homeschool Panda: Essentials **$50/yr**, Pro **$80/yr**.
    - Syllabird: **$60–90/yr**.
    - Well-Planned Gal: **$95/yr**.
    - Homeschool Tracker: **$65/yr or $8/mo** (Capterra also lists $8/mo, no free trial) ([Capterra](https://www.capterra.com/p/234127/Homeschool-Tracker/alternatives/)).
    - My School Year: **$60/yr**.
    - Scholaric: **$3–7/mo**.
    - Flexible Homeschool App: **$10/mo**.
  - **Co-ops, Homeschool-life.com:** Connections **$9.95 per family/yr**, Academy **$11.95 per family/yr**, Business **$310.80/yr**. Minimum and maximum fees apply, and SMS, domain and design are paid add-ons ([Homeschool-life](https://www.homeschool-life.com/pricing)).
  - **New App Store entrants:** Homeschooly, Home Edify, Schoolfolio, Hipling and others. The category is crowded and cheap.
- **Recent price hikes / changes (switching windows):**
  - **Growth:**
    - NHERI estimates **3.408M** K–12 homeschool students in 2024–25, **6.26%** of school-age children ([NHERI, Feb 27 2026](https://nheri.org/how-many-homeschool-students-are-there-in-the-united-states/)).
    - Johns Hopkins finds **4.9%** average growth in 2024–25 (versus about 2% before the pandemic). Fastest: SC **+21.5%**, VT **+17%**, OH **+15%**, NH **+14.5%**. Record highs in GA, MN, NE, OH, PA and WY ([JHU Homeschool Hub, updated Jul 2026](https://education.jhu.edu/edpolicy/policy-research-initiatives/homeschool-hub/homeschool-growth-2024-2025/)).
  - **New money** (each program brings receipt rules):
    - **Texas TEFA:** **$2,000** per homeschooler for 2026–27 ([Texas Comptroller, Nov 25 2025](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312)).
    - **One Big Beautiful Bill Act (OBBBA, Jul 2025):** raises the tax-free 529 K–12 withdrawal cap from **$10k to $20k per child per year** and adds homeschool expenses: curriculum and materials, online programs, tutoring, test fees (unverified; not in the cited source) and educational therapies ([PolitiFact, Feb 20 2026](https://politifact.com/truth-o-meter/promises/maga-meter-tracking-donald-trumps-2024-promises/promise/387540/provide-10000-per-child-tax-free-to-homeschoolers/article/387543/)).
    - **Federal tax-credit scholarships** start **Jan 1 2027**. 31 states planned to opt in as of May 2026 ([ECS](https://www.ecs.org/how-the-federal-tax-credit-scholarship-program-may-affect-states/)).
  - **State 529 conformity trap:** **13 states** don't treat K–12 as a qualified 529 expense for state tax: CA, CO, CT, HI, IL, MI, MN, MT, NE, NM, NY, OR, VT. California adds a **2.5%** state penalty on non-qualified distributions ([Savingforcollege, Jan 5 2026](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)).
  - **Retention-law spillover:** about 673 Indiana students left the state or were homeschooled after the first IREAD-3 retention year ([Chalkbeat, Nov 2025](https://www.chalkbeat.org/indiana/2025/11/05/how-many-students-held-back-under-retention-law/)).
- **Who buys:**
  - Homeschooling parents (card, annual plan).
  - Co-op leaders.
  - **B2B (V2):** Pennsylvania evaluators, umbrella or cover schools, and hybrid microschools (see F06).
- **US market size:** Estimate: about 3.4M students, which is roughly **1.5–2M families** assuming 1.7–2.3 homeschooled kids per family. Willingness to pay is proven at **$49–95/yr** by the incumbents.
- **Urgency trigger (why they'd switch NOW):**
  - **Back-to-school filings.** New York wants a letter of intent within **14 days** of starting and an instruction plan (IHIP) within **4 weeks** of receiving the district form ([NYSED](https://www.nysed.gov/nonpublic-schools/home-instruction-questions-and-answers)).
  - **Year-end** evaluations and assessments.
  - **Tax season Jan–Apr 2027**, the first year of the $20k 529 cap.
  - **TEFA** receipts in year one.
- **Fastest-selling states/metros:**
  - **High-regulation states:** NY, PA, MA, VT, RI, ND ([FreedomRankings, citing HSLDA, Sep 2026](https://freedomrankings.com/learn/homeschool-laws-by-state)). This is where filing pain is highest.
  - **Fast growers:** SC, OH, NH, VT.
  - **ESA states:** TX, AZ, FL, UT, AR.

## Pain points (evidence)
Reddit r/homeschool blocked fetching in this pass. Review volume on homeschool planners is thin, so complaints are moderate, not angry.
- **[Complexity/UX]** Homeschool Planet has an "overwhelming number of features", and curriculum schedules cost extra ([Homeschool Planning, 2025](https://homeschool-planning.com/homeschool-planners-digital/)).
- **[Bugs]** The Homeschool Planet iOS app logs users out unexpectedly after crashes or even a day of inactivity. The interface is sparse and can't be customized (App Store review, Nov 13 2025) ([App Store](https://apps.apple.com/us/app/homeschool-planet/id6639586865)).
- **[Missing features]** Homeschool Manager shows each student's schedule only separately. My School Year has no calendar view. Flexible Homeschool App has no grading, and Homeschool Curriculum Planner has no mobile app ([Homeschool Planning](https://homeschool-planning.com/homeschool-planners-digital/)).
- **[Price]** Well-Planned Gal is called "high price" with no monthly option. Flexible's $10/mo with no annual plan is "expensive ongoing". Homeschool Tracker has no free trial ([Homeschool Planning](https://homeschool-planning.com/homeschool-planners-digital/)).
- **[Compliance burden, NY]**
  - The district replies to the letter of intent within 10 business days.
  - The parent files the IHIP within 4 weeks. The district rules on it within 10 business days. If it's deficient, the parent revises within 15 days.
  - Quarterly reports must document total hours per quarter, and attendance records are mandatory ([NYSED](https://www.nysed.gov/nonpublic-schools/home-instruction-questions-and-answers)).
- **[Compliance complexity, PA and elsewhere]** Pennsylvania offers **four** homeschool options with different notification and assessment rules ([HSLDA PA](https://hslda.org/legal/pennsylvania)). Several states "offer more than one legal route, with genuinely different rules for each", and AK, FL, IA and MI are often mislabeled as no-notice ([FreedomRankings](https://freedomrankings.com/learn/homeschool-laws-by-state)).
- **[Money/tax risk]** 13 states don't conform on K–12 529 withdrawals, and several apply recapture. A family pulling 529 money for curriculum in CA or NY can owe state tax or a penalty without knowing it ([Savingforcollege](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)).
- **[Co-op cost]** Homeschool-life charges per family with minimum and maximum fees, and paid add-ons for SMS, domain and design ([Homeschool-life](https://www.homeschool-life.com/pricing)).
- **[Fragmentation]** No listed planner advertises state-specific filing generators such as the NY IHIP and quarterly reports or a PA evaluator packet. They sell planning and grading ([Homeschool Planning](https://homeschool-planning.com/homeschool-planners-digital/)). This is our observation from the feature lists, not a user quote.

## What we build (the better version)
1. **MVP** **State-law onboarding wizard** (50 states + DC). Pick your legal option (e.g. PA home-education statute vs. private tutor vs. religious school option; umbrella school in states that allow it). It creates a checklist, deadlines and reminders. Each rule is sourced from the statute or state DOE page with a "last verified" date. Not legal advice; links to HSLDA's state pages.
2. **MVP** **30-second daily log** on the phone: subject, minutes, book, photo or work sample. Entries are auto-tagged to the state's required subjects. Day and hour counters run against state minimums.
3. **MVP** **Filing generators:**
   - NY: letter of intent, IHIP, four quarterly reports and annual-assessment tracker.
   - PA: affidavit plus a portfolio PDF (log, reading list, samples, test scores) and a share link for the evaluator.
   - Notice-of-intent letters for notice states.
   - Attendance register.
4. **MVP** **Portfolio and transcript:** built automatically from logs, with high-school credits, GPA and course descriptions.
5. **MVP** **Receipt vault:** photograph or forward receipts, tag them to child and subject, and mark eligibility (TEFA, 529, scholarship). Includes a **state 529 conformity warning** and year-end 1099-Q matching export for the tax preparer.
6. **MVP** **Family plan:** unlimited kids, a lesson planner with CSV and curriculum-schedule import, and a calendar view.
7. **V2** **Evaluator/umbrella portal:** PA evaluators and umbrella schools review many families' portfolios, write AI-drafted evaluator letters and sign.
8. **V2** **Co-op lite:** class sign-ups, fees, volunteer hours and check-in, at flat per-co-op pricing.
9. **V2** Standardized-test scheduling and score history for testing states. ESA marketplace receipt formats (ClassWallet, Odyssey, Step Up), shared with F06.

## Pricing to win
- **Free:** logging and attendance. **Family: $59/yr or $7/mo** (all kids, all filings, receipt vault). **Evaluator Pro: $19/mo** (V2). **Co-op: $99/yr flat for up to 100 families** (V2).
- **Savings:**
  - vs Homeschool Planet ($84.95/yr): **$26/yr**.
  - vs Homeschool-life Academy for a 60-family co-op ($11.95 × 60 = **$717/yr**): **$618/yr**.
  - For NY and PA families the real saving is time and fewer IHIP rejections. Estimate: 8–15 hours a year of report writing.

## Go-to-market (first 100 customers)
- **State associations and conferences:**
  - PA: CHAP, and the PA evaluator networks.
  - NY: LEAH chapters and NYSLEARN.
  - TX: THSC.
  - OH: CHEO.
  - NC: NCHE (publishes homeschool statistics) ([NCHE](https://nche.com/stats/)).
  - Regional homeschool conventions (vendor booths).
- **Evaluator referral loop:** PA evaluators recommend HomeRoll because portfolios arrive standardized. Give evaluators a free Pro seat.
- **Communities:** r/homeschool, "NY homeschool IHIP help" and "PA homeschool evaluators" Facebook groups, TEFA parent groups.
- **SEO:** "NY IHIP template", "quarterly report homeschool NY", "PA homeschool portfolio checklist", "TEFA homeschool receipts", "can I use 529 for homeschool [state]".

## Risks and incumbent moats
- **Crowded and cheap** (low price gap). We win only on compliance depth, so stay narrow: filings, portfolios and receipts. Import from competitors' CSVs.
- **Legal accuracy:** a state-rules database with "last verified" dates, statute links and a clear "not legal advice" disclaimer. Partner with state associations to review rules.
- **Privacy-sensitive audience** (many homeschoolers distrust data collection):
  - No data sharing with government or third parties.
  - Export and delete anytime.
  - No ad trackers.
  - Clear retention policy.
- **COPPA and FERPA:** accounts are parent-owned. An optional kid view collects no personal information from the child, which keeps us outside COPPA's child-directed scope. Families aren't FERPA-covered schools. Umbrella schools and evaluators get a simple DPA.
- **ESA and 529 rules change often.** The rules engine is versioned by program year.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 2 | 5 | 4 | 4 | **18** |

## Sources
- [How Many Homeschool Students 2024–25 – NHERI, Feb 27 2026](https://nheri.org/how-many-homeschool-students-are-there-in-the-united-states/)
- [Homeschool Growth 2024–2025 – JHU Institute for Education Policy](https://education.jhu.edu/edpolicy/policy-research-initiatives/homeschool-hub/homeschool-growth-2024-2025/)
- [Homeschool Laws by State (2026) – FreedomRankings (HSLDA tiers)](https://freedomrankings.com/learn/homeschool-laws-by-state)
- [Homeschool Laws by State: 2026 Compliance – Eaton Academic](https://eatonacademic.com/homeschool-laws-by-state)
- [HSLDA – Homeschool Laws by State](https://hslda.org/legal) · [HSLDA New York](https://hslda.org/legal/new-york) · [HSLDA Pennsylvania](https://hslda.org/legal/pennsylvania)
- [Home Instruction Q&A – NYSED](https://www.nysed.gov/nonpublic-schools/home-instruction-questions-and-answers)
- [Homeschool Planet](https://homeschoolplanet.com/) · [Homeschool Planet iOS app](https://apps.apple.com/us/app/homeschool-planet/id6639586865)
- [Homeschool Manager pricing](https://homeschoolmanager.com/pricing/)
- [17 Best Homeschool Planners: Digital Edition (2025)](https://homeschool-planning.com/homeschool-planners-digital/)
- [Homeschool Tracker – Capterra](https://www.capterra.com/p/234127/Homeschool-Tracker/alternatives/)
- [Homeschool-life.com pricing](https://www.homeschool-life.com/pricing)
- [Texas Comptroller TEFA final rules, Nov 25 2025](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312)
- [Federal law expands 529 to homeschool – PolitiFact, Feb 2026](https://politifact.com/truth-o-meter/promises/maga-meter-tracking-donald-trumps-2024-promises/promise/387540/provide-10000-per-child-tax-free-to-homeschoolers/article/387543/)
- [How the Federal Tax Credit Scholarship May Affect States – ECS, May 2026](https://www.ecs.org/how-the-federal-tax-credit-scholarship-program-may-affect-states/)
- [States that do not conform with federal 529 laws – Savingforcollege, Jan 2026](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)
- [Indiana retention – Chalkbeat, Nov 2025](https://www.chalkbeat.org/indiana/2025/11/05/how-many-students-held-back-under-retention-law/)
- [NCHE homeschool statistics](https://nche.com/stats/)

## Verification (Sep 25 2026)
- ✅ Homeschool Planet $9.95/mo or $84.95/yr, with a 30-day free trial and no card required ([source](https://homeschoolplanet.com/))
- ✅ Homeschool Manager $5.99/mo or $49/yr, with a 30-day trial ([source](https://homeschoolmanager.com/pricing/))
- ⚠️ OBBBA 529 homeschool expansion — PolitiFact (Feb 20, 2026, "Promise Kept") confirms $10k → $20k per child per year and coverage of homeschool curriculum/materials, online programs, tutoring and therapies. Test fees are not listed there (marked unverified), and the article gives no effective date for the $20k cap ([source](https://politifact.com/truth-o-meter/promises/maga-meter-tracking-donald-trumps-2024-promises/promise/387540/provide-10000-per-child-tax-free-to-homeschoolers/article/387543/))
- ✅ Texas TEFA homeschool amount — the Comptroller release (Nov 25, 2025) gives homeschool students "$2,000 annually" ([source](https://comptroller.texas.gov/about/media-center/news/20251125-acting-texas-comptroller-kelly-hancock-announces-final-rules-and-key-dates-for-texas-education-freedom-accounts-program-1764103747312))
- ✅ NY filing timeline — the letter of intent is due within 14 days of starting and the IHIP within 4 weeks of receiving district materials. The district has 10 business days for each step, quarterly reports must document hours, and attendance records are required ([source](https://www.nysed.gov/nonpublic-schools/home-instruction-questions-and-answers))
