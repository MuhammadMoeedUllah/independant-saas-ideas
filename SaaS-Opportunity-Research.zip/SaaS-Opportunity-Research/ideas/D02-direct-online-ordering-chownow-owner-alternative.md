# DirectPlate: a cheaper, better Owner.com / ChowNow / DoorDash for independent restaurants and pizzerias

**One-liner:** A commission-free, POS-agnostic online ordering site and app for independent restaurants, with on-demand delivery at cost through DoorDash Drive / Uber Direct and built-in SMS loyalty, for one flat monthly fee.

## Snapshot
- **Replaces:**
  - **DoorDash** (2026): delivery commissions of 15% (Basic), 25% (Plus) and 30% (Premier), and 6% on pickup. Promos and ads cost extra ([KitchenHub, 2026](https://www.trykitchenhub.com/post/what-marketplaces-arent-telling-you-how-commission-models-are-quietly-changing)).
  - **Uber Eats:** mid-teens to about 30% on marketplace orders. **Grubhub:** about 15-30% on delivery and about 10-15% on pickup (same source).
  - **Owner.com** (as of May 6, 2026): Flex at $249/mo plus 5% per order, or Flat-Rate at $499/mo. Up to 15% on third-party app orders and about $7 per delivery ([Sauce](https://www.getsauce.com/post/chownow-vs-owner-com)).
  - **ChowNow** (as of May 6, 2026): Hub $119/mo, Pro $229/mo, Premier $328/mo, plus 2.95% + $0.29 per transaction. $199 cancellation fee on Premier if cancelled before the first order ([Sauce](https://www.getsauce.com/post/chownow-vs-owner-com)).
  - **BentoBox and Slice:** competitors. Pricing was not verified in this pass.
- **Recent price hikes / changes:**
  - **June 2025:** DoorDash, Uber Eats and Grubhub settled with New York City over the pandemic-era 15% + 5% fee caps. Per Sauce's analysis, platforms can now stack 15% delivery, 3% processing, 5% platform fee and an optional "enhanced services" tier of up to 20%, for a potential total of about 43% ([CNBC](https://www.cnbc.com/2025/06/04/doordash-grubhub-uber-eats-settle-with-new-york-city-over-fee-caps.html), [Sauce, July 2, 2025](https://www.getsauce.com/post/nyc-delivery-fee-cap-settlement-how-restaurants-can-navigate-rising-third-party-costs), [Restaurant Business](https://www.restaurantbusinessonline.com/technology/new-york-city-council-votes-lift-cap-delivery-fees)).
  - **2025-2026:** Base commission bands are roughly flat, but the "effective cost per order has continued to creep up" through paid visibility, promos and add-ons ([KitchenHub](https://www.trykitchenhub.com/post/what-marketplaces-arent-telling-you-how-commission-models-are-quietly-changing)).
  - **Early 2023:** Toast's $0.99 diner fee on online orders caused an outcry and was reversed (see D01).
- **Who buys:** Owners of independent restaurants, pizzerias, Chinese/Thai/Indian takeout, wing shops and bakeries with 20%+ of revenue from takeout or delivery. Single-location to 5-location groups.
- **US market size:** Estimate: several hundred thousand independent restaurants do meaningful takeout volume. This is derived from the approximately 1 million foodservice locations the National Restaurant Association commonly cites (not re-verified this pass).
- **Urgency trigger (why they'd switch NOW):** The end of NYC's fee caps (June 2025). Ads-driven "effective commission creep" on marketplaces. Owner.com's $499/mo price looks steep to small shops.
- **Fastest-selling states/metros:** NYC (fee caps lifted), San Francisco (15% cap passed in 2021; current status needs verification), Chicago, Los Angeles, Boston, and other dense takeout metros. Pizzerias nationwide, especially in the NY/NJ/PA corridor.

## Pain points (evidence)
- **[Price]** In NYC, stacking delivery, processing, platform and "enhanced services" fees can take marketplace take-rates to about 43% after the 2025 settlement ([Sauce](https://www.getsauce.com/post/nyc-delivery-fee-cap-settlement-how-restaurants-can-navigate-rising-third-party-costs)).
- **[Price]** DoorDash's 25-30% tiers plus paid promos and ads keep pushing the effective per-order cost up, even though base rates are flat ([KitchenHub](https://www.trykitchenhub.com/post/what-marketplaces-arent-telling-you-how-commission-models-are-quietly-changing)).
- **[Price]** Owner.com's Flex plan adds a 5% per-order fee on direct orders on top of $249/mo, and critics note high upfront costs before results show ([Sauce](https://www.getsauce.com/post/chownow-vs-owner-com)).
- **[Price]** ChowNow charges both a subscription ($119-$328/mo) and 2.95% + $0.29 per order ([Sauce](https://www.getsauce.com/post/chownow-vs-owner-com)).
- **[Lock-in/Contracts]** ChowNow offers annual and 2-year terms, and charges a $199 fee if Premier is cancelled before the first order ([Sauce](https://www.getsauce.com/post/chownow-vs-owner-com)).
- **[Missing features]** ChowNow users cite slow rollout of new features and POS integration that isn't seamless without third-party connectors ([Sauce](https://www.getsauce.com/post/chownow-vs-owner-com)).
- **[Support]** ChowNow users report occasional difficulty reaching support ([Sauce](https://www.getsauce.com/post/chownow-vs-owner-com)).
- **[Complexity/UX]** Owner.com users report occasional software glitches and Clover compatibility issues ([Sauce](https://www.getsauce.com/post/chownow-vs-owner-com)).
- **[Price]** Toast added a $0.99 fee to diners' online orders without clear operator notice, and removed it after backlash ([NRN](https://www.nrn.com/restaurant-segments/toast-to-remove-99-cent-fee-on-orders-over-10)).
- *Evidence gap:* Complaints here come mostly from competitor comparison pages (Sauce, KitchenHub). A second pass should pull first-hand r/restaurateur and Trustpilot threads on ChowNow and Owner.com.

## What we build (the better version)
1. **MVP: AI menu import.** The owner uploads a PDF or photo, or pastes a DoorDash/Toast menu link. We generate items, modifiers, prices and photo placeholders in about 10 minutes.
2. **MVP: Branded ordering site on a custom domain or free subdomain.** Mobile-first, with pickup and scheduled orders, and Stripe checkout including Apple Pay and Google Pay.
3. **MVP: On-demand delivery at cost** through the DoorDash Drive / Uber Direct APIs. The restaurant sets the delivery fee the diner pays, so the restaurant can pass it through fully.
4. **MVP: Order intake** by tablet app with sound alerts, auto-print to ESC/POS printers, and SMS/email fallback. POS-agnostic, so it works next to Toast, Clover or Square.
5. **MVP: SMS and email loyalty** ("10th order free") and a first-order discount for diners who move from apps to direct.
6. **MVP: "Order direct and save" insert generator**, a printable bag-stuffer with a QR code to hand out on third-party orders.
7. **MVP: Google Business Profile "Order online" link setup** plus a schema-optimized menu page for local SEO.
8. **V2: Native iOS/Android app** (white-label template).
9. **V2: POS injection** into Square and Clover (open APIs). Toast via Partner Connect, which requires approval.
10. **V2: Catering orders** with deposits and invoices. Pizza builder with half-and-half toppings for pizzerias.
11. **V2: AI phone ordering agent** that answers calls and texts the order to the kitchen.

## Pricing to win
- **DirectPlate:** $79/mo flat per location (or $59/mo billed annually, optional). **0% commission**, processing at cost plus a small disclosed markup, delivery passed through at DoorDash Drive / Uber Direct cost. Month-to-month, free menu setup and migration.
- **vs Owner.com Flex:** A restaurant with $15k/mo of direct orders pays $249 + 5% ($750), or about $999/mo in platform fees. DirectPlate costs $79, saving about $920/mo, or about $11k/yr (before processing on both sides).
- **vs ChowNow Pro:** $229/mo + 2.95% + $0.29. We match or beat processing and save about $150/mo on the subscription.
- **vs DoorDash Plus (25%):** Moving $5k/mo of orders from app to direct saves about $1,250/mo in commission.

## Go-to-market (first 100 customers)
- **Pizzerias first:** tight community, high takeout mix. Reach them through pizza trade media, the Pizza Expo (Las Vegas) and Facebook pizzeria-owner groups.
- **NYC blitz after the cap removal:** content on "what the 2025 NYC settlement means for your fees," plus door-to-door in Queens and Brooklyn takeout corridors.
- **"Switch from Owner.com / ChowNow" comparison pages** and a savings calculator.
- **Reddit:** r/restaurateur, r/restaurantowners, r/KitchenConfidential (founder AMA-style posts, no spam).
- **State restaurant associations:** vendor directories and member-perk programs. NRA Show networking in May.
- **Partners:** Independent POS resellers (Square/Clover ISOs) get a revenue share. Local web designers who build restaurant sites get the same.
- **Cold outreach:** Scrape restaurants whose Google Maps "Order" button points only to DoorDash/Uber Eats and email a personalized commission-savings estimate.

## Risks and incumbent moats
- **Crowded category** (Owner, ChowNow, Sauce, Menufy, BentoBox, Slice, Square Online, Toast Online Ordering). Our edge is price, AI setup in minutes and no contract. The moat is weak, so we win on distribution and speed.
- **Marketplace demand:** Direct ordering does not replace discovery. We position as "keep the apps for discovery, move repeat customers direct."
- **Delivery dependency** on DoorDash Drive / Uber Direct APIs and their pricing. Mitigation: support in-house drivers and multiple couriers.
- **Payments:** Stripe Connect handles PCI and KYC.
- **Google "Order online" placement** is controlled by Google and its partners. Mitigation: direct-link setup plus SEO.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 4 | 3 | 5 | **19** |

## Sources
- [ChowNow vs Owner.com – Sauce (May 6, 2026)](https://www.getsauce.com/post/chownow-vs-owner-com)
- [Commission models quietly changing in 2026 – KitchenHub](https://www.trykitchenhub.com/post/what-marketplaces-arent-telling-you-how-commission-models-are-quietly-changing)
- [DoorDash, Grubhub, Uber Eats settle with New York City over fee caps – CNBC (June 4, 2025)](https://www.cnbc.com/2025/06/04/doordash-grubhub-uber-eats-settle-with-new-york-city-over-fee-caps.html)
- [NYC Delivery Fee Caps Settlement – Sauce (July 2, 2025)](https://www.getsauce.com/post/nyc-delivery-fee-cap-settlement-how-restaurants-can-navigate-rising-third-party-costs)
- [New York City Council votes to lift cap on delivery fees – Restaurant Business](https://www.restaurantbusinessonline.com/technology/new-york-city-council-votes-lift-cap-delivery-fees)
- [Food Delivery Apps Hit with Commission Caps – Carpenter Wellington (2021)](https://carpenterwellington.com/post/food-delivery-apps-hit-commission-caps-new-rules/)
- [Toast to remove 99-cent fee – NRN](https://www.nrn.com/restaurant-segments/toast-to-remove-99-cent-fee-on-orders-over-10)
- [Owner.com Alternatives – Chowly](https://chowly.com/alternatives/owner-com-alternatives/)
