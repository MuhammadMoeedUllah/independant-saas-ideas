# SiteShield: a cheaper, better Termly / iubenda / Osano (plus an honest accessibility scanner) for SMB websites

**One-liner:** One flat subscription per website that covers a consent banner honoring Global Privacy Control, a 20-state privacy policy, a privacy-request inbox with legal clocks, and code-level ADA/WCAG scanning with fix instructions. It is explicitly not an overlay widget.

## Snapshot
- **Replaces:** Prices below are from [Consently, Jul 5 2026](https://consently.net/blog/consent-management-platform-pricing), a competitor source.
  - **Termly:** Free (10k banner views), Starter $10/mo billed annually (50k views), Pro+ $15/mo billed annually (unlimited views). Priced per site.
  - **iubenda:** Essentials €4.99/mo (25k pageviews), Advanced €19.99/mo (50k), Ultimate €79.99/mo (150k). Priced per site plus pageviews.
  - **Osano:** Free (5k visitors, 1 domain), Plus $199/mo self-serve (3 domains, 30k visitors), Enterprise custom (third parties estimate $200–$8,000+/mo).
  - **CookieYes:** $10–$55/mo per domain.
  - **Cookiebot:** €7–€30/mo per domain.
  - **OneTrust / TrustArc** are enterprise and quote-based. Not verified in this pass.
  - **Accessibility overlays** (accessiBe, UserWay and others) are sold per site per year. Prices were not verified in this pass.
- **Recent price hikes / changes:**
  - **FTC v. accessiBe.** The proposed order came in Jan 2025 and was finalized **Apr 22 2025**: a **$1M** payment, and accessiBe is barred from claiming its automated product can make any site WCAG-compliant without evidence. The FTC also cited paid reviews formatted to look independent ([FTC](https://www.ftc.gov/news-events/news/press-releases/2025/04/ftc-approves-final-order-requiring-accessibe-pay-1-million)).
  - No major dated list-price hike was found for the SMB consent-management tools. The pain here is regulatory churn and lawsuit risk, not price.
- **Who buys:** Owners of small e-commerce stores (Shopify/WooCommerce), restaurants, hotels, clinics and professional firms with a website. Web agencies and freelancers who maintain SMB sites for them are a second buyer.
- **US market size:**
  - Estimate: millions of SMB websites. The most motivated buyers are e-commerce and hospitality sites in lawsuit hot-spot states.
  - About 64% of 2025 accessibility-suit defendants had under $25M in revenue. E-commerce was about 70% of filings and food service/hospitality about 21% ([UsableNet, Jan 8 2026](https://blog.usablenet.com/ada-web-lawsuit-trends-2026)).
- **Urgency trigger (why they'd switch NOW):**
  - Twenty state privacy laws are now in force. Indiana, Kentucky and Rhode Island started **Jan 1 2026**.
  - ADA web lawsuits keep rising: **3,117 federal filings in 2025 (+27% over 2024)** ([Seyfarth ADA Title III blog, Mar 2026](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)) and **5,000+ including state courts** ([UsableNet](https://blog.usablenet.com/ada-web-lawsuit-trends-2026)).
  - Overlays don't protect: **1,300+ 2025 suits targeted sites that were running a widget** ([UsableNet](https://blog.usablenet.com/ada-web-lawsuit-trends-2026)).
  - The accessiBe FTC order gives widget customers a reason to look for something that actually fixes the code.
- **Fastest-selling states/metros:**
  - **Federal ADA web suits in 2025:** New York 1,021, Florida 961, Illinois 585, Minnesota 162, Pennsylvania 137, Missouri 86, Massachusetts 57 ([Seyfarth](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)).
  - California shows only 4 federal suits because California plaintiffs file in state court. UsableNet says NY and CA together account for nearly 2,000 state-level filings.
  - For privacy, merchants selling into the 20 states below.

### Comprehensive state privacy laws in force (per [privacyterms.io 2026 tracker](https://privacyterms.io/us-state-privacy-laws-2026) and [MultiState, Feb 2026](https://www.multistate.us/insider/2026/2/4/all-of-the-comprehensive-privacy-laws-that-take-effect-in-2026))
| State | Effective |
|---|---|
| California (CCPA/CPRA) | Jan 1 2020 |
| Virginia | Jan 1 2023 |
| Colorado, Connecticut | Jul 1 2023 |
| Utah | Dec 31 2023 |
| Texas, Oregon, Florida (narrow) | Jul 1 2024 |
| Montana | Oct 1 2024 |
| Delaware, Iowa, Nebraska, New Hampshire | Jan 1 2025 |
| New Jersey | Jan 15 2025 |
| Tennessee | Jul 1 2025 |
| Minnesota | Jul 31 2025 |
| Maryland | Oct 1 2025 |
| **Indiana, Kentucky, Rhode Island** | **Jan 1 2026** |

- **Thresholds:**
  - California applies if a business has more than $26,625,000 in gross revenue (2026-adjusted), gets 50% or more of revenue from selling/sharing personal information, or handles data on 100k+ California consumers.
  - Most other states use about 100k consumers.
  - **Rhode Island is unusually low:** 35,000 consumers, or 10,000 if more than 20% of revenue comes from selling data.
- **Mid-2026 amendments:** MultiState lists Connecticut, Arkansas and Utah changes effective Jul 1 2026. Details were truncated and not verified.
- **Newly enacted, effective dates to confirm:** privacyterms.io lists Alabama, Louisiana, Oklahoma and Vermont as passing laws in 2026. Verify in the per-state pass.

## Pain points (evidence)
- **[Legal risk]** Sites running accessibility widgets were still sued more than 1,300 times in 2025. Courts expect code-level fixes, not overlays ([UsableNet, Jan 2026](https://blog.usablenet.com/ada-web-lawsuit-trends-2026)).
- **[Legal risk]** 45% of 2025 federal web-accessibility suits (1,427) hit companies that had been sued before, so a quick settlement without fixing the site invites the next suit ([UsableNet](https://blog.usablenet.com/ada-web-lawsuit-trends-2026)).
- **[Trust]** The FTC found accessiBe's "make any website compliant" claim deceptive and fined it $1M ([FTC, Apr 2025](https://www.ftc.gov/news-events/news/press-releases/2025/04/ftc-approves-final-order-requiring-accessibe-pay-1-million)).
- **[Billing/Lock-in]** A Termly user cancelled but says they are still charged every month ([Trustpilot, Aug 2026](https://www.trustpilot.com/review/termly.io)).
- **[Billing]** Termly kept sending payment reminders and billing attempts after an explicit cancellation (two separate reviewers, [Trustpilot, Jul 2026](https://www.trustpilot.com/review/termly.io)).
- **[Billing/Support]** A reviewer was "charged for services I canceled," and then Termly went silent ([Trustpilot, Jul 2026](https://www.trustpilot.com/review/termly.io)).
- **[Support]** Termly support is limited to a 4-hour window, slow, and answers with canned replies ([Trustpilot, Jun–Jul 2026](https://www.trustpilot.com/review/termly.io)).
- **[UX/Missing features]** The free Termly policy generator's output isn't usable without a paid export. Another user couldn't customize the banner text ([Trustpilot, May–Jul 2026](https://www.trustpilot.com/review/termly.io)).
- **[UX]** An iubenda reviewer complains of "dark patterns" and says the website deletion feature is hard to find. iubenda disputes this ([Trustpilot, Aug 11 2026](https://www.trustpilot.com/review/iubenda.com)). iubenda is otherwise well rated at 4.4/5 on 617 reviews.
- **[Price model]** Most consent tools charge per domain and per pageview, so costs scale with traffic. Osano jumps from free to $199/mo ([Consently, Jul 2026](https://consently.net/blog/consent-management-platform-pricing)).
- **Evidence gap:** Owner-voice Reddit threads about demand letters weren't captured because the search budget ran out. Collect them from r/smallbusiness and r/shopify in the next pass.

## What we build (the better version)
1. **MVP: a consent banner** (one script tag, Shopify app, WordPress plugin).
   - It honors Global Privacy Control automatically, geo-targets the rules for the 20 states, and blocks scripts before consent.
   - It keeps a consent log that can be used as evidence.
2. **MVP: a privacy policy generator** that asks 15 questions and writes state-specific sections. It auto-updates when a law changes and emails the owner a diff.
3. **MVP: a privacy-request inbox.** A web form for access, delete and opt-out requests, identity verification, a 45-day countdown and response templates.
4. **MVP: an accessibility scanner** (axe-core based, plus AI explanations).
   - It crawls up to 500 pages weekly and ranks issues by lawsuit likelihood (images without alt text, form labels, contrast, keyboard traps, missing button names).
   - For each issue it gives **copy-paste code fixes** for Shopify Liquid and WordPress themes.
5. **MVP: a monthly "good-faith effort" PDF** with scan history, issues fixed and a draft accessibility statement. It is useful if a demand letter arrives.
6. **MVP: plain-English honesty.** No "100% compliant" claims, in light of the FTC order. We show a risk score instead.
7. **V2: AI auto-fix pull requests.** GitHub/Shopify theme patches and WordPress auto-fixes for alt text, labels and contrast.
8. **V2: a demand-letter response kit.** Triage, evidence packet, and a referral to vetted ADA defense counsel (a referral partnership).
9. **V2: a manual audit marketplace.** A human WCAG 2.2 AA audit with screen-reader testing for a flat fee, sold as an upsell.
10. **V2: an agency dashboard.** Manage 50+ client sites and white-label the reports.

## Pricing to win
- **Our plans:**
  - **$19/mo per site:** consent, policy, privacy-request inbox and a weekly accessibility scan, with unlimited pageviews.
  - **Agency plan:** $199/mo for 25 sites.
  - Month to month, and cancellation is one click. That is an explicit contrast with the Termly billing complaints.
- **Compared with the stack a typical owner buys today:**
  - A consent tool: Termly Pro+ at $15/mo, or Osano Plus at $199/mo.
  - A separate accessibility widget or audit (prices not verified).
  - The saving is mostly on accessibility and on Osano-tier plans. Against Termly alone, our price is roughly at parity, so the bundle is the selling point.

## Go-to-market (first 100 customers)
- **Shopify App Store and WordPress.org plugin** with the free scan as the lead magnet: "See your lawsuit-risk score in 60 seconds."
- **SEO pages:** "accessiBe alternative after FTC order," "got an ADA website demand letter, what now," "Rhode Island privacy law 35,000 consumer threshold," and "Termly alternative with one-click cancel."
- **Web agencies and freelancers** (the largest lever): white-label resale, listings in agency Slack and Facebook groups, and r/web_design, r/Wordpress, r/shopify.
- **Hot-spot targeting:** cold email to NY, FL and IL e-commerce and restaurant sites whose free scan finds critical errors. We would send the risk report as the email.
- **Partnerships** with ADA defense attorneys and business insurers (EPLI/cyber) for referrals.

## Risks and incumbent moats
- **Unauthorized practice of law and liability.** We provide templates and tools, not legal advice, and bring in attorney partners for letters.
- **We cannot guarantee ADA compliance.** Automated scans catch only part of WCAG. We sell risk reduction and repeat that message everywhere (the FTC precedent).
- **Crowded, cheap category** (Termly, CookieYes, iubenda). We differentiate with the privacy plus accessibility bundle, code fixes and the agency channel.
- **Browser and platform changes** to consent APIs and cookies need ongoing maintenance.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 2 | 4 | 3 | 5 | **17** |

## Sources
- [FTC: Final order requiring accessiBe to pay $1M (Apr 22 2025)](https://www.ftc.gov/news-events/news/press-releases/2025/04/ftc-approves-final-order-requiring-accessibe-pay-1-million)
- [FTC: Proposed order vs accessiBe (Jan 2025)](https://www.ftc.gov/news-events/news/press-releases/2025/01/ftc-order-requires-online-marketer-pay-1-million-deceptive-claims-its-ai-product-could-make-websites)
- [Seyfarth ADA Title III: Federal web-accessibility filings bounce back in 2025 (Mar 2026)](https://www.adatitleiii.com/2026/03/federal-court-website-accessibility-lawsuit-filings-bounce-back-in-2025/)
- [UsableNet: ADA web lawsuit trends for 2026 (Jan 8 2026)](https://blog.usablenet.com/ada-web-lawsuit-trends-2026)
- [privacyterms.io: US State Privacy Laws 2026](https://privacyterms.io/us-state-privacy-laws-2026)
- [MultiState: Comprehensive privacy laws taking effect in 2026](https://www.multistate.us/insider/2026/2/4/all-of-the-comprehensive-privacy-laws-that-take-effect-in-2026)
- [Consently: Consent management platform pricing 2026 (competitor source)](https://consently.net/blog/consent-management-platform-pricing)
- [Trustpilot: Termly](https://www.trustpilot.com/review/termly.io)
- [Trustpilot: iubenda](https://www.trustpilot.com/review/iubenda.com)
