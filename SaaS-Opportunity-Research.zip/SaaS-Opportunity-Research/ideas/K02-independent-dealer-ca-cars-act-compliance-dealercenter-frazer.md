# DealJacket: CARS Act–ready deal compliance for independent used-car dealers (works beside DealerCenter / Frazer, replaces paper and add-on compliance vendors)

**One-liner:** A lightweight digital deal jacket for independent and buy-here-pay-here (BHPH) dealers. It covers California's SB 766 (CARS Act) duties, which start **October 1, 2026**: the 3-day return tracker, total-price and add-on disclosures, consent capture and record retention. It plugs in beside the dealer's existing $99–$199/mo DMS.

## Snapshot
- **Replaces / sits beside:**
  - **DealerCenter** is $99/mo flat (Capterra listing, checked Sep 2026) ([Capterra compare](https://www.capterra.com/compare/34553-71935/Frazer-Auto-Dealer-Software-vs-DealerCenter)).
  - **Frazer** is $129/mo desktop or $1,299/yr, and hosted starts at $199/mo. BHPH, accounting and internet advertising are included ([Frazer pricing, checked Sep 24 2026](https://www.frazer.com/frazer-pricing)).
  - **Franchise tier:** CDK Global, Reynolds & Reynolds, Tekion, and CRMs such as VinSolutions and DealerSocket are quote-only enterprise contracts, so they are out of scope for card sales.
  - Compliance vendors (ComplyAuto, ProMax guidance, dealer attorneys) are also selling CARS Act help ([ComplyAuto CARS Act center](https://complyauto.com/ca-cars-act/); [ProMax](https://www.promaxunlimited.com/blog-california-cars-act-sb-766-dealer-compliance/)). Their prices were not captured in this pass.
- **Recent price hikes / changes:**
  - DealerCenter reviewers say "price and add ons … pricing constantly changing" (undated Capterra excerpts).
  - A Frazer reviewer complains about management since an acquisition.
  - **Switching windows:**
    - (a) **CA SB 766 takes effect Oct 1, 2026** ([CA Dealer Academy guide, Jan 6 2026, updated weekly](https://www.californiadealeracademy.com/articles/cars-act-sb-766-major-changes-coming-october-1-2026); [bill text](https://leginfo.legislature.ca.gov/faces/billNavClient.xhtml?bill_id=202520260SB766)).
    - (b) The June 2024 CDK Global ransomware outage left thousands of dealers without their DMS for weeks ([CBS News](https://www.cbsnews.com/amp/newyork/news/cdk-cyber-attack-outage-update-2024); [Mercer Capital](https://mercercapital.com/insights/blogs/auto-dealer-valuation-insights-blog/2024/the-latest-on-cdk-global-cybersecurity/)). It still drives "don't keep all records in one vendor" thinking.
- **SB 766 duties (per the CA Dealer Academy guide):**
  - A **3-day cancellation right** on used vehicles priced at $50,000 or less. The buyer may drive at most 400 miles, the restocking fee is 1.5% of the price (bounded at $200–$600), and the dealer must refund within 48 hours.
  - The **"total price"** in ads and the first written communication must include dealer markups and installed add-ons.
  - Wall signage in 36-point type, and a separate first-page contract disclosure.
  - Precontract disclosures now also apply to **cash deals and leases**.
  - Certain worthless add-ons are banned.
  - Record retention: 2 years under SB 766, alongside the DMV's 3 years and 7+ years under the finance rules.
  - Covered dealers are **all licensed CA retail dealers of light-duty vehicles**, not just franchise dealers.
- **Who buys:** The owner or general manager of an independent used-car lot or BHPH dealer (1–3 rooftops, 10–150 cars a month). The office manager or F&I person runs it.
- **US market size (estimate):**
  - Tens of thousands of licensed independent dealers nationally, with California a large share (not verified in this pass; pull CA DMV Occupational Licensing counts and NIADA figures).
  - The launch market is **California only**, then other states as FTC and state "junk fee" rules spread.
- **Urgency trigger (why they'd switch NOW):** SB 766 is effective **Oct 1, 2026**, one week from today. Enforcement runs through the Unfair Competition Law and possible DMV licensing action.
- **Fastest-selling states/metros:** California (LA and the Inland Empire, Sacramento, the Central Valley, San Diego). Next are states moving on dealer junk-fee and disclosure rules, and e-titling expansion states (IL, OK, OH) for a titling module.

## Pain points (evidence)
Evidence here mixes DMS complaints with regulatory pain; the compliance pain is new, and few reviews exist yet.
- **[Price]** DealerCenter users say pricing "can get a bit expensive," billing cycles lag, and "price and add ons … constantly changing" ([Capterra compare](https://www.capterra.com/compare/34553-71935/Frazer-Auto-Dealer-Software-vs-DealerCenter)).
- **[Support]** DealerCenter's "support team is mostly overseas," which slows fixes to email and text features (same source).
- **[UX/Reliability]** DealerCenter users describe "system glitches," call it "really slow, and clunky," and say it logs them out too soon (same source).
- **[Integration]** One dealer had a hard time syncing DealerCenter with their Frazer vehicle database (same source).
- **[Support]** Frazer users report waiting at least 45 minutes for support (same source).
- **[Reliability]** A Frazer user says they lost deals on holidays and weekends when the system went down (same source).
- **[Missing features]** Frazer's texting is "not as advanced as it needs to be" (same source).
- **[Vendor risk]** The CDK ransomware attack (June 2024) forced thousands of dealers back to paper deal jackets ([CBS News](https://www.cbsnews.com/amp/newyork/news/cdk-cyber-attack-outage-update-2024)).
- **[Compliance complexity]** Dealers must now meet three overlapping retention periods (2, 3 and 7+ years). They also need a 3-day return workflow with mileage caps, restocking-fee math and a 48-hour refund clock, and new disclosures on cash deals ([CA Dealer Academy](https://www.californiadealeracademy.com/articles/cars-act-sb-766-major-changes-coming-october-1-2026); [Hudson Cook](https://www.hudsoncook.com/article/california-enacts-the-combating-auto-retail-scams-cars-act/); [Madison Law](https://madisonlawapc.com/californias-cars-act-sb-766-is-official-what-auto-dealers-must-know-before-october-2026/)).
- **[Documentation]** Vendors now market vehicle-condition photo documentation because returns under the 3-day law hinge on proving condition at delivery ([press release on 3-day return law](https://www.mykxlg.com/online_features/press_releases/californias-new-3-day-used-car-return-law-puts-vehicle-condition-documentation-in-the-spotlight/article_402f4604-373d-5dc8-89e8-18de1729d87e.html)).

## What we build (the better version)
1. **MVP:** A digital deal jacket per VIN, holding the buyer's order, retail installment contract (RISC) or cash contract, disclosures, ID, insurance and odometer statement. It has immutable timestamps and an audit log, and the **retention clock is set to the longest applicable rule** (7+ years).
2. **MVP:** A **3-day return tracker.** It automatically flags vehicles that qualify (used, $50k or less), counts down 72 hours from the day after signing, and records odometer out and in against the 400-mile cap. It calculates the restocking fee (1.5%, bounded at $200–$600) and runs a **48-hour refund SLA timer** with manager alerts.
3. **MVP:** **Delivery condition kit.** A guided phone walk-around (photos and video of every panel, dash and odometer) that the customer e-signs at delivery and again at any return.
4. **MVP:** **Add-on and total-price disclosure builder.** It generates the separate first-page disclosure and a "total price" line for ads and first quotes, and blocks banned add-ons with a checklist.
5. **MVP:** Printable 36-point signage packs and consent capture (e-sign) for precontract disclosures on cash, finance and lease deals.
6. **MVP:** Import deals from DealerCenter and Frazer exports (CSV), with a Chrome-extension "send to DealJacket" button as a fallback.
7. **V2:** An ad-scanner that crawls the dealer's website and marketplace listings (Cars.com, CarGurus, Facebook Marketplace) and flags ads missing the required total price.
8. **V2:** An e-titling and registration packet builder per state (IL ELT expansion, OK electronic titles, OH e-title). Verify per state.
9. **V2:** Full independent-dealer DMS (inventory, BHPH payment ledger, credit reporting) for dealers who want to leave DealerCenter or Frazer.

## Pricing to win
- **Our prices:** $79/mo per rooftop, month to month, with unlimited deals and users. Alternatively $699/yr, which includes 7-year storage.
- **Compared with:** A single dealer-compliance consultation or attorney review typically costs more than a year of the tool (estimate; attorney rates not captured).
- **Example:** A Frazer ($129) or DealerCenter ($99) dealer adds DealJacket for $79/mo. That is far cheaper than one UCL claim or one mishandled refund.

## Go-to-market (first 100 customers)
- **Associations:** CIADA (California Independent Auto Dealers Association) and NIADA state associations. Offer a free CARS Act webinar with a dealer attorney.
- **Dealer education:** Partner with California dealer-education and licensing schools (for example California Dealer Academy, which publishes the weekly SB 766 guide) on a co-branded compliance checklist.
- **Legal and compliance referrals:** Dealer-law firms (Hudson Cook, Madison Law, Auto Legal Group) and F&I trainers.
- **Cold outreach:** CA dealer licenses are public records, so pull the DMV Occupational Licensing list for email and SMS outreach on an "Oct 1 deadline" theme.
- **Communities:** r/askcarsales (dealer staff), independent-dealer Facebook groups, and BHPH forums.
- **Events:** NIADA Convention & Expo and Used Car Week.

## Risks and incumbent moats
- **DMS vendors may ship CARS Act features for free.** DealerCenter and Frazer can add forms. We win on the photo condition kit, the refund SLA workflow and audit-grade retention, and we keep integrations light.
- **Forms liability.** Contract forms (RISC) come from forms vendors and attorneys, so we do not draft legal forms. We attach and track them and have an attorney review our disclosure templates.
- **CA-only at launch** limits market size. Expand as other states copy the law.
- **Franchise dealers** (CDK, Reynolds) need RFPs and are out of scope.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 2 | 4 | 5 | 3 | **17** |

## Sources
- [Frazer pricing (checked Sep 24 2026)](https://www.frazer.com/frazer-pricing)
- [Capterra: Frazer vs DealerCenter compare (2026)](https://www.capterra.com/compare/34553-71935/Frazer-Auto-Dealer-Software-vs-DealerCenter)
- [California Dealer Academy: CARS Act (SB 766) guide (Jan 6 2026, updated weekly)](https://www.californiadealeracademy.com/articles/cars-act-sb-766-major-changes-coming-october-1-2026)
- [SB 766 bill text](https://leginfo.legislature.ca.gov/faces/billNavClient.xhtml?bill_id=202520260SB766)
- [Hudson Cook: California Enacts the CARS Act](https://www.hudsoncook.com/article/california-enacts-the-combating-auto-retail-scams-cars-act/)
- [Madison Law: CARS Act is official](https://madisonlawapc.com/californias-cars-act-sb-766-is-official-what-auto-dealers-must-know-before-october-2026/)
- [ComplyAuto CARS Act Resource Center](https://complyauto.com/ca-cars-act/)
- [ProMax: CARS Act (SB 766) What Dealers Must Know](https://www.promaxunlimited.com/blog-california-cars-act-sb-766-dealer-compliance/)
- [CBS News: CDK Global cyberattack leaves thousands of car dealers spinning their wheels (Jun 2024)](https://www.cbsnews.com/amp/newyork/news/cdk-cyber-attack-outage-update-2024)
- [Mercer Capital: The Latest on CDK Global Cybersecurity (2024)](https://mercercapital.com/insights/blogs/auto-dealer-valuation-insights-blog/2024/the-latest-on-cdk-global-cybersecurity/)
- [Press release: California's new 3-day used car return law and vehicle condition documentation](https://www.mykxlg.com/online_features/press_releases/californias-new-3-day-used-car-return-law-puts-vehicle-condition-documentation-in-the-spotlight/article_402f4604-373d-5dc8-89e8-18de1729d87e.html)
- [Illinois SOS: Electronic Lien and Titling expansion (Feb 11 2026)](https://www.ilsos.gov/news/2026/february-11-2026-giannoulias-expands-electronic-lien-and-titling-to-deliver-faster-more-secure-vehicle-titles.html)
