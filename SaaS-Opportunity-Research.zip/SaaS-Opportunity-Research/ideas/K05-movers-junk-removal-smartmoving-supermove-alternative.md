# MoveBoard: transparent-priced CRM and ops for small movers and junk-removal crews (a simpler SmartMoving / Supermove / MoveitPro)

**One-liner:** Lead-to-invoice software for 1–10 truck local movers and junk haulers. It covers instant online quotes, inventory and estimates, crew scheduling, a crew app with photos and e-signature, and **state-tariff-compliant estimate and bill-of-lading documents**. The price is on the website, it is month to month, and setup is self-serve in a day.

## Snapshot
- **Replaces:**
  - **SmartMoving:** no public prices (checked Sep 24 2026). It has a "Growth" plan, billing monthly, quarterly or annually, and onboarding averages about 3 weeks. Pricing requires a sales call or demo ([SmartMoving pricing](https://www.smartmoving.com/pricing)).
  - **Supermove:** no public prices (checked Sep 24 2026). Plans are Essentials, Pro and Storage, charged by crew with no office-user limit, and "typically charged quarterly or annually" ([Supermove pricing](https://www.supermove.com/pricing)).
  - **MoveitPro, Elromco, Movegistics, Vonigo:** prices not captured in this pass. Capterra ratings are MoveitPro 4.4 (97 reviews), Elromco 4.7 (22), Movegistics 4.9 (43), Vonigo 4.6 (80), SmartMoving 4.9 (143) and Supermove 4.6 (18) ([Capterra moving software](https://www.capterra.com/moving-software/)).
- **Recent price hikes / changes:** None found. The friction is **opaque, demo-gated pricing plus quarterly or annual billing**, not a documented hike.
- **Who buys:** The owner or operator of a local moving company (1–10 trucks) or a junk-removal franchisee or independent. Typically first-generation owners who buy by card.
- **US market size:** Not sized in this pass. Estimate: movers (NAICS 484210, used household goods moving) number in the low tens of thousands of employer firms, plus many junk-removal startups. Verify with Census CBP.
- **Urgency trigger (why they'd switch NOW):**
  - Weak. The peak moving season (May–Sep) ends in October, the usual window for switching software.
  - State tariff and estimate rules for intrastate movers (California BHGS household mover rules, Texas TxDMV household goods rules) require compliant documents. They were not verified in this pass, so flag them for the per-state pass.
- **Fastest-selling states/metros (inference):** TX (DFW, Houston, Austin), FL, CA, AZ, NC and GA, where in-migration drives local-move volume.

## Pain points (evidence)
**Evidence is thin.** Incumbents are well rated on Capterra, and Reddit was not reachable in this pass. Do not build this until 10 owner interviews confirm the pain.
- **[Price opacity]** SmartMoving publishes no prices; owners must book a demo or email sales ([SmartMoving pricing](https://www.smartmoving.com/pricing)).
- **[Price opacity]** Supermove also publishes no prices and directs buyers to "contact a product expert" ([Supermove pricing](https://www.supermove.com/pricing)).
- **[Lock-in]** Supermove is "typically charged quarterly or annually," so a small mover prepays through the slow winter (same source).
- **[Complexity]** SmartMoving onboarding averages about 3 weeks with a dedicated onboarding manager, which signals a heavy setup for a 2-truck operator ([SmartMoving pricing](https://www.smartmoving.com/pricing)).
- **[Market signal]** Capterra lists 101 moving-software products, a fragmented field with no dominant low-cost, self-serve option ([Capterra](https://www.capterra.com/moving-software/)).

## What we build (the better version)
1. **MVP:** An embeddable instant-quote widget (rooms or inventory, stairs, distance, date) that produces non-binding, binding or not-to-exceed estimates from the owner's rate card. It texts the lead and books a deposit through Stripe.
2. **MVP:** Room-by-room inventory (photo or video walk-through, with AI item and cubic-foot estimation) that generates the estimate.
3. **MVP:** Job calendar and crew and truck scheduling, with a crew app for clock-in and out, a timer for hourly moves, before and after damage photos, and customer e-signature on the bill of lading.
4. **MVP:** Invoice and payments with tips split to the crew, and a review request after the job.
5. **MVP:** Junk-removal mode, with volume-based pricing (fractions of a truckload), dump-fee tracking and photo quotes.
6. **MVP:** Import from SmartMoving, Supermove and spreadsheet CSV exports.
7. **V2:** **State document packs.** Intrastate tariff tables, required consumer notices, estimate and bill-of-lading formats (California, Texas and others), and the federal "Your Rights and Responsibilities" packet for interstate moves. Verify in the per-state pass.
8. **V2:** Storage-unit billing (monthly recurring) and lead-provider inbox connectors that parse emails from lead marketplaces.
9. **V2:** An AI phone and SMS agent for after-hours quote requests.

## Pricing to win
- **Our prices:** $79/mo for up to 3 trucks, $149/mo unlimited. Prices published, month to month, self-serve setup.
- **Savings:** Unknown until incumbent quotes are collected. Get mystery-shopper quotes from SmartMoving and Supermove in the next pass.

## Go-to-market (first 100 customers)
- **Associations:** AMSA (the moving and storage conference of the American Trucking Associations) and state mover associations, such as the California Moving & Storage Association and Texas mover associations.
- **Communities:** r/moving (consumer-heavy, low value) and r/sweatystartup (junk removal and moving startups), plus mover and junk-removal Facebook groups.
- **Partners:** Junk-removal coaching communities and YouTube "start a junk removal business" creators, who get an affiliate rev-share.
- **SEO:** "SmartMoving pricing," "Supermove pricing," and "moving estimate template [state]."

## Risks and incumbent moats
- **Well-liked incumbents** (4.6–4.9 on Capterra) make the pain unproven.
- **Horizontal field-service tools** (Jobber, Housecall Pro) already serve many junk haulers.
- **Varying tariff rules** make state packs an ongoing maintenance cost. That is also a moat once built.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 2 | 3 | 4 | 3 | 2 | **14** |

## Sources
- [SmartMoving pricing (checked Sep 24 2026)](https://www.smartmoving.com/pricing)
- [Supermove pricing (checked Sep 24 2026)](https://www.supermove.com/pricing)
- [Capterra: Moving software category (Sep 2026)](https://www.capterra.com/moving-software/)
