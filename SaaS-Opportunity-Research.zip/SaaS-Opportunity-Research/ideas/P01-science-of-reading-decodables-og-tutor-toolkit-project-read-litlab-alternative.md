# PhonicsPrep: a cheaper, better Project Read / LitLab / TPT-decodables stack for private reading tutors, Orton-Gillingham (OG) and dyslexia specialists, and K–3 interventionists

**One-liner:** Decodable passages, word lists, dictation and fluency probes generated from the exact letter-sound patterns *one child* has mastered, not a whole-class lesson number. It also includes an OG lesson-plan builder, progress monitoring and a take-home parent pack, so a tutor who bills about $113/hr stops spending unpaid evenings making materials.

## Snapshot
- **Replaces** (prices checked Sep 2026 unless noted):
  - **Project Read** (AI decodables):
    - **Free teacher plan:** capped at "up to 5 per week, no customizations".
    - **School plan:** **$1,999/yr** ($999 the first year).
    - **Student "Tutor" app:** **$15/student**, 100-student minimum.
    - **UFLI assessment/planning portal:** **$4/student**.
    - **No paid individual-teacher or tutor plan is listed.** Project Read claims 150,000+ teachers and supports IMSE, UFLI, CKLA, Guided Phonics and RCF ([Project Read pricing](https://www.projectread.ai/pricing); [Project Read](https://www.projectread.ai/)).
  - **LitLab:** free teacher sign-up. School and district pricing is not published. It has 1,500+ decodables aligned to UFLI, CKLA, Fundations, Reading Horizons, Benchmark and Superkids, plus read-aloud fluency analysis and ESSA Tier IV status ([LitLab](https://www.litlab.ai/)).
  - **Other AI generators:** TeachQuill, TeacherTool.ai and Storytime AI (not priced in this pass) ([TeachQuill](https://teachquill.com/decodable-text-generator); [TeacherTool](https://www.teachertool.ai/best-ai-tools-for-teachers/ai-decodable-text-generator)).
  - **Reading A-Z / Raz-Plus, Heggerty, UFLI Foundations, Amplify CKLA, Flyleaf and Teachers Pay Teachers (TPT) packs:** not re-priced. The Reading A-Z and Heggerty home pages show no prices ([Reading A-Z](https://www.readinga-z.com/); [Heggerty](https://heggerty.org/)).
  - **Parent-paid tools** (ReadFlare, Jul 9 2026):
    - Lexia Core5: **$299/yr** direct.
    - Barton Reading: **$299 per level**.
    - Nessy: **$96/yr**.
    - Reading Eggs: **$84–99/yr**.
    - Phonics Hero: **$84/yr**.
    ([ReadFlare](https://readflare.com/articles/dyslexia/orton-gillingham-apps))
  - **Lexercise professional therapy:** **$495/mo** for families ([Lexercise](https://www.lexercise.com/online-dyslexia-treatment/professional-therapy)).
- **Recent price hikes / changes (switching windows):**
  - **Federal:**
    - **H.R. 7890 passed the House on Sep 16 2026.** It prioritizes science of reading (SoR) in the **$194M** Comprehensive Literacy State Development grants (23 states receive them) and bans three-cueing in grant-funded instruction. The Senate READ Act cleared committee in Jul 2026.
    - Education Week counts **"more than 40 states"** with SoR laws and **at least 14** that have required schools to stop using three-cueing materials ([EdWeek, Sep 2026](https://www.edweek.org/teaching-learning/federal-science-of-reading-legislation-passes-the-house/2026/09)).
  - **California AB 1454 (signed Oct 9 2025):**
    - Evidence-based reading training for elementary teachers (**$200M** one-time).
    - K–2 dyslexia screening.
    - The State Board must adopt aligned materials by **Jan 2027**.
    - California's 2025–26 budget carries **$480M** for literacy ([EdSource](https://edsource.org/2025/governor-newsom-signs-literacy-bill/742396)).
  - **Missouri** banned three-cueing as a primary method (signed Jul 9 2025) ([Missouri Independent](https://missouriindependent.com/2025/07/11/missouri-lawmakers-ban-controversial-reading-instruction-model-as-primary-method/)). APM counts **26+ states** with reading laws since 2022 and **15+** cueing bans ([APM Reports, Oct 16 2025](https://www.apmreports.org/story/2025/10/16/legislators-reading-laws-sold-a-story)).
  - **Curriculum churn:** UFLI Foundations is now the most-used program (38% of K–3 teachers), then i-Ready (33%). Benchmark Advance (19%) and Fountas & Pinnell (16%) persist ([Fordham, Apr 2026](https://fordhaminstitute.org/national/research/teachers-desk-science-reading-progress-report)).
- **Who buys:**
  1. Private structured-literacy and OG tutors, and certified academic language therapists. Solo operators who pay by card.
  2. Small reading and learning centers (2–15 tutors).
  3. K–3 interventionists, reading specialists and special-ed teachers, paying out of pocket or from a building budget.
  4. Parents of dyslexic children (take-home practice packs).
- **US market size:**
  - **Tutors (estimate, no census):** tens of thousands of US structured-literacy and OG practitioners, based on IDA, Wilson, IMSE, Barton and OG-academy trainees. Verify in the state pass.
  - **Families:** demand is large. The 2026 Reading Guru study puts SoR/OG tutoring at **$113.06/hr** on average, about **$4,409** per 9-month weekly program ([Reading Guru, 2026](https://readingguru.com/the-reading-guru-national-reading-tutoring-cost-study/)).
  - **Classroom teachers:** K–3 teachers number in the hundreds of thousands (NCES; not re-checked), but they have free tools.
- **Urgency trigger (why they'd switch NOW):** Four things line up:
  - State bans and approved-curriculum lists are forcing material swaps.
  - Tutors are capacity-capped. The Reading Guru found many providers "maxed out" with no slots, so each hour of prep saved becomes a billable slot.
  - California's January 2027 materials adoption.
  - The federal bill.
- **Fastest-selling states/metros:**
  - **Approved-curriculum mandate states** (NCTQ): AR, CO, FL, GA, LA, SC, TN, TX, VA.
  - **Early ban states:** AR, LA, FL, IN, NC, OH, SC, TX, WV, WI.
  - **California** (AB 1454).
  - **High-rate metros:** Los Angeles ($185/hr), New York ($161.67), DC ($156.67).

## Pain points (evidence)
Reddit (r/Dyslexia, r/Teachers) blocked fetching in this pass, so this list uses news, research and review sources.
- **[Price/access]** Project Read's free tier stops at 5 stories a week with no customizations. The only listed paid option is a $1,999/yr school plan, with nothing for a solo tutor ([Project Read pricing](https://www.projectread.ai/pricing)).
- **[Quality]** Teachers call decodables "boring and stupid". Many "just don't have a storyline" ([EdWeek](https://www.edweek.org/teaching-learning/decodable-books-boring-useful-or-both/2020/03)).
- **[Quality]** Publishers chasing state decodability thresholds (TX 80%, CA 75%) wrote stilted text like "Let Lin dab a lip" and cut word repetition, which reduces decoding practice ([EdWeek](https://www.edweek.org/teaching-learning/decodable-books-boring-useful-or-both/2020/03)).
- **[Complexity]** 93% of K–3 teachers use more than one reading curriculum, so materials rarely match a single scope and sequence ([The 74 on Fordham](https://www.the74million.org/article/report-nearly-one-third-of-teachers-still-use-discredited-reading-methods/)).
- **[Missing support]** Only 17% of K–3 teachers answered all the dyslexia questions correctly, and 22% don't clearly prefer phonics over cueing. Tools need built-in guidance, not just text ([Fordham, Apr 2026](https://fordhaminstitute.org/national/research/teachers-desk-science-reading-progress-report)).
- **[Price, families]** OG tutoring averages $113.06/hr and is up 4.6% since 2024; Los Angeles is $185/hr ([Reading Guru, 2026](https://readingguru.com/the-reading-guru-national-reading-tutoring-cost-study/)). Most families can't sustain $240–600/mo ([ReadFlare, Jul 2026](https://readflare.com/articles/dyslexia/orton-gillingham-apps)).
- **[Capacity]** Many tutoring companies were "maxed out" with no slots for new students ([Reading Guru](https://readingguru.com/the-reading-guru-national-reading-tutoring-cost-study/)). OG certification takes 60+ hours of coursework and 100 hours of supervised practice. Children often need 80–100 hours to gain a grade level, which costs families $8,000–11,000 a year ([We All Can Read](https://weallcanread.com/why-is-orton-gillingham-reading-instruction-so-expensive/)).
- **[Price, parent apps]** Barton costs $299 per level and Lexia Core5 $299/yr direct. Apps "cannot replace a trained OG tutor", and transfer to connected text "doesn't happen automatically" ([ReadFlare](https://readflare.com/articles/dyslexia/orton-gillingham-apps)).
- **[Policy confusion]** Critics argue Indiana's cueing ban defines "cueing" in scientifically unfounded terms, which leaves teachers unsure what is allowed ([Mora Modules](https://moramodules.com/science-of-reading-legislation/)).

## What we build (the better version)
1. **MVP** **Per-student mastery map.** The tutor ticks mastered graphemes, patterns, syllable types and "heart words". Scope-and-sequence presets are *mapped by lesson number*, never copied: generic OG order plus "compatible with UFLI / Wilson-style / Heggerty lesson N".
2. **MVP** **Deterministic decodability checker plus AI writer.** A grapheme-phoneme parser flags every word outside the child's map. The AI writer rewrites until the passage is at least 95% decodable, repeats target words at least N times and matches the child's interests. Fiction and nonfiction.
3. **MVP** **Practice kit per lesson:** word lists, nonsense words, phrase drills, sentence dictation, word chains and Elkonin boxes. Printable and tablet-ready.
4. **MVP** **Fluency probes:** 1-minute passages, tap-to-score WCPM and accuracy, and a trend chart against Hasbrouck-Tindal norms.
5. **MVP** **OG lesson-plan builder** (8–10 step template: review, new concept, blending, red words, dictation, connected text), auto-filled from the mastery map, with session notes.
6. **MVP** **Parent practice pack:** a weekly 10-minute take-home in 10+ languages with a QR code to a model-reading audio clip.
7. **MVP** **Monthly progress report PDF** for parents, IEP meetings and ESA documentation.
8. **V2** Caseload billing and ESA invoices, by connecting to the F07 LessonLedger codebase rather than rebuilding it.
9. **V2** Speech-recognition oral-reading scoring. This is opt-in with verifiable parent consent, and audio is auto-deleted after 30 days.
10. **V2** School mode: CSV/Clever rostering, district-locked scope and sequence, and a signed data-privacy agreement (DPA).
11. **V2** TPT-seller export: teacher-authors sell packs they generated, which gives us a distribution loop.

## Pricing to win
- **Solo tutor: $15/mo or $149/yr, unlimited students.** Center: **$49/mo for up to 10 tutors.** Classroom teacher: **$8/mo.** Parent practice pack: **$5/mo.** No per-student minimums, month-to-month.
- **Example:** a 6-tutor learning center on Project Read's school plan pays $1,999/yr after the first-year discount. On PhonicsPrep it pays $588/yr, saving about **$1,400/yr**.
- **The bigger ROI is time.** Estimate: saving 15 minutes of prep on each of 20 weekly sessions frees about 5 hours a week, roughly $500+ of billable time at $113/hr.

## Go-to-market (first 100 customers)
- **Associations:**
  - Exhibit or sponsor at **IDA (International Dyslexia Association) state branch** conferences and the IDA annual conference.
  - **The Reading League** state chapters and Summit.
  - **ALTA** (Academic Language Therapy Association) newsletters.
- **Communities:**
  - Facebook groups for OG, Wilson, IMSE and Barton tutors.
  - **Decoding Dyslexia** state parent groups.
  - r/Dyslexia, r/Teachers, r/specialed.
- **TPT:** free sample packs with "made with PhonicsPrep" links. A creator program for top SoR TPT sellers.
- **SEO long tail:** thousands of pages like "decodable passage for vowel teams ai/ay", "UFLI lesson 58 extra decodable", "Barton level 3 practice sentences".
- **Partners:** OG training providers (bundled with a course), tutor directories, and F07 cross-sell.

## Risks and incumbent moats
- **Free, well-funded competitors** (Project Read, LitLab, MagicSchool-style suites). We don't compete on "free decodables for a class". We win on the *individual* mastery map, the tutor workflow and parent packs.
- **Curriculum IP:** we map to lesson numbers and never copy proprietary text or word lists. UFLI, Heggerty and others are trademarks, so we say "compatible with".
- **AI accuracy:** the deterministic decodability checker is the trust feature. We publish the decodability % on every passage.
- **COPPA (children's online privacy law):**
  - MVP has no child accounts. Tutor and parent adults own all data, and the student profile is a first name or initials plus skills.
  - The amended FTC COPPA Rule (published Apr 22 2025; compliance deadline Apr 22 2026, as widely reported) requires a written information-security program, a data-retention policy and separate consent for third-party disclosure. The cheap route: no ad or analytics trackers on student-facing pages, 12-month retention, and a one-click delete.
- **FERPA and state student-privacy laws** (for school sales):
  - We operate as a FERPA "school official" under the district's direct control.
  - Sign the **Student Data Privacy Consortium (SDPC) National DPA** once and reuse it.
  - Meet CA SOPIPA/AB 1584, NY Ed Law 2-d and IL SOPPA with a public privacy policy, no data sale and deletion at contract end.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 4 | 3 | **17** |

## Sources
- [Federal 'Science of Reading' Legislation Passes the House – EdWeek, Sep 2026](https://www.edweek.org/teaching-learning/federal-science-of-reading-legislation-passes-the-house/2026/09)
- [New reading laws sweep the nation following Sold a Story – APM Reports, Oct 16 2025](https://www.apmreports.org/story/2025/10/16/legislators-reading-laws-sold-a-story)
- [More States Are Taking Aim at a Controversial Early Reading Method – EdWeek, Apr 2025](https://www.edweek.org/teaching-learning/more-states-are-taking-aim-at-a-controversial-early-reading-method/2025/04)
- [Why 8 States Banned Three-Cueing – ExcelinEd in Action, Jan 2024](https://excelinedinaction.org/2024/01/10/from-policy-to-action-why-8-states-banned-three-cueing-from-k-3-reading-instruction/)
- [State of the States 2024: Five Policy Actions – NCTQ](https://www.nctq.org/research-insights/state-of-the-states-2024-five-policy-actions-to-strengthen-implementation-of-the-science-of-reading/)
- [Missouri bans three-cueing – Missouri Independent, Jul 11 2025](https://missouriindependent.com/2025/07/11/missouri-lawmakers-ban-controversial-reading-instruction-model-as-primary-method/)
- [Governor signs literacy bill (AB 1454) – EdSource, Oct 2025](https://edsource.org/2025/governor-newsom-signs-literacy-bill/742396)
- [From the Teacher's Desk: A Science of Reading Progress Report – Fordham, Apr 2026](https://fordhaminstitute.org/national/research/teachers-desk-science-reading-progress-report)
- [Nearly one-third of teachers still use discredited methods – The 74](https://www.the74million.org/article/report-nearly-one-third-of-teachers-still-use-discredited-reading-methods/)
- ['Decodable' Books: Boring, Useful, or Both? – EdWeek, Mar 2020](https://www.edweek.org/teaching-learning/decodable-books-boring-useful-or-both/2020/03)
- [Project Read pricing](https://www.projectread.ai/pricing) · [Project Read](https://www.projectread.ai/)
- [LitLab](https://www.litlab.ai/)
- [2026 National Reading Tutoring Cost Study – The Reading Guru](https://readingguru.com/the-reading-guru-national-reading-tutoring-cost-study/)
- [Why Is OG Instruction So Expensive? – We All Can Read](https://weallcanread.com/why-is-orton-gillingham-reading-instruction-so-expensive/)
- [Orton-Gillingham apps – ReadFlare, Jul 2026](https://readflare.com/articles/dyslexia/orton-gillingham-apps)
- [Lexercise professional therapy](https://www.lexercise.com/online-dyslexia-treatment/professional-therapy)
- [Science of Reading Legislation critique – Mora Modules](https://moramodules.com/science-of-reading-legislation/)

## Verification (Sep 25 2026)
- ✅ Project Read pricing — the free plan allows "up to 5 per week, no customizations". The School plan is $1,999/yr ($999 the first year), Tutor is "$15 per student (100 minimum)", and the UFLI portal is $4/student. There is no paid individual-teacher plan ([source](https://www.projectread.ai/pricing))
- ❌ Federal bill date — EdWeek says H.R. 7890 passed the House on **Sep 16**, 2026 (the article was published Sep 17), so the date was corrected. The rest checks out: $194M CLSD in 23 states, "more than 40 states" with SoR laws, at least 14 requiring an end to three-cueing, and the Senate READ Act clearing committee in July 2026 ([source](https://www.edweek.org/teaching-learning/federal-science-of-reading-legislation-passes-the-house/2026/09))
- ✅ CA AB 1454 — signed Oct 9, 2025, with $200M one-time for teacher training inside $480M for literacy in 2025–26. It adds K–2 screening and requires the SBE to adopt aligned materials by January 2027 ([source](https://edsource.org/2025/governor-newsom-signs-literacy-bill/742396))
- ⚠️ Reading Guru rates — $113.06/hr, $4,409 per 9-month program, LA $185, NY $161.67, DC $156.67 and "maxed out" providers are all confirmed. The 4.6% is the increase "since 2024", not per year, and was corrected ([source](https://readingguru.com/the-reading-guru-national-reading-tutoring-cost-study/))
- ✅ Missouri cueing ban — signed Jul 9, 2025; three-cueing is barred as the *primary* method ([source](https://missouriindependent.com/2025/07/11/missouri-lawmakers-ban-controversial-reading-instruction-model-as-primary-method/))
