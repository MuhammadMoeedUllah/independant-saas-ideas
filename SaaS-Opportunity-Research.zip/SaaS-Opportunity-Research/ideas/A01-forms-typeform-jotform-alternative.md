# FormFlare: a cheaper, better Typeform / Jotform / SurveyMonkey for agencies, multi-vendor organizers and small wellness practices

**One-liner:** A fun, conversational form builder that collects answers on every channel (web, embed, QR, SMS, WhatsApp, kiosk, offline), gives each vendor or client their own subdomain, and never caps responses. HIPAA mode costs a fraction of Jotform Gold.

## Snapshot
- **Replaces:**
  - **Typeform** (pricing page, checked Sept 24, 2026): Basic $29/mo monthly or $25/mo annual for **100 responses/mo** with Typeform branding still on. Plus $59/$50 for 1,000 responses/mo, 3 seats, branding removed. Business $99/$83 for 10,000 responses/mo, 5 seats. Growth Flow $349/$266. Talent $169/$119. **HIPAA only on Enterprise (custom quote).** Per Trustpilot reviewers in Aug 2026, the free plan allows 10 responses/mo.
  - **Jotform** (Zite guide, Jan 30, 2026): Starter free (5 forms, 100 submissions/mo). Bronze $39 monthly / $34 annual (1,000 submissions/mo). Silver $49/$39 (2,500). Gold $129/$99 (10,000). **HIPAA only on Gold or above.** Every plan below Enterprise is single-user. Monthly form-view caps apply, and Gold still caps payment submissions at 1,000/mo.
  - **SurveyMonkey** (Survicate guide, Mar 23, 2026): Standard $99/mo billed monthly (1,000 responses/mo). Advantage Annual $39/mo ($468/yr). Premier Annual $139/mo ($1,668/yr). Team Advantage $30/user/mo and Team Premier $92/user/mo, both **3-user minimum, annual only**. Overage is **$0.15/response**. Unused responses don't roll over, and deleted responses still count against the cap.
  - **Google Forms**: free, but branding, logic, analytics and file-upload options are limited (Capterra reviews, 2026).
  - **Cheap challengers already in the market:** Tally is free with unlimited forms and submissions. Tally Pro is $24/mo (branding removal, custom domains, unlimited team members). Tally Business is $74/mo (tally.so/pricing, Sept 2026). Fillout is in the same price band.
- **Recent price hikes / changes:** Trustpilot reviewers report Jotform annual renewals at up to 3x the prior price. The "yearly discount" is one-time only, and plans renew at full price (Aug 31 and Sept 1, 2026). SurveyMonkey keeps annual-only team plans with 3-seat minimums and per-response overages. Typeform's cheapest paid tier still carries its branding and allows only 100 responses/mo.
- **Who buys (ranked by speed):**
  1. **Agencies and freelancers** who build forms for local-business clients. They need white-label subdomains per client and one bill.
  2. **Small health/wellness practices** (therapists, chiropractors, PT, med spas, dietitians, fitness studios) that need HIPAA or health-data-safe intake for less than Jotform Gold at $99–129/mo.
  3. **Multi-vendor and seasonal organizers** (farmers markets, craft fairs, festivals, trade-show exhibitors, chambers, PTAs, franchise brands, property managers). They need a subdomain per vendor, QR/kiosk/offline capture, and burst pricing for a few events a year.
  The buyer is the owner, office manager or event lead, paying with a card.
- **US market size:** Every business and nonprofit uses forms. Estimates: about 34–36M US small businesses (SBA Office of Advocacy annual FAQ) and 1.5M+ registered nonprofits (IRS). The fast-buy sub-segments (agencies, private-practice health and wellness, event organizers) number in the hundreds of thousands. All counts are estimates.
- **Urgency trigger (why they'd switch NOW):**
  - Annual renewal at a higher price (Jotform), hitting a response cap mid-campaign (Typeform, SurveyMonkey), or a HIPAA requirement forcing a jump to $99+/mo tiers.
  - State consumer-health-data laws (WA My Health My Data Act, NV SB 370) push wellness businesses to get consent and data handling right on intake forms. Verify the per-state specifics in the state pass.
- **Fastest-selling states/metros:** WA (My Health My Data), NV, TX (HB 300 medical privacy), and CA for health-data-sensitive intake. Event-dense metros (Austin, Nashville, Orlando, Las Vegas, Denver) for kiosk/QR/offline. Agency clusters in NYC, LA, Austin, Miami and Denver.

## Pain points (evidence)
- **[Price]** A respondent learned only at the 11th response that Typeform's free plan caps at 10 responses/mo. The creator had to pay about $43 to reopen a form already sent out (Trustpilot, Aug 20, 2026) ([source](https://www.trustpilot.com/review/typeform.com))
- **[Price]** A small association that runs one or two events a year calls Typeform "very nice" but far too expensive for occasional use (Trustpilot, Aug 11, 2026) ([source](https://www.trustpilot.com/review/typeform.com))
- **[Price]** A student researcher hit the response ceiling on deadline and found basic redirects locked behind a much higher tier (Trustpilot, Aug 22, 2026) ([source](https://www.trustpilot.com/review/typeform.com))
- **[Complexity/UX]** A user spent hours building a form with Typeform's AI, then hit surprise upgrade walls at publish time and failed submissions, and left (Trustpilot, Aug 7, 2026) ([source](https://www.trustpilot.com/review/typeform.com))
- **[Lock-in/Contracts]** A Jotform annual plan renewed at roughly triple the previous price with no advance notice. The account was suspended after the customer asked for a refund (Trustpilot, Sept 1, 2026) ([source](https://www.trustpilot.com/review/www.jotform.com))
- **[Lock-in/Contracts]** Jotform's annual discount applies once, and the plan renews at full price, catching users off guard (Trustpilot, Aug 31, 2026) ([source](https://www.trustpilot.com/review/www.jotform.com))
- **[Price]** Jotform view caps: an embedded form on a page with 500 daily visitors uses up its views in about 2 days, even if only 10 people submit (Zite pricing analysis, Jan 30, 2026) ([source](https://www.zite.com/blog/jotform-pricing))
- **[Complexity/UX]** A reviewer calls Jotform's interface "shockingly bad", with layers of outdated features and an AI assistant that doesn't help (Trustpilot, Sept 23, 2026) ([source](https://www.trustpilot.com/review/www.jotform.com))
- **[Missing features]** Jotform forms don't keep unfinished submissions when a respondent leaves the session, so they have to start over (Trustpilot, Sept 11, 2026) ([source](https://www.trustpilot.com/review/www.jotform.com))
- **[Support]** A paying Jotform customer had forms disappear and saw repeated "too many requests" errors (Trustpilot, Sept 14, 2026) ([source](https://www.trustpilot.com/review/www.jotform.com))
- **[Price]** SurveyMonkey: responses don't roll over, deleted responses still count toward the cap, and overage costs $0.15/response (Survicate, Mar 23, 2026) ([source](https://survicate.com/blog/surveymonkey-pricing/))
- **[Missing features]** Google Forms: a legal assistant says header, color and branding options are too limited to look professional, and analytics are shallow (Capterra, Mar 30, 2026). A tour manager says design choices are "very limited" (Capterra, Jun 15, 2026). A service rep hit the form-wide file-upload cap when many clients uploaded at once (Capterra, Sept 12, 2026) ([source](https://capterra.com/p/176571/Google-Forms/reviews/))

**Honest read:** "Everything Google Forms does + themes + custom domain" is already sold by Tally for $0–24/mo, so it is not a moat. What makes this idea different is the parts nobody bundles cheaply: **(a) omnichannel capture (SMS, WhatsApp, kiosk, offline)**, **(b) multi-tenant subdomains per vendor with roll-up analytics**, **(c) HIPAA / health-data mode under $50**, and **(d) burst or event pricing**.

## What we build (the better version)
1. **Fun mode.** Conversational one-question-at-a-time flow with reactions, a progress "quest" bar, confetti on submit, voice answers (transcribed), and an optional classic long-form mode. **MVP**
2. **Works 360 degrees.** Collect answers anywhere:
   - web link, embed and QR code with per-QR-code source tracking. **MVP**
   - **form-by-text** over SMS: we text one question at a time and replies fill the form (Twilio, 10DLC registration done for the customer). **MVP**
   - WhatsApp flow. **V2** (needs Meta Business approval)
   - email-embedded first question. **V2**
3. **Kiosk and offline mode.** Installable PWA with auto-reset between respondents, an attract screen and PIN exit. Answers are stored on the device and sync when back online (trade shows, markets, clinics with bad Wi-Fi). **MVP**
4. **Emails you.** Instant alerts, a daily or weekly digest, conditional alerts ("only if budget > $5k"), and respondent auto-replies with a PDF copy. **MVP**
5. **Everything Google Forms does.** All question types, sections, branching logic, quizzes with auto-grading, response validation, prefilled links, file uploads, and live Google Sheets sync. **MVP**
6. **Custom themes.** AI theme generated from a logo or website URL, Google Fonts, custom CSS, and **branding removal on every paid tier**. **MVP**
7. **Subdomains per vendor.** `vendor.brand.com` or `vendor.formflare.app`. Each vendor or client gets its own forms, inbox and alerts. The parent account sees a roll-up across vendors. **MVP** on our domain plus one custom domain (auto-SSL). **V2** adds a wildcard custom domain per tenant and per-vendor billing.
8. **Analytics.** **MVP:** unique visitors, starts, completions, drop-off per question, channel breakdown (QR, SMS, web, kiosk), time-to-complete, bulk response actions (tag, export, delete, PDF). **V2:** a demographics dashboard built from answered fields plus coarse geo (ZIP or IP) and device and language data, with no inferred sensitive traits.
9. **Unlimited responses and no view caps** on paid tiers (fair use). **MVP**
10. **Save and resume** partial submissions, with a magic link emailed to the respondent. **MVP**
11. **Payments and signatures.** Stripe checkout fields are **MVP**. A legally binding e-signature field shared with A04 is **V2**.
12. **One-click migration.** Import from Google Forms (Workspace add-on or URL), Typeform, Jotform and SurveyMonkey exports. An AI "describe your form" generator. **MVP**
13. **HIPAA / health-data mode.** Signed BAA, field-level encryption, audit log, retention auto-delete, and WA MHMDA-style consent blocks. **V2** (6–8 weeks, needs HIPAA-eligible hosting)
14. **Bulk follow-up.** Text or email every respondent who matches a filter ("everyone who picked Saturday"). **V2**

## Pricing to win
| Plan | FormFlare | What it replaces |
|---|---|---|
| Free | Unlimited forms and responses, small badge | Tally Free, Google Forms |
| Pro **$19/mo** | No branding, custom domain, kiosk and offline, unlimited seats, SMS at cost +20% | Typeform Plus $59, Jotform Bronze $39, Tally Pro $24 |
| Multi-vendor / Agency **$49/mo** | 25 vendor subdomains, roll-up analytics, white-label, then +$1/vendor | Typeform Business $99, or one Jotform account per client |
| Health **$39/mo** | Pro + BAA + encryption + audit log | Jotform Gold $99–129, Typeform Enterprise (custom) |
| Event Pass **$15 per 30 days** | Pro features for one burst, no renewal | Annual plans that seasonal orgs never use |

All plans are month-to-month and migration is free.
- **Savings example:** a therapist on Jotform Gold monthly ($129) pays $39 with us, saving **$1,080/yr**.
- **Savings example:** an agency running 10 client accounts on Jotform Bronze ($34 × 10 = $340/mo) pays $49, saving about **$3,500/yr**.

## Go-to-market (first 100 customers)
- **Agencies first:** post a "white-label forms for your clients" offer in r/agency, r/marketing, r/web_design and r/Wordpress. Recruit from Webflow, WordPress and Squarespace designer communities. Launch a Zapier directory listing and a Google Workspace Marketplace add-on ("import this Google Form and make it beautiful").
- **Health and wellness:** r/therapists, r/privatepractice and r/Chiropractic, plus private-practice Facebook groups. Lead content: "HIPAA intake form under $40", "Jotform HIPAA alternative", and "Washington My Health My Data consent form template".
- **Events and multi-vendor:** Farmers Market Coalition, state farmers-market associations, IAEE (exhibition organizers), local chambers of commerce, and National PTA and state PTAs. Demo kiosk and offline mode at markets and trade shows.
- **"Switch from X" SEO:**
  - "Typeform alternative unlimited responses"
  - "Jotform renewal price increase"
  - "SurveyMonkey alternative no response limit"
  - "Google Forms custom domain"
  - "survey by text message"
  - "offline survey kiosk app"
- **Launch:** Product Hunt, plus an AppSumo-style limited deal for seed users only (cap it to avoid lifetime-deal debt).

## Risks and incumbent moats
- **Free and cheap competition** (Google Forms, Tally, Fillout). Answer: don't compete on basic forms. Lead with omnichannel, multi-vendor and health mode, and keep a generous free tier.
- **SMS and WhatsApp compliance.** 10DLC brand registration, TCPA and state mini-TCPAs (FL, OK, MD) all apply. Answer: SMS only to people who opted in, with STOP handling built in and pass-through carrier fees.
- **HIPAA.** Needs BAA-eligible infrastructure (AWS/GCP BAA), encryption and an audit log. Answer: ship health mode as V2 and don't market HIPAA until the BAA is signed. SOC 2 comes later.
- **Abuse.** Form builders are widely used for phishing. Answer: automated phishing detection, domain reputation monitoring, and new accounts can't collect passwords or card fields until verified.
- **Data lock-in is low** (CSV export everywhere). That helps switching in, and it means we must win on product, not lock-in.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 4 | 5 | **19** |

## Sources
- [Typeform Plans & Pricing](https://www.typeform.com/pricing) (checked Sept 24, 2026)
- [Typeform on Trustpilot](https://www.trustpilot.com/review/typeform.com) (2.6/5, 777 reviews, Sept 2026)
- [Jotform Pricing Breakdown 2026 – Zite](https://www.zite.com/blog/jotform-pricing) (Jan 30, 2026)
- [Jotform on Trustpilot](https://www.trustpilot.com/review/www.jotform.com) (4.3/5, 1,835 reviews; complaints dated Aug–Sept 2026)
- [SurveyMonkey Pricing 2026 – Survicate](https://survicate.com/blog/surveymonkey-pricing/) (Mar 23, 2026)
- [Tally Pricing](https://tally.so/pricing) (Sept 2026)
- [Google Forms Reviews – Capterra](https://capterra.com/p/176571/Google-Forms/reviews/) (2026)
- [HIPAA Compliance: Pricing plan – Jotform Answers](https://www.jotform.com/answers/37597661-hipaa-compliance-pricing-plan)
