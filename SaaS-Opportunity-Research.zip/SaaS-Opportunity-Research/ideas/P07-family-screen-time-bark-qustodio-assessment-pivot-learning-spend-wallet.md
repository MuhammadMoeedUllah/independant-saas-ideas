# LearnLedger: instead of a cheaper Bark / Qustodio (not recommended), a family learning-spend wallet for parents paying for tutoring, classes and curriculum with 529, ESA and scholarship money

**One-liner:** First, an honest verdict: a small AI-built team **should not** try to beat Bark, Qustodio or Circle on screen time, or Yoto and Tonies on kid audio, because operating-system and hardware moats decide those markets. The sharper parent-facing wedge is **LearnLedger**. It captures every receipt for kids' learning (tutoring, online classes, curriculum, lessons, learning subscriptions), checks it against **529, ESA and scholarship rules and each state's 529 conformity**, and warns before kid-app subscriptions renew.

## Snapshot
- **Replaces (screen-time category, assessed):**
  - **Bark** (page updated Aug 7 2026) ([Bark pricing](https://www.bark.us/pricing/)):
    - App: **$14/mo or $99/yr**, unlimited kids and devices.
    - Bark Home: **$6/mo or $79 one-time**.
    - **Bark Phone:** service from **$29/mo**, plus **$10–25/mo** for the device over 24 months.
    - **Bark Watch:** **$15/mo**, plus $10/mo device.
  - **Qustodio:** Basic **$59.95/yr** (5 devices), Complete **$104.95/yr** (unlimited devices) ([Qustodio](https://www.qustodio.com/en/premium/), Sep 2026).
  - **Circle, Amazon Kids+, Yoto, Tonies:** not re-priced. Amazon blocks automated fetching.
  - Built into the operating system for free: **Apple Screen Time** and **Google Family Link**.
- **Replaces (LearnLedger pivot):** spreadsheets, shoebox receipts, generic subscription trackers (Rocket Money-type apps) and 529 plan portals, none of which apply K–12 529, ESA or state-conformity rules.
- **Recent price hikes / changes (switching windows):**
  - **Platform shift against third-party controls.** The **Texas App Store Accountability Act has been enforceable since Jun 10 2026**, after the Fifth Circuit stayed the preliminary injunction ([Morrison Foerster](https://www.mofo.com/resources/insights/251111-texas-targets-app-stores-with-new-accountability-law)).
    - App stores must place users in age bands (under 13 / 13–15 / 16–17 / 18+) and get **parental consent for each download or in-app purchase** by a minor.
    - Utah and Louisiana have similar laws ([MoFo](https://www.mofo.com/resources/insights/251111-texas-targets-app-stores-with-new-accountability-law); [Future of Privacy Forum](https://fpf.org/blog/comparing-enacted-app-store-accountability-acts/)).
    - Consent and age-gating move *into* Apple and Google, which strengthens free built-in controls.
  - **Money shift that favors LearnLedger:**
    - **OBBBA (Jul 2025):** 529 K–12 withdrawals capped at **$20k/child/yr** (up from $10k). Newly qualified expenses include curriculum, online education programs, tutoring, test fees and therapies ([PolitiFact, Feb 2026](https://politifact.com/truth-o-meter/promises/maga-meter-tracking-donald-trumps-2024-promises/promise/387540/provide-10000-per-child-tax-free-to-homeschoolers/article/387543/)).
    - **Federal tax-credit scholarships from Jan 1 2027:** $1,700 credit. **31 states** planned to opt in as of May 2026 ([ECS](https://www.ecs.org/how-the-federal-tax-credit-scholarship-program-may-affect-states/)).
    - **13 states don't conform** to federal K–12 529 treatment: CA, CO, CT, HI, IL, MI, MN, MT, NE, NM, NY, OR, VT. **California adds a 2.5% penalty.** Many states have recapture rules ([Savingforcollege, Jan 5 2026](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)).
    - **ESA wallets** in about 18 states (see F06). **Texas TEFA** year one (2026–27).
- **Who buys:** parents paying for kids' learning outside public school: private-school, homeschool, tutoring and enrichment families. Card, consumer subscription.
- **US market size:**
  - **Screen-time:** huge consumer market, but owned by the operating systems.
  - **LearnLedger:** estimate. The core is about 3.4M homeschool students ([NHERI](https://nheri.org/how-many-homeschool-students-are-there-in-the-united-states/)), plus private-school families and ESA recipients. The wider pool is every 529 account holder with K–12 children (529 account counts not verified this pass).
- **Urgency trigger (why they'd switch NOW):**
  - **Tax season Jan–Apr 2027** is the first year with the $20k cap and the expanded expense list. Every 529 withdrawal needs matching receipts, and families in the 13 non-conforming states risk state tax or penalties.
  - Scholarship money flows from Jan 2027.
- **Fastest-selling states/metros:**
  - **Non-conforming states with big private and homeschool populations** (CA, NY, IL, MI, MN, CO), where the risk is biggest.
  - **ESA states:** TX, AZ, FL, UT, AR.

## Pain points (evidence)
Screen-time complaints are loud. LearnLedger's pain is **inferred from rule complexity**, not yet from user quotes, so validate it with 20 parent interviews before building.
- **[Billing/lock-in, Bark]** Bark's TrustScore is **1.8/5** (112 reviews). Parents report unexpected charges, trouble cancelling and disputed return fees, including being charged despite FedEx proof of return ([Trustpilot](https://www.trustpilot.com/review/bark.us)).
- **[OS moat, Bark]** On iPhone, after iOS updates, reviewers say Bark needed a **$49 plug-in device**, and one said it "stopped working after just a few days" ([Trustpilot](https://www.trustpilot.com/review/bark.us)).
- **[Quality, Bark]** Alerts flag harmless chats (like birthday-present talk), and a teen says the controls are easy to bypass ([Trustpilot](https://www.trustpilot.com/review/bark.us)).
- **[Hardware, Bark]** Bark Phones and Watches fail within months. The phone's VPN makes pages "take ten minutes to load" ([Trustpilot](https://www.trustpilot.com/review/bark.us)).
- **[OS moat, Qustodio]** TrustScore **2.5/5** (476 reviews). On iOS, time limits are "easy to bypass", background apps count as screen time and reporting stops after reinstalls (Mar 19 2026) ([Trustpilot](https://www.trustpilot.com/review/qustodio.com)).
- **[Bypass, Qustodio]** Kids "completely bypass" the app, and one parent couldn't even uninstall it (Apr 5 2026) ([Trustpilot](https://www.trustpilot.com/review/qustodio.com)).
- **[Billing, Qustodio]** A parent was charged an annual renewal after deleting the app with no warning (refunded, Apr 9 2026). Google's refund policy kept another parent's money (Apr 12 2026) ([Trustpilot](https://www.trustpilot.com/review/qustodio.com)).
- **[Support, Qustodio]** One parent couldn't add an Android phone: "no help online, no online chat support" (Mar 24 2026) ([Trustpilot](https://www.trustpilot.com/review/qustodio.com)).
- **[Rules complexity, LearnLedger]** 13 states treat K–12 529 withdrawals as non-qualified. California adds 2.5%, and outbound rollovers trigger recapture in about 15 states ([Savingforcollege](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)).
- **[Rules complexity, LearnLedger]** States "may take time to adopt the expanded K–12 expense categories" from OBBBA, so federal and state treatment can differ for the same tutoring bill ([Savingforcollege](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)).

## What we build (the better version)
**Screen-time verdict: do not build.**
- Monitoring on iOS depends on Apple's Screen Time API limits and device-management/VPN workarounds.
- Reliable enforcement needs hardware (Bark Phone) or carrier deals.
- Kid-audio ecosystems (Yoto, Tonies) are hardware plus licensed content catalogs.
- The new app-store laws push parental consent into Apple and Google.

**LearnLedger (recommended pivot):**
1. **MVP** **Receipt capture:** photo, PDF upload or a unique forwarding email (avoids restricted Gmail API scopes and Google's security assessment). AI extracts vendor, child, amount, date and category.
2. **MVP** **Rules engine:** tags each expense as eligible or not for federal 529 K–12, *your state's* 529 conformity, your ESA program (e.g. TEFA) and 2027 scholarship programs. Rules are versioned by tax year and cite their sources.
3. **MVP** **529 withdrawal planner:** "you can withdraw $X tax-free this year". Warnings for non-conforming states and recapture. Year-end **1099-Q matching report** for the tax preparer.
4. **MVP** **Kid-subscription radar:** detects learning subscriptions from forwarded receipts (Outschool credits, Lingokids, ABCmouse, Kumon, lessons). Renewal reminders 7 days ahead, with direct cancel links.
5. **MVP** **Family budget by child and category**, shareable with a co-parent.
6. **V2** ESA wallet export formats (ClassWallet, Odyssey, Step Up; shared with F06).
7. **V2** Provider receipts on request: a "request a 529-ready receipt" link sent to the tutor, built on ClassHouse (P04) and LessonLedger (F07).
8. **V2** CPA/tax-preparer portal (read-only share).

## Pricing to win
- **Free: up to 20 receipts/yr. Family: $39/yr.**
- **Comparison:**
  - Bark ($99/yr) and Qustodio Complete ($104.95/yr) sell a different job, and we don't compete there.
  - LearnLedger's value is avoided tax and penalties plus cancelled subscriptions. Example (estimate): catching one forgotten $119/yr kids' app renewal, or one non-qualified $2,000 withdrawal in CA (2.5% penalty = $50 plus state tax), covers the fee.

## Go-to-market (first 100 customers)
- **Cross-sell** from P03 (homeschool), P04 (independent classes) and F07 (tutors), whose parents already need receipts.
- **Communities:** r/personalfinance, r/homeschool, ESA parent Facebook groups (TX, AZ, FL) and private-school parent associations.
- **SEO:** "can I use 529 for tutoring", "is [state] 529 K-12 conforming", "TEFA receipts", "529 homeschool curriculum 2026".
- **Partners:** tax preparers and CPAs (referral fee), and 529 advisors.
- **Timing:** launch by Dec 2026 for the 2027 tax season.

## Risks and incumbent moats
- **Screen-time moats** (why we don't build it): operating-system control (Apple/Google), hardware (Bark Phone/Watch, Yoto and Tonies players), carrier deals, content licensing, and new app-store consent laws that strengthen the built-ins.
- **LearnLedger risks:**
  - **Tax-advice liability:** informational, cites sources, and recommends a tax professional. Carry E&O insurance.
  - **Rules drift** as states update conformity: a versioned rules table reviewed each quarter.
  - **Unproven pain:** validate with 20 interviews, a landing page and waitlist before building.
- **Privacy:**
  - Only adult financial data. Children appear by first name only, which keeps us outside COPPA's child-directed scope.
  - Encrypted receipt storage, no data sale, no ad trackers, one-click delete.
  - SOC 2 readiness once revenue passes about $100k.

## Scores (1–5, 5 = best for us)
| Option | Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|---|
| Screen-time / kid-content clone (Bark, Qustodio, Yoto) | 3 | 2 | 1 | 3 | 4 | **13** |
| **LearnLedger pivot (recommended)** | 3 | 3 | 4 | 3 | 4 | **17** |

## Sources
- [Bark pricing, Aug 2026](https://www.bark.us/pricing/)
- [Bark reviews – Trustpilot](https://www.trustpilot.com/review/bark.us)
- [Qustodio Premium pricing](https://www.qustodio.com/en/premium/)
- [Qustodio reviews – Trustpilot](https://www.trustpilot.com/review/qustodio.com)
- [Texas App Store Accountability Act update – Morrison Foerster](https://www.mofo.com/resources/insights/251111-texas-targets-app-stores-with-new-accountability-law)
- [Comparing Enacted App Store Accountability Acts – Future of Privacy Forum](https://fpf.org/blog/comparing-enacted-app-store-accountability-acts/)
- [Federal law expands 529 expenses – PolitiFact, Feb 20 2026](https://politifact.com/truth-o-meter/promises/maga-meter-tracking-donald-trumps-2024-promises/promise/387540/provide-10000-per-child-tax-free-to-homeschoolers/article/387543/)
- [How the Federal Tax Credit Scholarship Program May Affect States – ECS, May 2026](https://www.ecs.org/how-the-federal-tax-credit-scholarship-program-may-affect-states/)
- [States that Do Not Conform with Federal 529 Plan Tax Laws – Savingforcollege, Jan 2026](https://www.savingforcollege.com/article/states-that-do-not-conform-with-federal-529-plan-tax-laws)
- [NHERI homeschool count 2024–25](https://nheri.org/how-many-homeschool-students-are-there-in-the-united-states/)
