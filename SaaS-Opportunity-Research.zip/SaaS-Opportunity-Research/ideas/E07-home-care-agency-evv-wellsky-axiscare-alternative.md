# Shiftwell: a cheaper, simpler WellSky Personal Care / AxisCare for small home care agencies, with state-by-state EVV built in

**One-liner:** Scheduling, a caregiver app with federal EVV data capture, care plans, private-pay billing and payroll export for 10–150 caregiver non-medical home care agencies. It exports to each state's EVV aggregator in open-model states.

## Snapshot
- **Replaces:**
  - **WellSky Personal Care** (formerly ClearCare): pricing not published in the reviews reviewed.
  - **AxisCare, AlayaCare:** quote-based; not verified in this pass.
  - **HHAeXchange provider portal:** in states or MCOs where HHAeXchange is the mandated or aggregator system, agencies often get a free portal but still need their own scheduling, payroll and private-pay tools (verify per state).
- **Recent price hikes / changes:**
  - **Federal EVV mandate (21st Century Cures Act §12006)** for Medicaid personal care services (in force since 2020–2021 with delays) and home health services (Jan 2024). Every state now runs an EVV aggregator.
  - WellSky customers report **lag after the open-model EVV integration launched** (Capterra, Sep 2025).
  - The **CMS 2024 Medicaid Access Rule** "80/20" provision would require 80% of Medicaid HCBS payments for personal care, homemaker and home health aide services to go to direct-care worker compensation, with a later compliance date (from memory, about 2030). Its status after 2025–2026 federal changes was **not re-verified in this pass**.
- **Who buys:** Owners and administrators of independent non-medical home care agencies (private pay, Medicaid waiver, VA, long-term-care insurance), typically 10–150 caregivers.
- **US market size:** Our estimate is tens of thousands of US non-medical home care and personal care agencies (not verified in this pass; check HCAOA and state licensure counts).
- **Urgency trigger (why they'd switch NOW):**
  - State EVV aggregator changes and open-model integrations (where the incumbent's integration is slow or buggy).
  - Medicaid claim denials for EVV mismatches.
  - The 80/20 wage pass-through reporting build-up (verify status).
  - Franchise exits: independents leaving franchise-mandated software.
- **Fastest-selling states/metros:** Open-model states where agencies may bring their own EVV and must export to the state aggregator, and large Medicaid personal-care states (NY, CA, TX, PA, IL, FL, NJ, OH, MI, NC). The **public sources disagree heavily** on which aggregator each state uses (table below). The per-state pass must confirm each against the state Medicaid EVV page.

**State EVV aggregator map, as claimed by two 2026 sources (conflicts flagged):**

| State | HHAeXchange's state guide (aggregator; HHAX role) | AveeCare list (vendor; model) | Agree? |
|---|---|---|---|
| AL | In house; optional | Sandata; closed | No |
| AK | Therap; optional | Sandata; closed | No |
| AZ | In house; optional | Sandata (AHCCCS); open + aggregator | No |
| AR | First Data (PCS), Sandata (HHCS) | HHAeXchange; open | No |
| CA | Sandata; optional | CalEVV (says HHAeXchange-based); open | No |
| CO | Sandata | AuthentiCare; closed | No |
| CT | Sandata | Sandata; closed | Yes |
| DE | Sandata | Sandata; closed | Yes |
| DC | Sandata | not listed | n/a |
| FL | **HHAeXchange = state aggregator** | Tellus/Netsmart; closed | No |
| GA | Conduent (Netsmart) | HHAeXchange; open | No |
| HI | Sandata | Sandata; closed | Yes |
| ID | Sandata | AuthentiCare; closed | No |
| IL | **HHAeXchange = state aggregator** | HHAeXchange; open | Yes |
| IN | Sandata | HHAeXchange; open | No |
| IA | CareBridge (MCO model) | Sandata; closed | No |
| KS | First Data | HHAeXchange; open | No |
| KY | Therap | CareBridge; closed | No |
| LA | SRI | Sandata; closed | No |
| ME | Sandata | AuthentiCare; closed | No |
| MD | FEI | CareBridge/AuthentiCare; closed | No |
| MA | Sandata | Sandata; closed | Yes |
| MI | **HHAeXchange = state aggregator** | HHAeXchange; open | Yes |
| MN | **HHAeXchange = state aggregator** (note: "80% by July 2026") | AuthentiCare; closed | No |
| MS | **HHAeXchange = state aggregator** | Sandata; closed | No |
| MO | Sandata | Sandata; closed | Yes |
| MT | Netsmart | AuthentiCare; closed | No |
| NE | Netsmart | Sandata; closed | No |
| NV | Sandata | CareBridge; closed | No |
| NH | First Data | Sandata; closed | No |
| NJ | **HHAeXchange = state aggregator** | Sandata; closed | No |
| NM | First Data | Sandata; closed | No |
| NY | General Dynamics | HHAeXchange; open | No |
| NC | Sandata | HHAeXchange; open | No |
| ND | Sandata | Sandata; closed | Yes |
| OH | Sandata | Sandata; closed | Yes |
| OK | Acumen | Sandata; closed | No |
| OR | eXPRS | Sandata; closed | No |
| PA | **HHAeXchange = state aggregator** | Sandata; closed | No (possibly both: FFS vs MCO) |
| RI | Sandata | Tellus/Netsmart; closed | No |
| SC | **HHAeXchange = state aggregator** | Sandata; closed | No |
| SD | Therap | Sandata; closed | No |
| TN | N/A | HHAeXchange; open | No |
| TX | Accenture | HHAeXchange (Texas EVV); open | No (possibly both: aggregator operator vs state-provided system) |
| UT | In house | Sandata; closed | No |
| VT | Sandata | Sandata; closed | Yes |
| VA | In house | CareBridge; closed | No |
| WA | CNSI | Sandata; closed | No |
| WV | **HHAeXchange = state aggregator** | Sandata; closed | No |
| WI | Sandata | Sandata; closed | Yes |
| WY | CareBridge | Sandata; closed | No |

The two sources agree on only 11 states (CT, DE, HI, IL, MA, MI, MO, ND, OH, VT, WI). Many states likely use **different systems for fee-for-service versus managed-care plans**, which explains some conflicts. Treat this table as a lead list, not fact. Sources: [HHAeXchange State-by-State EVV Guide](https://www.hhaexchange.com/state-evv-status) and [AveeCare EVV Vendors by State (2026)](https://www.aveecare.com/resources/evv-vendors-by-state).

## Pain points (evidence)
- **[Support]** An administrator says help-line waits run at least 45 minutes and support specialists don't respond to requests (Capterra, Jul 2026) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Complexity/UX]** A service coordinator at a 51–200 employee agency says shifts revert or disappear unexpectedly and scheduling suffers (Capterra, Mar 2026) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Missing features / EVV]** An HR manager reports the system lags since the open-model EVV integration launched (Capterra, Sep 2025) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Complexity/UX]** A caregiver says the app malfunctions often and some areas don't work even on strong Wi-Fi (Capterra, Jun 2026) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Missing features]** Reporting is weak, and the system needs resets to generate needed reports (Capterra, Jan 2025) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Missing features]** A CEO says the CRM side needs major upgrades and lacks AI marketing features (Capterra, Sep 2025) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Complexity/UX]** An agency president calls the platform buggy, with most features not working on the mobile website (Capterra, Feb 2025) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Support]** An owner rated it 1/5 because engineering tickets went unresolved for long periods (Capterra, Aug 2023) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Price]** A reviewer notes costs climb as client volume grows (Capterra) ([Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)).
- **[Complexity/regulatory]** Even basic questions like which EVV aggregator a state uses get contradictory answers from vendor sources (see table). Agencies bear the confusion and the denial risk ([HHAeXchange](https://www.hhaexchange.com/state-evv-status), [AveeCare](https://www.aveecare.com/resources/evv-vendors-by-state)).

## What we build (the better version)
1. **MVP:** An offline-capable **caregiver app** for GPS clock-in/out that captures the **six federal EVV data elements** (service type, individual receiving, individual providing, date, location, start/end time), plus task checklists, visit notes and photos.
2. **MVP:** **Scheduling** with caregiver matching (skills, language, distance, availability), open-shift broadcast by SMS ("first to accept wins"), and missed-visit alerts to the office.
3. **MVP:** **Care plans** covering ADL/IADL tasks, a family portal, and visit summaries.
4. **MVP:** **Private-pay billing**: invoices, autopay (Stripe/ACH), and **long-term-care insurance claim packets**.
5. **MVP:** **Payroll export** (Gusto, ADP) with overtime and travel-time calculations. Home care workers employed by agencies have generally been owed overtime since the DOL rule took effect in 2015. DOL proposed rolling that back in 2025, and its current status was not verified in this pass, so make the rule a per-state/per-date setting. Some states have their own overtime rules regardless.
6. **MVP:** **EVV export for one open-model state** at launch, then expand state by state. Pick the first state after the per-state pass confirms its aggregator spec and certification process.
7. **MVP:** Caregiver compliance files: training hours, TB tests, background checks, license and certification expiry, driven by state rules.
8. **V2:** More state aggregator connectors (Sandata, HHAeXchange, Netsmart/Tellus, CareBridge, AuthentiCare), Medicaid 837 billing, and MCO portal reconciliation.
9. **V2:** An **80/20 compensation-share report** (direct-care wages ÷ Medicaid HCBS revenue) if the rule stands.
10. **V2:** An AI scheduler (auto-fill call-offs), a recruiting pipeline, and a referral-source CRM.

## Pricing to win
- **$149/mo for up to 25 active clients, then $5 per active client per month.** Unlimited caregivers and office users, month-to-month, free migration.
- **Example:** A 60-client agency pays $324/mo.
- Incumbents are quote-based, so savings claims must come from real quotes collected on sales calls. Offer to beat any written quote by 30%.

## Go-to-market (first 100 customers)
- **Get listed as an approved third-party EVV vendor** in open-model states. Several states publish lists of certified alternate EVV systems, and a listing is free, high-intent distribution.
- **Associations:** Home Care Association of America (HCAOA) and state home care associations (e.g., Home Care Association of Florida, Pennsylvania Homecare Association, Texas Association for Home Care & Hospice, California Association for Health Services at Home). Sponsor EVV compliance webinars.
- **Communities:** r/HomeCare (verify activity) and Facebook groups for home care agency owners. Offer a "state EVV cheat sheet" lead magnet built from the per-state pass.
- **Partners:** Home care business consultants and startup-license consultants (new agencies need software from day one), plus franchise-exit advisors.
- **SEO:** "WellSky Personal Care alternative", "AxisCare pricing", "[state] EVV aggregator", "[state] open model EVV vendors".

## Risks and incumbent moats
- **Aggregator certification per state:** Specs, testing and timelines are the core moat, and each state is a mini-integration. Go deep on one or two states before expanding.
- **Medicaid billing complexity and MCO portals:** Launch private-pay-first plus EVV export, and add Medicaid claims in V2.
- **Franchise systems mandate software:** Target independents.
- **Payroll liability:** Export only; don't run payroll.
- **HIPAA/BAA on a small-team budget:** Agencies billing Medicaid are covered entities, and we are their business associate.
  - Sign customer BAAs and use AWS HIPAA-eligible services under AWS's self-serve BAA.
  - Caregiver phones: encrypted local cache, remote logout, no PHI in SMS or push text.
  - Location data is sensitive, so collect it only at clock-in/out.
  - A free HHS SRA Tool risk assessment, MFA, audit logs, and a breach runbook.
  - **Cost estimate:** A few hundred dollars a month plus a pen test and cyber insurance.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 2 | 3 | 4 | **16** |

## Sources
- [WellSky Personal Care reviews, Capterra](https://capterra.com/p/126968/Non-Medical-Private-Pay-System/reviews/)
- [State-by-State EVV Guide, HHAeXchange](https://www.hhaexchange.com/state-evv-status) (fetched 2026-09-24)
- [EVV Vendors by State (2026): All 50 States, AveeCare](https://www.aveecare.com/resources/evv-vendors-by-state) (fetched 2026-09-24)
- [EVV Requirements by State (2026), AveeCare](https://www.aveecare.com/resources/evv-requirements-by-state-2026)
- [EVV for Multiple Aggregators, States & Payers, CareVoyant](https://www.carevoyant.com/home-health-blog/evv-multiple-aggregators-states-payers)
- [EVV Requirements by State: 2026 Compliance Guide, Ankota](https://www.ankota.com/evv-state-by-state)
