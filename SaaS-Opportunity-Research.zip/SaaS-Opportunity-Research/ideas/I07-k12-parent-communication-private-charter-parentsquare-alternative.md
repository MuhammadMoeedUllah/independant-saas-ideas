# SchoolPing: a cheaper, better ParentSquare / Remind / SchoolMessenger for private, parochial and charter schools

**One-liner:** Two-way parent messaging (app, email and SMS included, auto-translated), permission slips and forms, event sign-ups and small school-fee payments. Flat per-school pricing that a principal or head of school can buy without a district RFP.

## Snapshot
- **Replaces:**
  - **ParentSquare:** quote-based (not published). A reviewer says "the base software comes with no features really, and any feature will cost you thousands per year" (Software Advice, Jul 2024) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
  - **Remind:** a nonprofit reviewer says Remind stopped offering SMS texting on its platform several months before Jul 2025 (reviewer claim; verify) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
  - SchoolMessenger, Finalsite and PowerSchool communications modules, plus RevTrak and MySchoolBucks fee payments: not re-priced in this pass.
- **Recent price hikes / changes (switching windows):**
  - **PowerSchool:** acquired by **Bain Capital** (announced Jun 2024, **completed Oct 1 2024**) ([Bain Capital, Wikipedia](https://en.wikipedia.org/wiki/PowerSchool)). Its **Dec 2024 SIS breach** was reported to have exposed data on tens of millions of students and educators; widely reported figures are about 62M students and 9.5M educators (not re-verified in this pass). The breach pushed districts and private schools to reassess vendor concentration and student-data-privacy agreements.
  - **Remind SMS change** (reviewer-reported), which leaves teachers who relied on free texting looking for an alternative.
  - **State student-data-privacy laws** (e.g. CA SOPIPA, NY Ed Law 2-d, IL SOPPA) require vendor data-privacy agreements. A small vendor with a clean DPA and data minimization can sell into that gap (see the state leads).
- **Who buys:**
  - **Heads of school and principals** at independent, Catholic and Christian schools.
  - **Diocesan school offices**, which can buy for 10–100 schools at once.
  - **Charter school operators** (single-site to small networks). Charters have boards but no district RFP for small tools.
  - District sales are out of scope for the MVP (long RFPs).
- **US market size:** Estimate: about 30,000 private schools and about 8,000 charter schools (NCES Private School Survey and National Alliance for Public Charter Schools figures as commonly cited; verify). Catholic schools are a large share of private schools and are grouped under diocesan offices (verify counts with NCEA).
- **Urgency trigger (why they'd switch NOW):** Back-to-school (Aug–Sep) exposes messaging gaps. Winter break (Dec–Jan) is the implementation window for the second semester. PowerSchool breach fallout and data-privacy reviews. Remind SMS changes.
- **Fastest-selling states/metros:** Charter-heavy AZ, FL, TX, CA, MI, OH. Private and parochial-heavy NY, PA, NJ, OH, IL, CA, MA. ESA/voucher states (FL, AZ, TX 2026–27) with new private-school growth (overlaps F06; estimate).

## Pain points (evidence)
- **[Price]** ParentSquare's base package has few features, and each add-on costs "thousands per year" (E-learning reviewer, Jul 2024) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
- **[Support]** A nonprofit reviewer waited **3.5 months** for a reply from ParentSquare support (Jul 2025) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
- **[Missing features]** The same reviewer says messages arrive multiple times and too late, and that Remind dropped SMS texting (Jul 2025) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
- **[Complexity/UX]** A reviewer calls the ParentSquare apps "extremely confusing and not user friendly" (Education, Jun 2020) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
- **[Complexity/UX]** A child day-care reviewer has trouble adding and removing people from groups (Oct 2024) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
- **[Complexity/UX]** Setup was "a beast" to get started and implement (Education, Oct 2023) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
- **[Lock-in]** A reviewer says they use it only because "the school made the switch", meaning end users don't choose the tool (Higher Education, Jun 2022) ([Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)).
- **[Security/Trust]** PowerSchool's Dec 2024 breach, under new Bain Capital ownership, is the main reason schools are auditing vendors (figures to verify; see Snapshot).
- *Evidence gap:* collect r/Teachers and r/Professors-adjacent threads, plus private-school admin forum complaints, in the state pass. Search budget was exhausted this pass.

## What we build (the better version)
1. **MVP** Messaging to the whole school, a grade, a class or a custom group: app push, email and **SMS included** (fair use), with **auto-translation into 100+ languages** and read receipts.
2. **MVP** **Two-way teacher–parent chat** with office-hours quiet times and admin oversight (a compliance archive).
3. **MVP** **Permission slips and forms** with e-sign and payment (field trips, sports physicals, photo release), plus a chaser for the non-returners.
4. **MVP** Emergency and attendance alerts (voice-call fallback via Twilio), plus an absence-reporting form for parents.
5. **MVP** Roster sync by CSV plus a OneRoster import (PowerSchool, Blackbaud, FACTS SIS exports), and Google/Microsoft SSO.
6. **MVP** Event sign-ups and volunteer slots (conferences, class parties, booster events).
7. **V2** **School-fee wallet:** lunch, activity and trip fees; a replacement for RevTrak/MySchoolBucks at small schools.
8. **V2** AI weekly newsletter builder (pulls from teacher posts and the calendar) and an AI "reply suggestions" inbox for the front office.
9. **V2** Diocese and network dashboards (multi-school), plus a signed student-data-privacy agreement library by state.
10. **V2** Data minimization and SOC 2 Type I, with a public trust page.

## Pricing to win
- **$99/mo per school** up to 500 students, **$199/mo** up to 1,500, with SMS and translation included. **Diocese/network plan: $69/school/mo** at 10+ schools. Month-to-month, or annual with 2 months free. Free setup and roster import.
- **Example (estimate):** a 400-student private school that a reviewer says pays "thousands per year" per ParentSquare module would pay **$1,188/yr** all-in. Exact savings depend on the ParentSquare quote; collect real quotes in the state pass.

## Go-to-market (first 100 customers)
- **Catholic diocesan school offices** and the NCEA (one decision can cover dozens of schools). **ACSI** (Association of Christian Schools International) regional events.
- **Independent school associations:** NAIS and regional ones (e.g. ISACS, SAIS). Tech-director listservs.
- **State charter school associations** (e.g. the Arizona, California and Texas charter school associations): vendor directories and conference booths.
- **Teachers' word of mouth:** r/Teachers and teacher Facebook groups with the "Remind stopped texting? Here's a free teacher tier" hook, then upsell the school.
- **SEO:** "ParentSquare alternative for private schools", "Remind SMS alternative", "school messaging app with translation".

## Risks and incumbent moats
- **SIS integration:** schools want roster sync. Start with CSV/OneRoster and add direct connectors later.
- **TCPA and SMS carrier rules** (A2P 10DLC registration): handle registration for each school.
- **Student data privacy:** DPAs by state, COPPA for under-13 accounts (parents only, no student accounts in the MVP).
- **Bundling:** SIS vendors (PowerSchool, Blackbaud, FACTS) bundle communications. Win on UX, SMS included and price.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 2 | 3 | **15** |

## Sources
- [ParentSquare reviews – Software Advice](https://www.softwareadvice.com/school-administration/parentsquare-profile/reviews/)
- [Bain Capital (PowerSchool acquisition completed Oct 1 2024) – Wikipedia, fetched from the PowerSchool URL](https://en.wikipedia.org/wiki/PowerSchool)
- PowerSchool Dec 2024 breach figures: widely reported (e.g. TechCrunch, Jan 2025); not re-verified in this pass. Add a primary source in the state pass.
