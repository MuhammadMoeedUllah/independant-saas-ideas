# CellarPermit: a cheaper, simpler ShipCompliant for small wineries, craft distilleries and breweries shipping direct-to-consumer

**One-liner:** A permit calendar, pre-shipment compliance check and state-report generator for small producers who ship direct to consumers. It plugs into Commerce7, WineDirect, OrderPort or Shopify and replaces the enterprise compliance stack at a flat price.

## Snapshot
- **Replaces:**
  - **Sovos ShipCompliant** covers DtC compliance checks, address-level tax rates, "fully automated, fully populated sales, excise, and direct shipper reports," license management and product registrations.
    - It is used by "more than 2,000 wineries, breweries, distilleries, importers, distributors and more" ([Sovos ShipCompliant, page modified Jul 2 2026](https://www.sovos.com/shipcompliant/)).
    - **Pricing is not published** and was not verified.
  - **Commerce7 (DtC commerce platform)** plans, per [Commerce7 pricing, updated Aug 12 2026](https://www.commerce7.com/pricing):

    | Plan | Price | Transaction fee | DtC revenue limit |
    |---|---|---|---|
    | Lite | $59/mo | 0% | up to $100K |
    | Basic | $149/mo | 1.5% | up to $600K |
    | Pro | $399/mo | 1% | up to $4M |
    | Experience | $1,249/mo | 0.75% | $4M–$6M |

    Contracts are month-to-month. Compliance is handled through integration with a compliance provider, which is not included in these plans (no compliance add-on is listed).
  - **WineDirect, OrderPort, Ekos (brewery/distillery ERP), Vinoshipper:** pricing not verified in this pass.
- **Recent price hikes / changes:**
  - Sovos is a large tax-compliance company, and its Trustpilot reviews (all products) show billing-after-cancellation and unreachable-support complaints (see below).
  - No ShipCompliant-specific 2025–2026 price change was verified.
- **Who buys:** The owner, DtC/club manager or office manager at a winery producing under about 10k cases a year, a craft distillery, or a brewery that ships beer where that is legal.
- **US market size:**
  - Estimates from trade-association counts, not re-verified in this pass: about 11k US wineries, about 9.5k breweries and about 2.5k–3k craft distilleries.
  - Only a subset ship DtC across state lines.
  - A small, focused market with high willingness to pay, since a compliance miss risks the permit.
- **Urgency trigger (why they'd switch NOW):**
  - Each state's direct-shipper permit renewal and its monthly, quarterly or annual shipment/excise reports.
  - Q4 is peak shipping season, when every month-end report matters.
  - We have no hard dated switching event. This is a weakness of this idea.
- **Fastest-selling states/metros:**
  - Producer clusters: CA (Napa, Sonoma, Paso Robles), OR (Willamette), WA (Walla Walla, Woodinville), NY (Finger Lakes), VA, MI, TX Hill Country.
  - Distilleries: KY, TN, TX, CO, NY.
  - Destination states with the heaviest reporting burden need a per-state pass (not verified here).

## Pain points (evidence)
- **[Support]** A Sovos customer found "no customer support number to call," and the salespeople couldn't help ([Trustpilot, Feb 2026](https://www.trustpilot.com/review/sovos.com)).
- **[Billing]** Sovos overcharged a customer monthly for nearly a year, with "no help" despite multiple tickets ([Trustpilot, Jan 2026](https://www.trustpilot.com/review/sovos.com)).
- **[Billing/Lock-in]** A customer was billed after cancelling in Feb 2024 and needed a credit-card dispute to stop it ([Trustpilot, Mar 2025](https://www.trustpilot.com/review/sovos.com)).
- **[Support]** Support lines go to voicemail with no callback ([Trustpilot, Mar 2025](https://www.trustpilot.com/review/sovos.com)).
- **[Support]** A 6+ month resolution delay and an account lockout. A 2FA issue was answered with unrelated FAQ links ([Trustpilot, Jan 2026](https://www.trustpilot.com/review/sovos.com)).
- **[Implementation]** An implementation was described as an "extremely bad experience" with no urgency from the team ([Trustpilot, Dec 2025](https://www.trustpilot.com/review/sovos.com)).
- **[Price model]** Commerce7 charges a 1.5% transaction fee on Basic on top of $149/mo, and compliance is a separate vendor. A $500K DtC winery pays about $7.5k/yr in platform transaction fees plus compliance fees ([Commerce7 pricing](https://www.commerce7.com/pricing); our arithmetic).
- Caveat: Sovos's Trustpilot profile is 2.2/5 on 8 reviews, all 1-star, and **none name ShipCompliant specifically**. They cover other Sovos products (VAT, e-invoicing).
- **Evidence gap:** r/winemaking and WineBusiness forums were not captured (Reddit blocked, search budget exhausted). Get ShipCompliant-specific reviews from G2/Capterra and interviews at WIN Expo in the next pass.

## What we build (the better version)
1. **MVP: a permit and license vault.**
   - It holds federal TTB basic permits, state direct-shipper permits, bonds and label approvals (COLAs), with expiry reminders at 90/60/30 days.
   - It also keeps a renewal checklist per state.
2. **MVP: a state rules matrix.** For each destination state and beverage type (wine, spirits, beer): whether DtC is allowed, the permit needed, volume caps per consumer, the tax rates and the report frequency. Every rule shows its source and last-verified date.
3. **MVP: a pre-shipment check API and webhook.** Before an order ships it checks the destination state, license status, per-consumer volume caps and carrier rules (age-verification service). It integrates with Shopify, Commerce7 and WineDirect webhooks.
4. **MVP: a report generator.** A monthly or quarterly per-state shipment and excise summary, prefilled in each state's form layout (PDF/CSV), with a due-date calendar and "filed" tracking.
5. **MVP: a club-run readiness check.** Before a wine-club shipment, it flags orders going to states where the permit has lapsed or the cap would be exceeded.
6. **V2: e-filing** to states that accept electronic filing, plus TTB Report of Operations prep.
7. **V2: product registration management** for distributor channels.
8. **V2: address-level sales-tax calculation** (shared engine with J01, NexusBook).

## Pricing to win
- **Our plans:**
  - **$99/mo for up to 10 destination states** and **$199/mo for unlimited states.**
  - Report prep included, no per-shipment fees, month-to-month.
- **Comparison:** ShipCompliant pricing isn't published. We would verify it in sales calls and publish a "we cost X% less" page once we have data. Until then, savings are not quantified.

## Go-to-market (first 100 customers)
- **Commerce7 and WineDirect app marketplaces:** be the cheaper compliance integration option inside the tools wineries already use.
- **Trade associations:** WineAmerica, state wine associations (the Oregon Winegrowers Association, Washington Wine Institute, New York Wine & Grape Foundation, Virginia Wineries Association), the American Craft Spirits Association and the Brewers Association.
- **Events:** WIN Expo (Santa Rosa), Unified Wine & Grape Symposium (Sacramento, January) and Craft Spirits conferences.
- **DtC consultants and wine-club managers** (a small community, strong referrals), plus Facebook groups of winery DtC managers.
- **Content:** a "State-by-state DtC shipping cheat sheet" lead magnet and a spirits DtC state tracker (a fast-changing area).

## Risks and incumbent moats
- **ShipCompliant is deeply integrated** with carriers, fulfillment houses and commerce platforms, and some states and carriers rely on its data sharing. We start with small producers who self-file and integrate via the commerce platforms' APIs.
- **The rules data is the moat.** We need a researcher to verify each state quarterly, and every rule shows its citation.
- **Small market.** This is capped at a few thousand paying producers, so it may be better as a module of a broader beverage-alcohol or sales-tax product (see J01).

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 2 | 4 | 2 | **14** |

## Sources
- [Sovos ShipCompliant product page (modified Jul 2 2026)](https://www.sovos.com/shipcompliant/)
- [Commerce7 pricing (updated Aug 12 2026)](https://www.commerce7.com/pricing)
- [Trustpilot: Sovos reviews](https://www.trustpilot.com/review/sovos.com)
