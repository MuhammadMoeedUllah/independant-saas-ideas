# TeeFree: a cheaper, better GolfNow / foreUP / Lightspeed Golf for independent public golf courses (and small recreation venues)

**One-liner:** A barter-free tee sheet, online booking, pro-shop POS and golfer CRM for independent daily-fee courses, for one flat monthly fee. The course keeps every tee time and owns its golfer data.

## Snapshot
- **Replaces:**
  - **GolfNow (NBC Sports Next):** barter model, where the course gives GolfNow tee times instead of cash. TeeAhead, a competitor, estimates about 2 tee times a day, or roughly **$94,500/yr in forgone revenue** at average rates, plus booking commissions on marketplace transactions. GolfNow retains the customer relationship data (per TeeAhead, Apr 28, 2026) ([TeeAhead](https://www.teeahead.com/blog/golfnow-vs-foreup-vs-lightspeed-vs-teeahead)).
  - **foreUP:** about $400-$800/mo, no barter. **Lightspeed Golf (formerly Chronogolf):** about $300-$700/mo, no barter. **TeeAhead:** free for year 1, then $349/mo ([TeeAhead](https://www.teeahead.com/blog/golfnow-vs-foreup-vs-lightspeed-vs-teeahead)). **Club Prophet:** not verified this pass.
- **Recent price hikes / changes:**
  - **Apr 21, 2025:** GolfNow claimed over 320 new properties in Q1 2025. An industry analysis found most of those courses use competitors' tee sheets, and several had *dropped* GolfNow's booking engine ([Golf Course Technology Reviews](https://www.golfcoursetechnologyreviews.org/blog/golfnow-press-release-sparks-curiosity-is-the-company-shifting-back-to-being-primarily-a-marketplace-partner)).
  - **2024:** GolfNow's Reserve with Google rollout brought communication and rollout problems and increased churn, per the same analysis.
  - The NGCOA has long published guidance warning owners about barter ("Beware of Barter") and runs tee-time advocacy ([NGCOA guide PDF](http://higherlogicdownload.s3.amazonaws.com/NGCOA/88142cfb-5094-4fc1-b917-ac6b2ce0c68b/UploadedImages/Final_-_beware_of_barter_011420_-_327_p_m_.pdf), [NGCOA tee-time advocacy](https://www.ngcoa.org/info-centers/advocacy/tee-time-advocacy/news-and-resources)).
- **Who buys:** Owners and GMs of privately owned daily-fee public courses, 9-hole and executive courses, par-3s, driving ranges, and small semi-private clubs. The adjacent segment is independent bowling centers, mini-golf, escape rooms and trampoline parks, which use a similar booking and POS pattern (lower priority). Municipal courses need RFPs, so they come later.
- **US market size:** Estimate: about 14,000 US golf facilities, commonly cited by the National Golf Foundation (not re-verified in this pass). Roughly three-quarters are public-access, and a large share are independently owned. Willingness to pay is proven at $300-$800/mo.
- **Urgency trigger (why they'd switch NOW):** Barter renewals, since each contract term is a decision point. Off-season (Nov-Feb in northern states) is when courses change tee sheets. Golfer data ownership concerns. TeeAhead's free first year shows the market is contestable.
- **Fastest-selling states/metros:** High course-count states: Florida, California, Texas, Michigan, New York, Ohio, North Carolina, Pennsylvania, South Carolina (Myrtle Beach cluster) and Arizona (Scottsdale/Phoenix). Estimate; verify with NGF data. Northern states buy in winter.

## Pain points (evidence)
*Evidence is thinner here (mostly industry analysis and competitor sources). A second pass should pull r/golf and course-owner forum threads.*
- **[Price]** Barter costs are hidden. Giving away about 2 prime tee times a day is estimated at about $94.5k/yr, and owners understate it in budgets ([TeeAhead](https://www.teeahead.com/blog/golfnow-vs-foreup-vs-lightspeed-vs-teeahead)).
- **[Lock-in]** Courses become dependent on GolfNow's marketplace instead of building direct relationships with their own golfers, and GolfNow retains the customer data ([TeeAhead](https://www.teeahead.com/blog/golfnow-vs-foreup-vs-lightspeed-vs-teeahead)).
- **[Support]** Reported communication and rollout difficulties around GolfNow's 2024 Reserve with Google implementation ([GCTR](https://www.golfcoursetechnologyreviews.org/blog/golfnow-press-release-sparks-curiosity-is-the-company-shifting-back-to-being-primarily-a-marketplace-partner)).
- **[Churn]** Documented customer dissatisfaction and higher churn, with several courses abandoning GolfNow's booking engine for competitors ([GCTR](https://www.golfcoursetechnologyreviews.org/blog/golfnow-press-release-sparks-curiosity-is-the-company-shifting-back-to-being-primarily-a-marketplace-partner)).
- **[Missing features]** Analysts question whether GolfNow is putting marketplace expansion ahead of technology development ([GCTR](https://www.golfcoursetechnologyreviews.org/blog/golfnow-press-release-sparks-curiosity-is-the-company-shifting-back-to-being-primarily-a-marketplace-partner)).
- **[Price]** Barter used to pay for software subscriptions is costlier than barter for marketplace exposure alone, because of the support load ([GCTR podcast and analysis](https://www.golfcoursetechnologyreviews.org/blog/trading-tee-times-for-tech-a-deep-dive-into-golfnows-barter-model-with-paul-sampliner)).
- **[Price]** The owners' trade association itself (NGCOA) publishes "Beware of Barter" guidance and runs tee-time advocacy, which signals industry-wide resentment ([NGCOA](https://www.ngcoa.org/info-centers/advocacy/tee-time-advocacy/news-and-resources)).
- **[Price]** Barter-free alternatives still cost $300-$800/mo (foreUP, Lightspeed Golf), which is steep for a 9-hole or rural course ([TeeAhead](https://www.teeahead.com/blog/golfnow-vs-foreup-vs-lightspeed-vs-teeahead)).

## What we build (the better version)
1. **MVP: Tee sheet.** Intervals, crossovers, 9/18 splits, shotgun starts, blocks for leagues and outings, and rate classes (resident, senior, twilight, walking or riding).
2. **MVP: Branded online booking** with prepay or card-on-file, no-show policy, and group size and cart selection. Mobile-first, with Apple Pay and Google Pay.
3. **MVP: Pro-shop and snack-bar POS** (Tap to Pay plus a reader) with green fees, carts, range buckets, merchandise inventory and gift cards.
4. **MVP: Golfer CRM the course owns.** Round history, email and SMS marketing for slow tee times ("tee time deals" sent to your own list instead of bartered), and a loyalty punch card.
5. **MVP: Memberships and passes** (annual, punch cards, junior) with autopay.
6. **MVP: Import tool** for foreUP, Lightspeed Golf and GolfNow/EZLinks customer lists (CSV plus AI mapping).
7. **V2: Dynamic pricing** by utilization, weather and time.
8. **V2: Tournament and outing management** (registration, pairings, scoring) and league handicaps through official partner APIs.
9. **V2: Reserve with Google and marketplace feeds** (sell selected inventory to aggregators for cash commission, never barter).
10. **V2: Recreation venue mode** for bowling lanes, escape rooms and trampoline parks. Resource and slot booking plus waivers (shares the D07 engine).

## Pricing to win
- **TeeFree:** $199/mo for 9-hole and executive courses, $299/mo for 18 holes, $399/mo for 27-36 holes. Tee sheet, booking, POS, CRM and memberships all included. **No barter, no booking commission.** Processing at Stripe cost plus a disclosed markup. Month-to-month, free winter migration.
- **Savings vs GolfNow barter:** If barter costs about $94.5k/yr (TeeAhead's estimate), an 18-hole course on TeeFree pays $3,588/yr, a net gain of about $90k in reclaimed tee-time revenue. Even at a quarter of that barter estimate, the gain is over $20k/yr.
- **vs foreUP/Lightspeed Golf:** Saves $100-$500/mo.

## Go-to-market (first 100 customers)
- **NGCOA** (National Golf Course Owners Association): exhibit at its annual Golf Business Conference and sponsor the tee-time advocacy content. The anti-barter message matches what the association already says.
- **PGA Show** (Orlando, January), plus state and regional PGA sections and state golf course owner associations.
- **Winter outbound** to northern-state courses (MI, OH, NY, PA, WI, MN) from Nov to Feb, when GMs have time.
- **"GolfNow barter calculator"** (enter tee times bartered per day and average rate to see annual cost) and "GolfNow alternative" SEO pages.
- **Reddit:** r/golf (golfer-side stories) and GM/superintendent communities. Golf Course Technology Reviews is an influential neutral review site, so get listed and reviewed there.
- **Referral:** Golf management consultants and course brokers.

## Risks and incumbent moats
- **GolfNow marketplace demand:** Courses fear losing rounds. Mitigation: a gradual step-down of barter, a direct-marketing CRM, and cash-commission aggregator feeds.
- **Established barter-free rivals** (foreUP, Lightspeed Golf, TeeAhead with a free first year) mean the price gap vs non-barter players is moderate.
- **Hardware and F&B complexity** at larger courses. Start with 9/18-hole daily-fee courses with a simple snack bar.
- **Seasonality:** The sales window is concentrated in winter.
- **Payments:** Stripe handles PCI.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 3 | 3 | 2 | **15** |

## Sources
- [GolfNow vs foreUP vs Lightspeed Golf vs TeeAhead – TeeAhead (Apr 28, 2026; competitor)](https://www.teeahead.com/blog/golfnow-vs-foreup-vs-lightspeed-vs-teeahead)
- [GolfNow press release sparks curiosity – Golf Course Technology Reviews](https://www.golfcoursetechnologyreviews.org/blog/golfnow-press-release-sparks-curiosity-is-the-company-shifting-back-to-being-primarily-a-marketplace-partner)
- [Trading tee times for tech: GolfNow's barter model – Golf Course Technology Reviews](https://www.golfcoursetechnologyreviews.org/blog/trading-tee-times-for-tech-a-deep-dive-into-golfnows-barter-model-with-paul-sampliner)
- [Paul Sampliner on GolfNow, Barter & Public Golf's Future – GCTR podcast](https://www.golfcoursetechnologyreviews.org/podcast-episodes/paul-sampliner-golfs-first-online-tee-time-revenue-manager)
- [Beware of Barter – NGCOA (PDF)](http://higherlogicdownload.s3.amazonaws.com/NGCOA/88142cfb-5094-4fc1-b917-ac6b2ce0c68b/UploadedImages/Final_-_beware_of_barter_011420_-_327_p_m_.pdf)
- [NGCOA Tee Time Advocacy – News & Resources](https://www.ngcoa.org/info-centers/advocacy/tee-time-advocacy/news-and-resources)
- [Is GolfNow Worth It for Your Golf Course? – Your Nice Shot](https://www.yourniceshot.com/blogs/news/is-golfnow-worth-it-for-your-golf-course-pros-cons-and-hidden-costs)
