# InspectKit: a cheaper, better Spectora / HomeGauge / ISN for solo and small multi-inspector home inspection firms

**One-liner:** A mobile, offline-first inspection report writer where the AI drafts narrative comments from photos and voice notes. It includes online booking, pre-inspection agreements, payments and agent sharing. There are no ads in your client portal and no per-inspection "advanced" fees. State forms such as the Texas TREC report and Florida wind-mitigation and 4-point forms are built in.

## Snapshot
- **Replaces:**
  - **Spectora:**
    - Report software **$109/mo** or **$1,090/yr**. Additional inspectors **$99/mo** or $999/yr each.
    - **"Advanced" upgrade at $4 per inspection** (automations, team management).
    - Base Website $699/yr plus a $499 setup fee; Pro Website $1,599/yr plus a $799 setup fee (setup waived or discounted with annual software).
    - Source: [Spectora pricing, viewed Sept 2026](https://www.spectora.com/pricing/).
  - HomeGauge and ISN: pricing not verified in this pass.
- **Recent price hikes / changes:**
  - Spectora now layers a **per-inspection fee ($4)** on top of the subscription for its automation tier, and charges setup fees on websites ([Spectora pricing](https://www.spectora.com/pricing/)). A dated history of list-price increases was not verified in this pass.
  - **Client-portal ads:** an inspection firm principal said Spectora added pop-up ads to client portals with no opt-out (Apr 2026). Another reviewer alleged the company markets directly to inspectors' clients ([G2](https://www.g2.com/products/spectora/reviews)). Inspectors see this as a brand and trust breach, which makes it a switching trigger.
- **Who buys:** Owner-operator home inspectors (a solo operator is the norm) and multi-inspector firms with 2-10 inspectors. They buy with a card and churn with templates in hand.
- **US market size:** Estimate: a few tens of thousands of active US home inspectors (InterNACHI and ASHI membership plus state licensees; verify). Small market, but high willingness to pay ($1,000+/yr per inspector today).
- **Urgency trigger (why they'd switch NOW):**
  - Portal ads and client-marketing backlash (April 2026 reviews).
  - The $4 per-inspection fee compounds with volume.
  - Annual renewal dates.
  - The winter slow season (Nov-Feb) is when inspectors rebuild templates.
- **Fastest-selling states/metros:** Texas (TREC-mandated report form and a large licensee base), Florida (wind-mitigation and 4-point insurance inspections are a huge add-on market), California, Arizona, North Carolina, Georgia and Colorado. Estimate.
- **Adjacent lead (appraisers):** Fannie Mae/Freddie Mac's **UAD 3.6 and redesigned URAR become mandatory on Nov 2, 2026** ([Fannie Mae UAD page](https://singlefamily.fanniemae.com/delivering/uniform-mortgage-data-program/uniform-appraisal-dataset)). This forces every appraiser's forms software to change, which is a separate, harder build (GSE XML schema) worth its own evaluation.

## Pain points (evidence)
- **[Lock-in/Trust]** A firm principal (Apr 2026) said Spectora added spammy pop-up ads to client portals with no opt-out, which hurts the inspector's brand ([G2](https://www.g2.com/products/spectora/reviews)).
- **[Trust]** A reviewer (Apr 2026) alleged Spectora markets directly to inspectors' clients without permission ([G2](https://www.g2.com/products/spectora/reviews)).
- **[Complexity/Bugs]** A reviewer (Apr 2026) said Spectora ships unhelpful new features while known bugs stay unfixed ([G2](https://www.g2.com/products/spectora/reviews)).
- **[Support]** An owner-operator (Nov 2023) said there's zero phone support, chat only, with 3-4 day callback delays that don't work for urgent needs ([G2](https://www.g2.com/products/spectora/reviews)).
- **[Price]** The same owner-operator called Spectora by far the most expensive inspection software he's seen ([G2](https://www.g2.com/products/spectora/reviews)).
- **[Complexity]** He also said the platform is rigid, and promised phone support never arrived ([G2](https://www.g2.com/products/spectora/reviews)).
- **[Integrations]** An admin (2022, older) said Spectora-to-ISN sync takes 15-20 minutes and slows scheduling ([G2](https://www.g2.com/products/spectora/reviews)).
- **[Missing features]** An inspector (2022, older) said there's no built-in CRM to track client and agent communications ([G2](https://www.g2.com/products/spectora/reviews)).
- **[Price/Hidden fees]** Websites carry $499-$799 setup fees plus $699-$1,599/yr, and automation costs $4 per inspection on top of $109/mo ([Spectora pricing](https://www.spectora.com/pricing/)).
- *Coverage gap:* No InterNACHI forum or Reddit threads could be fetched in this pass (robots-blocked). Next pass: pull r/homeinspectors "Spectora price" threads.

## What we build (the better version)
1. **MVP: Offline-first mobile report writer** (PWA or native wrapper). Sections, checklists, photos with annotation, and video clips.
2. **MVP: AI narratives.** Snap a photo and dictate a note, and the AI drafts the defect comment in the inspector's own voice (trained on their past reports), with severity and recommended trade. The inspector approves every line.
3. **MVP: Template importer** from Spectora, HomeGauge and ISN exports (or PDF), with AI mapping into our template schema.
4. **MVP: Booking and agreements.** Online scheduler, dynamic pricing by square footage and age, state-specific pre-inspection agreement e-sign, and pay-before-report (Stripe).
5. **MVP: Clean branded report delivery** (web plus PDF), a repair-request builder for agents, and **no third-party ads, ever**.
6. **MVP: Agent CRM-lite.** Referral source tracking, thank-you automations and a monthly agent report.
7. **MVP: State forms.** **Texas TREC REI 7-6 report layout** and **Florida wind mitigation (OIR-B1-1802) plus 4-point** insurance forms auto-filled from the inspection (verify current form versions).
8. **V2: Multi-inspector dispatch,** route planning and payroll or commission splits.
9. **V2: Ancillary services marketplace** (radon, mold, sewer scope) with lab integrations, all opt-in by the inspector.
10. **V2: Appraiser module** for UAD 3.6 / URAR data capture (separate product decision).

## Pricing to win
- **InspectKit:** **$59/mo** (or $590/yr) for a solo inspector with unlimited inspections and all automations included. Additional inspectors $39/mo. Website included free (no setup fee). Card processing at Stripe cost plus 0.5%. Free template migration.
- **Savings example:** A solo Spectora user on annual software ($1,090), the Base Website ($699), and Advanced for 400 inspections/yr ($1,600) pays **about $3,389/yr, plus a $100-$499 website setup fee**. On InspectKit the same inspector pays **$590/yr**, a saving of **about $2,800/yr** (estimate from list prices).

## Go-to-market (first 100 customers)
- **InterNACHI:** member-benefit listing and a free CE-style webinar on "AI report writing without losing your voice." **ASHI:** chapter meetings and the InspectionWorld conference.
- **State inspector associations** (e.g., Texas TPREIA, Florida FABI, California CREIA; verify names and vendor programs).
- **Communities:** r/homeinspectors and inspector Facebook groups. Post side-by-side "same report, half the time" demos and the "no portal ads" pledge.
- **Inspector schools and new licensees** (TX and FL licensing pipelines): free first year for new licensees.
- **SEO:** "Spectora alternative," "Spectora ads in client portal," "cheaper than Spectora," "wind mitigation form software."

## Risks and incumbent moats
- **Template lock-in:** years of custom comments live in Spectora. Mitigation: AI importer plus a free concierge migration.
- **Agent familiarity** with the Spectora report format. Mitigation: a clean, modern layout and repair-request tools agents like.
- **Offline reliability** in basements and crawlspaces. Mitigation: local-first storage and background sync.
- **State form accuracy** (TREC, FL OIR). Mitigation: official PDFs and version tracking.
- **Small market** caps upside. Expansion goes to wind-mit and insurance inspectors, commercial PCA and appraisers.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 4 | 5 | 2 | **18** |

## Sources
- [Spectora Pricing (viewed Sept 2026)](https://www.spectora.com/pricing/)
- [Spectora Reviews – G2](https://www.g2.com/products/spectora/reviews)
- [Uniform Appraisal Dataset (UAD 3.6 mandate Nov 2, 2026) – Fannie Mae](https://singlefamily.fanniemae.com/delivering/uniform-mortgage-data-program/uniform-appraisal-dataset)
