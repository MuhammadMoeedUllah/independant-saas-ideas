# ListFair: a cheaper, better Mailchimp / Klaviyo for small businesses and small Shopify stores

**One-liner:** Email and SMS marketing that bills only for contacts who actually engage, at a flat, published price, with the automations Mailchimp moved behind higher tiers.

## Snapshot
- **Replaces:**
  - **Mailchimp (Intuit)**, prices as of Aug 5, 2026 ([Emailtooltester](https://www.emailtooltester.com/en/reviews/mailchimp/pricing/)): Essentials $13/mo (500 contacts), $75 (5,000), $110 (10,000). Standard $20/mo (500), $100 (5,000), $135 (10,000). Premium from $350/mo. Free plan: 250 contacts and 500 sends since Feb 17, 2026 ([Audienceful](https://www.audienceful.com/blog/mailchimp-price-increase)).
  - **Klaviyo**: free up to 250 active profiles, about $30/mo at 1,000 profiles, with automatic tier upgrades as profile counts rise ([Audienceful, 2026](https://www.audienceful.com/blog/klaviyo-price-increase)).
  - Constant Contact and ActiveCampaign: in scope, but their 2026 prices were **not checked in this pass**.
- **Recent price hikes / changes:**
  - **Mailchimp:** The free plan was cut from 500 contacts / 1,000 sends to 250 contacts / 500 sends on Feb 17, 2026. It held 2,000 contacts in 2022, so that is roughly an 87% cut in four years. Automations were removed from the free tier in mid-2025. Pre-2019 legacy plans rose an average of 11–13% from Apr 13, 2026. Standard went from $17 to $20/mo at the entry tier after 2022 ([Audienceful](https://www.audienceful.com/blog/mailchimp-price-increase)).
  - **Mailchimp billable contacts:** For new users, unsubscribed contacts and contacts who haven't confirmed opt-in now count toward the bill. Going over the contact limit brings overage fees ([Emailtooltester, Aug 2026](https://www.emailtooltester.com/en/reviews/mailchimp/pricing/)).
  - **Klaviyo:** From Feb 18, 2025, billing moved to *all active profiles*: every subscribed profile counts, whether or not you emailed it. Plans auto-upgrade each billing cycle when a threshold is crossed. Audienceful says Klaviyo capped any single increase at 25%; Klaviyo's own FAQ does not mention a cap (unverified) ([Klaviyo Help Center FAQ](https://help.klaviyo.com/hc/en-us/articles/33136281415451); [Audienceful](https://www.audienceful.com/blog/klaviyo-price-increase)).
- **Who buys:** Owner-operators and one-person marketing teams at retail shops, restaurants, salons, gyms, local services, nonprofits, and Shopify stores with 1k–50k contacts. The owner or marketing lead decides.
- **US market size:** This is an estimate, not re-verified in this pass. The SBA Office of Advocacy counts about 34–36M US small businesses, and a large share send some email marketing. Serviceable market (**estimate**): 1–3M businesses paying $15–$300/mo for email/SMS.
- **Urgency trigger (why they'd switch NOW):**
  - Mailchimp's Feb 17, 2026 free-plan cut forces free users to pay or leave.
  - The Apr 13, 2026 legacy-plan hikes hit renewals.
  - Klaviyo keeps auto-upgrading bills every cycle as dormant profiles pile up.
- **Fastest-selling states/metros:** Shopify/DTC clusters: CA (LA), NY, TX (Austin, Dallas), FL (Miami). **Estimate.** Compliance selling angle: state "mini-TCPA" texting laws in FL, OK, and MD. That's background knowledge, to be verified in the per-state pass, and it makes built-in SMS consent logging a selling point.

## Pain points (evidence)
- **[Price]** An automotive general manager said Mailchimp starts free but becomes expensive once you pass the recipient threshold (Mar 2025) ([Capterra](https://www.capterra.com/p/110228/MailChimp/reviews/?page=18)).
- **[Price]** A small-office owner said Mailchimp has become "quite expensive" and less appealing to small businesses (Dec 2024) ([Capterra](https://www.capterra.com/p/110228/MailChimp/reviews/?page=18)).
- **[Price]** An IT business-development head left Mailchimp for SendX over price and plan restrictions (Aug 2024) ([Capterra](https://www.capterra.com/p/110228/MailChimp/reviews/?page=18)).
- **[Price]** A Shopify merchant pays Klaviyo for 50k+ profiles when only about 15k are engaged. Their bill keeps rising while email revenue has been flat for months (Aug 27, 2025) ([Shopify Community](https://community.shopify.com/t/anyone-else-getting-screwed-by-klaviyos-pricing/561275)).
- **[Price]** A reply in the same thread says billing on total profiles "catches a lot of people off guard," because you pay for every signup regardless of engagement (Sep 2025) ([Shopify Community](https://community.shopify.com/t/anyone-else-getting-screwed-by-klaviyos-pricing/561275)).
- **[Price/Lock-in]** A reviewer says Mailchimp's new structure (paying for unsubscribed and unconfirmed contacts, a reduced free plan) "doesn't really seem to benefit anyone other than Mailchimp" ([Emailtooltester, Aug 2026](https://www.emailtooltester.com/en/reviews/mailchimp/pricing/)).
- **[Complexity/UX]** A business-supplies VP found Mailchimp "too convoluted" to find the features they need (Feb 2025) ([Capterra](https://www.capterra.com/p/110228/MailChimp/reviews/?page=18)).
- **[Complexity/UX]** An education program advisor reported a learning curve and said the tool is "not the most user-friendly" (Feb 2025) ([Capterra](https://www.capterra.com/p/110228/MailChimp/reviews/?page=18)).
- **[Missing features]** A real-estate executive director said the lower Mailchimp tiers make it harder to send to specific groups (Mar 2025) ([Capterra](https://www.capterra.com/p/110228/MailChimp/reviews/?page=18)). This matches the audience caps of 1 on Free, 3 on Essentials and 5 on Standard ([Emailtooltester](https://www.emailtooltester.com/en/reviews/mailchimp/pricing/)).

## What we build (the better version)
1. **MVP:** One-click import from Mailchimp, Klaviyo, Constant Contact and CSV, keeping tags, segments, consent timestamps and unsubscribes.
2. **MVP:** An "Engaged-only billing" meter. You pay only for contacts who opened, clicked or bought in the last 180 days. Dormant contacts are stored free and never mailed until you run a win-back.
3. **MVP:** An AI campaign writer that turns a URL, product, or "we're closed Monday" into a branded email plus an SMS version. It suggests subject lines and learns your brand voice from past sends.
4. **MVP:** A drag-and-drop editor with around 30 mobile-first templates and auto-branding (logo, colors and fonts pulled from your website).
5. **MVP:** Core automations on every plan: welcome series, birthday, abandoned cart (Shopify), post-purchase review ask, and a win-back for dormant contacts.
6. **MVP:** Unlimited audiences and tags, with no audience caps.
7. **MVP:** Signup forms and pop-ups, a QR code for in-store signup, and double opt-in with a consent log (who, when, which form, IP).
8. **MVP:** Deliverability autopilot: SPF/DKIM/DMARC setup wizard, auto-suppression of hard bounces, and warm-up throttling.
9. **MVP:** A plain dashboard showing revenue per campaign (Shopify/Stripe), list growth, engaged vs dormant, and cost per engaged contact.
10. **V2:** SMS/MMS with A2P 10DLC registration handled for the customer, quiet-hours enforcement by recipient state, and a keyword opt-in log.
11. **V2:** Segment builder on purchase history and predicted next order date. AI "who to email this week."
12. **V2:** Square/Clover/Toast POS sync for restaurants and retail. Agency workspace with client billing.
13. **V2:** A deliverability-checked "list cleaner" report you can run before leaving Klaviyo, to shrink your bill there even if you don't switch yet. This is a lead magnet.

## Pricing to win
- **Plans:**
  - Free: 250 engaged contacts, 1,000 sends/mo, automations included.
  - Starter: $15/mo up to 2,500 engaged contacts.
  - Growth: $39/mo up to 10,000.
  - Pro: $79/mo up to 25,000.
  - Unlimited sends at 12x contacts.
- **Terms:** Month-to-month. Dormant contacts stored free. SMS at carrier cost + 20%. Free white-glove migration.
- **Example (Mailchimp):** A 5,000-contact business on Mailchimp Standard pays $100/mo ([Aug 2026](https://www.emailtooltester.com/en/reviews/mailchimp/pricing/)). On ListFair Growth it pays $39/mo, saving about **$732/yr**. If only 60% of its list is engaged, Starter-plus pricing saves more.
- **Example (Klaviyo):** A Shopify store with 50k profiles but 15k engaged (the thread above) would pay for 15k on ListFair, not 50k.
- **Cost basis (estimate):** Transactional email infrastructure (SES/Postmark-class) costs cents per thousand emails, so margins stay above 80%.

## Go-to-market (first 100 customers)
- **Reddit:**
  - r/smallbusiness, r/Emailmarketing, r/shopify, r/ecommerce, r/Entrepreneur, r/nonprofit.
  - Answer "Mailchimp free plan cut" and "Klaviyo bill went up" threads with the free list-cleaner report.
- **Shopify:**
  - Shopify Community forum threads on Klaviyo pricing.
  - A Shopify App Store listing positioned as "Klaviyo alternative, bill on engaged only."
- **Facebook groups:** Shopify entrepreneurs, local-business owner groups by metro, nonprofit communications groups.
- **"Switch from X" SEO pages:**
  - "Mailchimp free plan 250 contacts alternative"
  - "Mailchimp legacy plan price increase 2026"
  - "Klaviyo active profiles bill too high"
  - "Klaviyo vs ListFair cost calculator"
- **Partners:**
  - Shopify/Squarespace/Wix freelancers get a 30% recurring referral.
  - Local chambers of commerce get a member discount.
  - State nonprofit associations.
- **Cold email:** BuiltWith lists of sites running Mailchimp embed forms, sorted by traffic, with a personalized "your estimated Mailchimp bill vs ours" line.

## Risks and incumbent moats
- **Deliverability reputation:** New senders get throttled. Mitigation: a dedicated IP pool only at scale, strict onboarding verification, auto-suppression.
- **Ecommerce data depth (Klaviyo):** Klaviyo's Shopify event data and predictive analytics are deep. Mitigation: MVP targets small stores (<50k profiles) that don't use predictive features. Build the Shopify event sync first.
- **SMS compliance (TCPA, state mini-TCPAs, 10DLC):** Mitigation: SMS ships in V2, with consent logging and quiet hours built in. Use an established CPaaS for carrier registration.
- **Abuse/spam:** Mitigation: KYC on signup, list-quality scoring on import, and a manual review queue for first sends.
- **Brand trust (Intuit/Mailchimp):** Mitigation: free migration, month-to-month terms, and a public pricing calculator.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 3 | 4 | 5 | **20** |

## Sources
- [Mailchimp Price Increase 2026: Free Plan Cuts, Legacy Hikes (Audienceful)](https://www.audienceful.com/blog/mailchimp-price-increase)
- [Mailchimp Pricing 2026: Watch Out for These Extra Costs (Emailtooltester, Aug 5, 2026)](https://www.emailtooltester.com/en/reviews/mailchimp/pricing/)
- [Mailchimp reviews, page 18 (Capterra)](https://www.capterra.com/p/110228/MailChimp/reviews/?page=18)
- [Klaviyo Price Increase: How 'Active Profiles' Billing Raised Everyone's Bill (Audienceful)](https://www.audienceful.com/blog/klaviyo-price-increase)
- [FAQ: Feb 18 billing changes (Klaviyo Help Center)](https://help.klaviyo.com/hc/en-us/articles/33136281415451)
- [Anyone else getting screwed by Klaviyo's pricing? (Shopify Community, Aug–Sep 2025)](https://community.shopify.com/t/anyone-else-getting-screwed-by-klaviyos-pricing/561275)

## Verification (Sep 24 2026)
- ✅ Mailchimp free plan cut from 500 contacts/1,000 sends to 250/500 on Feb 17 2026; 2,000 contacts in 2022; automations removed mid-2025 — confirmed verbatim ([source](https://www.audienceful.com/blog/mailchimp-price-increase))
- ✅ Pre-2019 legacy plans +11–13% from first billing after Apr 13 2026 — confirmed ([source](https://www.audienceful.com/blog/mailchimp-price-increase))
- ✅ Mailchimp Essentials $13/$75/$110, Standard $20/$100/$135, Premium $350; unsubscribed and unconfirmed contacts billed for new users; audience caps 1/3/5 — confirmed (Aug 5 2026) ([source](https://www.emailtooltester.com/en/reviews/mailchimp/pricing/))
- ✅ Klaviyo active-profile billing from Feb 18 2025, with auto-upgrade at the next billing cycle — confirmed by Klaviyo ([source](https://help.klaviyo.com/hc/en-us/articles/33136281415451))
- ⚠️ "Klaviyo capped any single increase at 25%" — stated by Audienceful only; Klaviyo's own FAQ does not mention a cap. Marked unverified ([source](https://www.audienceful.com/blog/klaviyo-price-increase))
- Scores unchanged (the cap limits Klaviyo's hikes, so leaving it unverified does not weaken the case).
