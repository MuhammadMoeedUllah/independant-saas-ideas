# Alignly: a cheaper, better ChiroTouch / WebPT for independent chiropractors and cash-based PT clinics

**One-liner:** A month-to-month, cancel-in-app practice platform for 1–5 provider chiropractic and cash/hybrid PT clinics: fast tap-based SOAP notes with an AI scribe, care-plan packages and memberships, booking, reminders, home exercise programs, and clean exports.

## Snapshot
- **Replaces:**
  - **ChiroTouch**: Start / Grow / Scale tiers with **no public prices**. Buyers must "book a demo" or call sales (pricing page, fetched 2026-09-24). Add-ons include CT Pay, CT Billing Suite, volume or unlimited clearinghouse claims, and CT SmartFit. One BBB complainant reports a 12-month promo at **$74/mo that renewed at $198+/mo** (Jul 2025).
  - **WebPT**: about **$99/provider/mo** (published figure), **$500–$2,000 setup**, RCM at **about 6.5% of collections**, 8–16 week implementation. Billing, outcomes, telehealth and prior auth are add-ons (per SPRY's 2026 comparison, a competitor source).
  - **Prompt Health**: about **$289/provider/mo**, user-reported and not published (SPRY 2026, estimate).
  - **Jane App** (pricing page, fetched 2026-09-24): Balance $54, Practice $79, Thrive $99 USD/mo, plus per-practitioner fees on Practice/Thrive. AI Scribe $15/practitioner/mo; group telehealth $15/practitioner/mo; insurance billing $20/mo + $5 per full-time / $2.50 per part-time extra practitioner; websites $59/clinic/mo; cards 2.85% + 25c online. Jane is the "good" incumbent, so it is our price and UX benchmark rather than the main target.
- **Recent price hikes / changes:**
  - A WebPT reviewer reports **annual price hikes plus undisclosed add-on costs** (Capterra, Jul 21, 2026).
  - ChiroTouch renewal jumps (BBB, Jul 2025).
  - ChiroTouch's **April 2026 server migration broke appointment-reminder texts and emails** for at least one practice for 6+ weeks while billing continued (BBB, May 2026).
  - ChiroTouch has **26 BBB complaints in 3 years, 24 of them unanswered** (as of fetch).
- **Who buys:** Owner chiropractors (1–3 DCs, often cash or hybrid with personal-injury cases) and owners of cash-based or hybrid outpatient PT clinics (1–5 PTs). The buyer is the owner-provider or office manager.
- **US market size:** Our estimate is about 70k practicing US chiropractors (commonly cited association figure, not verified in this pass) and tens of thousands of outpatient PT private practices (estimate).
- **Urgency trigger (why they'd switch NOW):** ChiroTouch contract renewal dates (price jumps, cancellation friction), the reminder outages after the April 2026 migration, and WebPT's annual increases.
- **Fastest-selling states/metros:** Estimate: Sun Belt and high-chiro-density states (TX, FL, CA, GA, AZ) and metros with strong cash-PT markets (Denver, Austin, Nashville, Phoenix). APTA reports that all states allow some form of direct access to PT (from memory, not re-verified in this pass). Scope and limits vary by state, which makes this a lead for the per-state pass.

## Pain points (evidence)
- **[Lock-in/Contracts]** A ChiroTouch customer tried four times over six weeks to cancel and was bounced to a "Retention Support Team" that never replied (BBB, Jul 2026) ([BBB](https://www.bbb.org/us/ca/san-diego/profile/computer-hardware/chirotouch-1126-30000841/complaints)).
- **[Lock-in/Contracts]** A customer who cancelled in Nov 2023 says they were billed for more than a year afterward, **$12,809.16** in total, and sent to collections (BBB, Apr 2026) ([BBB](https://www.bbb.org/us/ca/san-diego/profile/computer-hardware/chirotouch-1126-30000841/complaints)).
- **[Price]** A promo rate of $74/mo renewed at $198+/mo without proper notice, allegedly breaking a stated 10% renewal cap (BBB, Jul 2025) ([BBB](https://www.bbb.org/us/ca/san-diego/profile/computer-hardware/chirotouch-1126-30000841/complaints)).
- **[Lock-in/Contracts]** Charges of $156–$171 every two weeks continued after a cancellation request, totaling $881.70 (BBB, Aug 2025) ([BBB](https://www.bbb.org/us/ca/san-diego/profile/computer-hardware/chirotouch-1126-30000841/complaints)).
- **[Price]** A practice was billed for both the old ($119.95) and new clearinghouse every month for about 10 months (BBB, Mar 2025) ([BBB](https://www.bbb.org/us/ca/san-diego/profile/computer-hardware/chirotouch-1126-30000841/complaints)).
- **[Support]** After the Apr 2026 server migration, reminder texts and emails stopped for 6+ weeks with no fix, costing the practice missed appointments (BBB, May 2026) ([BBB](https://www.bbb.org/us/ca/san-diego/profile/computer-hardware/chirotouch-1126-30000841/complaints)).
- **[Price]** A WebPT director reports annual price hikes and hidden add-on fees (Capterra, Jul 2026) ([Capterra](https://www.capterra.com/p/92920/WebPT/reviews/)).
- **[Price]** Appointment reminders are billed separately at WebPT and run to hundreds of dollars a month (Capterra, Feb 2025) ([Capterra](https://www.capterra.com/p/92920/WebPT/reviews/)).
- **[Complexity/UX]** A daily note takes 8–10 minutes and an evaluation 30–45 minutes in WebPT (Capterra, Feb 2025) ([Capterra](https://www.capterra.com/p/92920/WebPT/reviews/)).
- **[Support]** WebPT outages last hours to days and block documentation (Capterra, Feb 2025). Support reps lack the authority to fix problems (Capterra, May 2026) ([Capterra](https://www.capterra.com/p/92920/WebPT/reviews/)).
- **[Lock-in]** A WebPT data export arrived as "hundreds of randomly named folders" that can't be searched by patient or date (Capterra, Sep 2025) ([Capterra](https://www.capterra.com/p/92920/WebPT/reviews/)).
- **[Missing features]** WebPT's documentation and billing don't talk to each other, so claims were missed (Capterra, Feb 2024) ([Capterra](https://www.capterra.com/p/92920/WebPT/reviews/)).

## What we build (the better version)
1. **MVP:** Tap-based SOAP templates for chiro (spinal listings and segments, technique, regions adjusted, subjective pain scales) and PT (flowsheets, exercise and reps log, goals), with **autosave**.
2. **MVP:** An AI scribe that turns a 60-second dictation into a draft note ready to sign. The target is under 2 minutes per daily note, against the 8–10 minutes reviewers report on WebPT.
3. **MVP:** **Care plans, prepaid visit packages and wellness memberships** (e.g., 12-visit plan, $99/mo maintenance) with Stripe autopay and visit-balance tracking.
4. **MVP:** Online booking, waitlist, and unlimited reminders included (email free, SMS at cost). A clinic "flow board" shows checked in, in room and done, with QR/iPad check-in.
5. **MVP:** A home exercise program (HEP) library with video links and a patient web page (no app install).
6. **MVP:** Superbills, cash fee schedules, and **Medicare ABN** generation for non-covered chiro services.
7. **MVP:** **One-click full export**: a ZIP with patient-named PDFs plus CSVs, which directly answers the WebPT export complaint.
8. **MVP:** **Cancel in app, month-to-month**, which is the ChiroTouch counter-position.
9. **V2:** 837P claims and ERA through a clearinghouse API. For PT, an 8-minute-rule unit calculator, plan-of-care recert reminders, and KX-threshold tracking.
10. **V2:** Personal-injury case management: attorney contacts, lien tracking, and narrative-report generator.
11. **V2:** Outcome measures (Oswestry, NDI, LEFS) with auto-scoring and progress graphs, X-ray/image storage, and multi-location.
12. **V2:** Free migration service from on-premise ChiroTouch databases and WebPT exports.

## Pricing to win
- **$59/mo for the first provider + $29 per additional provider.** Unlimited staff, AI scribe included, reminders included, no setup fee, month-to-month.
- **Savings examples:**
  - Against a ChiroTouch renewal at $198/mo, one DC **saves about $1,668/yr**.
  - A 2-PT clinic on WebPT at about $99/provider pays $198/mo plus $500–$2,000 setup plus reminder fees. Alignly costs $88/mo, **saving $1,300+/yr before setup and reminder fees**.
  - Against Jane Practice/Thrive with AI Scribe and insurance add-ons, we match or undercut, and we add chiro-specific packages and PI tools.

## Go-to-market (first 100 customers)
- **Reddit:** r/Chiropractic and r/physicaltherapy (practice-owner threads).
- **Facebook:** Chiropractic practice-owner groups and cash-based PT owner communities (verify names and rules).
- **Associations:** State chiropractic associations (e.g., Texas Chiropractic Association, California Chiropractic Association, Florida Chiropractic Association), the American Chiropractic Association, and APTA Private Practice (section for PT owners). Pursue member discounts and newsletter sponsorships.
- **Events and CE:** Parker Seminars (Las Vegas), APTA Combined Sections Meeting, APTA Private Practice annual conference, and state chiro association conventions, which often carry CE.
- **Partners:** Chiro practice-management coaches and PI attorney networks (V2), with a referral fee per clinic.
- **SEO:** "ChiroTouch cancellation", "ChiroTouch alternative", "WebPT alternative for cash practice", "WebPT price increase", and "Jane vs".
- **List building:** Build prospect lists from public state license lookup databases for B2B outreach, following CAN-SPAM.

## Risks and incumbent moats
- **Insurance and Medicare depth for PT:** Launch cash- and hybrid-first. Add claims through a clearinghouse API in V2 and avoid building our own RCM service.
- **Data migration from on-premise ChiroTouch:** Offer a white-glove migration and a data-rescue service. Their export complaints are our acquisition angle.
- **Incumbent bundles:** Clearinghouse and payments bundles, and RCM "percentage of collections" contracts. We counter with transparency and no percentage fees.
- **HIPAA/BAA on a small-team budget:** Chiro and PT clinics that bill insurance are covered entities, and we are their business associate.
  - Sign BAAs with customers and get BAAs from every subprocessor.
  - **Infrastructure:** AWS (self-serve BAA via AWS Artifact) with only HIPAA-eligible services (encrypted RDS/S3, SES, Transcribe/Bedrock for the scribe).
  - **SMS and payments:** No PHI in SMS. Stripe for payments with no clinical detail in metadata.
  - **Paperwork:** A free HHS SRA Tool risk assessment, policies, MFA, audit logs, and a breach runbook.
  - **Cost estimate:** A few hundred dollars a month in infrastructure plus a few thousand dollars a year for a pen test and cyber insurance.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 3 | 4 | 3 | **18** |

## Sources
- [ChiroTouch BBB complaints](https://www.bbb.org/us/ca/san-diego/profile/computer-hardware/chirotouch-1126-30000841/complaints) (fetched 2026-09-24)
- [ChiroTouch pricing page](https://www.chirotouch.com/pricing) (fetched 2026-09-24)
- [WebPT reviews, Capterra](https://www.capterra.com/p/92920/WebPT/reviews/)
- [PT EMR Pricing Comparison 2026: SPRY vs WebPT vs Prompt vs Raintree (competitor source)](https://www.sprypt.com/blog/2026-pt-emr-pricing-spry-vs-webpt-vs-prompt-vs-raintree)
- [Jane App pricing](https://jane.app/pricing) (fetched 2026-09-24)
- [WebPT Pricing, TrustRadius](https://www.trustradius.com/products/webpt/pricing)
