# StatePay: a cheaper, better Gusto / ADP RUN for small employers in paid-leave states

**One-liner:** Starts as an AI state-compliance copilot that works alongside any payroll provider (tax notices, registrations, paid-leave programs, sick-leave accruals). Then it becomes flat-priced full payroll on an embedded payroll API.

## Snapshot
- **Replaces:**
  - **Gusto (gusto.com pricing, fetched Sep 24, 2026):**

    | Plan | Base | Per person | Key extra |
    |---|---|---|---|
    | Simple | $49/mo | $6/mo | Single state |
    | Plus | $80/mo | $12/mo | Multi-state |
    | Premium | $180/mo | $22/mo | Service advisor, HR experts |
    | Contractor-only | $0 promo (regularly $35/mo) | $6/mo | Contractors only |

    Add-ons: Next-Day Pay $15/mo + $3/person. Priority Support $30/mo + $3/person. Time & Attendance Plus $6/person. Outside-broker health integration $6 per eligible employee ([Gusto pricing](https://gusto.com/product/pricing)).
  - **ADP RUN, Paychex Flex, OnPay, Rippling:** 2026 prices **not verified this pass**. ADP and Paychex are quote-based.
- **Recent price hikes / changes:**
  - Gusto's Simple base fee rose from $40 to **$49/mo in March 2026 (+22%)** ([HRPayPick, Aug 31, 2026](https://hrpaypick.com/gusto-pricing/)).
  - Gusto Global needs roughly a $199/mo minimum ([HRPayPick](https://hrpaypick.com/gusto-pricing/)).
  - **New state paid-leave programs** ([OnPay, Jul 22, 2026](https://onpay.com/insights/paid-family-leave-by-state/)):

    | State | Contributions start | Benefits start | Notes |
    |---|---|---|---|
    | Minnesota | Jan 1, 2026 | Jan 1, 2026 | 0.88% premium, split employer/employee |
    | Delaware | Jan 1, 2025 | Jan 1, 2026 | Under 10 employees exempt |
    | Maine | Jan 1, 2025 | May 1, 2026 | |
    | Maryland | Jan 1, 2027 | Jan 3, 2028 | 0.90% split 50/50; under 15 employees exempt from employer share |
    | Virginia | Apr 1, 2028 | Dec 1, 2028 | 10 or fewer employees exempt from employer premium |
- **Who buys:** Owners and office managers of 2–50 employee businesses. The outside bookkeeper or CPA is often the influencer.
- **US market size:** Estimate (background, not verified this pass). About 6M US employer firms, most under 20 employees. Serviceable market: 1M+ employers paying $50–$300/mo for payroll. A very large dollar pool.
- **Urgency trigger (why they'd switch NOW):**
  - Gusto's Mar 2026 hike.
  - Jan 1 is the cleanest payroll switch date (the next is **Jan 1, 2027**), and Q4 is when owners decide.
  - Maryland paid-leave contributions start **Jan 1, 2027**. MN, DE and ME programs are now live.
  - Tax-notice errors (see evidence) push owners to leave mid-year.
- **Fastest-selling states/metros:**
  - Paid-leave and complexity states: MN, MD, DE, ME, plus existing programs in CA, NY, NJ, WA, MA, CT, OR, CO, RI.
  - Multi-state remote employers anywhere.

## Pain points (evidence)
- **[Price]** Gusto's entry base fee jumped 22% ($40 to $49) in March 2026 ([HRPayPick](https://hrpaypick.com/gusto-pricing/)).
- **[Price / hidden fees]**
  - Anyone paid in a month (final checks, bonuses) counts toward per-person fees.
  - Outside-broker benefits add $6/employee/mo.
  - Late corrections can trigger re-run fees ([HRPayPick](https://hrpaypick.com/gusto-pricing/)).
- **[Missing features]** Gusto won't open your state withholding or unemployment accounts. It only files once you have them ([HRPayPick](https://hrpaypick.com/gusto-pricing/)).
- **[Missing features]** The most common G2 complaint is hitting Simple's ceiling (next-day deposit, PTO policies) and having to upgrade early ([HRPayPick](https://hrpaypick.com/gusto-pricing/), citing G2).
- **[Tax errors]** Gusto refused to cover state unemployment tax errors it caused and left the customer to fix them (Sep 2026) ([Trustpilot](https://www.trustpilot.com/review/gusto.com)).
- **[Tax errors]** Three W-2s were prepared incorrectly. After a month and 13 emails, the owner fixed them personally (Sep 2026) ([Trustpilot](https://www.trustpilot.com/review/gusto.com)).
- **[Tax errors / Support]** A customer who paid about $30,000 over the years had two major tax problems and poor support response (Sep 2026) ([Trustpilot](https://www.trustpilot.com/review/gusto.com)).
- **[Price / Billing]** A customer says the monthly rate doubled without notice, the account was suspended yet still charged, and filings failed (Sep 2026) ([Trustpilot](https://www.trustpilot.com/review/gusto.com)).
- **[Benefits errors]** A benefits transition created duplicate deductions, unresolved for months (Sep 2026) ([Trustpilot](https://www.trustpilot.com/review/gusto.com)).
- **[Support]** Two unresolved issues including taxes, and "the follow through is terrible" (Sep 2026). Another user says service has declined and needs multiple calls (Sep 2026) ([Trustpilot](https://www.trustpilot.com/review/gusto.com)).
- **Balance note:** Gusto's Trustpilot is 1.9/5 (2,522 reviews), but Trustpilot skews negative for payroll. Gusto rates much higher on G2 and Capterra (not re-checked this pass).

## What we build (the better version)
**Phase 1: compliance copilot (works with Gusto, ADP, Paychex, QuickBooks Payroll)**
1. **MVP:** **Tax-notice inbox.** Upload or forward any IRS or state notice (SUI rate, withholding, penalty). An AI identifies the agency, the issue and the deadline, drafts the response, and tracks it to resolution.
2. **MVP:** **State registration wizard.** For each state where you have an employee: withholding account, SUI account, local tax, new-hire reporting, paid-leave program registration. Includes links, prefilled answers, and account-number tracking.
3. **MVP:** **Paid-leave and sick-leave engine.** Per-state and per-city accrual rules (MN, MD, DE, ME, CA, NY, NJ, WA, CO and others), with employee balances, required notices and posters, and quarterly premium reminders.
4. **MVP:** An owner dashboard. "Your compliance calendar" for the next 90 days by state, with email/SMS alerts.

**Phase 2: flat-priced payroll**

5. **V2:** Full-service payroll on an **embedded payroll API partner**. The partner does money movement and tax filing; we do the UX and compliance layer. Unlimited runs, direct deposit, W-2/1099.
6. **V2:** A **"We fix our mistakes" guarantee.** If a tax error is ours, we pay the penalty and do the fix, in writing.
7. **V2:** Time tracking, PTO requests, onboarding (I-4/W-4, state forms, e-sign), and a contractor portal.
8. **V2:** Benefits connectors (bring-your-own broker at no surcharge) and 401(k) integrations.

## Pricing to win
- **Phase 1 copilot:** $29/mo flat for up to 25 employees. Sold to owners and through bookkeepers.
- **Phase 2 payroll:** $39/mo + $5/person, all states included, next-day deposit included. Priced below Gusto Plus's $80 + $12.
  - **Verify margins:** Embedded payroll partner fees are unknown and must be priced before committing.
- **Example:** A 12-person, 2-state employer on Gusto Plus pays $80 + 12 × $12 = **$224/mo ($2,688/yr)**. StatePay payroll costs $39 + $60 = $99/mo ($1,188/yr), saving **about $1,500/yr** (estimate).

## Go-to-market (first 100 customers)
- **Bookkeepers and CPAs** (they clean up payroll-tax messes): r/Bookkeeping, r/Accounting, r/taxpros, r/smallbusiness, r/humanresources. Offer a partner dashboard across clients.
- **State targeting:** MN, MD and DE chambers of commerce and small-business development centers (SBDCs). Run webinars like "Maryland paid leave starts Jan 1, 2027: what small employers must do."
- **SEO pages:**
  - "Gusto price increase 2026"
  - "Gusto SUI error"
  - "Minnesota paid leave employer registration"
  - "Maryland FAMLI employer checklist"
  - "state tax notice what does it mean [state]"
- **Launch timing:** A Jan 1, 2027 switch campaign starting Oct 2026.

## Risks and incumbent moats
- **Regulated money movement and multi-state tax filing** are not buildable by us quickly. Mitigation: an embedded payroll API partner for Phase 2. Phase 1 needs no money movement.
- **Liability for compliance advice:** Mitigation: position as "tracking and drafting," require human review, add E&O insurance, and publish rule sources per state.
- **Rules change constantly:** Mitigation: an AI-assisted rule watcher plus human review per state. This is also a moat once built.
- **Incumbent bundling** (payroll + benefits + HR): Mitigation: integrate rather than fight in Phase 1.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 2 | 3 | 5 | **17** |

## Sources
- [Gusto pricing (fetched Sep 24, 2026)](https://gusto.com/product/pricing)
- [Gusto Pricing 2026: Every Plan With Real Examples (HRPayPick, Aug 31, 2026)](https://hrpaypick.com/gusto-pricing/)
- [Gusto reviews (Trustpilot, 1.9/5, Sep 2026)](https://www.trustpilot.com/review/gusto.com)
- [States with paid family leave 2026 (OnPay, Jul 22, 2026)](https://onpay.com/insights/paid-family-leave-by-state/)
- [2026 Family and Medical Leave Law Updates (Epstein Becker Green)](https://www.ebglaw.com/insights/publications/2026-family-and-medical-leave-law-updates-what-employers-in-seven-states-need-to-know)
- [State Paid Leave Laws to Grow Next Year (Bloomberg Law)](https://news.bloomberglaw.com/daily-labor-report/state-paid-leave-laws-to-grow-next-year-in-number-variation)
