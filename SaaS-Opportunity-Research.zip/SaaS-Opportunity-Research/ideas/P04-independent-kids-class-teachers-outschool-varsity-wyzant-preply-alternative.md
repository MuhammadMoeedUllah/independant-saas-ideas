# ClassHouse: a cheaper, better Outschool / Varsity Tutors / Wyzant / Preply for independent teachers of live kids' classes

**One-liner:** A storefront the teacher owns, for live small-group kids' classes online or local. It handles sections, seat caps, waitlists, weekly billing, parent messaging and parent-gated class links for a **flat monthly fee instead of a 25–33% cut**. A shared "collective" directory replaces the discovery teachers lose when they leave a marketplace.

## Snapshot
- **Replaces** (dated):
  - **Outschool:**
    - Takes **30%** of the class price; the teacher keeps 70%. Parents also pay a separate "Marketplace Fee".
    - Payouts arrive **7–13 days** after the class (policy dated Mar 4 2026) ([Outschool earnings policy](https://support.outschool.com/en/articles/2382129-teacher-earnings-and-payments-policy)).
    - Parents buy membership credits (e.g. **$40 = 80 credits** at $0.50 each) ([Outschool teacher guide to memberships](https://support.outschool.com/en/articles/10480877-a-teacher-s-guide-to-outschool-memberships)).
    - A **pay-per-class option was (re)introduced in the May 25 2026 update** as an alternative to the "previously required membership" ([Outschool payment FAQ](https://support.outschool.com/en/articles/14171122-outschool-payment-options-faqs-for-teachers)).
  - **Wyzant:** tutor keeps **75%** (25% fee), and a separate **9% service fee** applies to all lessons, even students the tutor referred ([Wyzant fee structure](https://support.wyzant.com/tutors/tutor-payments/what-is-the-fee-structure-for-tutors-listed-on-wyzant/)).
  - **Preply:** commission of **33%** for 0–20 hours, falling to **18%** at 400+ hours. Preply also keeps **100% of the first lesson** with each new student ([MyEngineeringBuddy, Jul 2026](https://www.myengineeringbuddy.com/blog/preply-reviews-features-pricing-alternatives/)).
  - **Varsity Tutors (Nerdy):** consumer "Learning Membership" average revenue per member of **$366/mo** (Q2 2026), up 5%, driven by **Feb 2025 price increases**. Tutor pay is set by the company ([Nerdy 10-Q via StockTitan, Aug 6 2026](https://www.stocktitan.net/sec-filings/NRDY/10-q-nerdy-inc-quarterly-earnings-report-7ae2fdff5381.html)).
  - **DIY stack:** Zoom + Stripe + Google Forms + Calendly. Course platforms (A06: Kajabi/Teachable) aren't built for live kids' sections.
- **Recent price hikes / changes (switching windows):**
  - **Nerdy retreat** ([10-Q, Aug 6 2026](https://www.stocktitan.net/sec-filings/NRDY/10-q-nerdy-inc-quarterly-earnings-report-7ae2fdff5381.html)):
    - Abandoned **First Tutors** in Q2 2026.
    - **Committed on Jul 31 2026 to wind down Varsity Tutors for Schools** ($2–4M expected exit costs).
    - Active members fell 5% to 29.1k.
    - Received an NYSE notice for trading under $1.
    - Tutors and school clients are being displaced.
  - **Outschool:** payment-model churn (required membership, then an optional pay-per-class, May 2026). A teacher reviewer says the fee went **from 17% to 30%** (Indeed, Apr 20 2026; reviewer claim, not verified).
  - **Money moving to families:** since Jul 2025, 529 plans cover **online education programs and tutoring** for K–12, with a **$20k/yr** cap (the cap's start date is unverified: the source gives none) ([PolitiFact](https://politifact.com/truth-o-meter/promises/maga-meter-tracking-donald-trumps-2024-promises/promise/387540/provide-10000-per-child-tax-free-to-homeschoolers/article/387543/)). ESA wallets run in about 18 states (see F06). Independent teachers who issue proper receipts can be paid directly.
- **Who buys:**
  - Independent teachers of live group classes for ages 5–17: coding, art, chess, languages, writing, science, homeschool core classes, test prep.
  - Many are certified teachers moonlighting or ex-Outschool and ex-Varsity tutors.
  - Also micro-academies of 2–10 teachers.
- **Overlap check:**
  - **F07** covers recurring 1:1 lessons, makeup credits and ESA vendor invoicing.
  - **A06** covers recorded courses and community for adults.
  - **P04 is different:** live *group sections* for *kids*, parent-owned learner profiles, COPPA-safe class links, safeguarding rules and a cross-teacher discovery directory. It should share a codebase with F07.
- **US market size:** Estimate: tens of thousands of US teachers sell kids' classes on Outschool, Wyzant, Preply and Varsity. No verified 2026 counts were found this pass; Glassdoor and ZipRecruiter salary pages show many Outschool teacher reports but not a headcount ([Glassdoor](https://www.glassdoor.com/Hourly-Pay/Outschool-Teacher-Hourly-Pay-E1311528_D_KO10,17.htm)).
- **Urgency trigger (why they'd switch NOW):**
  - The Varsity Tutors for Schools wind-down (Jul 31 2026).
  - Fall (Sep) and winter (Jan) term launches.
  - Parents now want itemized receipts for 529 and ESA reimbursement.
- **Fastest-selling states/metros:**
  - **ESA states:** AZ, FL, TX, UT, AR.
  - **Homeschool-growth states:** SC, OH, NH.
  - **Large metros** for local in-person classes.

## Pain points (evidence)
- **[Price]** Outschool keeps 30% of every payment, "fixed" no matter how long you've taught ([SupaTutor, 2026](https://supatutor.in/outschool-for-teachers-review/); [Outschool policy](https://support.outschool.com/en/articles/2382129-teacher-earnings-and-payments-policy)).
- **[Price]** A teacher says Outschool "started taking 30% instead of 17%" and "got greedy" after aggressive teacher recruiting (Indeed, Apr 20 2026) ([Indeed](https://www.indeed.com/cmp/Outschool/reviews)).
- **[Demand]** "The market for classes is highly saturated". Teachers spend a lot of time experimenting with topics and time slots to fill seats (Indeed, Mar 25 2026) ([Indeed](https://www.indeed.com/cmp/Outschool/reviews)).
- **[Lock-in]** Teachers can't see parent or student emails, so all communication runs through the platform ([SupaTutor](https://supatutor.in/outschool-for-teachers-review/)).
- **[Demand]** New teachers "commonly launch with 1 to 2 students". Enrollment has been thinning since 2022 ([SupaTutor](https://supatutor.in/outschool-for-teachers-review/)).
- **[Price]** At Varsity Tutors, certified teachers report "very low pay and no bargaining power" (Apr 10 2026), and one says "Varsity takes a huge chunk" of what clients pay (Jan 18 2025). Pay and benefits are rated **2.8/5** ([Indeed, Varsity Tutors pay reviews](https://www.indeed.com/cmp/Varsity-Tutors/reviews?fjobtitle=Tutor&ftopic=paybenefits)).
- **[Reliability]** Varsity student opportunities are "very inconsistent" (Aug 27 2026), and the tutor experience "has changed dramatically" (Aug 9 2026) ([Indeed](https://www.indeed.com/cmp/Varsity-Tutors/reviews?fjobtitle=Tutor&ftopic=paybenefits)).
- **[Price]** Wyzant takes 25% plus a separate 9% service fee, which applies even to students the tutor brought in ([Wyzant](https://support.wyzant.com/tutors/tutor-payments/what-is-the-fee-structure-for-tutors-listed-on-wyzant/)).
- **[Price/support]** Preply takes 100% of each new student's first lesson. Tutors cite high commissions, "inconsistent payment" and "glitches" in Preply Classroom ([MyEngineeringBuddy, Jul 2026](https://www.myengineeringbuddy.com/blog/preply-reviews-features-pricing-alternatives/)).
- **[Cash flow]** Outschool weekly classes pay out only on Sundays, 7–13 days after the meetings ([Outschool policy](https://support.outschool.com/en/articles/2382129-teacher-earnings-and-payments-policy)).

## What we build (the better version)
1. **MVP** **Teacher storefront** (subdomain or custom domain): class listings with multiple sections, parent-timezone display, seat caps, age ranges, waitlists, trial or first-class discounts, and an AI listing writer.
2. **MVP** **Checkout and billing** on Stripe Connect, with the teacher as merchant of record. Supports one-time, weekly subscription and term billing, sibling discounts and a refund/credit policy engine. Payouts on Stripe's standard schedule (typically about 2 days).
3. **MVP** **Parent-owned learner profiles** (first name + age band only) with recorded parent consent. **Class links are released only to enrolled parent accounts.** Each section gets a unique link with a waiting room, and no public links (Zoom/Google Meet integration).
4. **MVP** **Safeguarded messaging:** teacher↔parent threads and section announcements, logged. **No private teacher↔child DMs.** Automatic reminders.
5. **MVP** **Move-your-families kit:** import the teacher's own rosters by CSV and send invite links through the teacher's own channels. Built to respect marketplace rules against soliciting on-platform.
6. **MVP** **Receipts for 529 and ESA** (itemized, with provider details), plus a 1099-K/income summary export.
7. **MVP** **Collective directory** (opt-in): parents search across member teachers by age, subject and time. Teachers earn referral credit for sending families to each other.
8. **V2** Built-in classroom (WebRTC) with attendance, a homework drop box, and recording off by default (recording needs parent opt-in).
9. **V2** Background-check badge (Checkr integration) and verified reviews.
10. **V2** ESA vendor mode and marketplace listings, reusing F07's ESA module.

## Pricing to win
- **Solo: $29/mo flat, 0% platform fee** (Stripe processing passed through at cost, about 2.9% + 30¢). **Studio: $79/mo for up to 10 teachers.** Month-to-month, free migration.
- **Examples:**
  - Outschool teacher grossing **$3,000/mo**: Outschool keeps about **$900/mo**. ClassHouse costs $29 + about $90 processing = **$119/mo**. Saves about **$9,300/yr**.
  - Wyzant tutor billing 40 hrs × $60 = $2,400/mo: pays **$600/mo** (25%) before the 9% service fee. ClassHouse costs about $29 + $72 processing.

## Go-to-market (first 100 customers)
- **Communities:** Outschool-teacher Facebook groups and YouTube creators who publish Outschool income videos, r/Outschool, r/Teachers, r/OnlineESLTeaching and ex-Varsity tutor groups.
- **Offer:** free migration and 3 months free for teachers with 20+ marketplace reviews. We seed the collective directory with 100 teachers before launching to parents.
- **Parent demand side:** homeschool co-ops and associations (P03 cross-sell), ESA parent Facebook groups in AZ, FL and TX, and 529 content.
- **SEO:** "Outschool alternative for teachers", "leave Varsity Tutors", "how to sell online classes for kids without Outschool", "529 eligible online class".

## Risks and incumbent moats
- **Losing marketplace demand** is the biggest risk. Mitigate with the collective directory, parent referral credits, SEO class pages and a hybrid plan: stay on Outschool for discovery while moving repeat families to ClassHouse.
- **Marketplace terms:** don't encourage off-platform solicitation of marketplace-acquired families. Migration uses the teacher's own audience and channels.
- **COPPA:**
  - Accounts belong to parents, and children don't register.
  - Follow the amended COPPA Rule (compliance deadline Apr 22 2026, widely reported): written security program, retention policy, separate consent for any third-party disclosure.
  - No ad or analytics pixels on class pages.
- **Safeguarding:** no private teacher-child chat, recording off by default, optional background checks, and a reporting button.
- **Payments:** Stripe Connect KYC. Chargeback tooling for disputes over no-show classes.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 5 | 4 | 3 | 3 | **19** |

## Sources
- [Teacher Earnings and Payments Policy – Outschool, Mar 2026](https://support.outschool.com/en/articles/2382129-teacher-earnings-and-payments-policy)
- [Outschool Payment Options: FAQs for Teachers – May 2026](https://support.outschool.com/en/articles/14171122-outschool-payment-options-faqs-for-teachers)
- [A Teacher's Guide to Outschool Memberships](https://support.outschool.com/en/articles/10480877-a-teacher-s-guide-to-outschool-memberships)
- [Teacher Terms for Outschool Memberships](https://outschool.com/pages/membership-teacher-terms)
- [Working at Outschool – Indeed reviews](https://www.indeed.com/cmp/Outschool/reviews)
- [Outschool for Teachers: Is the 30% Commission Worth It in 2026? – SupaTutor](https://supatutor.in/outschool-for-teachers-review/)
- [Wyzant tutor fee structure](https://support.wyzant.com/tutors/tutor-payments/what-is-the-fee-structure-for-tutors-listed-on-wyzant/)
- [Preply reviews, pricing – MyEngineeringBuddy, Jul 2026](https://www.myengineeringbuddy.com/blog/preply-reviews-features-pricing-alternatives/)
- [Nerdy Q2 2026 10-Q summary – StockTitan, Aug 6 2026](https://www.stocktitan.net/sec-filings/NRDY/10-q-nerdy-inc-quarterly-earnings-report-7ae2fdff5381.html)
- [Varsity Tutors tutor pay reviews – Indeed](https://www.indeed.com/cmp/Varsity-Tutors/reviews?fjobtitle=Tutor&ftopic=paybenefits)
- [Federal law expands 529 expenses – PolitiFact, Feb 2026](https://politifact.com/truth-o-meter/promises/maga-meter-tracking-donald-trumps-2024-promises/promise/387540/provide-10000-per-child-tax-free-to-homeschoolers/article/387543/)
- [Outschool teacher hourly pay – Glassdoor](https://www.glassdoor.com/Hourly-Pay/Outschool-Teacher-Hourly-Pay-E1311528_D_KO10,17.htm)

## Verification (Sep 25 2026)
- ✅ Outschool 30% fee — the policy (dated Mar 4, 2026) says the teacher receives 70% of the class price, parents pay a separate Marketplace Fee, and weekly classes pay out on Sundays 7–13 days after the meetings ([source](https://support.outschool.com/en/articles/2382129-teacher-earnings-and-payments-policy))
- ✅ Payment-model change — the May 25, 2026 FAQ adds pay-per-class. Previously "a membership was required to enroll", and the teacher payout structure is unchanged ([source](https://support.outschool.com/en/articles/14171122-outschool-payment-options-faqs-for-teachers))
- ✅ Varsity Tutors for Schools wind-down — Nerdy's 10-Q (Aug 6, 2026): on Jul 31, 2026 the company committed to discontinue it ($2–4M exit costs). It also exited First Tutors in Q2, active members fell 5% to 29.1k, ARPM rose 5% to $366 on Feb 2025 price increases, and it received an NYSE $1 notice. Wording tightened ([source](https://www.stocktitan.net/sec-filings/NRDY/10-q-nerdy-inc-quarterly-earnings-report-7ae2fdff5381.html))
- ⚠️ 529 expansion ($20k cap) — PolitiFact (Feb 20, 2026) confirms $10k → $20k per child per year and coverage of online programs and tutoring, but gives no effective date. The start date is marked unverified ([source](https://politifact.com/truth-o-meter/promises/maga-meter-tracking-donald-trumps-2024-promises/promise/387540/provide-10000-per-child-tax-free-to-homeschoolers/article/387543/))
- ✅ Wyzant 25% + 9% — tutors keep 75%, and a 9% service fee applies to all lessons. On tutor-referred students the tutor keeps 100% of the rate, but the 9% still applies. The page does not say who pays the 9% ([source](https://support.wyzant.com/tutors/tutor-payments/what-is-the-fee-structure-for-tutors-listed-on-wyzant/))
