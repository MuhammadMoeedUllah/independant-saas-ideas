# BenchBoard: a cheaper, contract-free Bullhorn / JobDiva for small staffing agencies and recruiters

**One-liner:** An ATS and recruiting CRM for 1–50 person staffing firms. AI resume parsing, junk-applicant filtering, SMS/email sequences and pay-transparency-compliant job posts. Month-to-month, with one-click full data export.

## Snapshot
- **Replaces:**
  - **Bullhorn, JobDiva, Crelate, Recruit CRM:** 2026 list prices **not verified this pass**. Bullhorn and JobDiva are quote-based; Crelate and Recruit CRM publish per-user pricing that needs re-checking.
  - **Indeed Sponsored Jobs:**
    - Billed on "job seeker interactions like clicks or started applications."
    - Invoiced monthly or whenever spend hits $500.
    - Tiers: Free, Standard, Premium, and Premium Plus (beta, AI tools).
    - Smart Sourcing (resume search) is a separate subscription ([Indeed pricing](https://www.indeed.com/hire/pricing)).
- **Recent price hikes / changes:**
  - Bullhorn customers report 2025–2026 **auto-renewals despite cancellation requests** and renewals with excess licenses (Trustpilot, below).
  - Indeed moved to charging for "started applications," not just clicks ([Indeed pricing](https://www.indeed.com/hire/pricing)). The exact change date was not verified this pass.
- **Who buys:** Owners of independent staffing agencies (light industrial, healthcare, IT, office/clerical) and boutique recruiting firms with 1–50 recruiters.
- **US market size:** Estimate (background, not verified this pass). The American Staffing Association cites roughly 25k staffing and recruiting companies with about 49k offices, plus many solo recruiters. Serviceable market: about 20k–30k firms at $100–$1,000/mo.
- **Urgency trigger (why they'd switch NOW):**
  - Contract renewal dates: Bullhorn customers are trapped until renewal, so we must capture the date 90+ days out.
  - Rising Indeed spend and junk applicants.
  - New state pay-transparency and temp-worker laws that need job-post and assignment compliance (see state leads).
- **Fastest-selling states/metros:** Estimate. Staffing-heavy states: TX, CA, FL, IL, OH, GA, NJ, NY, plus light-industrial hubs (Dallas–Fort Worth, Chicago, Atlanta, Inland Empire, Columbus).

## Pain points (evidence)
All Bullhorn reviews below are from [Trustpilot](https://www.trustpilot.com/review/bullhorn.com).
- **[Lock-in/Contracts]** A customer cancelled in June and got a confirmation, then was auto-renewed two months later. Bullhorn couldn't track the cancellation internally (Aug 2026).
- **[Lock-in/Contracts]** A contract auto-renewed with excess user licenses. There were "countless voicemails and emails since November 2025" with no resolution; the customer called it "bullhorn jail" (Jun 2026).
- **[Lock-in/Contracts]** Support averaged 7 days, and an explicit non-renewal request was ignored before the contract renewed (Jul 2025).
- **[Lock-in/data]** A customer couldn't get a full data export to migrate away despite years of import/export complaints (Jul 2025).
- **[Support]** After switching to Bullhorn, a customer had slow support for three months of onboarding, and integration failures blocked daily work (Jul 2026).
- **[Support]** Two support requests about search got no acknowledgment after multiple follow-ups (May 2026).
- **[Missing features]** Bulk email, SMS and WhatsApp didn't work, and applicant notifications never reached recruiters, forcing manual job checking (May 2026).
- **[Complexity]** A simple self-service API setup took a multi-week ticket process, and promised callbacks never came (Apr 2026).
- **[Price / job boards]** Small employers say free Indeed postings get little visibility, so sponsored posting feels like the only realistic option. One calls it "misleading, frustrating, and unfair to small businesses" (Sep 23, 2026) ([Trustpilot, Indeed](https://www.trustpilot.com/review/www.indeed.com)).
- **[Applicant quality]** Employers report irrelevant resumes and fake or scam applicant accounts ([Trustpilot, Indeed](https://www.trustpilot.com/review/www.indeed.com)). Under click or started-application billing, those can cost money.
- **Balance note:**
  - Bullhorn's Trustpilot score is 3.4/5 (123 reviews), and it is the category leader with many satisfied large customers.
  - Indeed's 1.8/5 (13k reviews) is dominated by job seekers.

## What we build (the better version)
1. **MVP:** Import from Bullhorn, Crelate, JobDiva and Recruit CRM (CSV/API), including candidates, contacts, companies, jobs, notes and resumes. AI dedupes and re-parses resumes.
2. **MVP:** ATS and CRM: jobs, pipelines, submittals, interviews and placements. Kanban plus list views. Fast search with boolean and AI semantic search ("forklift certified, 2nd shift, within 15 miles").
3. **MVP:** **Applicant triage.** AI scores inbound applicants against must-haves, filters duplicates and suspected spam/fake profiles, and auto-texts qualified ones to book a screen.
4. **MVP:** Two-way SMS (10DLC registered), email sequences and bulk messaging that actually works, logged to the record.
5. **MVP:** A career page and job feed (XML) for free organic distribution, with **pay-transparency checks**: flags a missing salary range for postings in states and cities that require one.
6. **MVP:** **"Leave anytime" guarantee.** One-click full export (CSV + files) and month-to-month billing, with cancellation in the app. No phone calls.
7. **V2:** Temp staffing back office: onboarding (I-9, W-4, state forms, e-sign), a mobile timesheet app, client approval, and pay/bill export to payroll or funding partners.
8. **V2:** VMS connectors, client portal and redeployment alerts (assignments ending, then match to open orders).
9. **V2:** State temp-worker compliance packs (e.g., Illinois Day and Temporary Labor Services Act notices and equal-pay tracking; verify requirements).

## Pricing to win
- **Plans:** $49/recruiter/mo with everything included, or an agency flat rate of $399/mo for up to 15 recruiters. SMS billed at cost.
- **Terms:** No annual contract required (−15% if annual). Free migration.
- **Example (estimate; Bullhorn pricing not verified):** For a 10-recruiter agency, any per-seat incumbent above about $90/user/mo costs $10,800+/yr. BenchBoard flat costs $4,788/yr.

## Go-to-market (first 100 customers)
- **Associations:** American Staffing Association (ASA), including the Staffing World conference and ASA state chapters (e.g., California Staffing Professionals, Texas Association of Staffing, Illinois Staffing Association, Florida Staffing Association).
- **Events:** Staffing Industry Analysts (SIA) Executive Forum, and the Bullhorn Engage counter-programming week.
- **Communities:** r/recruiting, r/humanresources, r/smallbusiness, and recruiter Facebook/LinkedIn groups (agency owners, "Recruiter Tools & Hacks"-type groups).
- **SEO pages:**
  - "Bullhorn contract auto renew cancel"
  - "Bullhorn alternative small agency"
  - "Bullhorn data export"
  - "Indeed started application charge"
  - "pay transparency job posting [state]"
- **Timing:** A renewal-date capture campaign: "Tell us your Bullhorn renewal date and we'll send the 90-day non-renewal letter template + free migration."

## Risks and incumbent moats
- **Bullhorn marketplace depth** (hundreds of integrations, VMS connectivity, pay/bill): Mitigation: target perm and light temp agencies first. Add VMS and back office in V2.
- **Contract lock-in:** Buyers can't leave until renewal. Mitigation: renewal-date capture and a parallel run at a discount.
- **Job-board dependencies** (Indeed/LinkedIn policy changes): Mitigation: multi-channel posting, referral and redeployment features.
- **Data privacy** (candidate PII, state privacy laws): Mitigation: retention settings, consent logging and deletion workflows.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 4 | 3 | 3 | **17** |

## Sources
- [Bullhorn reviews (Trustpilot, 3.4/5, 2025–2026)](https://www.trustpilot.com/review/bullhorn.com)
- [Indeed employer pricing (fetched Sep 24, 2026)](https://www.indeed.com/hire/pricing)
- [Indeed reviews (Trustpilot, 1.8/5)](https://www.trustpilot.com/review/www.indeed.com)
