# DoorList: a cheaper, better Eventbrite for small organizers, community theaters and local venues

**One-liner:** Ticketing and registration with all-in pricing (compliant with the FTC's 2025 fees rule), a $0.99 flat per-ticket fee or a flat monthly plan, next-day payouts, QR check-in, and a free Eventbrite import. For organizers who sell 200–20,000 tickets a year.

## Snapshot
- **Replaces:**
  - **Eventbrite** (US organizer pricing, accessed Sep 24 2026): **3.7% + $1.79 service fee per paid ticket, plus 2.9% payment processing per order.** Free events cost nothing. The "Eventbrite Pro" email add-on **starts at $15/mo** ([Eventbrite pricing](https://www.eventbrite.com/organizer/pricing/)).
  - A competitor notes Eventbrite has **no per-ticket fee cap** (removed in 2018) and **keeps its service and processing fees when an organizer refunds** a ticket. The Pro plan was restructured around email volume at **$15–$100/mo** (SimpleTix, Jul 8 2026, competitor) ([SimpleTix](https://www.simpletix.com/eventbrite-2026-pricing-changes/)).
  - Ticketmaster (small venues) and Cvent (small events): not re-priced in this pass.
- **Recent price hikes / changes (switching windows):**
  - **Bending Spoons bought Eventbrite:** announced **Dec 2025** for **about $500M**, closed **Mar 10 2026** (per Equaticket). The co-founder/CEO departed, followed by staff cuts across engineering, marketing and support ([SimpleTix](https://www.simpletix.com/eventbrite-2026-pricing-changes/); [Equaticket](https://equaticket.com/blog/eventbrite-bending-spoons-what-organizers-need-to-know)). IQ Magazine reported layoffs of "a large portion of the pre-acquisition team" (Apr 14 2026) ([IQ Magazine](https://www.iqmagazine.com/2026/04/eventbrite-makes-layoffs-following-bending-spoons-acquisition/); [heise](https://www.heise.de/en/news/Event-platform-Eventbrite-lays-off-a-large-part-of-its-employees-11257427.html)). Bending Spoons is widely reported to reprice and cut staff at acquired products (e.g. Evernote); not sourced in this pass. Fee or plan changes at Eventbrite are our inference only; none has been announced.
  - **FTC Rule on Unfair or Deceptive Fees**, effective **May 12 2025**. Anyone who "offers, displays, or advertises live-event tickets" (venues, promoters, platforms, apps) must show the **total price, including all mandatory fees, more prominently** than other prices, with no small-organizer exemption. Penalties include civil penalties and refunds ([FTC FAQ](https://www.ftc.gov/business-guidance/resources/rule-unfair-or-deceptive-fees-frequently-asked-questions)). Many small organizers' fee-added checkouts are now a compliance risk. **State all-in ticket-pricing laws** add to this (see the state leads).
- **Who buys:** Owner-operators and volunteer leads: community theaters, comedy clubs, small music venues, breweries and wineries running events, workshop hosts, nonprofit galas, local festivals, fitness pop-ups, conferences under 500 people. The buyer is one person with a card.
- **US market size:** Estimate: hundreds of thousands of US organizers sell paid tickets each year. Treat Eventbrite's organizer base as a proxy and verify in the state pass.
- **Urgency trigger (why they'd switch NOW):** Uncertainty after the Bending Spoons takeover (support cuts, expected repricing). FTC all-in pricing compliance. Fall and holiday season, plus 2027 season planning (theater seasons and festivals set up ticketing in Q4).
- **Fastest-selling states/metros:** Dense live-event metros: NYC, LA, Chicago, Austin, Nashville, Denver, Minneapolis, Atlanta. States with their own all-in ticket laws (CA, NY, CO, MN, MD; verify) where compliance messaging lands (estimate).

## Pain points (evidence)
- **[Price]** A ticketing agent says Eventbrite's service fee on paid events "can accumulate quickly", on top of a percentage of sales (Capterra, Mar 2025) ([Capterra](https://capterra.com/p/114949/Eventbrite/reviews/?page=4)).
- **[Price/Trust]** An education COO lost **over $3,000 to auto-activated "Boost" ads** they say they never approved, with no refund, and support couldn't even find the ads (Capterra, Apr 2025) ([Capterra](https://capterra.com/p/114949/Eventbrite/reviews/?page=4)).
- **[Support]** An events producer says accounting problems on a complex event were very hard to fix because of the lack of support (Capterra, Oct 2025) ([Capterra](https://capterra.com/p/114949/Eventbrite/reviews/?page=4)).
- **[Missing features]** A sports office manager finds event-page customization too limited for a small business (Capterra, Apr 2026) ([Capterra](https://capterra.com/p/114949/Eventbrite/reviews/?page=4)).
- **[Reliability]** A CEO reports recurring-event bugs where dates change unexpectedly (Capterra, Sep 2026) ([Capterra](https://capterra.com/p/114949/Eventbrite/reviews/?page=4)).
- **[Complexity/UX]** A religious-institution user says the UI needs lots of copy-and-paste between sections and has no defaults for repeat tasks (Capterra, Jul 2025) ([Capterra](https://capterra.com/p/114949/Eventbrite/reviews/?page=4)).
- **[Missing features]** An operations manager says integrations don't connect reliably, so RSVP data is re-entered by hand (Capterra, Apr 2026) ([Capterra](https://capterra.com/p/114949/Eventbrite/reviews/?page=4)).
- **[Price/Refunds]** Eventbrite keeps its fees when organizers refund, and fee credits after a full cancellation must be requested manually (SimpleTix, Jul 2026, competitor) ([SimpleTix](https://www.simpletix.com/eventbrite-2026-pricing-changes/)).
- **[Cash flow]** A competitor explainer says Eventbrite holds organizers' money for days after the event ([TicketCrest](https://ticketcrest.com/blog/eventbrite-holds-your-money), competitor; not opened in this pass, verify the payout policy by account type).

## What we build (the better version)
1. **MVP** Event pages with reserved or GA seating, ticket tiers, promo codes, capacity and waitlists, on custom domains or embedded on the organizer's site.
2. **MVP** **All-in pricing by default:** the price shown includes every mandatory fee. An FTC-rule checklist runs on each event, and a per-state rules toggle comes in V2.
3. **MVP** Flat fees: **$0.99/ticket** or **$29/mo unlimited**. Processing is billed at Stripe cost, and the organizer chooses whether to absorb or include it in the all-in price.
4. **MVP** **Fast payouts:** Stripe Connect standard payouts to the organizer's own account, not held until after the event.
5. **MVP** QR check-in app (PWA, works offline), door sales on phone tap-to-pay, and a guest-list export.
6. **MVP** **Eventbrite import:** past attendees become an email list; upcoming events are cloned.
7. **MVP** Built-in email and SMS to past attendees (no $15–$100/mo add-on).
8. **V2** Season passes and flex packs (community theater subscriptions), donations at checkout (nonprofit galas), and memberships.
9. **V2** Assigned-seat map builder for small venues (up to 1,000 seats).
10. **V2** AI event copy and "who to invite" suggestions from past attendance, plus a refund/transfer self-service portal.

## Pricing to win
- **Free for free events.** Paid events: **$0.99/ticket** (Starter) or **$29/mo with no per-ticket fee** (Pro). Processing at cost. No fees kept on refunds except the non-refundable card-network portion.
- **Example (estimate):** 2,000 tickets/yr at $25.
  - Eventbrite: about $3.52/ticket, or **~$7,000/yr**.
  - DoorList Starter: about $1.87/ticket, or **~$3,700/yr**.
  - DoorList Pro: **~$2,100/yr** ($348 plus ~$1,750 processing).
  - That saves **$3,300–$4,900/yr**.

## Go-to-market (first 100 customers)
- **Communities:** r/eventplanning, r/EventProduction and r/Theatre. Facebook groups for community theater managers, comedy producers and brewery event managers.
- **Associations:** the American Association of Community Theatre (AACT) and its state affiliates, state arts councils and local arts agencies, IFEA (festivals and events), state brewers guilds.
- **News-jacking content:** "What Bending Spoons owning Eventbrite means for your fees", and "FTC all-in pricing checklist for small organizers".
- **SEO:** "Eventbrite alternative lower fees", "Eventbrite refund fees", "all-in ticket pricing law [state]".
- **Partner:** venue booking agents and local event calendars (referral fee).

## Risks and incumbent moats
- **Discovery marketplace:** Eventbrite brings buyers. We counter with organizer-owned lists, Google event schema, and Instagram and SMS integration.
- **Crowded field:** Ticket Tailor, Humanitix, SimpleTix and TicketSpice. Our wedge is fast migration, compliance-first all-in pricing and Eventbrite-refugee messaging.
- **Chargebacks and fraud:** Stripe Radar, holds only for high-risk new accounts, disclosed up front.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 4 | 4 | 4 | 4 | **20** |

## Sources
- [Eventbrite organizer pricing (accessed Sep 24 2026)](https://www.eventbrite.com/organizer/pricing/)
- [Eventbrite 2026 pricing changes – SimpleTix (competitor, Jul 8 2026)](https://www.simpletix.com/eventbrite-2026-pricing-changes/)
- [Eventbrite makes layoffs following Bending Spoons acquisition – IQ Magazine (Apr 14 2026)](https://www.iqmagazine.com/2026/04/eventbrite-makes-layoffs-following-bending-spoons-acquisition/)
- [Eventbrite lays off a large part of its employees – heise](https://www.heise.de/en/news/Event-platform-Eventbrite-lays-off-a-large-part-of-its-employees-11257427.html)
- [Bending Spoons acquired Eventbrite (March 2026) – Equaticket](https://equaticket.com/blog/eventbrite-bending-spoons-what-organizers-need-to-know)
- [Eventbrite reviews p.4 – Capterra](https://capterra.com/p/114949/Eventbrite/reviews/?page=4)
- [FTC Rule on Unfair or Deceptive Fees – FAQ](https://www.ftc.gov/business-guidance/resources/rule-unfair-or-deceptive-fees-frequently-asked-questions)
- [Why Eventbrite holds your money – TicketCrest (competitor)](https://ticketcrest.com/blog/eventbrite-holds-your-money)

## Verification (Sep 24 2026)
- ✅ Eventbrite US: 3.7% + $1.79 service fee per ticket, 2.9% processing per order, free events free, Pro from $15/mo — confirmed on the pricing page ([source](https://www.eventbrite.com/organizer/pricing/))
- ✅ Bending Spoons deal ~$500M, closed Mar 10 2026 (date added); "a large portion of the pre-acquisition team" laid off; no fee increase announced as of May 2026 ([source](https://equaticket.com/blog/eventbrite-bending-spoons-what-organizers-need-to-know))
- ✅ Layoffs reported Apr 14 2026 with the same quote ([source](https://www.iqmagazine.com/2026/04/eventbrite-makes-layoffs-following-bending-spoons-acquisition/))
- ✅ Announced Dec 2025; co-founder/CEO Julia Hartz departed; no fee cap since 2018; Eventbrite keeps its fees on refunds; Pro at $15/$50/$100; "none of the underlying fee mechanics changed" — confirmed (competitor source) ([source](https://www.simpletix.com/eventbrite-2026-pricing-changes/))
- Scores unchanged. Note: the trigger rests on uncertainty and staff cuts, not an actual fee hike.
