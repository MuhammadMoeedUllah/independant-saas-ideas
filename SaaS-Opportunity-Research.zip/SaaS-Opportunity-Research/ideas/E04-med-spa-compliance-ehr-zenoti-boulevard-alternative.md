# Glowchart: a cheaper, simpler, compliance-first Zenoti / PatientNow / Boulevard for owner-operated med spas

**One-liner:** Booking, memberships and injector charting for single-location med spas, with a built-in **state-law compliance engine** (good-faith exam gating, delegation protocols, "ordered by / administered by" records, adverse-event logs, state registration checklists) as a new wave of state med-spa laws takes effect.

## Snapshot
- **Replaces** (prices per Vagaro's comparison dated Aug 6, 2026, a competitor source):
  - **Boulevard:** Essentials $158/mo, Premier $263/mo, Prestige $369/mo per location.
  - **Aesthetic Record:** Essentials $15/mo per user + $399 "Startup Investment"; Accelerator $19/mo + $399.
  - **PatientNow and Zenoti:** "contact for pricing" (quote-only).
  - **Vagaro**, the cheap end: $23.99/mo solo + $10 per additional staff.
- **Recent price hikes / changes** (law is the big one):
  - **Texas HB 3749 ("Jenifer's Law") and TMB Rule 169.28, effective Sep 1, 2025.** IV therapy is limited to physicians, PAs, APRNs and RNs. Prescribing delegation is restricted. Written delegation protocols and physician disclosure are required, and **treatment records must document who ordered and who administered** each service.
  - **Indiana SB 282, effective Jul 1, 2026, with state registration required by Jan 1, 2027.** It requires a designated responsible practitioner, **adverse-event reporting within 15 days**, and advertising rules. It covers med spas, IV hydration and GLP-1 weight-loss clinics.
  - **California SB 351, effective Jan 1, 2026.** It codifies the bar on management companies or PE controlling clinical decisions and requires physician-directed individualized orders.
  - **New Jersey S2996, effective Mar 30, 2026.** Aesthetic providers need current, service-specific collaborating-physician agreements.
  - **Florida SB 1728** (registration and responsible practitioner) **failed in committee on Mar 13, 2026** and is expected to return.
  - All of the above is per Decoda Health's 2026 summary. Verify against statute text in the per-state pass.
- **Who buys:** Owner-operators (NP/RN/PA injectors, physician owners, aesthetician-owners with a medical director) at single-location med spas, IV hydration lounges and GLP-1 weight-loss clinics. About 81% of operators run a single location.
- **US market size:** About **10,488 US med spas in 2023** (up from 8,899 in 2022), per Orbital/American Med Spa Association data cited by AestheticHires. The industry is **$17B+ in annual revenue and growing by $1B+ a year** (AmSpa, report dated Apr 22, 2026).
- **Urgency trigger (why they'd switch NOW):** The Indiana registration deadline (Jan 1, 2027) and adverse-event reporting, Texas record-keeping requirements (in force since Sep 2025), California SB 351 (Jan 2026), New Jersey collaborating agreements (Mar 2026), and Florida's likely re-filing. Incumbent tools weren't designed around these rules.
- **Fastest-selling states/metros:** TX (Houston, Dallas, Austin), IN (Indianapolis), CA (LA, OC, SD), NJ, FL (Miami, Tampa, Orlando). CA, FL and TX lead med-spa job openings on AestheticHires.

## Pain points (evidence)
- **[Complexity/UX]** A health/wellness business with 11–50 employees says Zenoti setup needed extensive configuration, and data discrepancies appeared during implementation (Capterra, Jul 2026) ([Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)).
- **[Complexity/UX]** Promotions, loyalty and booking settings aren't intuitive and took several attempts to set up (Capterra, Jun 2026) ([Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)).
- **[Complexity/UX]** A medical practice says routine tasks take too many steps compared with competitors (Capterra, Apr 2026) ([Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)).
- **[Complexity/UX]** Implementation meant many hours and late nights and felt overwhelming for the first months (Capterra, Apr 2026) ([Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)).
- **[Support]** Only an AI chatbot and messaging are available, with no phone support unless you're a large business (Capterra, Jan 2026) ([Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)).
- **[Support]** Simple webstore changes need the support team because there's no self-service (Capterra, Aug 2026) ([Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)).
- **[Missing features]** Reports for specific time frames are hard to pull reliably (Capterra, Jun 2025) ([Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)).
- **[Complexity/UX]** A cosmetics business finds Zenoti slower than alternatives and wants a simpler version for small businesses (Capterra, Dec 2025) ([Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)).
- **[Missing features / regulatory]** New laws require records of who ordered and who administered (TX), 15-day adverse-event reporting and registration (IN), and service-specific collaborating agreements (NJ). Owners need workflow support, not just a booking calendar ([Decoda Health](https://decodahealth.com/blog/new-med-spa-laws-2026), [Holland & Knight](https://www.hklaw.com/en/insights/publications/2025/06/texas-governor-signs-bill-into-law-increasing-regulations)).
- **[Price]** Several major platforms (Zenoti, PatientNow) hide pricing behind demos, while Boulevard runs $158–$369 per location per month ([Vagaro comparison, Aug 2026](https://www.vagaro.com/learn/best-emr-software)).

## What we build (the better version)
1. **MVP:** Booking with **deposits and no-show fees**, a waitlist, and SMS/email reminders.
2. **MVP:** **Memberships, packages and "unit banks"** (e.g., prepaid neurotoxin units) with Stripe autopay and a retail POS.
3. **MVP:** **Injector charting.** A tap-to-mark face map records product, units, lot and expiry, and a before/after photo capture tool with angle guides stores photos in the chart (off the phone's camera roll).
4. **MVP:** **Compliance engine ("State Pack")**:
   - Good-faith exam gating: treatment can't be charted without a valid GFE on file, either in-house or from a GFE partner.
   - Medical-director protocol and standing-order library with e-signature and version history.
   - Mandatory **"ordered by / administered by / supervising physician"** fields (TX).
   - An **adverse-event log** with a 15-day reporting countdown (IN).
   - License and certification expiry tracking for every provider.
5. **MVP:** Per-treatment consent forms with e-signature, and product **lot tracking** so recalls take one click.
6. **MVP:** A medical-director review queue (chart sampling, co-sign) and an exportable audit binder PDF.
7. **V2:** A GLP-1 weight-loss program module (Rx tracking, check-ins, labs), IV therapy charting per the TX rules, and Indiana registration data export.
8. **V2:** Marketing automation (rebooking at the 90-day neurotoxin interval), loyalty-program integrations, and AI photo comparisons.
9. **V2:** State Packs for FL (when passed), plus other states identified in the per-state pass.

## Pricing to win
- **$99/mo per location, including 3 providers; $19 per additional provider.** State Pack included, month-to-month, free migration. Payments at Stripe's standard rate at launch (no forced in-house processor).
- **Savings:** Against Boulevard Premier ($263/mo), one location **saves about $1,968/yr**. Against Boulevard Prestige ($369/mo), it **saves about $3,240/yr**. Against Aesthetic Record, there's no $399 startup fee.
- **Honest note:** Vagaro is cheaper on sticker price. We win on compliance workflow and injector-specific charting, not on being the absolute cheapest.

## Go-to-market (first 100 customers)
- **State-deadline campaigns:** "Indiana SB 282 registration checklist" (before Jan 1, 2027), a "Texas Jenifer's Law chart audit", and a "California SB 351 contract check". Offer free webinars with med-spa compliance attorneys.
- **Events:** AmSpa's Medical Aesthetics Business Boot Camps (multi-city) and The Aesthetic Show (Las Vegas). Sponsor state-specific breakout sessions.
- **Partners:** Medical-director-as-a-service and GFE telehealth providers (e.g., companies like Qualiphy and Spakinect, which publish on these laws), injector training academies, and med-spa law firms. Referral fees or integrations.
- **Communities:** Nurse-injector Facebook and Instagram communities, and injector subreddits (verify activity).
- **SEO:** "Zenoti alternative for small med spa", "Boulevard pricing", "Texas HB 3749 compliance software", "Indiana med spa registration".

## Risks and incumbent moats
- **Cheap competitors** (Vagaro, Aesthetic Record) plus payments-revenue business models. Our moat is compliance workflow depth and state packs that competitors are slow to build.
- **Legal-advice liability:** We position the product as tooling with attorney-reviewed templates and "not legal advice" disclaimers, and track statute changes.
- **Fast-moving laws:** We keep a law-change monitor, which is also a content marketing engine.
- **HIPAA/BAA on a small-team budget:**
  - A cash-only med spa may not technically be a HIPAA covered entity (HIPAA status turns on conducting standard electronic transactions such as insurance claims). Photos and treatment records are still sensitive health data, state privacy laws apply, and buyers expect HIPAA. Build to HIPAA anyway and sign BAAs.
  - Use AWS HIPAA-eligible services under its self-serve BAA, encrypted photo storage in S3 with KMS, and no PHI or photos over SMS.
  - Stripe for payments, with no clinical detail in metadata.
  - A free HHS SRA Tool risk assessment, MFA, audit logs, and a breach runbook.
  - **Cost estimate:** A few hundred dollars a month plus a few thousand dollars a year for a pen test and cyber insurance.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 4 | 3 | **17** |

## Sources
- [5 Best Med Spa EMR Systems 2026: Pricing & Features Comparison, Vagaro (Aug 6, 2026; competitor source)](https://www.vagaro.com/learn/best-emr-software)
- [ZENOTI reviews, Capterra](https://www.capterra.com/p/131057/ZENOTI/reviews/)
- [New Med Spa Laws in 2026: Indiana, Texas, California, New Jersey, Florida, Decoda Health](https://decodahealth.com/blog/new-med-spa-laws-2026)
- [Texas Governor Signs Bill into Law Increasing Regulations on Medical Spas, Holland & Knight (Jun 2025)](https://www.hklaw.com/en/insights/publications/2025/06/texas-governor-signs-bill-into-law-increasing-regulations)
- [Texas Med Spa Legislation Action Center, AmSpa](https://americanmedspa.org/texas-med-spa-action-center)
- [Medical Spa State of the Industry Report, AmSpa (Apr 22, 2026)](https://www.americanmedspa.org/med-spa-statistics/)
- [Med Spa Industry Statistics 2026, AestheticHires (cites Orbital/AmSpa count)](https://www.aesthetichires.com/med-spa-industry-statistics/)
