# ClockRight IL: a cheaper, better Homebase / 7shifts / biometric time clock for Illinois employers

**One-liner:** A time clock and scheduler that is BIPA-free by design (no fingerprints or face geometry). It tracks paid-leave accruals for PLAWA, Chicago and Cook County automatically, adds a Chicago tip-credit tracker and an Illinois pay-transparency posting checker, all for one flat per-location price.

## Snapshot
- **Replaces:**
  - **Homebase**, per location per month: Basic free (1 location, 10 employees), Essentials $30, Plus $70, All-in-One $120 ([Turnozo, 2026](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts), via D04).
  - **7shifts**, per location per month: Comp free, Essentials $44.99, Pro $89.99, Premium $149.99 ([Turnozo, updated Jul 23 2026](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
  - **Gusto Time & Attendance Plus**, $6 per person per month on top of payroll (Simple base $49/mo) ([Gusto pricing, fetched Sep 24 2026](https://gusto.com/product/pricing), via G04).
  - **Biometric clocks bundled by ADP, Paychex and UKG:** quote-based, not priced in this pass.
- **Recent price hikes / changes:**
  - 7shifts restructured its plans on Jul 2 2025 ([7shifts changelog](https://developers.7shifts.com/changelog/changes-to-7shifts-pricing-plans)).
  - Gusto's base fee rose from $40 to $49 in Mar 2026, +22% ([HRPayPick, Aug 31 2026](https://hrpaypick.com/gusto-pricing/)).
  - Homebase gates PTO controls behind Plus ($70) and overtime and labor-cost tools behind All-in-One ($120) ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
  - **The Illinois rule stack keeps growing:**
    - Pay transparency for 15+ employee firms (Jan 1 2025), with 5-year records, an anonymous-complaint policy from Jan 1 2026, and rule revisions from Jun 18 2026 ([IDOL](https://labor.illinois.gov/laws-rules/conmed/equalpay.html)).
    - The statewide Paid Leave for All Workers Act (Jan 1 2024; verify).
    - Chicago Paid Leave and Paid Sick Leave (Jul 1 2024; verify).
    - The Chicago tip-credit phase-out, ending Jul 1 2028 (verify).
    - The BIPA amendment (Aug 2024; verify).
- **Who buys:** Owners, GMs and office managers of Illinois businesses with hourly staff: restaurants and bars, light manufacturers, staffing agencies, home care, retail and salons. Buyers typically have 10–150 employees; bookkeepers and payroll providers influence the choice.
- **US market size:** This is a single-state product.
  - Illinois has **1.4 million small businesses** employing 2.4 million people.
  - Small-business employment in hourly-heavy sectors: accommodation and food services 318,909, manufacturing 239,226, health care 343,660 ([SBA Advocacy 2025 IL profile](https://advocacy.sba.gov/wp-content/uploads/2025/06/Illinois_2025-State-Profile.pdf)).
  - The number of Illinois *employer* firms was not pulled. An estimate is that tens of thousands have hourly teams. The engine carries over to Michigan (ESTA), Minnesota and other paid-leave states (G04).
- **Urgency trigger (why they'd switch NOW):**
  - **BIPA:** fingerprint and face time clocks need a written release and a public retention policy. Most BIPA suits have targeted employer time clocks (verify). The 2024 amendment limits damages to one violation per person (verify), but $1,000–$5,000 per worker is still a lawsuit.
  - **Chicago's next tipped-wage step is Jul 1 2027** (verify).
  - **Jan 1 2027** is the clean payroll and timekeeping switch date.
  - The **2026 pay-transparency enforcement changes** are live now.
- **Fastest-selling states/metros:** Chicago first (three leave layers plus the tip phase-out plus BIPA), then suburban Cook County (county paid leave; verify), collar counties, and Rockford and Peoria manufacturers. The engine then extends to MI, MN and other paid-leave states.

## Pain points (evidence)
- **[Complexity/UX]** A Homebase user (Sep 21 2026) said employee clock-in was malfunctioning even with geofencing turned off ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Missing features / reliability]** A reviewer (Sep 8 2026) reported phantom shifts, gaps in timesheets, and remote staff unable to log in. For Illinois, timesheet gaps mean wrong PLAWA and Chicago accruals ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Price]** A reviewer (Sep 15 2026) said mobile time-clock costs were higher than expected despite "free" claims ([Trustpilot](https://www.trustpilot.com/review/joinhomebase.com)).
- **[Price]** Homebase gates PTO controls behind the $70 tier and overtime and labor-cost alerts behind the $120 All-in-One tier. Leave tracking, which Illinois requires, is not in the cheap plans ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
- **[Price]** Gusto charges $6 per person per month for Time & Attendance Plus on top of a base fee that rose 22% in Mar 2026. For 25 hourly workers, that is $150/mo just for the clock ([Gusto pricing](https://gusto.com/product/pricing); [HRPayPick](https://hrpaypick.com/gusto-pricing/)).
- **[Lock-in/Contracts]** Reddit users report difficulty cancelling Homebase and charges after cancellation. This is secondhand, via Turnozo ([Turnozo](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts)).
- **[Missing features / legal]** Illinois requires every internal and external posting at 15+ employee firms to include pay and benefits, promotion notices to staff within 14 days, and 5 years of posting records. Schedulers and clocks don't check or archive any of this ([IDOL](https://labor.illinois.gov/laws-rules/conmed/equalpay.html)).
- **[Missing features / legal]** BIPA requires a written release and a public retention and destruction schedule before any biometric scan. Owners who bought fingerprint clocks often never collected releases (verify) ([740 ILCS 14, ILGA](https://www.ilga.gov/legislation/ilcs/ilcs3.asp?ActID=3004&ChapterID=57); the page was robots-blocked, so details are marked verify).
- **[Vendor risk]** 7shifts cut about 19% of staff in Jan 2024 and changed plans in Jul 2025 (Turnozo, citing BetaKit; [7shifts changelog](https://developers.7shifts.com/changelog/changes-to-7shifts-pricing-plans)).

## What we build (the better version)
1. **MVP: BIPA-free time clock.** Shared-tablet PIN or QR badge, phone geofence, and optional plain photo capture with no face-geometry analysis and no biometric templates stored. A "BIPA status: no biometrics collected" certificate PDF comes with it for the owner's files and insurer.
2. **MVP: Illinois leave engine.** Rules are picked per worksite address: PLAWA (1 hour per 40, 40-hour cap), Chicago paid leave plus paid sick leave, and Cook County suburban rules (verify each parameter with counsel). It handles front-load vs. accrual, carryover and payout-at-separation flags, and employee balance views.
3. **MVP: Chicago tip-credit tracker.** It shows the current cash-wage and tip-credit step by date. Each pay period it flags any worker whose tips plus cash wage fall below the full minimum, and it keeps a July-1 change calendar.
4. **MVP: Scheduler.** Templates, availability, shift swaps and SMS or push reminders (shared code with D04 ShiftTip).
5. **MVP: Pay-transparency posting checker.** Paste or connect job posts, flag missing pay range and benefits, log the 14-day internal promotion notice, and archive postings for 5 years.
6. **MVP: Payroll export** to Gusto, ADP RUN, Paychex, QuickBooks and Square Payroll (CSV), with leave hours and tip credits on separate lines.
7. **V2: BIPA consent module** for customers who insist on biometrics: e-signed releases, a published retention policy page, and a destruction log.
8. **V2: AI-in-hiring notice templates** for the Illinois Human Rights Act amendment (Jan 1 2026; verify), shared with G07.
9. **V2: Chicago Fair Workweek** predictability-pay calculator for covered industries (verify thresholds).
10. **V2: Other state packs** using the same engine: Michigan ESTA and wage steps, Minnesota ESST, and a Day and Temporary Labor Services Act pack for staffing agencies (G07).

## Pricing to win
- **ClockRight IL:** Free for 1 location with up to 10 staff (clock plus PLAWA accruals). **$39/mo per location with unlimited staff and every feature** (Chicago leave, tip tracker, posting checker, payroll export). No per-person fees, no annual contract, and free import of existing leave balances.
- **Savings:**
  - A 25-person Chicago restaurant needing PTO and overtime tools pays $120/mo on Homebase All-in-One or $89.99–$149.99 on 7shifts. On Gusto T&A Plus it pays $150/mo. ClockRight IL saves **$50–$110/mo per location, or $600–$1,300 a year**.
  - The biggest value is avoiding a BIPA claim or a leave-underpayment complaint.

## Go-to-market (first 100 customers)
- **Free tools:** "Chicago Paid Leave + PLAWA accrual calculator", "One Fair Wage 2027 cash-wage calculator" and "Is your time clock a BIPA risk? 2-minute check". These double as SEO pages ("PLAWA calculator", "Chicago paid leave calculator", "BIPA time clock").
- **Illinois Restaurant Association** member webinar with an employment-law firm on July 1 wage steps and leave. Also neighborhood chambers in Chicago (Pilsen, Little Village, Chinatown, Devon Ave) with Spanish, Polish and Chinese onboarding (estimate of demand).
- **Payroll bookkeepers and restaurant CPAs in Chicagoland:** revenue share, since they field the accrual and tip-credit questions.
- **Illinois Manufacturers' Association and staffing firms** (Illinois Staffing Association via G07) for the BIPA-free clock angle.
- **Reddit:** r/chicago, r/restaurateur, r/smallbusiness. Also Square and Clover app marketplaces.

## Risks and incumbent moats
- **Legal accuracy:** the leave and tip rules are detailed and change often. Mitigation: counsel-reviewed rule tables, conservative defaults, dated change logs and "not legal advice" disclosures.
- **Cheap and free incumbents** (Homebase free tier, 7shifts Comp) keep the price gap modest. We win on Illinois-specific compliance they don't model.
- **The BIPA amendment lowered damages** (verify), so fear alone is weaker than in 2023. We lead with the combined leave, tip and posting stack; BIPA is the door-opener.
- **Payroll bundling:** ADP and Paychex bundle clocks. Mitigation: export-first and integrate rather than replace payroll, with a Gusto-embedded partnership later (G04).
- **Single-state market ceiling:** the engine is built to be multi-state from day one, with MI and MN packs next.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 4 | 4 | 3 | **17** |

## Sources
- [SBA Office of Advocacy: 2025 Illinois Small Business Profile (PDF)](https://advocacy.sba.gov/wp-content/uploads/2025/06/Illinois_2025-State-Profile.pdf)
- [IL Department of Labor: Equal Pay Act / Pay Transparency / EPRC](https://labor.illinois.gov/laws-rules/conmed/equalpay.html)
- [Biometric Information Privacy Act, 740 ILCS 14 (ILGA)](https://www.ilga.gov/legislation/ilcs/ilcs3.asp?ActID=3004&ChapterID=57) (robots-blocked; statute details marked verify)
- [Turnozo: Turnozo vs Homebase vs 7shifts (updated Jul 23 2026)](https://turnozo.com/blog/turnozo-vs-homebase-vs-7shifts) (via D04)
- [Homebase reviews, Trustpilot](https://www.trustpilot.com/review/joinhomebase.com) (via D04)
- [7shifts changelog: changes to pricing plans (Jul 2 2025)](https://developers.7shifts.com/changelog/changes-to-7shifts-pricing-plans) (via D04)
- [Gusto pricing](https://gusto.com/product/pricing) (via G04)
- [HRPayPick: Gusto pricing (Aug 31 2026)](https://hrpaypick.com/gusto-pricing/) (via G04)
- Details of PLAWA, the Chicago Paid Leave ordinance, One Fair Wage, Cook County leave, Fair Workweek, the IL HRA AI amendment and the BIPA amendment come from background knowledge and are marked (verify). The chicago.gov wage page showed only 2023 rates, and the One Fair Wage page returned 403.
