# Quietdesk: a cheaper, better Zendesk / Intercom / Help Scout for small support teams

**One-liner:** A shared inbox, live chat, help center and AI answer bot for a flat team price, with AI resolutions included in bulk rather than billed at $0.75–0.99 each.

## Snapshot
- **Replaces:**
  - **Intercom** (GetMacha, Jul 3, 2026, updated Sept 24, 2026):
    - Per seat: Essential $29 annual / $39 monthly (Intercom is price-testing $19/$29 on some visitors), Advanced $85/$99, Expert $132/$139
    - **Fin AI $0.99 per "outcome"** (resolution, handoff, disqualification or routing), and $9.99 per sales qualification
    - Copilot $29–35/agent/mo; Proactive Support Plus $99/mo + pay-as-you-go SMS, WhatsApp and phone
  - **Zendesk Suite** (Software Pricing Guide, Apr 3, 2026), per agent per month:
    - Team $55, Growth $89, Professional $115, Enterprise $169
    - **AI Advanced +$50/agent/mo**, WFM about $25, QA about $35
    - About **$279/agent** fully loaded
  - **Help Scout** (GetMacha, Sept 24, 2026):
    - Free up to 5 users; Standard $25/$30 per user; Plus $45/$54; Pro $75/$90 (**10-user minimum**)
    - **AI Answers $0.75/resolution**
  - **Freshdesk** and **Front**: per-seat tiers, not re-priced in this pass.
- **Recent price hikes / changes:**
  - Intercom's move to **per-outcome AI billing**, where "assumed" resolutions (the customer just leaves) are billable.
  - Help Scout moved to **contact-based pricing around Nov 2024**, faced backlash and **walked much of it back**. New signups are per-user again, and some legacy customers stayed on contact plans.
  - Zendesk sells AI as a $50/agent add-on.
- **Who buys:** SMBs with 1–15 support agents: Shopify/DTC brands, small SaaS, agencies, online course and membership businesses (cross-sell to A06), and multi-location service firms. The buyer is the founder, head of CX or ops lead. They buy with a card, but usually trial for a week or more.
- **US market size:** estimate. Hundreds of thousands of US SMBs run a formal support inbox, and ecommerce brands alone number in the hundreds of thousands. Market size is moderate relative to the other ideas.
- **Urgency trigger (why they'd switch NOW):**
  - A surprise AI bill (Fin outcomes or Help Scout AI Answers).
  - Seat minimums at renewal.
  - Zendesk's AI add-on quote.
  - Account lockouts or email suspensions (Intercom reviews below).
- **Fastest-selling states/metros:** no state-law driver. DTC and SaaS clusters: SF Bay Area, NYC, LA, Austin, Miami, Salt Lake City, Denver.

## Pain points (evidence)
- **[Lock-in/Contracts]** An Intercom customer locked out of their account can't cancel, and charges continue (Trustpilot, May 19, 2026) ([source](https://www.trustpilot.com/review/www.intercom.com))
- **[Support]** Intercom suspended a customer's outgoing email during a compliance review without warning, breaking weekend onboarding emails (Trustpilot, Jun 28, 2026) ([source](https://www.trustpilot.com/review/www.intercom.com))
- **[Support]** An Intercom customer says account-change requests by chat and email were ignored from February onward: "literally no customer service" (Trustpilot, Jun 2, 2026) ([source](https://www.trustpilot.com/review/www.intercom.com))
- **[Complexity/UX]** Intercom has persistent glitches: unintended assignments, missed call notifications, and interface elements blocking clicks (Trustpilot, Sept 17, 2026) ([source](https://www.trustpilot.com/review/www.intercom.com))
- **[Price]** Intercom Fin bills "assumed resolutions", so a customer who just leaves the chat still costs $0.99 (GetMacha, 2026) ([source](https://www.getmacha.com/blog/intercom-pricing-explained))
- **[Price]** Intercom is price-testing Essential, so different visitors see $19 or $29 annual. The price is hard to predict (GetMacha, 2026) ([source](https://www.getmacha.com/blog/intercom-pricing-explained))
- **[Price]** Zendesk AI Advanced is +$50/agent on top of Suite, and fully loaded Enterprise reaches about $279/agent/mo. Small teams "often overpay" (Software Pricing Guide, Apr 3, 2026) ([source](https://softwarepricingguide.com/zendesk-pricing-2025-suite-plans-hidden-costs-and-when-to-switch-to-a-cheaper-alternative/))
- **[Lock-in/Contracts]** Help Scout's late-2024 switch to contact-based pricing drew enough criticism that it was mostly walked back. Commentary such as "Whither Help Scout?" (Apr 2025) captures customers' worries about predictable bills (GetMacha, Sept 24, 2026) ([source](https://www.getmacha.com/blog/help-scout-pricing-explained))
- **[Price]** Help Scout Pro requires a 10-user minimum, and AI Answers adds $0.75 per resolution (GetMacha, Sept 24, 2026) ([source](https://www.getmacha.com/blog/help-scout-pricing-explained))

**Honest read:** the pain is real but mostly about **AI pricing and support quality**, not public fury. Intercom has only 12 Trustpilot reviews, and Help Scout and Freshdesk offer free tiers. Our edge is structural: an AI resolution costs us cents in LLM spend, so we can bundle thousands. This works better as a cross-sell to A03 and A06 customers than as a headline product.

## What we build (the better version)
1. **Shared inbox.** Forward support@ into it and get assignment, collision detection, tags, saved replies, notes and snooze. **MVP**
2. **Live chat widget** that falls back to email or SMS when nobody is online (reuses A03 webchat). **MVP**
3. **Help center / knowledge base** with AI-drafted articles generated from resolved tickets, on a custom domain. **MVP**
4. **AI answer bot**, grounded in your help center, past tickets and product/order data, with cited answers, a clean handoff to a human and **no charge for handoffs**. **MVP**
5. **Order lookup** for Shopify and Stripe (order status, refund request), with approval rules. **MVP** for Shopify, **V2** for Stripe.
6. **AI assist for agents** (draft reply, summarize, translate) included on all plans. **MVP**
7. **SLAs, business hours, CSAT survey** (reuses A01 forms) and basic reports (first response time, resolution time, AI deflection rate). **MVP**
8. **Import from Zendesk, Help Scout, Intercom and Freshdesk** via their APIs (tickets, customers, macros, articles). **MVP** for Help Scout and Zendesk, **V2** for the others.
9. **WhatsApp, Instagram and Facebook channels.** **V2**
10. **Voice callback plus voicemail transcription.** **V2**
11. **AI "spend guardrail"** that caps monthly AI conversations, alerts at 80%, and never counts an abandoned chat as a resolution. **MVP**

## Pricing to win
- **Starter $29/mo:** up to 3 agents, 500 AI-answered conversations.
- **Team $79/mo:** up to 10 agents, 3,000 AI conversations, all channels.
- **Additional AI:** $10 per 1,000 conversations.
- Month-to-month, free migration, no seat minimums.
- **Savings:** a 3-agent brand on Intercom Essential ($87–117/mo) with 500 Fin outcomes ($495) pays about **$580–610/mo**. Our Starter is $29, saving **about $6,600–7,000/yr**. A 5-agent team on Zendesk Growth with AI Advanced (5 × $139 = $695/mo) moving to Team ($79) saves **about $7,400/yr**.

## Go-to-market (first 100 customers)
- **Cross-sell** into A03 (local business inbox) and A06 (creator support) customers.
- **Communities:** r/shopify, r/ecommerce, r/CustomerSuccess, r/SaaS, r/startups, and the Shopify Community forums. Also a Shopify App Store listing, which is key for discovery.
- **SEO:**
  - "Intercom Fin pricing too expensive"
  - "Intercom assumed resolution billing"
  - "Help Scout contact based pricing alternative"
  - "Zendesk AI add-on cost"
  - "cheap helpdesk with AI chatbot included"
- **Partners:** Shopify agencies and freelance CX consultants (a 20% recurring referral).
- **Launch:** Product Hunt, and Indie Hackers build-in-public with "AI resolutions at cost" as the hook.

## Risks and incumbent moats
- **Email deliverability and reliability** are critical: use a reputable ESP, SPF/DKIM/DMARC onboarding, and a status page.
- **AI accuracy liability**, since businesses have been held to chatbot promises. Mitigate with grounded answers only, citations, "I'll get a human" fallback, and allow/deny topics.
- **Integration depth** (Shopify, Stripe, CRMs). Start Shopify-only for focus.
- **Free tiers** (Help Scout Free for 5 users, Freshdesk Free). Win on bundled AI, not base price.
- **Gorgias owns Shopify helpdesk mindshare.** Differentiate on flat AI and simplicity.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 4 | 3 | 3 | 3 | **16** |

## Sources
- [Intercom Pricing Explained (2026) – GetMacha](https://www.getmacha.com/blog/intercom-pricing-explained) (Jul 3, 2026, updated Sept 24, 2026)
- [Intercom Fin Pricing: The Per-Resolution Cost Breakdown – GetMacha](https://www.getmacha.com/blog/intercom-fin-pricing)
- [Intercom on Trustpilot](https://www.trustpilot.com/review/www.intercom.com) (2.1/5, 12 reviews)
- [Zendesk Pricing 2025: Suite Plans, Hidden Costs – Software Pricing Guide](https://softwarepricingguide.com/zendesk-pricing-2025-suite-plans-hidden-costs-and-when-to-switch-to-a-cheaper-alternative/) (Apr 3, 2026)
- [Help Scout Pricing Explained (2026) – GetMacha](https://www.getmacha.com/blog/help-scout-pricing-explained) (Sept 24, 2026)
