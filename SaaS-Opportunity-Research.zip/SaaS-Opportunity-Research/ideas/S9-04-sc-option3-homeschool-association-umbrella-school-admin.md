# CoverDesk: a cheaper, better Homeschool-life / "email + Google Forms" back office for South Carolina Option 3 homeschool associations (then Tennessee umbrella schools)

**One-liner:** A back office for the 81 South Carolina "Option 3" homeschool associations. It handles enrollment and fees, the semiannual check-in forms, late-member chasing, membership, DMV and withdrawal letters, and the director's annual assurance, and it gives every member family a free attendance and progress log that fills in the semiannual report. The association is the paying customer and the channel to its families, who can upgrade to P03 HomeRoll.

## Snapshot
- **Replaces:**
  - **Homeschool-life.com** (the co-op and group-site default): Connections **$9.95 per family/yr**, Academy **$11.95 per family/yr**, Business **$310.80/yr**. SMS, domain and design are paid add-ons (Sep 2026, via P03: [Homeschool-life pricing](https://www.homeschool-life.com/pricing)).
  - **The status quo is a website plus email.** Hometown Homeschool Association of SC says "We do all communication via email." Members submit their semiannual progress report and then complete questionnaires on the site's Members Page ([HHASC FAQ](https://www.hometownhasc.com/faqs/), accessed Sep 2026).
  - SC-TOP runs "convenient, online forms" and sells letters and transcript help as tier add-ons ([SC-TOP](https://sc-top.org/), accessed Sep 2026).
  - Google Forms and spreadsheets at smaller associations: an estimate, not surveyed.
- **Recent changes:**
  - **Fastest homeschool growth in the US:** South Carolina's homeschooling grew **+21.5%** in 2024–25, the fastest of any state (JHU Homeschool Hub, Jul 2026, via P03: [JHU](https://education.jhu.edu/edpolicy/policy-research-initiatives/homeschool-hub/homeschool-growth-2024-2025/)). Volunteer-run associations absorb that growth by hand.
  - **The 2026–27 Option 3 list has 81 associations.** Each must complete SCDE's "Annual Standards Assurance form" under S.C. Code §59-65-47 ([SCDE Option 3 list](https://ed.sc.gov/districts-schools/state-accountability/home-schooling/home-school-option-3/)).
  - **ESTF growth:** SC's ESA grows to at least **15,000** scholarships in 2026–27 with a **500% FPL** income cap ([EdChoice](https://www.edchoice.org/school-choice/programs/south-carolina-education-scholarship-trust-fund-program/)). That adds new money and paperwork to homeschool households. Whether ESTF counts homeschoolers as eligible needs checking (verify).
- **Who buys:** The director (often the owner or a volunteer) of an SC Option 3 homeschool association. Background knowledge says the statute requires associations to have at least 50 members (verify). **Expansion buyers:** Tennessee church-related umbrella schools (Category IV), which parents enroll in instead of filing a notice with the district ([TN DOE](https://www.tn.gov/education/families/school-options/home-schooling-in-tn.html)). After that, church-school and umbrella-school models in other states (background knowledge; verify each).
- **US market size:**
  - **Beachhead:** 81 SC associations (SCDE). Member counts aren't published. Fees run **$35–$75 per family** ([Homeschool Start Guide, Feb 4 2026](https://homeschoolstartguide.com/blog/south-carolina-option-3-accountability-association)) or **$20–$50 per student** (SC-TOP).
  - **Estimate:** if the average association has 200–400 families, SC Option 3 covers roughly **16k–32k families**. This is an estimate, not sourced.
  - **Expansion:** the number of Tennessee umbrella schools wasn't found (verify).
  - **Why it's worth more than the buyer count:** the buyer pool is tiny, but each buyer brings its whole membership (B2B2C).
- **Urgency trigger (why they'd switch NOW):**
  - **The fall enrollment surge is happening now.** Deadlines are fixed and "strictly enforced."
  - **Semiannual deadlines differ by association,** for example **~Jan 5 / ~Jun 5** (Homeschool Start Guide) versus **Mar 1 / Jul 31** at HHASC. That means an association can go live before its next check-in window, which is 3–5 months away.
  - The annual SCDE assurance is also due each year.
- **Fastest-selling states/metros:** Greenville–Spartanburg, Columbia and Charleston (estimate, following population), then Tennessee (Nashville suburbs, Knoxville, Chattanooga; estimate).

## Pain points (evidence)
No public review complaints about association tooling were found. These are process burdens documented on association and state pages, and the pain score reflects that.
- **[Complexity/UX]** One association runs everything through email. Members file the semiannual report and then fill in separate website questionnaires, with the 90-day check-in due Mar 1 and the 180-day check-in due Jul 31, "strictly enforced" ([HHASC FAQ](https://www.hometownhasc.com/faqs/)).
- **[Complexity/UX]** Calendars aren't standard. One guide puts the check-ins around Jan 5 and Jun 5, while HHASC uses Mar 1 and Jul 31, so families who switch associations or read generic advice miss dates ([Homeschool Start Guide](https://homeschoolstartguide.com/blog/south-carolina-option-3-accountability-association); [HHASC](https://www.hometownhasc.com/faqs/)).
- **[Missing features]** Directors produce documents by hand. SC-TOP's tiers include a membership letter, printable wallet card, withdrawal notice and records request, DMV letter, transcript assistance and class ranking ([SC-TOP](https://sc-top.org/)).
- **[Missing features]** "Most associations provide the legal umbrella function only." Transcripts and testing coordination cost extra where they exist at all ([Homeschool Start Guide](https://homeschoolstartguide.com/blog/south-carolina-option-3-accountability-association)).
- **[Compliance]** The law requires parents to keep a plan book, a portfolio and "a semiannual progress report including attendance records and individualized documentation of the student's academic progress" over a 180-day year ([S.C. Code §59-65-47](https://www.scstatehouse.gov/code/t59c065.php)). Most families rebuild this from memory at deadline time (inference).
- **[Price]** Homeschool-life's per-family pricing plus paid SMS, domain and design add-ons (via P03) is costly for a volunteer association that charges only $35–$75 a family.

## What we build (the better version)
1. **MVP: Roster and enrollment.**
   - Online join form with Stripe fee collection (per family or per student, matching how the association prices).
   - The parent's diploma/GED attestation required under Option 3 ([§59-65-47](https://www.scstatehouse.gov/code/t59c065.php)).
   - Children and grades, and CSV import of existing rosters.
2. **MVP: Check-in engine.**
   - Each association sets its semiannual due dates (Jan/Jun, Mar/Jul, etc.).
   - Automatic email and SMS reminders at 30, 14 and 3 days out.
   - A live "not yet submitted" list with one-click nudges, and late-fee handling where the association charges one.
3. **MVP: Free family log (the P03 engine).**
   - Daily attendance toward 180 days, a plan-book entry and portfolio uploads.
   - At check-in time it produces the semiannual progress report, including attendance.
   - **Records stay parent-owned.** The association sees only the attestation and status unless the family shares more. This matches the law's parent-kept model.
4. **MVP: Letter and document generator.** Membership letters, wallet cards, withdrawal notices to the district, answers to records requests, and DMV/permit verification letters (verify SC DMV's form). Every document is signed, dated and logged.
5. **MVP: Director dashboard.** Member, fee and check-in status, counts ready for the SCDE Annual Standards Assurance form, and CSV/PDF exports.
6. **V2: High-school services.** Transcripts, credits, GPA and class rank. SC-TOP already charges $35–$50 per student for grades 9–12 that include these.
7. **V2: Testing coordination.** Optional standardized-test sign-ups and score storage.
8. **V2: Tennessee umbrella-school pack.** Enrollment verification for districts and attendance records for Category IV church-related schools (verify TN reporting rules). Then packs for other church-school and umbrella models.
9. **V2: Money add-on.** ESTF, Hope, TEFA and 529 receipt vault via P03/P07.

## Pricing to win
- **Association plans:**
  - **Free** up to 50 families.
  - **$49/mo** up to 400 families.
  - **$99/mo** up to 1,500 families.
  - Month-to-month, with free roster migration.
  - The alternative is $1.50 per family per year passed through in dues.
- **Families** get the check-in log free through their association. **HomeRoll premium** (P03: transcripts, ESA/529 receipt vault) is **$49/yr** as an upsell.
- **Savings example:** a 400-family association on Homeschool-life Connections pays about **$3,980/yr** (400 × $9.95, before add-ons). CoverDesk costs **$588/yr**, a saving of about 85%, and also generates the letters and reports.

## Go-to-market (first 100 customers)
- **Direct outreach to all 81 associations** on SCDE's 2026–27 list during Oct–Dec 2026. The offer: "Run your next check-in on CoverDesk free." A signed-up association brings every member family onto the free log.
- **Directories and community:** homeschoolingsc.org's association directory ([Homeschool Associations Directory](https://www.homeschoolingsc.org/resources-page/homeschool-associations/), not fetched) and SC homeschool Facebook groups (search by name).
- **SEO pages:** "South Carolina Option 3 checklist", "semiannual progress report template" and "how to switch Option 3 associations".
- **Tennessee (month 4+):** umbrella-school directors and Tennessee Home Education Association events (verify).
- **Partners:** curriculum co-ops and hybrid microschools (F06) that already sit next to associations, and SC-TOP-style larger associations as reference customers.

## Risks and incumbent moats
- **Tiny beachhead (81 buyers).** *Mitigation:* the B2B2C route to thousands of families feeds P03, and the product ships as a mode of P03 rather than a separate codebase. Tennessee and other umbrella models follow.
- **Free-tool inertia.** Many directors are volunteers on Google Forms. *Mitigation:* a free tier, a one-click roster import, and a letter generator that saves hours in the first week.
- **Legal accuracy.** Association duties and parent duties differ, and the statute says parents keep records. *Mitigation:* show only attestations by default, link every rule to the statute and SCDE page with a "last verified" date, and say plainly that this isn't legal advice.
- **Child data.** Accounts are parent-owned with a data processing agreement (DPA) for the association. There's no child login in the MVP, which keeps COPPA exposure low (same approach as P03).
- **Incumbents:** Homeschool-life (group sites) and custom association websites. Neither generates the semiannual report from daily logs.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 3 | 3 | 5 | 4 | 2 | **17** |

Market size is 1 for South Carolina alone. It's raised to 2 for the B2B2C family reach and the Tennessee umbrella-school expansion (both estimates).

## Sources
- [SCDE: Home School Option 3, 2026–27 association list (81 associations; Annual Standards Assurance form)](https://ed.sc.gov/districts-schools/state-accountability/home-schooling/home-school-option-3/)
- [S.C. Code Title 59 Chapter 65 (§§59-65-40, -45, -47)](https://www.scstatehouse.gov/code/t59c065.php)
- [Homeschool Start Guide: SC Option 3 accountability association, how to choose one (Feb 4 2026)](https://homeschoolstartguide.com/blog/south-carolina-option-3-accountability-association)
- [Hometown Homeschool Association of SC: FAQs](https://www.hometownhasc.com/faqs/)
- [SC-TOP (SC Third Option Participants): fees and services](https://sc-top.org/)
- [EdChoice: SC Education Scholarship Trust Fund](https://www.edchoice.org/school-choice/programs/south-carolina-education-scholarship-trust-fund-program/)
- [TN DOE: Home schooling in Tennessee (Category IV church-related umbrella schools)](https://www.tn.gov/education/families/school-options/home-schooling-in-tn.html)
- [JHU Homeschool Hub: homeschool growth 2024–25 (via P03)](https://education.jhu.edu/edpolicy/policy-research-initiatives/homeschool-hub/homeschool-growth-2024-2025/)
- [Homeschool-life pricing (via P03)](https://www.homeschool-life.com/pricing)
- [homeschoolingsc.org: Homeschool Associations Directory (search result, not fetched)](https://www.homeschoolingsc.org/resources-page/homeschool-associations/)
- Internal: ideas P03 (HomeRoll), P07, F06; states/SC-south-carolina.md, states/TN-tennessee.md
