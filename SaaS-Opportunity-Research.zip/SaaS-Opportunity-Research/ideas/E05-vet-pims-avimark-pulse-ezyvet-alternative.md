# Tailwag PIMS: a cheaper, simpler Covetrus Pulse / AVImark / ezyVet for independent vet clinics

**One-liner:** A cloud veterinary practice-management system for independent 1–4 DVM clinics, built around a free migration off AVImark and Pulse. It includes one-click estimate-to-invoice, an AI exam-room scribe, a controlled-drug log, and built-in reminders and booking that replace PetDesk-style add-ons.

## Snapshot
- **Replaces:**
  - **Covetrus Pulse:** no public pricing; about **$300–$500/mo** estimated (PawChart blog, unofficial).
  - **Covetrus AVImark:** legacy on-premise PIMS. Covetrus is pushing customers to Pulse.
  - **ezyVet (IDEXX):** no pricing in reviews and not verified in this pass.
  - **Shepherd, Vetspire, PetDesk** (client comms add-on): pricing not verified in this pass.
- **Recent price hikes / changes:**
  - **AVImark "sunset" signals.** Covetrus has **not** published an official end-of-life date. A competitor blog cites slower feature development, reduced support staffing, and active pushing of Pulse, along with Reddit comments from Mar–Sep 2025 ([PawChart](https://pawchart.io/blog/avimark-being-sunset-what-are-your-options/)). This is inference, not an announcement.
  - A Pulse customer reports that a **3-year price lock "was no longer honored after the first year"** without notice (Capterra, Mar 2025).
  - Covetrus has been private-equity owned since a 2022 take-private by CD&R and TPG (from memory, not re-verified in this pass). ezyVet is owned by IDEXX.
- **Who buys:** Independent small-animal general practices with 1–4 DVMs. The buyer is the owner DVM, with the practice manager as champion.
- **US market size:** Our estimate is about 30k US veterinary practices (AVMA-derived, not verified in this pass). Corporate and PE-owned clinics are locked into group PIMS, so the target is the independent share, which is still large but shrinking (estimate).
- **Urgency trigger (why they'd switch NOW):** AVImark users face a forced "cloud decision" as Covetrus steers them to Pulse. Pulse customers report broken price locks and migration pain. Switching once is the moment to compare.
- **Fastest-selling states/metros:** Estimate: large pet-owning states with many independents (TX, CA, FL, NC, GA, OH, PA). Target AVImark-heavy regions once identified (not known in this pass).

## Pain points (evidence)
- **[Price / Lock-in]** A 3-year price lock wasn't honored after year one, and the client wasn't told (Capterra, Mar 2025) ([Capterra, Covetrus Pulse](https://www.capterra.com/p/130107/Covetrus-Pulse/reviews/)).
- **[Complexity/UX]** A veterinarian at a 51–200 employee practice says Pulse's interface is extremely slow, with long waits for basic functions (Capterra, 2+ years' use) ([Capterra](https://www.capterra.com/p/130107/Covetrus-Pulse/reviews/)).
- **[Missing features]** Patient search and prescription functions broke after an update (Capterra, Apr 2026) ([Capterra](https://www.capterra.com/p/130107/Covetrus-Pulse/reviews/)).
- **[Lock-in / migration]** Data migrated from Cornerstone landed in the wrong categories and staff records were mislabeled (Capterra) ([Capterra](https://www.capterra.com/p/130107/Covetrus-Pulse/reviews/)).
- **[Support]** A practice manager says onboarding training was lacking and single tasks take multiple steps (Capterra, Feb 2026). Another reviewer got under 2 hours of training and no on-site help (Capterra, Oct 2023) ([Capterra](https://www.capterra.com/p/130107/Covetrus-Pulse/reviews/)).
- **[Missing features]** The boarding module can't select multiple pets at once and is very time-consuming (Capterra, Oct 2024) ([Capterra](https://www.capterra.com/p/130107/Covetrus-Pulse/reviews/)).
- **[Missing features]** Reports frequently time out (Capterra, Sep 2023) ([Capterra](https://www.capterra.com/p/130107/Covetrus-Pulse/reviews/)).
- **[Complexity/UX]** ezyVet has no way to turn estimates into invoices digitally, so staff re-key them and make errors (Capterra, Jan 2026) ([Capterra, ezyVet](https://capterra.com/p/99977/ezyVet-Cloud-Vet-Software/reviews/)).
- **[Complexity/UX]** ezyVet is "clunky", with too many tabs and confusing terminology (Capterra, Jan–Feb 2026, 2–10 employee clinics) ([Capterra](https://capterra.com/p/99977/ezyVet-Cloud-Vet-Software/reviews/)).
- **[Price]** An ezyVet practice owner says per-text costs add up fast (Capterra, Jul 2020) ([Capterra](https://capterra.com/p/99977/ezyVet-Cloud-Vet-Software/reviews/)).
- **[Support]** AVImark users on Reddit say Covetrus isn't investing in AVImark anymore and is pushing everyone to cloud, as quoted by a competitor blog in 2025 ([PawChart](https://pawchart.io/blog/avimark-being-sunset-what-are-your-options/)).

## What we build (the better version)
1. **MVP:** **Migration-first onboarding.** Import clients, patients, vaccine and reminder history, and invoices from AVImark/Pulse/Cornerstone report exports. We run it for free.
2. **MVP:** An appointment book, online booking, and **vaccine and wellness reminders by SMS and email included**, which replaces the need for a separate client-comms subscription.
3. **MVP:** SOAP medical records with an **AI exam-room scribe** and wellness, sick, dental and surgery templates.
4. **MVP:** **Estimate to client approval (text link with deposit) to invoice in one click**, fixing the ezyVet complaint.
5. **MVP:** Invoicing and POS through Stripe Terminal, payment plans, and wellness-plan autopay.
6. **MVP:** A **controlled-drug log** designed to support DEA record-keeping: bottle-level running balances, witness sign-off, and discrepancy alerts.
7. **MVP:** Basic inventory with reorder points.
8. **V2:** Boarding and grooming with multi-pet booking (fixing the Pulse complaint) and kennel maps.
9. **V2:** Reference-lab and in-house analyzer integrations (IDEXX, Antech, Zoetis), a DICOM imaging viewer, and online pharmacy/store integration.
10. **V2:** State PDMP reporting where vets must report, multi-location support, and AI discharge instructions for clients.

## Pricing to win
- **$199/mo per clinic, including 3 DVMs; $49 per additional DVM.** Unlimited staff, reminders and 2-way texting included (SMS at cost above a large bundle), free migration, month-to-month.
- **Savings:** Against Pulse's estimated $300–$500/mo, a clinic **saves about $1,200–$3,600/yr** and stops paying for a separate reminders/texting vendor.

## Go-to-market (first 100 customers)
- **Communities:** r/veterinaryprofession and r/VetTech. Post an "AVImark to cloud: migration guide" and answer questions.
- **Practice managers:** VHMA (Veterinary Hospital Managers Association) and practice-manager Facebook groups.
- **State VMAs:** e.g., TVMA (Texas), CVMA (California), FVMA (Florida). Pursue exhibitor booths and CE sponsorships.
- **Conferences:** VMX (Orlando, January) and WVC (Las Vegas, late winter). Run a "Switch from AVImark" booth demo with a free data-extraction test.
- **Partners:** Independent-practice consultants and vet buying groups (verify names). Use practice brokers and appraisers as a warm channel to independents.
- **SEO:** "AVImark end of life", "AVImark alternative", "Covetrus Pulse price increase", "ezyVet vs".

## Risks and incumbent moats
- **PIMS depth:** Labs, imaging, pharmacy and inventory make this a heavy build. Ship a focused general-practice MVP and integrate labs in V2.
- **Vertical lock-in:** IDEXX owns ezyVet and Covetrus owns distribution, so lab and pharmacy integrations may be slow or political.
- **Migration from AVImark's local database:** Offer a hands-on extraction service.
- **Consolidation:** PE-owned clinics are off-limits, so focus on independents and "de-consolidating" owners.
- **HIPAA/BAA:** **HIPAA does not apply to animal medical records**, which is a major build-cost advantage. What does apply:
  - State veterinary record-confidentiality statutes (flag for the per-state pass).
  - DEA controlled-substance record-keeping.
  - PCI, handled through Stripe.
  - Standard security: MFA, encryption, backups.
  - No BAA stack is needed, which cuts infrastructure to standard cloud costs.

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| 4 | 3 | 2 | 3 | 3 | **15** |

## Sources
- [Avimark Is Being Sunset: What Are Your Options in 2026?, PawChart (competitor blog; no official EOL)](https://pawchart.io/blog/avimark-being-sunset-what-are-your-options/)
- [Covetrus Pulse reviews, Capterra](https://www.capterra.com/p/130107/Covetrus-Pulse/reviews/)
- [ezyVet reviews, Capterra](https://capterra.com/p/99977/ezyVet-Cloud-Vet-Software/reviews/)
- [Avimark vs Covetrus Pulse comparison, PupPilot](https://www.puppilot.co/resources/compare-pims/avimark-vs-covetrus-pulse)
- [Pulse Support, Covetrus](https://covetrus.com/support/pulse/)
