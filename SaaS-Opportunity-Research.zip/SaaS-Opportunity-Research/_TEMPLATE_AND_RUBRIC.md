# How every idea file is written

Goal: find US subscription platforms that have grown bloated, complex, or more expensive, pull out the real pain their customers feel, and spec a cheaper, better, AI-built replacement we can sell fast.

## File naming
`ideas/<AgentLetter><NN>-<short-slug>.md`, for example `ideas/A01-forms-typeform-jotform-alternative.md`

## Idea file template (use these exact headings)

```
# <Working product name>: a cheaper, better <Incumbent(s)> for <who>

**One-liner:** <what it is, in one sentence>

## Snapshot
- **Replaces:** <incumbents + their current list prices (tier names, $/mo), with dated sources>
- **Recent price hikes / changes:** <what changed, when, by how much. Include acquisitions, sunsets, forced migrations, fee changes, lawsuits>
- **Who buys:** <business type, size, buyer role>
- **US market size:** <# of US businesses/orgs in the segment + source; note when it's an estimate>
- **Urgency trigger (why they'd switch NOW):** <price hike date, sunset date, new law deadline, breach, etc.>
- **Fastest-selling states/metros:** <where the buyers cluster or where a state law forces demand>

## Pain points (evidence)
Aim for 6–12 bullets. Each is a real complaint paraphrased from reviews (G2, Capterra, Trustpilot, BBB, Reddit, forums, news) with a link. Group them: Price, Complexity/UX, Lock-in/Contracts, Support, Missing features.
- **[Price]** <paraphrase> ([source](url))

## What we build (the better version)
A numbered feature list in the spirit of this example ("fun way to submit forms, works 360, emails you, has everything Google has, custom themes, subdomains per vendor, analytics like total users, bulk responses, demographics"):
1. ...
Mark which features are **MVP** (can ship in 2–4 weeks with AI-assisted dev) vs **V2**.

## Pricing to win
<our price vs theirs. Flat, transparent, no per-seat traps, no annual lock-in, free migration. Show the savings for a typical customer.>

## Go-to-market (first 100 customers)
<exact channels: subreddits, Facebook groups, trade associations, conferences, marketplaces, directories, cold-email lists, partner/referral angles, "switch from X" SEO pages>

## Risks and incumbent moats
<data lock-in, integrations, compliance (HIPAA, PCI, SOC2), payments dependency, network effects. How we get around each one.>

## Scores (1–5, 5 = best for us)
| Pain | Price gap | Build ease | Sales speed | Market size | **Total /25** |
|---|---|---|---|---|---|
| x | x | x | x | x | **xx** |

## Sources
- [Title](url)
```

## Scoring rubric
- **Pain (1–5):** how loud and frequent the complaints are (5 = widespread anger, public threads, churn talk).
- **Price gap (1–5):** how far we can undercut while keeping healthy margins (5 = incumbent 3x+ our cost basis, or hidden fees/lock-in).
- **Build ease (1–5):** how fast AI-assisted dev can ship a credible MVP (5 = CRUD + forms + notifications in 2–4 weeks; 1 = needs deep integrations, certifications, hardware, or a regulated data network).
- **Sales speed (1–5):** how fast buyers decide (5 = owner-operator buys with a credit card, clear urgency trigger; 1 = long RFPs, committees).
- **Market size (1–5):** count of US buyers × willingness to pay (5 = 500k+ businesses or a large dollar pool).

## Rules for researchers
- Use 2025–2026 sources wherever possible (today is Sept 2026). Give a date for every price.
- Never invent quotes, numbers, or sources. Paraphrase complaints and link them. Label estimates as estimates.
- Look hard for **switching windows**: price hikes, acquisitions (PE roll-ups), product sunsets, forced migrations, breaches, lawsuits or FTC actions, and state or federal law deadlines. These sell fastest.
- Favor owner-operated SMB segments that can buy with a card over enterprise segments that need RFPs.
